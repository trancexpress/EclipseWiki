[Agenda Zeitplan Protokoll
Teilnehmer](Media:151028_Herstellerworkshop_Protokoll.pdf "wikilink")

[Stand openKONSEQUENZ Steering
Committee](Media:151028oKSCPH.pdf "wikilink")

[Lead Buyer](Media:151028LeadBuyerGP.pdf "wikilink")

[BTC: Architektur, CIM und Pilot](Media:151028BTC3MRFK.pdf "wikilink")

[Spezifikation
Schaltantragsverwaltung](Media:Spezifikation_für_das_modul_Schaltantragsverwaltung_15_09_28.pdf "wikilink")

[Spezifikation
Betriebstagebuch](Media:Spezifikation_für_das_Modul_Betriebstagebuch_150929.pdf "wikilink")