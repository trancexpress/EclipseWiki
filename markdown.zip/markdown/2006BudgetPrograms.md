We're currently going through the process of creating an Eclipse
Foundation budget for next year. A major part of this process is
deciding what programs we want to support.

I would like to get community feedback on the programs we're currently
thinking about. Better yet, I would love to get some ideas for programs
that we <span style="font-style:italic;">haven't</span> thought about.

So here's what we're thinking. For simplicity, I've lumped them into two
categories: (a) those for the committers and projects and (b) those for
the membership and ecosystem. The latter category would be traditionally
thought of as "marketing."

To be clear, there is no way we have the resources to do all of these,
so feedback on prioritization would be helpful as well.

So in no particular order, here we go:

<strong>Projects and Committers</strong>

  - Facilitate project-oriented (e.g. CDT) and topic-oriented (e.g.
    multi-language support) technical symposiums.
  - Upon request, help facilitate project meetings. In particular,
    provide the necessary support for virtual and face-to-face Callisto
    release train coordination meetings beyond the scope of the council
    meetings if required.
  - Invite new project members to committer meetings and code camps to
    help them get started. Investigate the possibility of running new
    distinct events for new projects at pre-determinted locations. (We
    cannot scale enough to travel out to each new project to help them
    get started; they will need to come to us.)
    In addition, look at ways to better mentor new and/or struggling
    projects from EMO and community resources.
  - Continue to evolve and improve the development tools made available
    to the projects. Examples include:
      - Project dashboards to provide rapid public feedback about
        important 'project heath' metrics. Define/use additional metrics
        for: community development, API/app quality, strategic
        importance of technology area addressed by project.
      - Investigate the possibility of building additional features into
        Bugzilla.
      - better collaboration tools (wikis, IM, ...)
      - investigate how to improve committer productivity around areas
        such as bug triage.
  - [Bjorn and Ward](http://eclipse-projects.blogspot.com/) want to
    write articles on “The Eclipse Way” on best practices for
    development and process for Eclipse projects. Collaboration from as
    many committers as possible will be gratefully accepted. The primary
    intent here is to promote best practice development processes
    consisently across all projects.
  - Continue to invest in improving and streamlining the approvals
    process for contributions to projects.
  - Schedule committer meetings at least once per quarter in various
    locales where we pull together people from a number of projects in a
    particular city. Location choices include Boston, Ottawa, San
    Francisco, Toronto, Portland. The Foundation would send someone to
    attend and facilitate, and pay for the meeting room (if needed) and
    pizza, etc.
  - Committer code camps. Wherever possible, the code camps will be
    combined with the Committer Meetings to create a single, multi-day
    event.
  - Committer community development: Led by Ward Cunningham, put effort
    into creating a cohesive and collaborative Eclipse committer
    community across all the projects.

<strong>Members and Ecosystem</strong>

  - Have a stock of Eclipse logoware. (We don't right now, and it's a
    drag sometimes.)
  - Provide an Eclipse community portal for plug-ins with a focus on
    driving value for plug-in providers via the eclipse.org website.
    Spend some funds on advertising to drive demand to the portal.
  - In conjunction with interested members, develop and execute a series
    of seminars in North America targeted at growing awareness within
    the user developer community.
    This program may also include user code camps, plug-in fests, etc.
  - In conjunction with interested members, develop and execute a series
    of webinars focused on Java and embedded topic areas.
  - Develop and execute a series of developer-focused contests targeted
    at growing awareness within the user developer community. For one
    example of such a contest, see the [MySQL 5.0
    contest](http://dev.mysql.com/mysql_5_contest.html).
  - Develop customer success case studies which illustrate the
    successful adoption of commercial products based on Eclipse
    technology. The commercial products selected will be from member
    companies.
  - Continue to look for, and where appropriate fund, the development of
    quality Eclipse technical content. This will include translations
    from articles in other languages (e.g. German).
  - Raise the profile of the Eclipse Foundation in Europe.
  - Jointly fund on-going market research on the growth of the Eclipse
    installed base and ecosystem.
  - Arrange for booths and staffing for members to exhibit at events
    such as JavaOne, LinuxWorld and Embedded Systems. Ensure that the
    Eclipse Foundation has a presence at open source events such as
    OSCON.
  - Arrange for at least two marketing symposiums for the Eclipse
    Membership in 2006. (One in North America, one in Europe.)
  - Develop common Eclipse marketing collateral for use by all member
    companies.
  - Develop case studies which illustrate how member companies have
    achieved commercial success by their participation with Eclipse.
  - Develop public collateral documents illustrating the various
    business models successfully applied by member companies.
  - Devise and execute a program inspired by the “Google Summer of Code”
    and/or the existing “Eclipse Innovation Grants” targeted at raising
    the profile of Eclipse within the open source development community.