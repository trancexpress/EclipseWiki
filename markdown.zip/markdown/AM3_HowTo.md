This is the [AM3](AM3 "wikilink") wiki How to. __TOC__

## Installing TGE from source for editing KM3 and TCS files

  - Checkout the plugin `org.eclipse.gmt/AM3/org.eclipse.am3.tools.tge`
    from the `:pserver:anonymous@dev.eclipse.org:/cvsroot/technology`
    repository and its dependencies.
  - Build the plugin and install it.
  - Associate the KM3 and TCS files to TGE in "Windows -\> Preferences
    -\> Editor -\> File Associations".

[Category:AM3](Category:AM3 "wikilink")