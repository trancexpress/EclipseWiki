This page lists papers related to ATL. Some articles describe the
language itself while other describe various applications.

## 2011

  - [\[Wagelaar2011](http://soft.vub.ac.be/Publications/2011/vub-soft-tr-11-07.pdf)\]
    Dennis Wagelaar, Massimo Tisi, Jordi Cabot, Frédéric Jouault.
    Towards a general composition semantics for rule-based model
    transformation. In *Proceedings of the ACM/IEEE 14th International
    Conference on Model Driven Engineering Languages and Systems
    ([MoDELS 2011](http://ecs.victoria.ac.nz/Events/MODELS2011/))*, LNCS
    6981, pp.623 - 637. [Presentation on
    Youtube](http://youtu.be/-P9vgTtPVzg)

<!-- end list -->

  - [\[Planas2011](http://ceur-ws.org/Vol-742/mtatl2011_submission_1.pdf)\]
    Elena Planas, Jordi Cabot, Cristina Gómez. Two Basic Correctness
    Properties for ATL Transformations: Executability and Coverage. In
    *Proceedings of the 3rd International Workshop on Model
    Transformation with ATL
    ([MtATL 2011](http://www.emn.fr/z-info/atlanmod/index.php/MtATL2011))*,
    pp.1 - 9.

<!-- end list -->

  - [\[Cuadrado2011](http://ceur-ws.org/Vol-742/mtatl2011_submission_2.pdf)\]
    Jesús Sánchez Cuadrado, Jesús Perera Aracil. Compiling ATL with
    Continuations. In *Proceedings of the 3rd International Workshop on
    Model Transformation with ATL
    ([MtATL 2011](http://www.emn.fr/z-info/atlanmod/index.php/MtATL2011))*,
    pp.10 - 19.

<!-- end list -->

  - [\[Amstel2011](http://ceur-ws.org/Vol-742/mtatl2011_submission_3.pdf)\]
    M.F. van Amstel, M.G.J. van den Brand. Using Metrics for Assessing
    the Quality of ATL Model Transformations. In *Proceedings of the 3rd
    International Workshop on Model Transformation with ATL
    ([MtATL 2011](http://www.emn.fr/z-info/atlanmod/index.php/MtATL2011))*,
    pp.20 - 34.

<!-- end list -->

  - [\[Jimenez2011](http://ceur-ws.org/Vol-742/mtatl2011_submission_4.pdf)\]
    Álvaro Jiménez, David Granada, Verónica Bollati, Juan M. Vara. Using
    ATL to Support Model-Driven Development of RubyTL Model
    Transformations. In *Proceedings of the 3rd International Workshop
    on Model Transformation with ATL
    ([MtATL 2011](http://www.emn.fr/z-info/atlanmod/index.php/MtATL2011))*,
    pp.35 - 48.

<!-- end list -->

  - [\[Randak2011](http://ceur-ws.org/Vol-742/mtatl2011_submission_5.pdf)\]
    Andrea Randak, Salvador Martínez, Manuel Wimmer. Extending ATL for
    Native UML Profile Support: An Experience Report. In *Proceedings of
    the 3rd International Workshop on Model Transformation with ATL
    ([MtATL 2011](http://www.emn.fr/z-info/atlanmod/index.php/MtATL2011))*,
    pp.49 - 62.

<!-- end list -->

  - [\[Wagelaar2011a](http://ceur-ws.org/Vol-742/mtatl2011_submission_6.pdf)\]
    Dennis Wagelaar. A Revised Semantics for Rule Inheritance and Module
    Superimposition in ATL. In *Proceedings of the 3rd International
    Workshop on Model Transformation with ATL
    ([MtATL 2011](http://www.emn.fr/z-info/atlanmod/index.php/MtATL2011))*,
    pp.63 - 74.

<!-- end list -->

  - [\[Vieira2011](http://ceur-ws.org/Vol-742/mtatl2011_submission_7.pdf)\]
    Andreza Vieira, Franklin Ramalho. A Static Analyzer for Model
    Transformations. In *Proceedings of the 3rd International Workshop
    on Model Transformation with ATL
    ([MtATL 2011](http://www.emn.fr/z-info/atlanmod/index.php/MtATL2011))*,
    pp.75 - 88.

<!-- end list -->

  - [\[Khadka2011](http://ceur-ws.org/Vol-742/mtatl2011_submission_8.pdf)\]
    Ravi Khadka, Brahmananda Sapkota, Luís Ferreira Pires, Marten van
    Sinderen, Slinger Jansen. WSCDL to WSBPEL: a Case Study of ATL-based
    Transformation. In *Proceedings of the 3rd International Workshop on
    Model Transformation with ATL
    ([MtATL 2011](http://www.emn.fr/z-info/atlanmod/index.php/MtATL2011))*,
    pp.89 - 103.

## 2009

  - [\[Wagelaar2009](http://www.springerlink.com/content/k46004716659657t/)\]
    Dennis Wagelaar, Ragnhild Van Der Straeten and Dirk Deridder. Module
    superimposition: a composition technique for rule-based model
    transformation languages. Software and Systems Modeling, Online
    First, 15 October, 2009. © Springer-Verlag.

<!-- end list -->

  - [\[Yie2009a](http://www.springerlink.com/content/367u8051657hx672)\]
    Andrés Yie, Rubby Casallas, Dirk Deridder and Dennis Wagelaar. An
    Approach for Evolving Transformation Chains. In *Proceedings of the
    12th International Conference on Model Driven Engineering Languages
    and Systems (MoDELS 2009)*, Denver, CO, USA, October 4-9, 2009. LNCS
    5795, pp. 551-555. © Springer-Verlag.

<!-- end list -->

  - [\[Yie2009](http://docatlanmod.emn.fr/MtATL2009Presentations/PreliminaryProceedings.pdf)\]
    Andrés Yie and Dennis Wagelaar. Advanced Traceability for ATL. In
    *Proceedings of the 1st International Workshop on Model
    Transformation with ATL (MtATL 2009)*, Nantes, France, July 8-9,
    2009. pp. 78-87.

## 2008

  - [\[Chenouard2008](http://homepage-of-raphael-chenouard.servhome.org/spip.php?rubrique9)\]
    Raphaël Chenouard, Laurent Granvilliers, and Ricardo Soto.
    Model-Driven Constraint Programming. In *PPDP'2008, 10th
    International ACM SIGPLAN Conference on Principles and Practice of
    Declarative Programming*, Valence, Spain. July 15-17, 2008.

<!-- end list -->

  - [\[Wagelaar2008](http://ssel.vub.ac.be/Members/DennisWagelaar/docs/WagelaarATLcomposition.pdf)\]
    Dennis Wagelaar. Composition Techniques for Rule-based Model
    Transformation Languages. In *Proceedings of the First International
    Conference on Theory and Practice of Model Transformations (ICMT
    2008)*, Zürich, Switzerland, July 1-2, 2008. LNCS 5063, pp.152-167.
    © Springer-Verlag.

## 2007

  - [\[Wagelaar2007](http://ssel.vub.ac.be/Members/DennisWagelaar/docs/WagelaarVanDerStraetenEJIS2006.pdf)\]
    Dennis Wagelaar and Ragnhild Van Der Straeten. Platform Ontologies
    for the Model-Driven Architecture. European Journal of Information
    Systems 4(16), pp. 362-373. © Palgrave-Macmillan.

<!-- end list -->

  - [\[Lukichev2007a](http://rewerse.net/publications/)\] Sergey
    Lukichev, Adrian Giurca, Gerd Wagner, Dragan Gasevic and Marko
    Ribaric , "Using UML-based Rules for Web Services Modeling", In
    Proceedings of the Second International Workshop on Services
    Engineering, Istanbul, Turkey, 2007. pp. 290–298.

<!-- end list -->

  - [\[Stankovic07a](http://www.doc.ic.ac.uk/crg/events/ARW07/submissions/Stankovic.pdf)\]
    Bosco Stankovic, Nenad Krdzavac, Vladan Devedzic : An Universal GUI
    for Theorem Provers. ARW'07

<!-- end list -->

  - [\[Graaf07a](http://www.st.ewi.tudelft.nl/~basgraaf/publications/JSS2007.pdf)\]
    Bas Graaf, Sven Weber, and Arie van Deursen: Model-Driven Migration
    of Supervisory Machine Control Architectures. In: Journal of Systems
    and Software. © Elsevier 2007. Accepted for publication.

<!-- end list -->

  - [\[Graaf07b](http://www.st.ewi.tudelft.nl/~basgraaf/publications/MOMPES2007.pdf)\]
    Bas Graaf and Arie van Deursen: Model-Driven Consistency Checking of
    Behavioural Specifications. In: Proceedings of MOMPES 2007, Fourth
    International Workshop on Model-based Methodologies for Pervasive
    and Embedded Software, Braga, Portugal, March 2007, pages 115--126.
    © IEEE Computer Society 2007.

<!-- end list -->

  - [\[Graaf2007c](http://www.st.ewi.tudelft.nl/~basgraaf/publications/ECBS2007.pdf)\]
    Bas Graaf and Arie van Deursen: Visualisation of Domain-Specific
    Modelling Languages Using UML. In: Proceedings of ECBS 2007, 14th
    Annual IEEE International Conference and Workshop on the Engineering
    of Computer Based Systems, Tucson, AZ, USA, March 2007, pages
    586--595. © IEEE Computer Society 2007.

<!-- end list -->

  - [\[Milanovic2007a](http://swese2007.fzi.de/papers/02.Model_Transformations.pdf)\]
    Milanović, M., Gašević, D., Giurca, A., Wagner, G., Devedžić, V.,
    Model Transformations to Share Rules between SWRL and R2ML, 3rd
    International Workshop on Semantic Web Enabled Software Engineering
    (SWESE 2007), Innsbruck, Austria, 2007. (Best paper award).

<!-- end list -->

  - [\[Milanovic2007b](http://dx.doi.org/10.1007/978-3-540-72982-2_25)\]
    Milanović, M., Gašević, D., Giurca, A., Wagner, G., Lukichevm S.,
    Devedžić, V., Bridging Concrete and Abstract Syntax of Web Rule
    Languages, , The First International Conference on Web Reasoning and
    Rule Systems (RR2007),Innsbruck, Austria, 2007. (Lecture Notes in
    Computer Science, Vol. 4524, Springer), pp. 309-318.

<!-- end list -->

  - [\[Strommer2007a](http://www.wit.at/people/murzek/publications/Strommer_Murzek_Wimmer_ER07.pdf)\]
    M.Strommer, M.Murzek, M.Wimmer: Applying Model Transformation
    By-Example on Business Process Modeling Languages Accepted at the
    3rd International Workshop on Foundations and Practices of UML at
    the 26the International Conference on Conceptual Modelling, ER 2007,
    Auckland, New Zealand, November 2007.

<!-- end list -->

  - [\[Friske2007a](http://swt.cs.tu-berlin.de/~mario/2007_MBEES_FriskeSchlingloff_Generierung_von_UML-Modellen.pdf)\]
    Mario Friske, Holger Schlingloff: Generierung von UML-Modellen aus
    formalisierten Anwendungsfallbeschreibungen; In: M. Conrad, H.
    Giese, B. Rumpe, B. Schätz (Eds.): MBEES - Model Based Engineering
    of Embedded Systems III, Dagstuhl-Workshop, TU Braunschweig Report
    TUBS-SSE 2007-01, January 2007

<!-- end list -->

  - [1](http://big.tuwien.ac.at/research/publications/2007/0907.pdf%5BMurzek2007a%5D)
    Marion Murzek & Gerhard Kramler Business Model Transformation Issues
    : The top 7 adversaries encountered at defining model
    transformations. <b>Abstract:</b> <i>Not least due to the widespread
    use of meta modeling concepts, model transformation techniques have
    reached a certain level of maturity (Czarnecki and Helsen, 2006).
    Nevertheless, defining transformations in some application areas in
    our case business process modeling is still a challenge because
    current transformation languages provide general solutions but do
    not support issues specific to a distinct area. We aim at providing
    generic solutions for model transformation problems distinct to the
    area of horizontal business process model transformations. As a
    first step in this endeavor, this work reports on the most pressing
    problems encountered at defining business process model
    transformations.</i>

<!-- end list -->

  - [\[Benguria2007a](http://doi.ieeecomputersociety.org/10.1109/ICCBSS.2007.12)\]
    Gorka Benguria, Xabier Larrucea, Data Model Transformation for
    Supporting Interoperability, Sixth International IEEE Conference on
    Commercial-off-the-Shelf (COTS)-Based Software Systems
    (ICCBSS'07)pp. 172-181 <b>Abstract </b> <i>One of the main barriers
    for interoperability today, is the proliferation of different
    standards and proprietary formats for the exchange of information
    among the organizations willing to interoperate. But how can the
    different standards

## 2006

  - [2](http://www.eclipse.org/gmt/oaw/doc/4.0/t45_atlExample.pdf%5BVoelter2006a%5D)
    Markus Voelter, Using ATL with oAW and EMF, oAW document.

<!-- end list -->

  - [3](http://eceasst.cs.tu-berlin.de/index.php/eceasst/article/viewFile/18/9%5BWillink2006a%5D)
    Ed Willink, Model Instantiation and Type Checking in UMLX,
    Gramot'2006, Electronic Communications of the EASST, Proceedings of
    the Second International Workshop on Graph and Model Transformation
    (GraMoT 2006). <b>Abstract: </b> <i>OMG's MDA initiative encourages
    the use of meta-model based transformations and re-usable
    specifications. We discuss how Graphical Transformation Notations
    such as UMLX reduce opportunities for errors in this programming
    domain. </i>

<!-- end list -->

  - [4](http://www.andromda.org/jira/secure/attachment/10744/bohlen_OS_02_06_k4.pdf%5BBohlen2006a%5D)
    Matthias Bohlen QVT UND MULTI-METAMODELLTRANSFORMATIONEN IN MDA,
    www.mbohlen.de/downloads/os2006

<!-- end list -->

  - [\[SAC06a](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/SAC06a)\]
    Jouault, F, and Kurtev, I : On the Architectural Alignment of ATL
    and QVT. In: Proceedings of ACM Symposium on Applied Computing (SAC
    06), model transformation track, Dijon, Bourgogne, France.

<!-- end list -->

  - [\[SAC06b](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/SAC06b)\]
    Kurtev, I, van den Berg, K, and Jouault, F : Rule-based
    Modularization in Model Transformation Languages illustrated with
    ATL. In: Proceedings of ACM Symposium on Applied Computing (SAC 06),
    model transformation track, Dijon, Bourgogne, France.

<!-- end list -->

  - [5](http://swt.cs.tu-berlin.de/~mario/2006_MOTES_FriskeHilse_Evaluation_von_Transformationsmaschinen.pdf%5BFriske06a%5D)
    Mario Friske, Konrad Hilse: Evaluation von Transformationsmaschinen
    in der modellbasierten Qualitätssicherung; In: C. Hochberger und R.
    Liskowsky (Eds.): Beiträge der 36. Jahrestagung der Gesellschaft für
    Informatik (Band2), Lecture Notes in Informatics (LNI), Band P-94,
    Seiten 205-209, Oktober 2006

<!-- end list -->

  - [6](http://doi.ieeecomputersociety.org/10.1109/SCW.2006.32%5BOrtiz2006a%5D)
    Guadalupe Ortiz, Juan Hernández, Fernando Sánchez, "Model Driven
    Extra-Functional Properties for Web Services," scw, pp. 113-120,
    IEEE Services Computing Workshops (SCW'06), 2006 <b>Abstract:</b>
    <i>Web Services provide our systems with a platform independent and
    loosely coupled distributed computing environment. However, on
    adding extra-functional properties to web services, the loosely
    coupled environment is not always maintained due to dependences
    established between the main functionality service modules and the
    ones from added properties, thus decreasing the application’s
    modularity and flexibility. In order to decouple extra-functional
    properties from services at modeling and implementation stage, we
    propose to use a model driven approach, in which the Platform
    Independent Model (PIM) has been designed by using UML. Then, ATL
    transformation rules have been applied to transform the PIM into the
    Platform Specific Model (PSM), which has been split into three
    specific models, an object, an aspect and a policy based models.
    Finally Java, AspectJ and Ws-Policy code is generated from the
    specific models.</i>

<!-- end list -->

  - [\[koch2006a](http://www.lcc.uma.es/~av/mdwe2006/camera_ready_papers/koch-mdwe-2006-final.pdf)\]
    Nora Koch Transformation Techniques in the Model-Driven Development
    Process of UWE

<!-- end list -->

  - [7](http://www.bmf.hu/conferences/huci2006/48_Angyal.pdf%5BAngyal2006a%5D)
    László Angyal, László Lengyel, Hassan Charaf An Overview of the
    State-of-The-Art Reverse Engineering Techniques Magyar Kutatók 7.
    Nemzetközi Szimpóziuma 7th International Symposium of Hungarian
    Researchers on Computational Intelligence

<!-- end list -->

  - [\[Milanovic2006a](http://st.inf.tu-dresden.de/OCLApps2006/topic/acceptedPapers/04_Gasevic_OnInterchanging.pdf)\]
    Milanović, M., Gašević, D., Giurca, A., Wagner, G., Devedžić, V., On
    Interchanging between OWL/SWRL and UML/OCL, In Proceedings of 6th
    Workshop on OCL for (Meta-)Models in Multiple Application Domains
    (OCLApps) at the 9th ACM/IEEE International Conference on Model
    Driven Engineering Languages and Systems (MoDELS), Genoa, Italy,
    2006., pp. 81-95.

<!-- end list -->

  - [8](http://www.cs.uvic.ca/~chisel/pubs/irbull_cascon06.pdf%5BBull2006a%5D)
    Bull, R. I. 2006. Integrating dynamic views using model driven
    development. In Proceedings of the 2006 Conference of the Center For
    Advanced Studies on Collaborative Research (Toronto, Ontario,
    Canada, October 16 - 19, 2006). CASCON '06. ACM Press, New York, NY,
    17. <b>Abstract:</b> <i>Model Driven Development is helping software
    developers rapidly engineer today's most sophisticated business
    applications. Tool support, such as the Eclipse Modeling Framework
    (EMF) and the newly announced Eclipse Modeling Project, provide a
    variety of support to software engineers. While these tools provide
    assistance during many stages of the software lifecycle, few tools
    exist to help the engineers design, generate and reason about
    complex, data centric user interfaces.This paper describes our Model
    Driven Visualization framework. This framework allows the Model
    Driven Development community to leverage several well established
    information visualization techniques. Using model driven
    development, we have provided a mechanism to rapidly prototype new
    visualizations from an application's data model. To demonstrate this
    approach, we have used this framework to generate a number of new,
    dynamically coordinated views for an EMF model that summarizes
    almost a century of National Hockey League statistics.</i>

## 2005

  - [\[GraMoT05](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/GraMoT05)\]
    Bézivin, J, and Jouault, F : Using ATL for Checking Models. In:
    Proceedings of the International Workshop on Graph and Model
    Transformation (GraMoT), Tallinn, Estonia.

<!-- end list -->

  - [\[GTTSE05](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/GTTSE05_Didonet)\]
    Didonet Del Fabro, M, and Jouault, F : Model Transformation and
    Weaving in the AMMA Platform. In: Pre-proceedings of the Generative
    and Transformational Techniques in Software Engineering (GTTSE'05),
    Workshop. Centro de Ciências e Tecnologias de Computação,
    Departemento de Informatica, Universidade do Minho, Braga, Portugal,
    pages 71--77.

<!-- end list -->

  - [\[MTIP05](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/MTIP05)\]
    Jouault, F, and Kurtev, I : Transforming Models with ATL. In:
    Proceedings of the Model Transformations in Practice Workshop at
    MoDELS 2005, Montego Bay, Jamaica.

<!-- end list -->

  - [\[ECMDA_05](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/ECMDA_05)\]
    Jouault, F : Loosely Coupled Traceability for ATL. In: Proceedings
    of the European Conference on Model Driven Architecture (ECMDA)
    workshop on traceability, Nuremberg, Germany.

<!-- end list -->

  - [9](http://ieeexplore.ieee.org/xpl/freeabs_all.jsp?arnumber=1577183%5BDascalu2005a%5D)
    Dascalu, S.; Ning Hao; Debnath, N. Design patterns automation with
    template library, Signal Processing and Information Technology,
    2005. Proceedings of the Fifth IEEE International Symposium on
    Digital Object Identifier, Volume , Issue , 18-21 Dec. 2005 Page(s):
    699 - 705 10.1109/ISSPIT.2005.1577183 <b>Summary:</b> <i>Design
    patterns offer reusable solutions to particular software design
    problems. Design patterns automation is an approach that applies
    design patterns at the implementation stage of the software
    development life cycle. Inspired by two commonly used template
    libraries, Active Template Library and Standard Template Library,
    and one of the most popular generic programming technologies, C++
    templates, this paper introduces a new method for achieving design
    patterns automation. This method differs from the currently
    available UML-based and wizard-based design patterns automation
    techniques and provides support for increased flexibility,
    expandability and compatibility in developing software using design
    patterns. Seven of the patterns proposed by Gamma et al. have been
    implemented using C++ templates, namely singleton, factory method,
    visitor, memento, strategy, iterator, and decorator. To illustrate
    the method proposed, details of singleton and decorator
    implementations are provided and a larger "check" example developed
    using the decorator template is presented. The paper also includes a
    comparison with similar approaches and presents several directions
    of future work.</i>

## 2004

  - [\[AllilaireIdrissi0001](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/AllilaireIdrissi0001)\]
    Allilaire, F, and Idrissi, T : ADT: Eclipse development tools for
    ATL. In: Proceedings of the Second European Workshop on Model Driven
    Architecture (MDA) with an emphasis on Methodologies and
    Transformations (EWMDA-2). Computing Laboratory, University of Kent,
    Canterbury, UK.

<!-- end list -->

  - [\[RR-LINA2004-08](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/RR-LINA2004-08)\]
    Bézivin, J, Jouault, F, and Valduriez, P : An Eclipse-based IDE for
    the ATL model transformation language. Research Report LINA,
    (04.08).

## 2003

  - [\[Bezivin0004](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/Bezivin0004)\]
    Bézivin, J, Dupé, G, Jouault, F, Pitette, G, and Rougui, JE : First
    experiments with the ATL model transformation language: Transforming
    XSLT into XQuery. In: OOPSLA 2003 Workshop, Anaheim, California.
    2003.

[Category:Modeling](Category:Modeling "wikilink")
[Category:MDD](Category:MDD "wikilink")
[Category:GMT](Category:GMT "wikilink")
[Category:ATL](Category:ATL "wikilink")
[Category:AMMA](Category:AMMA "wikilink")