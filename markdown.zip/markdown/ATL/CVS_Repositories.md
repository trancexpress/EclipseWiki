ATL migrated from the technology project to the m2m project. So did the
source code in the CVS. That is, you will find ATL's sources at two
different repositories, depending on the version.

## Newer Versions

The source code of the **current version** is found at the following CVS
repository location:

  - Host: dev.eclipse.org
  - Path: /cvsroot/modeling
  - Module: org.eclipse.m2m/org.eclipse.m2m.atl/plugins/...

The dots are to replaced with the project you want to check out.

ViewCVS-URL:
[1](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/?root=Modeling_Project)

## Elder Versions

CVS-Settings for elder versions (e.g. source code for **stable release
of February 16, 2007**):

  - Host: dev.eclipse.org
  - Path: /cvsroot/modeling
  - Module: org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/...

The dots are to replaced with the project you want to check out.

View-CVS-URL:
[2](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/?root=Modeling_Project)