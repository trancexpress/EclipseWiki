This page intent to define good coding practices in order to better
manage ATL source code. The use of several tools is detailed here and
will provide a way for ATL commiters and contributors to correctly
contribute to the ATL project.

# Code formatter

The Eclipse code formatter helps to correctly indent and format a .java
file. Basically it is activated by the ctrl+shift+F command. The
formatter is parametrizable, so you must apply the [ATL formatter
specific
configuration](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl/codeStyle/ATLFormatter.xml?hideattic=1&root=Modeling_Project&view=markup).

And here is the way to apply the ATL configuration, in the eclipse
preferences : ![Image:ATL_format_config.PNG](ATL_format_config.PNG
"Image:ATL_format_config.PNG")

# Code templates

The Eclipse code templates helps the developper to automatically write
code parts. In order to keep this in coherence with the code formatter,
you must apply the [ATL templates specific
configuration](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl/codeStyle/ATLCodeTemplates.xml?hideattic=1&root=Modeling_Project&view=markup).

And here is the way to apply the ATL configuration, in the eclipse
preferences : ![Image:ATL_template_config.PNG](ATL_template_config.PNG
"Image:ATL_template_config.PNG")

# Checkstyle

[Checkstyle](http://eclipse-cs.sourceforge.net) is a well known code
analyser which detects all kind of problems in a Java code. It is
activated on the most relevant ATL plugins, here is the [specific
configuration](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl/codeStyle/ATLCheckstyleConfiguration.xml?hideattic=1&root=Modeling_Project&view=markup).