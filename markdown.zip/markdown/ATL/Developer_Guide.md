This documentation aims at contributing to improve the comprehension of
the ATL source code.

# ATL Source Code

## Plug-ins organization

Below is the list of the [ATL
plugins](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/?root=Modeling_Project):

  - **ATL Core**: provides APIs to launch and extend ATL
      - [org.eclipse.m2m.atl.common](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.common/?root=Modeling_Project):
        provide common utilities
      - [org.eclipse.m2m.atl.core](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/?root=Modeling_Project):
        defines the [ATL Core API](#Core "wikilink") (launching, model
        handling)
      - [org.eclipse.m2m.atl.core.emf](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core.emf/?root=Modeling_Project):
        EMF implementation of the Core API
      - [org.eclipse.m2m.atl.core.ui.vm](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core.ui.vm/?root=Modeling_Project):
        defines a wrapper which allow to launch the ATL Regular VM using
        the Core API
      - [org.eclipse.m2m.atl.core.ant](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core.ant/?root=Modeling_Project):
        provides the ATL ant tasks, based on the Core API

<!-- end list -->

  - **ADT** ***(ATL Development Tools)***: Eclipse integration plugins:
      - [org.eclipse.m2m.atl.core.ui](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core.ui/?root=Modeling_Project):
        provides the ATL launch configuration, based on the Core API
      - [org.eclipse.m2m.atl.adt](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.adt/?root=Modeling_Project):
        provides ATL nature and builder
      - [org.eclipse.m2m.atl.adt.ui](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.adt.ui/?root=Modeling_Project):
        provides ATL perspective and wizards (new file, new project)
      - [org.eclipse.m2m.atl.adt.debug](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.adt.debug/?root=Modeling_Project):
        the ATL Regular VM debugger
      - [org.eclipse.m2m.atl.adt.editor](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.adt.editor/?root=Modeling_Project):
        the ATL textual editor

<!-- end list -->

  - **ATL Parser and Compiler**:
      - [org.eclipse.m2m.atl.dsls](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.dsls/?root=Modeling_Project):
        provides the syntaxic/semantic definition of ATL and ACG
      - [org.eclipse.m2m.atl.engine](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine/?root=Modeling_Project):
        provides ATL compiling and parsing utilities

<!-- end list -->

  - **ATL Virtual Machines**:
      - [org.eclipse.m2m.atl.engine.emfvm](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine.emfvm/?root=Modeling_Project):
        the ATL EMF-specific VM
      - [org.eclipse.m2m.atl.engine.vm](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine.vm/?root=Modeling_Project):
        the ATL Regular VM, using model handlers:
          - [org.eclipse.m2m.atl.drivers.emf4atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.drivers.emf4atl/?root=Modeling_Project):
            the ATL Regular VM model handler for EMF
          - [org.eclipse.m2m.atl.drivers.uml24atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.drivers.uml24atl/?root=Modeling_Project):
            the ATL Regular VM model handler for UML2

## External dependencies

Historically, ATL imports two libraries : ANTLR version 2 and MDR. Those
libraries are not authorized in Eclipse because of their non-compliance
with the Eclipse IP policy. Consequently, ATL imposes users to download
those libraries by themselves and install them into Eclipse plugin
folder.

Today, ATL dependencies have been strongly reduced : ATL only needs
ANTLR-runtime (version 3) library, which is compliant with the Eclipse
IP policy and included into ATL source code. The MDR library is only
necessary for the MDR Model Handler. According to the fact that most of
people uses EMF Model Handler (which seems to be more powerful), MDR
Model Handler has been separated into a single feature, which is not
natively required for ATL.

[TCS (Textual Concrete Syntax)](TCS "wikilink"), a tool for parsing and
extraction, is used to generate some ATL components (e.g. ATL-Parser).
Unlike ATL, TCS uses both ANTLR library, in version 2 and newly in
version 3. TCS is available on [GMT](http://www.eclipse.org/gmt/). ATL
doesn't have any dependency with TCS. Specific injectors depend on ANTLR
too.

## Install ATL from CVS

### Import team project set

ATL provides team project sets in order to simplify access to the source
code. You have to download a .psf file on your local disk, and then you
can import projects in Eclipse using : *File-\>Import-\>Team-\>Team
Project Set*

  - [Anonymous access, using pserver to connect on
    CVS](http://dev.eclipse.org/viewcvs/viewvc.cgi/org.eclipse.m2m/org.eclipse.atl/plugins/org.eclipse.m2m.atl/psf/ATL_anonymous.psf?view=markup&root=Modeling_Project)
  - [Commiter access, using extssh to connect on
    CVS](http://dev.eclipse.org/viewcvs/viewvc.cgi/org.eclipse.m2m/org.eclipse.atl/plugins/org.eclipse.m2m.atl/psf/ATL_commiter.psf?view=markup&root=Modeling_Project)

#### ANTLR installation

Note that the download of this plugin is embedded into atl.psf files.
So, if you followed the previous instructions, you don't need to read
the next steps. In Eclipse, antlr is managed by the
[Orbit](http://www.eclipse.org/orbit/) project. To checkout this plugin,
follow those steps :

  - Open an anonymous/commiter CVS connection to `dev.eclipse.org`,
    repository `/cvsroot/tools`
  - Right-click on the repository location, then choose *Refresh
    branches*
  - In the wizard, check the `org.eclipse.orbit` project
  - In the branches, select the one named `v3_0_0`
  - Checkout `org.antlr.runtime`

#### MDR installation (Regular VM only)

Some external libraries are required for the plug-in
org.eclipse.m2m.atl.drivers.mdr4atl but not available on the CVS
repository. You need to download the jar files into the lib/ directory
of this project.

Download mdr-standalone.zip from <http://mdr.netbeans.org/download/> and
put the included jar files into lib/ of plugin
org.eclipse.m2m.atl.drivers.mdr4atl.

Note that mdr-standalone.zip is updated more often on the MDR website
than in our development source. As a consequence, bugs may appear when
using the last-in-date mdr-standalone version of MDR.

When you have finished this operation, there is normally no error left.

WARNING: The MDR model handler is no more maintained, so it may need to
be fixed.

#### Testing

ATL is ready to be tested. There are two ways to use it:

  - In the "Plug-in Development perspective", you can launch a Run-time
    workbench (Click on Run -\> Run as -\> Run-time workbench).
  - You can install ATL in your copy of Eclipse. Go in the Plug-in
    perspective and select all the plug-in projects. In the context menu
    choose Export -\> Deployable Plug-ins and Fragments.

In the screen Export Plug-ins and Fragments, check if all the projects
are selected and choose the output folder.

Now you need to close Eclipse. Enter the "eclipse" directory (which
contains plug-ins and features directories) then copy the created Jar
files into the "plugins" directory. After that you can restart Eclipse.

# ATL Architecture

The ATL architecture consists on:

  - a [Core](#Core "wikilink"), which describes ATL concepts in an
    abstract way
  - a [Parser](#Parser "wikilink") and a
    [Compiler](#Compiler "wikilink")
  - [Virtual Machines](#ATL_Virtual_Machine "wikilink"), allowing to
    execute transformations
  - an IDE: editor, debugger, perspective, all based on previous
    components

The following schema describes ATL components and their role during the
execution of a transformation.

![Image:ATL_compilation_process.JPG](ATL_compilation_process.JPG
"Image:ATL_compilation_process.JPG")

ATL VM is intercalated between the ATL compiler and the used frameworks
(EMF, MDR), allowing modularity. Consequently, changes on ATL Language
only involve ATL compiler.

## Core API

This schema describes the ATL Core API and how it interacts with tools
like LaunchConfigurations, Ant tasks.

![Image:ATL_Core_Architecture.png](ATL_Core_Architecture.png
"Image:ATL_Core_Architecture.png")

  - An
    [IModel](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/src/org/eclipse/m2m/atl/core/IModel.java?root=Modeling_Project&view=markup)
    is an adapted representation of a model, suitable for ATL
    transformations. It provides methods to lookup elements, create new
    ones, etc...
  - The
    [IReferenceModel](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/src/org/eclipse/m2m/atl/core/IReferenceModel.java?root=Modeling_Project&view=markup)
    interface extends the IModel one, and is a specific version of an
    IModel which symbolizes metamodels. It defines metamodel-specific
    operations which are useful for ATL transformations
  - The
    [ModelFactory](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/src/org/eclipse/m2m/atl/core/ModelFactory.java?root=Modeling_Project&view=markup)
    is dedicated for model and reference model creation
  - The
    [IInjector](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/src/org/eclipse/m2m/atl/core/IInjector.java?root=Modeling_Project&view=markup),
    [IExtractor](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/src/org/eclipse/m2m/atl/core/IExtractor.java?root=Modeling_Project&view=markup)
    interfaces provide a way to load and save models previously created
    by the modelFactory
  - The
    [ILauncher](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/src/org/eclipse/m2m/atl/core/launch/ILauncher.java?root=Modeling_Project&view=markup)
    interface is dedicated to be implemented by ATL virtual machines: it
    defines methods to parametrize and launch a transformation

### Services

To simplify the use of ATL Core and reduce code duplication, two
services are provided:
[CoreService](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/src/org/eclipse/m2m/atl/core/service/CoreService.java?root=Modeling_Project&view=markup)
and
[LauncherService](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/src/org/eclipse/m2m/atl/core/service/LauncherService.java?root=Modeling_Project&view=log).

#### CoreService

This utility class provide a way to lookup into eclipse extensions, or
an internal storage, for Core implementations. Those implementations can
be registered into the CoreService for a standalone use. For instance,
here we register the extensions needed to launch a transformation using
EMF-specific VM, in standalone:

`CoreService.registerLauncher(new EMFVMLauncher());`
`CoreService.registerFactory("EMF", EMFModelFactory.class);`
`CoreService.registerExtractor("EMF", new EMFExtractor());`
`CoreService.registerInjector("EMF", new EMFInjector());`

#### LauncherService

The launcher service allows to launch a transformation from a set of
parameters like maps of path and maps of model names: this is strongly
related to launch configurations and ant tasks as it allows to launch
the transformation on any virtual machine.

### EMF interactions

The main implementation of the ATL Core is the EMF one, which is used by
ATL itself for parsing and compilation. It is defined under the
[org.eclipse.m2m.atl.core.emf](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core.emf/?root=Modeling_Project)
plugin.

Here is an explanation about the use ATL EMF-specific
injector/extractor. For both, we use the EMF notation to select
Resources:

| Resource Type        | ATL EMF API Syntax          | Example                                                       |
| -------------------- | --------------------------- | ------------------------------------------------------------- |
| File system Resource | <file:/><path>              | <file:/D:/eclipse/workspace/mmproject/sample_metamodel.ecore> |
| EMF uri              | <uri>                       | <http://www.eclipse.org/uml2/2.1.0/UML>                       |
| pathmap              | pathmap:<path>              | pathmap://PROFILE/sample_profile.uml\#_0                    |
| Workspace Resource   | <platform:/resource/><path> | <platform:/resource/mmproject/sample_metamodel.ecore>         |
| Plug-in Resource     | <platform:/plugin/><path>   | <platform:/plugin/mmproject/sample_metamodel.ecore>           |

Here is an example of usage:

`ModelFactory factory = CoreService.createModelFactory("EMF");`
`IReferenceModel umlMetamodel = factory.newReferenceModel();`
`injector.inject(umlMetamodel, "`<http://www.eclipse.org/uml2/2.1.0/UML>`");`

According to the previous table, you can use another notation to load
the model:

`injector.inject(sampleMetamodel, "`<file:/D:/eclipse/workspace/mmproject/sample_metamodel.ecore>`");`

### Examples of use (run ATL transformations in Java)

  - This very simple
    [RunTransfoJava](https://github.com/101companies/101repo/blob/master/contributions/atl/src/atl/RunTransfoJava.java)
    program shows how to run ATL transformations programmatically,
    including the loading (injection) and saving (extraction) of
    corresponding required metamodels and models.
  - The [ATL launch configuration
    delegate](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core.ui/src/org/eclipse/m2m/atl/core/ui/launch/AtlLaunchConfigurationDelegate.java?root=Modeling_Project&view=markup)
    and the [ATL non-regression
    test](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/tests/org.eclipse.m2m.atl.tests/src/org/eclipse/m2m/atl/tests/unit/TestNonRegressionTransfo.java?root=Modeling_Project&view=markup)
    are examples of launching using the [Launcher
    Service](#LauncherService "wikilink").
  - The public2private example ([UI
    part](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/examples/org.eclipse.m2m.atl.examples.public2private.ui/src/org/eclipse/m2m/atl/examples/public2private/ui/PrivatizeAction.java?root=Modeling_Project&view=markup))
    shows how to directly use the Core

## ATL Virtual Machine

The ATL VM is a [byte code](#ASM_format "wikilink") interpreter which
manages OCL and ATL types hierarchy. A complete ATL VM specification is
available :
[ATL_VMSpecification](http://www.eclipse.org/m2m/atl/doc/ATL_VMSpecification%5Bv00.01%5D.pdf).
This specification consists on a precise description of the ATL VM
functionalities, but doesn't describe the implementation. The intent is
to allow any developer to create an ATL VM in any language. The [Native
Library](http://wiki.eclipse.org/ATL_Standard_Library)
(org.eclipse.m2m.atl.engine.vm.nativelib package) gathers all basic type
definitions used by the ATL VM : OCL types and ATL specific types. Both
are defined at the same level, and use reflexion. OCL appears at several
levels in the ATL architecture :

  - nativelib implementation
  - OCL package in the ATL, ACG and TCS metamodels

The following schema shows the ATL VM working:

![Image:ATL_ASMInterpreter.JPG](ATL_ASMInterpreter.JPG
"Image:ATL_ASMInterpreter.JPG")

During ATL VM initialization, every operations are registered into a
Map. The ExecEnv Class contains the virtual execution environment. It
deals with the operation map which registers all operations used by the
transformation. It contains every information used by a given execution,
like models, and is recreated for each execution. Operations are
executed sequentially, into frames, according to their type. For
instance, in ATL, a call of the append() method is directly mapped to a
call to the corresponding method in the ASMSequence class.

The Frame stores and throws all error messages. The ASMStackFrame is
dedicated to ASM methods, when the StackFrame is dedicated to native
methods. Execution errors come from ATL VM when the method
Frame.printstacktrace is called.

At this time there are two implementations of the ATL VM.

### Regular VM

The Regular VM is the first version of the ATL Virtual Machine. The
implementation is abstracted from the used model management framework,
using model handlers. Model Handlers consists on an abstraction layer
dedicated to model access. This access is implemented by two classes :
ASMModel et ASMModelElement.

ATL contains three plugins drivers corresponding to different Model
Handlers : EMF, MDR, UML2. Each plugin implements those abstract classes
:

  - AtlModelHandler : implementation of the basic tasks "newModel",
    "saveModel", "loadModel"
  - ASMModel : getElementsByType implementation, framework oriented
    "newModelElement" method, etc...
  - ASMModelElement : "allInstances" implementation, etc...

Input and output models are loaded using the same API and are
differenciated with an "isTarget" property. That API implements the
"getMetaElementsByName" method which correspond to the "findme" ASM
instruction.

This VM implementation is still used in ATL, because it is strongly
linked to several parts. But the Regular VM has a lot of performance
issues, especially because of the model handler architecture.

### EMF-specific VM

The EMF-specific VM is a redefinition of the Regular one, which resolves
a lot of performance issues by avoiding EObjects wrapping. Its API allow
to consider EMF Resources directly as models, without complex loading as
done previously in the Regular VM.

### ASM format

ASM language is a kind of assembly language, adapted to model handling.
The low level of ASM allows modularity facilities, with the intent to
provide easier model management possibilities. The current file format
for ASM is XML. Thus it allows not to care about any syntax and to only
focus on bytecode. An ASM file only contains names and string constants.
No Ecore reference is present. Those are resolved by launch
configurations and AMMA Megamodel, with a name binding.

#### Serialization

ASM transformations are serialized in a way to increase performance and
preempt further serializations like binary files. The ASMXMLWriter class
is an ASM extractor used to save ASM into a file. Serialization computes
the constant pool, which factorizes constants, values and method calls
by generating an ordered constants list at the top of the ASM file.
ASMWriter is the parent abstract class which allows a binary
implementation of ASM injection and extraction.

#### Instructions

All instructions are explained into ATL VM specification. Here are
details about some of them:

  - The getasm instruction retrieves the ATL Context Module, i.e. The
    "thisModule" equivalent for ATL.
  - N symbolizes a native type, ATL specific
  - TransientLink are traceability links
  - all functions like "getLinkBySourceElement" are implemented in the
    nativelib
  - Object creation :
      - The "new" instruction takes two parameters : the metamodel name
        and the classifier type. Then it creates an element of this type
        in the output model (only one is allowed). The parameters are
        not available in the bytecode because they are pushed on the
        stack before calling instruction.
      - We can notice that ATL allows only one output model, but the ATL
        VM could be extended two allow many others.
      - A delete instruction could be implemented in the ATL VM
      - ATL provides the newInstance method which is directly mapped to
        the Model Handler method. This method doesn't generates a new
        because the call is dynamic. The main advantage is that the
        newInstance is directly applied to the class and do not use the
        ATL VM stack for that (otherwise it should store the class
        element).

## Parser

ATL parsing is done using a parser defined in TCS, which outputs an ATL
model conforming to the ATL metamodel. Then, an ATL-WFR transformation
(interpreted by the engine) generates a problem model. This model
produces errors interpreted by the editor and translated into markers,
visible on the ATL file on each compilation.

To manually parse (or extract) ATL files, see the
[ATLParser](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine/src/org/eclipse/m2m/atl/engine/parser/AtlParser.java?root=Modeling_Project&view=markup)
class.

Note that as ATL parser implements IInjector and IExtractor interfaces,
it can be use in [ATL ant
tasks](http://wiki.eclipse.org/ATL/User_Guide#ATL_ant_tasks) to parse or
extract atl files (just specify "ATL" as injector/extractor name).

## Compiler

Two versions of the ATL compiler are available : 2004 and
[2006](ATL_2006 "wikilink"). The 2006 version of ATL compiler uses
[ACG](#ACG_.28ATL_VM_Code_Generator.29 "wikilink"). The 2004 version
uses ATP, the historical ACG predecessor.

To manually compile ATL files, see the
[AtlDefaultCompiler](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine/src/org/eclipse/m2m/atl/engine/compiler/AtlDefaultCompiler.java?root=Modeling_Project&view=markup)
class.

### ACG (ATL VM Code Generator)

ACG is a compiler-oriented DSL, which intends to make easier to create a
compiler targeting the [ATL VM](#ATL_Virtual_Machine "wikilink"). A
compiler described with ACG generates ASM files and contains a
description of ASM instructions to generate for each type of input
elements, coming from a compiled file. Therefore the input of this kind
of compiler is a model describing the content of a compiled file (for
instance, an ATL file).

An ACG file, when compiled, looks through the input model using a
visitor design pattern. ACG is bootstrapped : an ACG.acg file exists and
describes the ACG compiler. Since an ACG file describes precisely ASM
instructions, the ACG.acg file is rather trivial.

A [complete ACG documentation](ACG "wikilink") is available.

The following schema places ACG in the AMMA platform.

![Image:AMMA_bootstrap.JPG](AMMA_bootstrap.JPG
"Image:AMMA_bootstrap.JPG")

# ATL Bugzilla

[Here](https://bugs.eclipse.org/bugs/buglist.cgi?bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&product=M2M&order=Reuse+same+sort+as+last+time&component=ATL-Contribution&component=ATL-Doc&component=ATL-emfvm&component=ATL-Engine&component=ATL-UI&component=ATL-Website)
is a link to query the ATL bugzilla for opened bugs.

  - To report a new bug about a specific ATL component, please use the
    table below:

| \-- Table headers --                                                                                                                                                                     |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Bugzilla Component                                                                                                                                                                       |
| [ATL-UI](https://bugs.eclipse.org/bugs/enter_bug.cgi?product=M2M&component=ATL-UI)                                                                                                       |
| [org.eclipse.m2m.atl.adt](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.adt/?root=Modeling_Project)                           |
| [org.eclipse.m2m.atl.adt.ui](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.adt.ui/?root=Modeling_Project)                     |
| [org.eclipse.m2m.atl.adt.debug](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.adt.debug/?root=Modeling_Project)               |
| [org.eclipse.m2m.atl.adt.editor](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.adt.editor/?root=Modeling_Project)             |
| [ATL-Engine](https://bugs.eclipse.org/bugs/enter_bug.cgi?product=M2M&component=ATL-Engine)                                                                                               |
| [org.eclipse.m2m.atl.core](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core/?root=Modeling_Project)                         |
| [org.eclipse.m2m.atl.core.emf](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core.emf/?root=Modeling_Project)                 |
| [org.eclipse.m2m.atl.core.ui.vm](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core.ui.vm/?root=Modeling_Project)             |
| [org.eclipse.m2m.atl.core.ant](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.core.ant/?root=Modeling_Project)                 |
| [org.eclipse.m2m.atl.dsls](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.dsls/?root=Modeling_Project)                         |
| [org.eclipse.m2m.atl.engine](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine/?root=Modeling_Project)                     |
| [org.eclipse.m2m.atl.engine.vm](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine.vm/?root=Modeling_Project)               |
| [org.eclipse.m2m.atl.drivers.emf4atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.drivers.emf4atl/?root=Modeling_Project)   |
| [org.eclipse.m2m.atl.drivers.uml24atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.drivers.uml24atl/?root=Modeling_Project) |
| [ATL-emfvm](https://bugs.eclipse.org/bugs/enter_bug.cgi?product=M2M&component=ATL-emfvm)                                                                                                 |

  - To contribute something to ATL, use the
    [ATL-Contribution](https://bugs.eclipse.org/bugs/enter_bug.cgi?product=M2M&component=ATL-Contribution)
    component.

<!-- end list -->

  - To report a bug about ATL documentation, use the
    [ATL-Doc](https://bugs.eclipse.org/bugs/enter_bug.cgi?product=M2M&component=ATL-Doc)
    component.

<!-- end list -->

  - To report a bug about ATL website, use the
    [ATL-Website](https://bugs.eclipse.org/bugs/enter_bug.cgi?product=M2M&component=ATL-Website)
    component.

[Category:ATL](Category:ATL "wikilink")