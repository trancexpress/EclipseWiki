This page has been moved
[here](ATL/Developer_Guide#Install_ATL_from_CVS "wikilink").