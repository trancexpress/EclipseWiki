# Installation of ADT (ATL Development Toolkit) from CVS

## Install Eclipse and EMF

In order to use ADT (ATL Development Tools), you need Eclipse and EMF.
ADT has been developed with and for Eclipse 3.3.x. You can download
Eclipse here: <http://www.eclipse.org/downloads/> and EMF here:
<http://www.eclipse.org/emf/>.

Unzip the Eclipse zip file; this will create an eclipse directory with
every Eclipse files in it.

Unzip the EMF zip file from the same directory (it also contains an
eclipse directory, with the EMF additional files to Eclipse).

When you have finished to install Eclipse and EMF, you can run it.

## Configuration of CVS access

You should go to CVS Repository view (Window -\> Open Perspective). Then
you should add a new repository location. The required parameters are
the followings:

![Image:ATL_CVSRepositoryLocation.PNG](ATL_CVSRepositoryLocation.PNG
"Image:ATL_CVSRepositoryLocation.PNG")

You do not need a password.

Then, you can go to HEAD -\> org.eclipse.m2m -\> org.eclipse.m2m.atl -\>
plugins. You can now select the projects of the folder "plugins" (note
that the "XXX-feature" ones are not mandatory) and check them out (this
action is available in the context menu).

![Image:ATL_CVSCheckout.PNG](ATL_CVSCheckout.PNG
"Image:ATL_CVSCheckout.PNG")

## Configuration of ADT

Now, you need to go to the Plug-in perspective.

Some external libraries are required for the plug-in
org.eclipse.m2m.atl.drivers.mdr4atl but not available on the CVS
repository (a README file is available in this plug-in). You need to
download the jar files into the lib/ directory of these projects.

Download mdr-standalone.zip from <http://mdr.netbeans.org/download/> and
put the included jar files into lib/ of plugin
org.eclipse.m2m.atl.drivers.mdr4atl.

Note that mdr-standalone.zip is updated more often on the MDR website
than in our development source. As a consequence, bugs may appear when
using the last-in-date mdr-standalone version of MDR.

When you have finished this operation, there is normally no error left.

ADT is ready to be tested. The quickest way to do this is to launch,
from the "Plug-in Development perspective", a Run-time workbench (Click
on Run -\> Run as -\> Run-time workbench).

You are now ready to use ADT.

[Category:ATL](Category:ATL "wikilink")