The ATL transformations Zoo is open to contributors. All external
contributions are welcome.

There are two possibilities to publish your scenario(s):

  - [Your scenario(s) will be hosted on the Eclipse
    server](#ATL_Scenario_Hosted_on_the_Eclipse_Server "wikilink")
  - [Your scenario(s) will be hosted on an external
    server](#ATL_Scenario_Hosted_on_an_External_Server "wikilink")

In the documentation or in the comments of the transformation itself,
you may mention your identity and company by mail, URL, etc. In this way
you may get back some advice from interested people.

Please send your contribution or XML description (depending on the case)
by entering a [contribution
request](https://bugs.eclipse.org/bugs/enter_bug.cgi?product=M2M&component=ATL-Contribution).
A bugzilla account is required, you can create one
[here](https://bugs.eclipse.org/bugs/createaccount.cgi).

All contributions you make to our web site are governed by Eclipse.org
[Terms Of Use](http://www.eclipse.org/legal/termsofuse.php), so please
take the time to actually read it.

## ATL Scenario Hosted on the Eclipse Server

If you wish to publish your scenario(s) in this zoo, you should provide
the following information:

  - A zip containing:
      - ATL transformation(s) used
      - Metamodels used in Ecore/XMI format and if possible KM3 format
        (you can also contribute to the Atlantic Zoo)
      - Sample models (input and ouput)
      - Launch configuration script(s) and/or ANT script(s)
      - Documentation
  - A documentation (PDF, Word, etc.)
  - An XML description of your example (see [XML Description of ATL
    Scenario](#XML_Description_of_ATL_Scenario_\(Eclipse_Server\) "wikilink"))

### XML Description of ATL Scenario (Eclipse Server)

<atlTransformation>
` `<shortName>`KM32DOT`</shortName>
` `<name>`KM3 to DOT`</name>
` `<docLink>`KM32DOT/ExampleKM32DOT[v00.01].pdf`</docLink>
` `<sourceLink>`KM32DOT/KM32DOT.zip`</sourceLink>
` `<description>
`  The KM3 to DOT example describes a transformation from a KM3 metamodel description into a class`
`  diagram drawn with DOT. KM3 is a textual concrete syntax to describe metamodels. It has its advantages,`
`  yet having a graphical presentation of a metamodel can be sometimes enlightening. DOT is an automatic`
`  graph layout program from Graphviz. It can be used to create graphical files, such as PS, PNG... out of`
`  its layout. The aim of this transformation is to generate a rough visualization, in the form of a class`
`  diagram, of a KM3 model. A metamodel created with KM3 does not include any representation information,`
`  so DOT, the Graphviz tool, is used to compute the layout and generate the output picture.`
` `</description>
` `<pubDate></pubDate>
</atlTransformation>

## ATL Scenario Hosted on an External Server

If your ATL scenario is hosted on an external server (i.e. not the
Eclipse server), you just need to send us an XML description of your
example (see [XML Description of ATL
Scenario](#XML_Description_of_ATL_Scenario_\(External_Server\) "wikilink")).

### XML Description of ATL Scenario (External Server)

<atlTransformation>
` `<shortName>`UMLAccessors`</shortName>
` `<name>`UML Accessors, Java2Accessors`</name>
` `<docLink><http://ssel.vub.ac.be/ssel/research:mdd:casestudies#accessors_java2accessors></docLink>
` `<sourceLink><http://ssel.vub.ac.be/viewcvs/viewcvs.py/svn-gen/UML1CaseStudies/uml1cs-transformations/></sourceLink>
` `<description>
`  These transformations are part of the `<a href="http://ssel.vub.ac.be/ssel/research:mdd:casestudies">`UML refinement transformations`</a>` by`
`  `<a href="http://ssel.vub.ac.be/ssel/about:members:denniswagelaar">`Dennis Wagelaar`</a>`.`
`  These transformations introduce accessor Operations/Methods (with Java bodies) for each public Attribute.`
`  The public Attributes are then made private. This transformation is also used in refactoring as "Encapsulate Field".`
`  There are two variants available:`
`   `<a href="http://ssel.vub.ac.be/viewcvs/viewcvs.py/UML1CaseStudies/uml1cs-transformations/Accessors.atl?view=markup">`Accessors.atl`</a>`:`</b>
`   Uses strict Java 1 API. Works on J2ME MIDP 1.0 as well.`
`   `<a href="http://ssel.vub.ac.be/viewcvs/viewcvs.py/UML1CaseStudies/uml1cs-transformations/Java2Accessors.atl?view=markup">`Java2Accessors.atl`</a>`:`
`   Uses the Java 2 Collections framework. Works on J2ME PP 1.0 as well.`
`  `

</ul>

` `</description>
` `<pubDate></pubDate>
</atlTransformation>

[Category:ATL](Category:ATL "wikilink")