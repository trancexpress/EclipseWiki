This page contains a list of common questions related to the use of
[ATL](ATL "wikilink"). It gives hints towards solutions as well as links
to some concrete examples.

__TOC__

## How do I launch transformations programmatically?

### ATL-specific launch configurations and ANT tasks

The ATL development environment provides several base ways of launching
transformations:

  - by specifying a [launch
    configuration](ATL/User_Guide_-_The_ATL_Tools#Setting_up_an_ATL_run_launch_configuration "wikilink"),
  - by writing an ant script using the [ATL-specific ANT
    tasks](ATL/User_Guide_-_The_ATL_Tools#ATL_ant_tasks "wikilink").

### ATL API & Services

However, notably for integration purposes in Eclipse solutions, it is
necessary to launch transformations by mean of Java code.

This is why ATL directly provides in addition a [dedicated API and core
services](ATL/Developer_Guide#Core_API "wikilink") enabling to run ATL
transformations programmatically, including the loading (injection) and
saving (extraction) of corresponding required metamodels and models.

## How do I generate text from models?

There are several possibilies. We only detail some of them here.

### Using ATL

You can specify a query over your model in ATL. An example of this is
available in the
[UML-to-JavaCode](http://www.eclipse.org/atl/atlTransformations/#UML2Java)
transformation.

The [atlanticRaster
zoo](http://www.emn.fr/z-info/atlanmod/index.php/Raster) is also using
this technique. It first transforms KM3 metamodels into DOT models with
a KM32DOT.atl transformation. It then uses DOT2Text.atl to query a
string, corresponding to the generated DOT code, from the DOT model.
These two ATL transformation/query can be found from
[here](http://www.eclipse.org/atl/atlTransformations/#KM32DOT).

Then, an ANT script makes use of the
[atl.saveModel](ATL/User_Guide_-_The_ATL_Tools#Task_atl.saveModel "wikilink")
task with an ATL extractor pointing to the DOT2Text.atl transformation.

### Using other tools

The [Xtext](http://www.eclipse.org/Xtext/) framework in Eclipse Modeling
is dedicated to this kind of tasks.

[TCS](TCS "wikilink") (Textual Concrete Syntax) is also a tool enabling
the specification of textual syntaxes for metamodels.

## How do I declare/use external parameters in ATL transformations?

### Using an XML file

A solution is to save transformation parameters in a extern XML model.
In the transformation, you will use an *helper* to get parameters from
your model.

To inject and/or extract XML models (and to get the simple XML metamodel
in Ecore), you can check out and install the
[org.eclipse.m2m.atl.projectors.xml](https://dev.eclipse.org/svnroot/modeling/org.eclipse.mdt.modisco/incubation/trunk/am3/plugins/trunk/org.eclipse.m2m.atl.projectors.xml/)
plugin with your ATL Eclipse install.

The following code is a simple parameters XML file:

    <parameters>
        <param name="param1" value="valueX"/>
        <param name="param2" value="valueY"/>
    </parameters>

In the transformation header, you add the *parameters* model and its
[XML
metamodel](https://dev.eclipse.org/svnroot/modeling/org.eclipse.mdt.modisco/incubation/trunk/am3/plugins/trunk/org.eclipse.m2m.atl.projectors.xml/model/):

    module AMW2ATL;
    create OUT : XXX from IN : YYY, parameters : XML;

From *parameters* model, the following helper is used to get *value*
attribute select in the *param* entities according to the given *name*:

    helper def : getParameter(name : String) : String =
        XML!Element.allInstancesFrom('parameters')->select(e |
            e.name = 'param'
        )->select(e |
            e.getAttrVal('name') = name
        )->first().getAttrVal('value');

To use the previous helper (due to the *getAttrVal* call), you need to
use
[XMLHelpers.asm](https://gforge.inria.fr/scm/viewvc.php/*checkout*/AtlanticRaster/build/XMLHelpers.asm?revision=6&root=atlantic-zoos)
ATL Library and add in the transformation:

    uses XMLHelpers;

The following code is a simple example to show how to use the
*getParameter* helper:

    helper def : sourceValue  : String = thisModule.getParameter('source');

## How can I handle arbitrary XML documents?

Arbitrary XML documents can be used as source or target of ATL
transformations. However, this cannot be done directly (see [next
section](ATL_Howtos#How_can_I_tune_the_XML_output_of_ATL? "wikilink"))
but rather through specific injectors and extractors.

Injecting XML files as XML models or extracting XML models as XML files
can be performed thanks to the the
[org.eclipse.m2m.atl.projectors.xml](https://dev.eclipse.org/svnroot/modeling/org.eclipse.mdt.modisco/incubation/trunk/am3/plugins/trunk/org.eclipse.m2m.atl.projectors.xml/)
plugin and [ATL-specific ANT
tasks](ATL/User_Guide_-_The_ATL_Tools#ATL_ant_tasks "wikilink").

A version of this plugin built for the Juno ATL version can be
downloaded from
[here](http://docatlanmod.emn.fr/ATL/Plugins/org.eclipse.m2m.atl.projectors.xml_0.4.0.jar)
and has to be copied to the *dropins* folder of your Eclipse install
before starting. For other ATL versions, the plugin sources first have
to be checked out into your workspace in order to re-export the plugin
as a compatible deployable one (to be then copied to the *dropins*
folder similarly as mentioned before).

## How can I tune the XML output of ATL?

The ATL Virtual Machine can write target models to XML files in two
different ways:

  - XMI writing is delegated to EMF.
  - Target models can be extracted into XML files using custom XML
    Schemas.

To do this, the target model is first transformed into a model
conforming to a [specific XML
metamodel](https://dev.eclipse.org/svnroot/modeling/org.eclipse.mdt.modisco/incubation/trunk/am3/plugins/trunk/org.eclipse.m2m.atl.projectors.xml/model/).
The resulting XML model can then be extracted into an XML document. An
example can be found in the
[Table2SVGPieChart](http://www.eclipse.org/atl/atlTransformations/#Table2SVGPieChart)
transformation scenario: the target SVG model is transformed into an XML
model that can then be extracted (see documentation of scenario for more
details and README.txt in zip file for directions). The process of
transforming a model to XML then extracting it can be automated using
[ATL-specific ANT
tasks](ATL/User_Guide_-_The_ATL_Tools#ATL_ant_tasks "wikilink") and the
*org.eclipse.m2m.atl.projectors.xml* plugin (see [previous
section](ATL/Howtos#How_can_I_handle_arbitrary_XML_documents? "wikilink")).

## How can I implement my own injector or extractor?

An injection/extraction is a transformation from/to another Technical
Space (e.g., XML, Grammarware) to/from the Model Engineering Technical
Space. An injector/extractor is a component implementing an
injection/extraction.

Injectors and extractors may be then used programmatically or via
ATL-specific ANT tasks
[atl.loadModel](ATL/User_Guide_-_The_ATL_Tools#Task_atl.loadModel "wikilink")
and
[atl.saveModel](ATL/User_Guide_-_The_ATL_Tools#Task_atl.saveModel "wikilink").

To be usable in practice, an injector/extractor must implement the
IInjector/IExtractor interface (cf. [ATL Core API
documentation](ATL/Developer_Guide#Core_API "wikilink")), as shown by
the [XML injector/extractor
example](https://dev.eclipse.org/svnroot/modeling/org.eclipse.mdt.modisco/incubation/trunk/am3/plugins/trunk/org.eclipse.m2m.atl.projectors.xml/src/org/eclipse/m2m/atl/projectors/xml/)
for instance. It must also declare explicitly the use of the specific
org.eclipse.m2m.atl.core.injector/extractor extension points, as shown
by the [same example than
before](https://dev.eclipse.org/svnroot/modeling/org.eclipse.mdt.modisco/incubation/trunk/am3/plugins/trunk/org.eclipse.m2m.atl.projectors.xml/plugin.xml).

## How can I transform UML models?

There are several implementations of UML. The one we consider here is
the de-facto standard implementation from Eclipse: [the UML2
project](MDT-UML2 "wikilink").

ATL allows to transform such UML models as any other EMF models.

The UML2 metamodel must be loaded from the EMF registry (i.e., by
namespace URI). This can be done using the "EMF Registry..." button of
the ATL launch configuration, or using the nsURI attribute of the
[atl.loadModel](ATL/User_Guide_-_The_ATL_Tools#Task_atl.loadModel "wikilink")
task.

Usage of [content
assist](ATL/User_Guide_-_The_ATL_Tools#Content_assist "wikilink") (i.e.,
code completion) is especially useful with big metamodels like UML2.

## How can I retrieve tagged values from stereotyped UML model elements?

In ATL, a profiled UML model used as source model is viewed like any
other UML model. You generally (i.e., when the profile is referenced
with a valid relative path) do not have to specify the profile used with
the model. So, in the header of the ATL module you just have:

`module uml2something;`
`create OUT : targetMetamodel from IN : UML;`

If atl seems to ignore your stereotypes, you can add your profile as
source model. You obtain the following header:

`module uml2something;`
`create OUT : targetMetamodel from IN : UML, INPROFILE : profile;`

After that you can use operations like:

  - getAppliedStereotype(sterotypeName : String) on a UML element to get
    the stereotype with the name "stereotypeName" applied on this
    element. This operation needs the fully qualifed name of the
    stereotype so it looks like: profileName::sterotypeName.
  - getValue(stereotype : Stereotype, propertyName : String) to get the
    Value of the tagged value with name "propertyName" on the stereotype
    "stereotype" (the sterotype can be retrieved by
    getAppliedStereotype).

A helper like:

`helper context UML!Element def: hasStereotype(name : String) : Boolean =`
`   not self.getAppliedStereotype(name).oclIsUndefined();`

can also be useful to check if a stereotype is applied on the UML
element before trying to retrieve it or to get a tagged value from it.
As it uses getAppliedStereotype, it needs the fully qualified name of
the stereotype (e.g., profileName::sterotypeName).

## How can I specify a Virtual Machine operation in Java? (Deprecated)

It is possible to add new Java operations to the ATL Virtual Machine
(VM). These operations can then be called like helpers.

The  plugin offers the  class to create instances of  and to register
them in the ATL VM.

This is used in  to redefine the dumpASM method of ASMEmitter. The
process to register operations on OCL primitive types (e.g. Boolean,
Integer, String) is similar.

[Category:ATL](Category:ATL "wikilink")