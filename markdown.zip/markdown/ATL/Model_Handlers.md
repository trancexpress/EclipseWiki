In [ATL](ATL "wikilink") engine terminology, a model handler is a
library providing primitives for handling models:

  - Creating new models,
  - Loading and saving models,
  - Adding and deleting elements,
  - Reading and writing element properties.

A model handler driver is a piece of Java code making it possible to use
the corresponding model handler with the ATL Virtual Machine.

The current version of ATL Virtual Machine provides three model handler
drivers:

  - [emf4atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.drivers.emf4atl/?root=Modeling_Project)
    to use [Eclipse/EMF](http://www.eclipse.org/emf/),
  - [mdr4atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.drivers.mdr4atl/?root=Modeling_Project)
    to use [Netbeans/MDR](http://mdr.netbeans.org/).
  - [uml24atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.drivers.uml24atl/?root=Modeling_Project)
    to use [UML2](http://www.eclipse.org/uml2/).

__TOC__

## Creating New Model Handler Drivers

Here is a brief description of the work to be done (see CVS Links table
below for links to source code):

  - Extend ASMModel to implement specific model-level behavior. There
    are already two examples: ASMEMFModel, and ASMMDRModel.
  - Extend ASMModelElement to implement specific model-element-level
    behavior. There are already two examples: ASMEMFModelElement, and
    ASMMDRModelElement.
  - Extend AtlModelHandler to implement model loading and saving. There
    are already two examples: AtlEMFModelHandler, and
    AtlMDRModelHandler.
  - Use the `org.atl.eclipse.engine.modelhandler` extension in your
    plugin.xml to register your model handler driver. There is already
    one example: mdr4atl plugin.xml.

ATL Development Tools strongly depend on emf4atl, which is consequently
built into it. mdr4atl should rather be used as an example for properly
placing Java classes and plugin.xml elements.

| Entity                                     | [M2M/ATL/deprecated](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/?root=Modeling_Project) (moved from GMT/ATL CVS)                                                                                       | [M2M/ATL/plugins CVS](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/?root=Modeling_Project) (current location)                                                                                               |
| ------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| [Eclipse/EMF](http://www.eclipse.org/emf/) | [Netbeans/MDR](http://mdr.netbeans.org/)                                                                                                                                                                                                            | [Eclipse/EMF](http://www.eclipse.org/emf/)                                                                                                                                                                                                          |
| plugin                                     | [emf4atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.engine.repositories.emf4atl/?root=Modeling_Project)                                                                                       | [mdr4atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.engine.repositories.mdr4atl/?root=Modeling_Project)                                                                                       |
| ASMModel                                   | [ASMModel](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.engine.vm/src/org/atl/engine/vm/nativelib/ASMModel.java?root=Modeling_Project&view=markup)                                               | [ASMModel](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine.vm/src/org/eclipse/m2m/atl/engine/vm/nativelib/ASMModel.java?root=Modeling_Project&view=markup)                          |
| ASM<ModelHandler>Model                     | [ASMEMFModel](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.engine.repositories.emf4atl/src/org/atl/engine/repositories/emf4atl/ASMEMFModel.java?root=Modeling_Project&view=markup)               | [ASMMDRModel](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.engine.repositories.mdr4atl/src/org/atl/engine/repositories/mdr4atl/ASMMDRModel.java?root=Modeling_Project&view=markup)               |
| ASMModelElement                            | [ASMModelElement](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.engine.vm/src/org/atl/engine/vm/nativelib/ASMModelElement.java?root=Modeling_Project&view=markup)                                 | [ASMModelElement](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine.vm/src/org/eclipse/m2m/atl/engine/vm/nativelib/ASMModelElement.java?root=Modeling_Project&view=markup)            |
| ASM<ModelHandler>ModelElement              | [ASMEMFModelElement](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.engine.repositories.emf4atl/src/org/atl/engine/repositories/emf4atl/ASMEMFModelElement.java?root=Modeling_Project&view=markup) | [ASMMDRModelElement](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.engine.repositories.mdr4atl/src/org/atl/engine/repositories/mdr4atl/ASMMDRModelElement.java?root=Modeling_Project&view=markup) |
| AtlModelHandler                            | [AtlModelHandler](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.eclipse.engine/src/org/atl/eclipse/engine/AtlModelHandler.java?root=Modeling_Project&view=markup)                                 | [AtlModelHandler](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.engine/src/org/eclipse/m2m/atl/engine/AtlModelHandler.java?root=Modeling_Project&view=markup)                            |
| Atl<ModelHandler>ModelHandler              | [AtlEMFModelHandler](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.eclipse.engine/src/org/atl/eclipse/engine/AtlEMFModelHandler.java?root=Modeling_Project&view=markup)                           | [AtlMDRModelHandler](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/deprecated/org.atl.engine.repositories.mdr4atl/src/org/atl/engine/repositories/mdr4atl/AtlMDRModelHandler.java?root=Modeling_Project&view=markup) |

CVS Links

## When to Create a New Model Handler Driver

In theory, there should be a distinct model handler driver for each
model handler, independently of the metamodel that is used. For
instance, there is one for [Eclipse/EMF](http://www.eclipse.org/emf/)
and one for [Netbeans/MDR](http://mdr.netbeans.org/).

In practice, there are exceptions. For instance, the
[Eclipse/UML2](http://www.eclipse.org/uml2/) plugin implements the UML
2.0 metamodel by using EMF. However, it seems that UML2 models created
with this plugin cannot be handled by EMF without the additional Java
code available in the Eclipse/UML2 plugin (see
[ATL_Language_Troubleshooter\#UML2_Profiles](ATL_Language_Troubleshooter#UML2_Profiles "wikilink")
and [this
thread](http://groups.yahoo.com/group/atl_discussion/message/1201?threaded=1&var=1)).
This means that the UML2 metamodel that is implemented does not strictly
follow EMF rules but adds its own rules. One example is profile and
stereotype application: the profile must be applied before the
stereotype. Such an ordering constraint is beyond EMF semantics. For
this reason, full support for the
[Eclipse/UML2](http://www.eclipse.org/uml2/) plugin can only be properly
achieved by adding code specific to this plugin in the model handler
driver. Instead of doing this in
[emf4atl](http://dev.eclipse.org/viewcvs/indextech.cgi/org.eclipse.gmt/ATL/org.atl.engine.repositories.emf4atl/),
which is metamodel-independant, the
[uml24atl](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.m2m.atl/plugins/org.eclipse.m2m.atl.drivers.uml24atl/?root=Modeling_Project)
model handler driver has been developed.