# Indigo Release Review - ATL 3.2

**Indigo Simultaneous Release**

**Release Review and Graduation Review**

William Piers *(william.piers@obeo.fr)*

Release Review : June 1, 2011

*Communication Channel : eclipse.modeling.m2m newsgroup*

*Process Documentation :
<http://www.eclipse.org/projects/dev_process/development_process.php>*

*Project Plan :
<http://www.eclipse.org/projects/project-plan.php?projectid=modeling.m2m.atl>*

## Indigo Release Highlights

### New and noteworthy

ATL 3.2 is compatible with Eclipse 3.4 (Ganymede), Eclipse 3.5
(Galileo), Eclipse 3.6 (Helios) and Eclipse 3.7 (Indigo).

#### ATL Code Formatter

The ATL editor has been improved with a code formatter which enables the
Ctrl+Shift+F on ATL transformation files. It is parametrizable via a
preference page.

#### New Refining mode

The ATL2010 compiler implements an in-place strategy, e.g., the changes
are directly performed on the source model without making any copy of
the elements. The rules in the transformation only need to specify the
values that have changed whereas all the other elements just remain
untouched. The transformations in this mode are performed in two steps.
In the first step, the transformation engine executes the rules which,
as a result, produce a set of changes that are temporally stored. In the
second step, this set changes are applied directly on the source model.

This compiler enhances the refining capabilities provided by the 2006
compiler, that also implemented an in-place strategy. First of all, it
addresses the lacking of deletion support by providing the user an
explicit way to specify in the transformation that a matched element has
to be removed.

### Quality of APIs

The component lead certifies that the requirements for Eclipse Quality
APIs have been met for this release. All non-API code is in "internal"
packages.

### End of Life Issues

None

### Committer Diversity

3 Committers from Obeo, 1 from INRIA and 2 individual committers.

## IP Issues

The about files and use licenses are in place as per the Guidelines to
Legal Documentation.

All other contributions (code, documentation, images, etc) have been
committed by individuals who are either Members of the Foundation, or
have signed the appropriate Committer Agreement. In either case, these
are individuals who have signed, and are abiding by, the Eclipse IP
Policy. The other contributions of the IP log are not significant or are
written 100% by employees of the same employer (Obeo) as the Submitting
Committer (http://www.eclipse.org/legal/EclipseLegalProcessPoster.pdf).

All contribution Questionnaires have been completed.

The "provider" field of each plugin is set to "Eclipse Modeling
Project".

The "copyright" field of each plugin is set to the copyright owner.

Any third-party logos or trademarks included in the distribution (icons,
logos, etc) have been licensed under the EPL.

The ATL IP log is located at
<http://www.eclipse.org/projects/ip_log.php?projectid=modeling.m2m.atl>

## Non-Code Aspects

### Build

ATL releng system recently moved to the common Hudson build server.

### Unit tests

Non-regression tests covers most of the Core part of ATL. ATL
transformation engines, compilers, parser, formatter are covered by
those tests. ATL uses EMFCompare to check model results.

### Code quality

Checkstyle activated on each distinct plug-in.

Yourkit used on a regular basis to improve performances.

## APIs

Metamodel definitions and interfaces are considered APIs.

APIs provide access to programmatic launch of ATL components
(transformation engine, parser, compiler).

## Documentation

The documentation that comes with ATL 3.2 is available in the Help menu
: ATL Model To Text Transformation Language.

The documentation is also fully available on the wiki
<http://wiki.eclipse.org/ATL>. The main sections are:

  - ATL User Guide: a complete description of the tooling and the ATL
    language
  - ATL Developer Guide: a more specific description of API

The wiki documentation is converted to the ATL eclipse help plugin using
Mylyn Wikitext.

ATL also provide an example and a cheatsheet.

## Bugzilla

|             |     |          |          |        |       |
| ----------- | --- | -------- | -------- | ------ | ----- |
|             | NEW | ASSIGNED | RESOLVED | CLOSED | TOTAL |
| blocker     | 0   | 0        | 2        | 0      | 2     |
| critical    | 3   | 0        | 5        | 0      | 8     |
| major       | 1   | 2        | 10       | 1      | 14    |
| normal      | 20  | 0        | 113      | 8      | 141   |
| minor       | 0   | 0        | 5        | 0      | 5     |
| trivial     | 0   | 0        | 1        | 0      | 1     |
| enhancement | 8   | 0        | 12       | 0      | 20    |
| TOTAL       | 32  | 2        | 148      | 9      | 191   |

Note : these figures are subject to changes as the whole team is in the
process of fixing bugs until the final release (this snapshot has been
taken on May 30, 2011)‏

## Tool usability

Localization : integrated into Babel

## End of Life

There are no specific end of life concerns for this release.

## Communities

Talks have been given on the following events:

  - ATL at the Topcased Days 2011:
    <http://gforge.enseeiht.fr/docman/view.php/52/4318/B5-AtlanMod-Obeo.pdf>

Other medium:

  - Activity on the M2M newsgroup (eclipse.modeling.m2m): more than 500
    threads on ATL from June 2010 to May 2011

## Schedule

ATL 3.2 Release Plan

`M1 08/17/2009`
`M2 09/28/2009`
`M3 11/9/2009`
`M4 12/14/2009`
`M5 02/01/2010`
`M6 03/15/2010`
`M7 05/03/2010`
`RC1    05/17/2010`
`RC2    05/24/2010`
`RC3    05/31/2010`
`RC4    06/07/2010`
`Final  06/16/2010`
`3.2    06/22/2010`

The schedule used is matching the schedule of the [release
train](Indigo/Simultaneous_Release_Plan "wikilink") for "+2" projects.

## Project Plan

The Indigo project plan is available at
<http://www.eclipse.org/projects/project-plan.php?projectid=modeling.m2m.atl>

What's next?

## Legal Notices

Java and all Java-based trademarks are trademarks of Oracle, Inc. in the
United States, other countries, or both.

Other company, product, or service names may be trademarks or service
marks of others.

[Category:Modeling](Category:Modeling "wikilink")
[Category:MMT](Category:MMT "wikilink")
[Category:ATL](Category:ATL "wikilink")