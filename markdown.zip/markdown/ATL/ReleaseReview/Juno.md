# Juno Release Review - ATL 3.3

**Juno Simultaneous Release**

**Release Review and Graduation Review**

William Piers *(william.piers@obeo.fr)*

Release Review : June, 2012

*Communication Channel :
[eclipse.atl](http://www.eclipse.org/forums/eclipse.atl) (newsgroup) &
[m2m-atl-dev](https://dev.eclipse.org/mailman/listinfo/m2m-atl-dev)
(mailing list)*

*Process Documentation :
<http://www.eclipse.org/projects/dev_process/development_process.php>*

*Project Plan :
<http://www.eclipse.org/projects/project-plan.php?projectid=modeling.mmt.atl>*

## Juno Release Highlights

### New and noteworthy

ATL 3.3 is compatible with Eclipse 3.4 (Ganymede), Eclipse 3.5
(Galileo), Eclipse 3.6 (Helios), Eclipse 3.7 (Indigo) and Eclipse
3.8/4.2 (Juno).

#### ATL EMFTVM

A new VM for ATL (EMFTVM), but also other rule-based transformations
languages, that incorporates composition (rule inheritance, module
superimposition) as an integral part.

### Quality of APIs

The component lead certifies that the requirements for Eclipse Quality
APIs have been met for this release. All non-API code is in "internal"
packages.

### End of Life Issues

None

### Committer Diversity

3 Committers from Obeo, 1 from INRIA and 2 individual committers.
William Piers is now co-lead on the project with Frédéric Jouault.

## IP Issues

The about files and use licenses are in place as per the Guidelines to
Legal Documentation.

All other contributions (code, documentation, images, etc) have been
committed by individuals who are either Members of the Foundation, or
have signed the appropriate Committer Agreement. In either case, these
are individuals who have signed, and are abiding by, the Eclipse IP
Policy. The other contributions of the IP log are not significant or are
written 100% by employees of the same employer (Obeo) as the Submitting
Committer (http://www.eclipse.org/legal/EclipseLegalProcessPoster.pdf).

All contribution Questionnaires have been completed.

The "provider" field of each plugin is set to "Eclipse Modeling
Project".

The "copyright" field of each plugin is set to the copyright owner.

Any third-party logos or trademarks included in the distribution (icons,
logos, etc) have been licensed under the EPL.

The ATL IP log is located at
<http://www.eclipse.org/projects/ip_log.php?projectid=modeling.mmt.atl>

## Non-Code Aspects

### Build

ATL releng system recently moved to the common Hudson build server and
uses Tycho to build.

### Unit tests

Non-regression tests covers most of the Core part of ATL. ATL
transformation engines, compilers, parser, formatter are covered by
those tests. ATL uses EMFCompare to check model results.

### Code quality

Checkstyle activated on each distinct plug-in.

Yourkit used on a regular basis to improve performances.

## APIs

Metamodel definitions and interfaces are considered APIs.

APIs provide access to programmatic launch of ATL components
(transformation engine, parser, compiler).

## Documentation

The documentation that comes with ATL 3.3 is available in the Help menu
: ATL Model To Text Transformation Language.

The documentation is also fully available on the wiki
<http://wiki.eclipse.org/ATL>. The main sections are:

  - ATL User Guide: a complete description of the tooling and the ATL
    language
  - ATL Developer Guide: a more specific description of API

The wiki documentation is converted to the ATL eclipse help plugin using
Mylyn Wikitext.

ATL also provide an example and a cheatsheet.

## Bugzilla

|             |     |          |          |        |       |
| ----------- | --- | -------- | -------- | ------ | ----- |
|             | NEW | ASSIGNED | RESOLVED | CLOSED | TOTAL |
| blocker     | 0   | 0        | 2        | 0      | 2     |
| critical    | 0   | 0        | 5        | 0      | 5     |
| major       | 3   | 2        | 10       | 1      | 16    |
| normal      | 29  | 0        | 118      | 8      | 155   |
| minor       | 4   | 0        | 5        | 0      | 9     |
| trivial     | 0   | 0        | 1        | 0      | 1     |
| enhancement | 8   | 0        | 13       | 0      | 21    |
| TOTAL       | 44  | 2        | 154      | 9      | 209   |

Note : these figures are subject to changes as the whole team is in the
process of fixing bugs until the final release (this snapshot has been
taken on June 1, 2012)‏

## End of Life

There are no specific end of life concerns for this release.

## Communities

The ATL newsgroup (eclipse.atl) is still very active, with about 300
messages from the last release.

## Schedule

ATL 3.3 Release Plan

  - Final 06/27/2012
  - RC4 06/12/2012
  - RC3 06/05/2012
  - RC2 05/29/2012
  - RC1 05/22/2012

The schedule used is matching the schedule of the [release
train](Juno/Simultaneous_Release_Plan "wikilink") for "+2" projects.

## Project Plan

The Juno project plan is available at
<http://www.eclipse.org/projects/project-plan.php?projectid=modeling.mmt.atl>

## Legal Notices

Java and all Java-based trademarks are trademarks of Oracle, Inc. in the
United States, other countries, or both.

Other company, product, or service names may be trademarks or service
marks of others.

[Category:Modeling](Category:Modeling "wikilink")
[Category:MMT](Category:MMT "wikilink")
[Category:ATL](Category:ATL "wikilink")