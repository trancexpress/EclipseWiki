__FORCETOC__

<div name="Building ATL Files With ANT And Maven">

</div>

# The Problem

Currently Maven doesn't provide any plugin to compile ATL files and
given such limitations a workaround is necessary. A custom ANT task has
been developed that receives .atl files as input and then compiles them
into .asm files. The following instructions describe how to set up a
project to compile ATL files.

# ATL Compilation ANT Task

  - Create a new project to contain the ATL compilation ANT task
  - Create the ANT task using the following code:

`package com.x.ant;`
`import java.io.File;`
`import java.io.FileInputStream;`
`import java.util.Iterator;`
`import java.util.Vector;`
`import org.apache.tools.ant.BuildException;`
`import org.apache.tools.ant.Task;`
`import org.apache.tools.ant.types.FileSet;`
`import org.apache.tools.ant.types.resources.FileResource;`
`import org.apache.tools.ant.types.resources.FileResourceIterator;`
`import org.eclipse.m2m.atl.engine.compiler.atl2006.Atl2006Compiler;`

`public class AtlCompilerTask extends Task {`
`  private Atl2006Compiler compiler = new Atl2006Compiler();`

`  private Vector`<FileSet>` filesets = new Vector`<FileSet>`();`

`  public AtlCompilerTask() {`
`       Thread.currentThread().setContextClassLoader(getClass().getClassLoader());`
`  }`

`  public void addFileset(FileSet fileset) {`
`     filesets.add(fileset);`
`  }`

`     @Override`
`     public void execute() throws BuildException {`
`             try {`
`                     //iterate over all the FileSet(s) passed in from ANT`
`                     for(Iterator`<FileSet>` itFSets = filesets.iterator(); itFSets.hasNext();)`
`                     {`
`                          //get a FileSet`
`                          FileSet fs = itFSets.next();`

`                          FileResourceIterator iter = (FileResourceIterator)fs.iterator();`

`                          //loop over all the files in a given FileSet`
`                          while(iter.hasNext())`
`                          {`
`                             FileResource fr = (FileResource)iter.next();`
`                             File file = fr.getFile();`

`                             //compile each ATL file suffixing it with .asm`
`                             compiler.compile(new FileInputStream(file),file.getAbsolutePath().replace(".atl", ".asm"));`
`                          }`
`                     }`
`             }`
`             catch (Exception e) {`
`                     e.printStackTrace();`
`                     throw new BuildException("Exception while calling the ATL compiler task.", e);`
`             }`
`     }`
`}`

  - Ensure you have all the ATL dependencies on your ANT builder
    classpath

# ATL Compilation Maven Build

  - We assume the ANT task defined above exists in your workspace
  - Add a build procedure to the .pom file located in the project for
    which you wish to compile its .atl sources, as follows:

`       `<build>
`            `<plugins>
`                    `<plugin>
`                            `<groupId>`org.apache.maven.plugins`</groupId>
`                            `<artifactId>`maven-antrun-plugin`</artifactId>
`                            `<version>`1.7`</version>
`                            `<executions>
`                                    `<execution>
`                                            `<id>`compile`</id>
`                                            `<phase>`compile`</phase>
`                                            `<configuration>
`                                                    `<target>
`                                                            `<property name="com.x.ant.location" value="../com.x.ant" />
`                                                            `<property name="dependency-classpath" refid="maven.dependency.classpath" />
`                                                            `<echo message="Start ATL compilation" />
`                                                            `<echo message="Maven Dependencies: ${dependency-classpath}" />
`                                                                  `

`                                                            `<taskdef name="compileATL"
                                                                     classpath="${com.x.ant.location}/target/AtlCompilerTask.jar"
                                                                     classname="com.x.ant.AtlCompilerTask" classpathref="maven.dependency.classpath" />
`                                                                  `

`                                                            `<compileATL>
`                                                                    `<fileset dir="${basedir}/ATL" includes="**/*.atl" />
`                                                            `</compileATL>
`                                                            `<echo message="Done!" />
`                                                    `</target>
`                                            `</configuration>
`                                            `<goals>
`                                                    `<goal>`run`</goal>
`                                            `</goals>
`                                    `</execution>
`                            `</executions>
`                    `</plugin>
`            `</plugins>
`    `</build>

  - If not already done, add a reference to the ATL folder in your
    project's build.properties, so that all .atl and .asm files can be
    included inside the jar generated for that particular project
    module, as follows:

`source.. = src/`
`output.. = bin/`
`bin.includes = META-INF/,\`
`.,\`
`ATL/,\`
`plugin.properties`

Some notes:

  - The build section is executed during compilation phase, invoking the
    task<compileATL> defined in AtlCompilerTask.jar This task receives
    as input all references to those files ended with .atl suffix under
    the folder ATL and then starts their compilation, creating their
    equivalent .asm file. It's mandatory that AtlCompilerTask.jar exists
    just before executing the ant script, for this reason the project
    com.x.ant should always be compiled before any project that uses
    ATL.

<!-- end list -->

  - If you have any sort of dependency errors regarding ATL libraries,
    it's most likely that you need to update the MANIFEST.MF file with
    those missing libraries.

Maven reads this file in order to figure out which jars should be
downloaded from the local or remote repositories and then adds them to
the project's classpath. For example your Manifest.MF may need:

`Require-Bundle: org.eclipse.ui,`
`org.eclipse.core.runtime;bundle-version="3.4.0",`
`org.eclipse.core.resources;bundle-version="3.4.2",`
`org.eclipse.m2m.atl.core.emf;bundle-version="3.2.1";visibility:=reexport,`
`org.eclipse.m2m.atl;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.adt;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.adt.debug;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.adt.editor;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.adt.ui;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.cheatsheets;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.common;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.core.ant;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.core.ui;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.core.ui.vm;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.debug.core;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.doc;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.drivers.emf4atl;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.drivers.uml24atl;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.dsls;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.engine;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.engine.emfvm;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.engine.emfvm.launch;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.engine.vm;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.examples;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.profiler.core;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.profiler.emfvm;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.profiler.exportmodel;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.profiler.exportmodel.editor;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.profiler.model;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.profiler.ui;bundle-version="3.2.1",`
`org.eclipse.m2m.atl.profiler.vm;bundle-version="3.2.1"`

<div style="">

</div>

# See Also

<div style="">

  - [Introduction](ATL/User_Guide_-_Introduction "wikilink")

</div>

<div style="">

  - [Overview of the Atlas Transformation
    Language](ATL/User_Guide_-_Overview_of_the_Atlas_Transformation_Language "wikilink")

</div>

<div style="">

  - [The ATL Language](ATL/User_Guide_-_The_ATL_Language "wikilink")

</div>

<div style="">

  - [The ATL Tools](ATL/User_Guide_-_The_ATL_Tools "wikilink")

</div>

[Category:ATL](Category:ATL "wikilink")