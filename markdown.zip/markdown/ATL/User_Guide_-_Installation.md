__FORCETOC__

<div name="Installation">

</div>

# Prerequisites

**Java**

  - Download and [install a
    JVM](Modeling_Project/Installation#Install_a_JVM "wikilink") (JRE or
    JDK), if one is not already installed.
      - for ATL 2.0 or older, JDK 1.4 will work.
      - for ATL 3.0+, you need JDK 5.0 or later

**Eclipse**

  - Download and install
    [Eclipse](IRC_FAQ#Where_can_I_get_Eclipse.3F "wikilink").

**EMF**

  - Install [EMF](EMF/Installation#Install_EMF "wikilink").

# Install ATL

There are two ways to install ATL:

  - via [update site](http://www.eclipse.org/modeling/m2m/updates/)
  - via zip: see [ATL
    Downloads](http://www.eclipse.org/modeling/m2m/downloads/index.php?project=atl).
    Once your zip is downloaded, just unpack it into
      - with Eclipse 3.3, 3.2: \~/eclipse/features/ and
        \~/eclipse/plugins/ folders
      - with Eclipse 3.4+: \~/eclipse/dropins/ folder

Finally, restart Eclipse.

The ATL SDK build enables to:

  - consult documentation offline
  - access ATL examples
  - access the source code of installed ATL plugins

To install ATL from CVS, please refer to the [Developer
Guide](ATL/Developer_Guide#Install_ATL_from_CVS "wikilink").

<div style="">

# See Also

</div>

<div style="">

  - [Introduction](ATL/User_Guide_-_Introduction "wikilink")

</div>

<div style="">

  - [Overview of the Atlas Transformation
    Language](ATL/User_Guide_-_Overview_of_the_Atlas_Transformation_Language "wikilink")

</div>

<div style="">

  - [The ATL Language](ATL/User_Guide_-_The_ATL_Language "wikilink")

</div>

<div style="">

  - [The ATL Tools](ATL/User_Guide_-_The_ATL_Tools "wikilink")

</div>

<div style="">

  - [Building ATL Files With ANT And
    Maven](ATL/User_Guide_-_Building_ATL_With_ANT_And_Maven "wikilink")

</div>

[Category:ATL](Category:ATL "wikilink")