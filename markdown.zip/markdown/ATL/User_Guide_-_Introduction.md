<div name="Introduction">

</div>

ATL is the AtlanMod research group's (Inria, Ecole des Mines de Nantes &
LINA) answer to the [OMG
MOF](http://www.omg.org/docs/formal/02-04-03.pdf)/[QVT
RFP](http://www.omg.org/docs/ad/02-04-10.pdf). It is a model
transformation language specified as both a metamodel and a textual
concrete syntax. In the field of Model-Driven Engineering (MDE), ATL
provides developers with a means to specify the way to produce a number
of target models from a set of source models.

The ATL language is a hybrid of declarative and imperative programming.
The preferred style of transformation writing is the declarative one: it
enables to simply express mappings between the source and target model
elements. However, ATL also provides imperative constructs in order to
ease the specification of mappings that can hardly be expressed
declaratively.

An ATL transformation program is composed of rules that define how
source model elements are matched and navigated to create and initialize
the elements of the target models. Besides basic model transformations,
ATL defines an additional model querying facility that enables to
specify requests onto models. ATL also allows code factorization through
the definition of ATL libraries.

Developed over the Eclipse platform, the [ATL Integrated Development
Environment
(IDE)](http://www.sciences.univ-nantes.fr/lina/atl/bibliography/AllilaireIdrissi0001)
provides a number of standard development tools (syntax highlighting,
debugger, etc.) that aim to ease the design of ATL transformations. The
ATL development environment also offers a number of additional
facilities dedicated to models and metamodels handling. These features
include a simple textual notation dedicated to the specification of
metamodels, but also a number of standard bridges between common textual
syntaxes and their corresponding model representations.

[ATL Installation](ATL/User_Guide_-_Installation "wikilink")

# Contents

  - [ATL Concepts](ATL/Concepts "wikilink") : this section introduces
    you to the **fundamental concepts of model transformation**
  - [ATL
    Overview](ATL/User_Guide_-_Overview_of_the_Atlas_Transformation_Language "wikilink")
    : the section is a description of the **very basic elements of ATL**
  - [The ATL Language](ATL/User_Guide_-_The_ATL_Language "wikilink") :
    this section will provide you the **reference documentation of the
    ATL language**
  - [A catalog of refactorings for ATL
    transformations](http://www.jot.fm/issues/issue_2012_08/article2.pdf)
    : this paper provides a useful set of refactorings for **improving
    the quality of ATL transformations**
  - [ATL Design Patterns](ATL/Design_Patterns "wikilink") : this section
    lists various [design
    patterns](http://en.wikipedia.org/wiki/Software_design_pattern)
    specific to ATL.
  - [The ATL Tools](ATL/User_Guide_-_The_ATL_Tools "wikilink") : this
    section describes the various **practical development tools around
    ATL**
  - [Building ATL Files With ANT And
    Maven](ATL/User_Guide_-_Building_ATL_With_ANT_And_Maven "wikilink")
    : this section describes how to automate the compilation of .atl
    files to .asm files.

[Category:ATL](Category:ATL "wikilink")