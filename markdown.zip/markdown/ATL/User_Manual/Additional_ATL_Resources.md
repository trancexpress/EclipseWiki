ATL developers, beginner as confirmed ones, should find in the present
manual answers to most of the problems they may encounter while either
programming ATL modules or interacting with the ATL development
environment. However, there exist a number of additional ATL resources
that provide detailed information on specific aspects of ATL. This
section provides the ATL developers with a list of these available ATL
resources.

Before starting using the ATL tools, developers are encouraged to
consult the ATL Installation Guide
[\[16](ATL/User_Manual/References#r16 "wikilink")\]. This guide
describes the step-by-step procedures corresponding to the different
available installation modes (e.g., from source code or binaries).

After having installed ATL for the first time, beginner developers may
feel a little bit confused with the different concepts and technologies
on which ATL relies on. The ATL Starter’s Guide
[\[12](ATL/User_Manual/References#r12 "wikilink")\] has been designed
for these beginner developers: it presents the step-by-step design of a
very simple ATL transformation. It progressively introduces, in this
scope, the different functionalities of the ATL IDE.

A number of ATL transformation examples, from varied fields (such as
build tools, bug tracking systems, etc.), are available on the GMT web
site [\[17](ATL/User_Manual/References#r17 "wikilink")\]. This set of
transformations illustrates the use of the different ATL capabilities.
They can be executed as standalone transformations, but also be
integrated in larger transformation chains. Also available from the GMT
web site, the Atlantic Zoo provides a collection of more than one
hundred metamodels specified by means of the KM3 textual notation. These
metamodels can be used for the design of new ATL transformations.

Note that a specific template has been designed to provide a standard
scheme for the description of transformations
[\[20](ATL/User_Manual/References#r20 "wikilink")\]. Developers sharing
the transformations they develop are strongly encouraged to use this
template to specify their transformations.

Available ATL documentation also includes the specification of the ATL
virtual machine [\[21](ATL/User_Manual/References#r21 "wikilink")\].
This specification details the set of instructions on which the ATL
virtual machine implemented by the ATL IDE is based. It also describes
the way the ATL compiler generates the ATL bytecode contained in ASM
file from the code specified in .atl files. This specification can be
used as a reference for developers that are interested in developing an
alternative ATL engine.

The KM3 user manual [\[14](ATL/User_Manual/References#r14 "wikilink")\]
provides an overview of the Kernel MetaMetaModel language. KM3 is a
textual notation dedicated to the specification of metamodels. This user
manual describes both the language textual syntax and its semantics.

Finally, there exists an ATL discussion board
[\[22](ATL/User_Manual/References#r22 "wikilink")\] enabling the ATL
community to share information about the ATL language and its dedicated
development environment. This board is in particular used to announce
the new ATL releases.