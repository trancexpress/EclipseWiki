This manual introduces both the ATL transformation language and the
development environment that was designed for it. In a first part, the
document proposes a brief overview of the model transformation area in
which it introduces the model transformation concepts that are used in
the rest of the manual. In a second part, it provides the complete
reference of the ATL language, describing the syntactic structure of the
different types of ATL units (e.g., ATL modules, queries and libraries).
It also provides a comprehensive overview of the execution semantics of
these different units. The last part of this manual was dedicated to the
description of the ATL development environment.

The reader may have note that both the ATL language and its associated
development environment still suffer from some limitations. As an
example, the ATL compiler does not enable developers to define helpers
or attributes in the context of a collection type. In the same way, the
provided debugger does not allow developers to navigate the content of
the attributes defined in the context of the ATL module. There however
exist some on-going development efforts that aim to correct know
problems and limitations of both the language and its development
environment. Further developments will also provide new functionalities,
in particular by extending the capabilities of the AM3 (ATL MegaModel
Management) component. ATL developers are therefore encouraged to keep
aware of the ATL actuality by means of the ATL discussion board. New
releases of versions, of resources (transformation examples, metamodels,
etc.) and documentations are therefore prioritary announced onto this
dedicated discussion board.