<span id="r1">\[1\]</span> OMG/MOF Meta Object Facility (MOF) 1.4. Final
Adopted Specification Document. formal/02-04-03, 2002.

<span id="r2">\[2\]</span> OMG/RFP/QVT MOF 2.0
Query/Views/Transformations RFP. October 2002.

<span id="r3">\[3\]</span> Allilaire, F., Idrissi, T. ADT: Eclipse
Development Tools for ATL. EWMDA-2, Kent, September 2004.

<span id="r4">\[4\]</span> Budinsky, F., Steinberg, D., Ellersick, R.,
Grose, T. Eclipse Modeling Framework, Chapter 5 ”Ecore Modeling
Concepts”. Addison Wesley Professional. ISBN: 0131425420, 2004.

<span id="r5">\[5\]</span> Budinsky, F., Steinberg, D., Ellersick, R.,
Grose, T. Eclipse Modeling Framework. Addison Wesley Professional. ISBN:
0131425420, 2004.

<span id="r6">\[6\]</span> The ATL Book to Publication transformation.
Available at <http://www.eclipse.org/gmt/atl/atlTransformations/>.

<span id="r7">\[7\]</span> OMG/OCL Object Constraint Language (OCL) 2.0.
OMG Final Adopted Specification. ptc/03-10-14, 2003.

<span id="r8">\[8\]</span> Java regular expressions. Available at
<http://java.sun.com/j2se/1.4.2/docs/api/java/util/regex/Pattern.html#sum>.

<span id="r9">\[9\]</span> Java Map interface. Available at
<http://java.sun.com/j2se/1.4.2/docs/api/java/util/Map.html>.

<span id="r10">\[10\]</span> The ATL EMF to KM3 transformation.
Available at <http://www.eclipse.org/gmt/atl/atlTransformations/>.

<span id="r11">\[11\]</span> The Eclipse project.
<http://www.eclipse.org/>.

<span id="r12">\[12\]</span> The ATL Starter’s Guide. Available at
<http://www.eclipse.org/gmt/atl/doc/>.

<span id="r13">\[13\]</span> The netbeans Metadata Repository (MDR)
project. <http://mdr.netbeans.org/>.

<span id="r14">\[14\]</span> The Kernel MetaMetaModel (KM3) Manual.
Available at <http://www.eclipse.org/gmt/atl/doc/>.

<span id="r15">\[15\]</span> The Atlas MegaModel Management project.
<http://www.eclipse.org/gmt/am3/>.

<span id="r16">\[16\]</span> The ATL Installation Guide. Available at
<http://www.eclipse.org/gmt/atl/doc/>.

<span id="r17">\[17\]</span> The Generative Model Transformer (GMT)
project. <http://eclipse.org/gmt/>.

<span id="r18">\[18\]</span> Gentleware. Poseidon for UML. Available at
<http://gentleware.com/index.php>.

<span id="r19">\[19\]</span> OMG/XMI XML Model Interchange (XMI) OMG
Document AD/98-10-05, October 1998.

<span id="r20">\[20\]</span> The ATL transformation description
template. Available at <http://www.eclipse.org/gmt/atl/doc/>.

<span id="r21">\[21\]</span> Specification of the ATL Virtual Machine.
Available at <http://www.eclipse.org/gmt/atl/doc/>.

<span id="r22">\[22\]</span> The ATL mailing list.
<http://groups.yahoo.com/group/atl_discussion/>.