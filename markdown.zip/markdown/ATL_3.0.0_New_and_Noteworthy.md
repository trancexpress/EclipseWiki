## Galileo Release

The ATL Toolkit is now compatible with Eclipse Galileo (Eclipse 3.5, EMF
2.5). ATL is still compatible with Eclipse 3.4, 3.3 and 3.2.

## ATL IDE

### Wizards

The ATL file wizard has been refactored to improve user guidance when
creating a new ATL file. You can specify metamodels URIs/paths (for
content assist inside the editor) and generate the corresponding launch
configuration. Then, to launch the transformation, you just have to
specify model (input, output) paths in the launch configuration window.

![Image:ATL_file_wizard.png](ATL_file_wizard.png
"Image:ATL_file_wizard.png")

### Code Folding

ATL editor now allows code folding, which can be useful when developing
large ATL files.

![Image:ATL_code_folding.png](ATL_code_folding.png
"Image:ATL_code_folding.png")

### Clickable Execution Traces

ATL3.0.0 provides console hyperlinks which allow to follow errors just
by clicking, as you can see below.

![Image:ATL_execution_trace.png](ATL_execution_trace.png
"Image:ATL_execution_trace.png")

### Launch Shortcuts

ATL IDE implements the Eclipse launch shortcuts API and allows to
directly launch an ATL transformation from its ATL file. When the ATL
editor active page is opened on the file you want to launch, simply do
Ctrl + F11, this will:

  - if you ever defined a launch configuration based on the current
    file: this will automatically launch the matching launch
    configuration
  - if you ever defined several launch configuration based on the
    current file: this will open a dialog which allow to choose which
    configuration you want to launch

![Image:ATL_launch_shortcut.png](ATL_launch_shortcut.png
"Image:ATL_launch_shortcut.png")

  - if there is no launch configuration based on the current file: this
    will initialize a new configuration based on the current ATL file
    and open it to configure paths (models, libraries...).

### Register Metamodel

ATL provides, under the ATL perspective, the "Register Metamodel" action
on .ecore files.

![Image:ATL_register_metamodel.png](ATL_register_metamodel.png
"Image:ATL_register_metamodel.png")

This action reads the .ecore file and registers it into the EMF
Registry. This is useful in the case you only have an ecore file as
metamodel and you don't have the generated EMF plug-ins installed: in
this case usually you can't open models conforming to the ecore
metamodel into the EMF xmi default editor. Using the "Register
Metamodel" action, you will be able to open such models.

### Toggle ATL Nature on projects

ATL perspective provides two new actions available on projects, by
right-clicking: under the ATL perspective, you can now convert any
project to an ATL project. This action adds the ATL nature to the
project, which makes every .atl files inside of the project to be
compiled as a .asm file. You can remove the ATL nature from an ATL
project, regardless of the perspective you are in.

## Core Changes

### API refactoring

ATL API has been refactored in that release, to provide a better support
for:

  - launching transformation from Java code, inside & outside of Eclipse
  - multiple ATL Virtual Machines use
  - HOT (High-Order Transformations) utilities: ATL compilation from an
    ATL model, .atl files parsing, generation

For more details, please refer to the
[documentation](http://wiki.eclipse.org/ATL/Developer_Guide#Core).

### In-place Transformations

ATL refining mode consists on transforming a model itself, only rules
that do not perform simple copy need to be specified, with all bindings
(similar to superimposition but with an implicit copy transformation).
In the first refining mode version, the ATL VM was copying the whole
model to a new one, applying modifications specified by the rules at the
same time. It was not enough efficient and there was no identity
preserving.

In that release, the refining mode works by performing in-place
transformation. It still keeps ATL semantics (i.e., write-only target
model during rule execution) but performs well-enough for interactive
usage and preserves elements identity.

An example of that mode is embedded into ATL SDK, you can install it
from eclipse: **New → Example... → ATL → Public to private Example**

### Ant tasks

ATL now embeds its own set of ant tasks, which are quite similar to the
AM3 ones. The task API is extensible and can be improved to support new
functionalities – or to redo old AM3 ones. [An example of ant
launching](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.m2m/org.eclipse.atl/examples/org.eclipse.m2m.atl.examples.public2private/launch/build.xml?root=Modeling_Project&view=markup)
is integrated into the Public to private Example.