## Introduction

While [ATL](ATL "wikilink") transformation modules and queries are
normally run by themselves, that is one transformation module or query
at a time, it is also possible to superimpose several transformation
modules on top of eachother. The end result is a transformation module
that contains the union of all transformation rules and all helpers,
where it is possible for a transformation module to override rules and
helpers from the transformation modules underneath. Below is an example
of a typical use case for superimposition: the transformation rules of
the UML2Copy
[1](http://ssel.vub.ac.be/viewcvs/viewcvs.py/UML2CaseStudies/uml2cs-transformations/UML2Copy.atl?view=markup)
module are reused and overridden where necessary by the UML2Profiles
[2](http://ssel.vub.ac.be/viewcvs/viewcvs.py/UML2CaseStudies/uml2cs-transformations/UML2Profiles.atl?view=markup)
module.

![Image:ATL_Superimposition-example.png](ATL_Superimposition-example.png
"Image:ATL_Superimposition-example.png")

The UML2Copy transformation module includes a transformation rule for
every meta-class instance it must copy. This amounts to approximately
200 rules for the entire UML2 meta-model
[3](http://ssel.vub.ac.be/viewcvs/viewcvs.py/UML2CaseStudies/uml2cs-transformations/metamodels/UML.ecore?view=markup).
Any refinement transformation basically needs to copy all meta-class
instances, except for the few meta-class instances that are refined. The
UML2Profiles transformation module applies a profile to the “uml::Model”
instance, provided it was not yet applied. All other elements should
just be copied. To achieve this, the UML2Profiles module is superimposed
on the UML2Copy module. It overrides the “Model” rule, which copies each
“uml::Model” instance, by a version that checks that the profile we want
to apply has already been applied. It also introduces a new rule
“ModelProfile”, which checks that the profile we want to apply has not
been applied and then applies the profile. The resulting transformation
contains all rules from the above figure that have not been striked
through. Note that superimposition is a load-time construct: there is no
real transformation module that represents the result of superimposing
several modules on top of eachother. Instead, several modules are simply
loaded on top of eachother, overriding existing rules and adding new
rules.

## Using superimposition

ATL Superimposition is configured in the Eclipse "Run..." dialog, in the
Advanced tab to be exact. Below are a few screenshots. You can also use
Superimposition from AM3 Ant scripts. An example Ant script can be found
at
[4](http://ssel.vub.ac.be/viewcvs/viewcvs.py/UML2CaseStudies/uml2cs-instantmessenger-model/outmodels/common/build.xml?rev=5633&view=markup)
(see the "profiles" macro).

See also the [ATL FAQ entry on
Superimposition](ATL_FAQ#What.27s_this_ATL_feature_called_.22superimposition.22.3F "wikilink").

![475 px](ATL_Run_UML2Profiles-common.png "475 px")

![475 px](ATL_Run_UML2Profiles-models.png "475 px")

![475 px](ATL_Run_UML2Profiles-advanced.png "475 px")

[Category:ATL](Category:ATL "wikilink")