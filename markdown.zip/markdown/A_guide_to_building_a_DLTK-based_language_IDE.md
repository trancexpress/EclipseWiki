## Summary

This tutorial describes the set of steps to create an integrated
development environment (IDE) for a dynamically-typed language using
Eclipse Dynamic Languages Toolkit (DLTK). In this tutorial we will make
a simple IDE for Python language.

## Skeleton

At this step we'll build a skeleton for our IDE. Skeleton includes empty
structure parser, content type, declaration of python language to DLTK.
And we also create Python Project wizards, and support of python
interpreter.

[Step 1: Skeleton](DLTK_IDE_Guide:Step_1_Skeleton "wikilink")

## Towards an Editor

At this step we'll add source code parser to the project and implement
source code editor with syntax highlighting.

As a result our IDE will receive basic source editing and project
navigation capabilities. This would include Code Outline, Editor with
code folding and syntax highlighting, editor preference pages and Source
module structure shown in the Script Explorer.

[Step 2. Towards an
Editor](DLTK_IDE_Guide:Step_2._Towards_an_Editor "wikilink")

## Towards an IDE

The step will show how to add search capabilities (search for
Declarations, for References), implement "Open Type" action and "Goto
Declaration" feature. We'll add basic code assistance (completion on
keywords, and code templates support).

[Step 3. Towards an
IDE](DLTK_IDE_Guide:Step_3._Towards_an_IDE "wikilink")

[Category:DLTK](Category:DLTK "wikilink")