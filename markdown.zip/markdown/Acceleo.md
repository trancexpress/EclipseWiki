![Acceleo.png](Acceleo.png "Acceleo.png")

[Acceleo 3](http://www.eclipse.org/acceleo) is a code generator
implementing of the [OMG's Model-to-text
specification](http://www.omg.org/spec/MOFM2T/1.0/). It supports the
developer with most of the [features](Acceleo/Features "wikilink") that
can be expected from a top quality code generator IDE: simple syntax,
efficient code generation, advanced tooling, features on par with the
JDT... Acceleo help the developer to handle the lifecycle of its code
generators. Thanks to a prototype based approach, you can quickly and
easily create your first generator from the source code of an existing
prototype, then with all the features of the Acceleo tooling like the
[refactoring tools](Acceleo/Acceleo_Editor#Refactoring "wikilink") you
will easily improve your generator to realize a full fledged code
generator.

<div style="float:left; width:54.5%;">

![Logo_obeo.png](Logo_obeo.png "Logo_obeo.png")Acceleo is an Eclipse
based product created and developed by the Eclipse Strategic Member
[Obeo](http://www.obeo.fr/index.php?lang=en). It is included in the
Eclipse release train since Eclipse 3.6 Helios.

Acceleo.org was created in 2005, and as the time goes, the Team has been
more and more convinced that the MOF Model To Text OMG specification was
the way to go for the project. We started to code a reference
implementation for the standard within the Eclipse M2T project. We have
managed to provide nice tooling, simple syntax and efficient code
generation with all the pragmatism we had about Acceleo.org. There
aren't a lot of differences between the old version of acceleo and the
new one.

We are confident that the Acceleo community gain value from moving to a
self hosted project to an Eclipse one, and that end users will follow
the transfert from Acceleo.org to Eclipse.org as we will provide the
same level of functionnalities and we will insure an interoperability
between the old syntax and the new syntax (the standard one).

The Acceleo Team will continue to maintain the old syntax of Acceleo
outside of eclipse (www.acceleo.org ) for a couple of years, but the new
versions and the new features will take place on Eclipse.org. In the
next release you'll have an automated tooling helping you to migrate
your templates from a syntax to another.

For Acceleo lover, you will find in Eclipse Acceleo everything you have
loved in the Acceleo.org version and more (the standard compliance with
more documentation). This specification is really a good one :
<http://www.omg.org/spec/MOFM2T/1.0>

On this wiki, you will also find links to Acceleo
[tutorials](Acceleo/Tutorials "wikilink") in which beginner will be able
to see some concrete use case of code generation and acquire good
practices for the realization of Acceleo generators. People already
familiar with Acceleo will be able to learn some tricks and to discover
the brand new features of the new versions of Acceleo.

</div>

<div style="float:right; width:45%">

Acceleo has been created with the objective of having the best tooling
possible to generate code. As such, Acceleo possess several key features
like an editor with syntax highlighting, errors detection, completion,
refactoring etc. This editor is coupled with a traceability API which
can be leveraged to see the elements from its input models and the
region of its generators that have been involved in the generation of a
selected element. The features available in Acceleo can be found
[here](Acceleo/Features "wikilink"). On this page, you can also find
some of the exciting new features that we want to bring in the next
release of Acceleo.

Documentation for Acceleo is composed of a [User
Guide](Acceleo/User_Guide "wikilink") and the operations reference for
the [Acceleo library](Acceleo/Acceleo_Operations_Reference "wikilink")
and the [OCL library](Acceleo/OCL_Operations_Reference "wikilink"). The
operations reference is also included in the Help Content of Eclipse; in
your Eclipse, go to Help =\> Help Contents and navigate to the Acceleo
Model To Text section. The very same help is accessible online on the
[Eclipse help
center](https://help.eclipse.org/topic/org.eclipse.acceleo.doc/pages/index.html?cp=5).
The documentation for the Acceleo Query Language (AQL) used with Sirius
[is published here](https://www.eclipse.org/acceleo/documentation/)

![Community.png](Community.png "Community.png") Acceleo is an Eclipse
based generator but it is also a community, and you can find the Acceleo
community on the [forums](Acceleo/Forums "wikilink").

![Video.png](Video.png "Video.png") You will find on this wiki some
[videos](Acceleo/Videos "wikilink") of Acceleo
[presentations](Acceleo/Presentations "wikilink") and
[tutorials](Acceleo/Tutorials "wikilink") realized by members of the
Acceleo dev' team or users of Acceleo. During those videos you will be
able to all the features of the new versions of Acceleo and good
practices for the realization of code generators. You will also find
links to powerpoint or pdf presentation of Acceleo created for Eclipse
conferences.

</div>

[Category:Modeling](Category:Modeling "wikilink")
[Category:M2T](Category:M2T "wikilink")
[Category:Acceleo](Category:Acceleo "wikilink")