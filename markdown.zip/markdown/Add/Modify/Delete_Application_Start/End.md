Application Start:

  - [Add Application Start](Add_Application_Start "wikilink")
  - [Modify Application Start](Modify_Application_Start "wikilink")
  - [Delete Application Start](Delete_Application_Start "wikilink")

Application End:

  - [Add Application End](Add_Application_End "wikilink")
  - [Delete Application End](Delete_Application_End "wikilink")