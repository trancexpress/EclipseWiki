  - [Add Operation Triggering](Add_Operation_Triggering "wikilink")
  - [Modify Operation
    Triggering](Modify_Operation_Triggering "wikilink")
  - [Delete Operation
    Triggering](Delete_Operation_Triggering "wikilink")