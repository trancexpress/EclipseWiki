[Aperi Wiki
Home](http://wiki.eclipse.org/index.php/Aperi_Storage_Management_Project)
[Aperi Community
Meetings](http://wiki.eclipse.org/Aperi_Community_Meetings)

## Agenda

<FONT COLOR=maroon>

1.  Marketing - Close on SNW booth status/items
2.  Roadmap Closure - Discuss approved roadmap and review items and
    timelines
    [slides](http://wiki.eclipse.org/images/3/3b/Aperi_Community_Call_032708-arh.pdf)
3.  Workgroup Update - Summary of where we are for the workgroups:
    Launch in Context Standardisation, Production Ready Task Force and
    CMDB Integration. In each section we will discuss a quick status,
    describe the current activities, and provide insight into the next
    steps that we'll be taking (along with rough
    milestones)[slides](http://wiki.eclipse.org/Image:Microsoft_PowerPoint_-_Marketing_Call_2008-03-27.pdf)

## Attendees:

| Company    | Attendees                                                                       |
| ---------- | ------------------------------------------------------------------------------- |
| Brocade    | <FONT COLOR="maroon">Absent</FONT>                                              |
| CA         | <FONT COLOR="maroon">Absent</FONT>                                              |
| Cisco      | <FONT COLOR="maroon">Absent</FONT>                                              |
| Emulex     | <FONT COLOR="maroon">Absent</FONT>                                              |
| LSI        | <FONT COLOR="maroon">Absent</FONT>                                              |
| Fujitsu    | <FONT COLOR="teal">Hiroshi Yoshida</FONT>                                       |
| IBM        | <FONT COLOR="teal">Russ Warren, Allen Marin, Martine Wedlake, Al Heitman</FONT> |
| NetApp     | <FONT COLOR="teal">John Tyrell</FONT>                                           |
| Novell     | <FONT COLOR="maroon">Absent</FONT>                                              |
| YottaYotta | <FONT COLOR="teal">Javier Lozano</FONT>                                         |

## Minutes

<FONT COLOR=black> **Marketing- discuss upcoming Storage Network World
(Orlando) plans and status** – Allen Marin

  - Refer to [SNW Planning
    Dashboard](http://wiki.eclipse.org/images/2/2f/SNW_Dashboard.pdf)
  - Allen still needs to order internet connectivity. He’s working on a
    FAQ and still needs to complete the booth assignments. Allen will
    order the promo items and has some left over tee shirts to hand out.
    Question came up about Aperi member get-together, may do something
    informal. There was a suggestion to meet at the Aperi SNW booth at
    8:30 PM or so on Tuesday.

''' Roadmap Closure - Discuss approved roadmap and review items and
timelines ''' - Al Heitman

  - Refer to
    [slides](http://wiki.eclipse.org/images/3/3b/Aperi_Community_Call_032708-arh.pdf)
  - Slide 3 shows that we completed the roadmap update process. Voting
    ended last Monday and the roadmap update was approved on 3/25. Al
    thanked all the committers who voted and the other community members
    that provided input, comments, and suggestions.
  - Slide 4 shows updated roadmap.
      - Novell is working on Linux HA Cluster support. Aperi will make
        this available in a point release off of SRM milestone 4 rather
        than waiting until milestone 5 which has shifted out to 1Q09.
      - Also in 2Q08, Brocade is contributing a Virtual Fabric / FC
        security spec.
      - To improve interoperability between the Aperi SRM application
        and vendor product management applications, Aperi is developing
        a Launch In Context (LIC) and Single Sign On (SSO) support. This
        will really help users during process workflows. This
        development is broken into a 3 phased approach. Phase 1, which
        is planned for 2Q08, is to develop and release the architecture
        document along with specifications for the launch descriptor
        files, the APIs, and inter-application data exchange. This will
        allow vendors who wish to enable their product management
        application for 3rd party Launch In Context and Single Sign On
        to start their design work. Phase 2, which is targeted for 3Q08,
        is to provide a prototype using SSO and LIC along with a unit
        test framework. This will allow vendors that are enabling their
        product management applications to use this prototype and unit
        test framework to develop and test their applications. Finally
        Phase 3, is to enable LIC/SSO in the Aperi SRM application and
        exploit at least one management application. This is targeted
        for the milestone 5 delivery. Other work items for milestone 5
        are to remove the Java Help dependency by moving to an eclipse
        based help system. Also, we need to upgrade the publications and
        helps for all the new functions and run a full regression test
        and IDVT.
      - In the last Aperi development team meeting, some enhancements to
        the SAN Simulator were discussed. The next release will include
        support for ESS CIM control calls rather than just the querying
        type calls. Some other enhancements include support for the
        Derby database, support of more than a single database instance
        and support for new releases of IBM DS 6000 and 8000 Enterprise
        Storage Servers. We will be putting out milestone 2 release of
        the SAN Simulator. The goal would be to have this available in
        2Q08 as well. Large contributions, such as this, need to be
        reviewed and approved by the committer community so Ramani and
        Al will be reviewing and voting on this contribute in the next
        several weeks.
  - Also in the next couple of weeks, Al will be developing the detailed
    schedule around all these deliveries. Al has been communication with
    most of the developers who are engaged with the roadmap workitems.
    He plans to continue this schedule work and have it ready for
    roll-out next month.
  - Russ would like to have a working prototype which demonstrates the
    LIC/SSO for the fall SNW. Fall SNW is usually in October.
  - Al mentioned that there was a spike in downloads after the SMI Scale
    Fest demo that Hans and Ramani put together.
  - Ramani has taken SAN Simulator snapshot of the Scale Fest setup and
    is massaging the data.
  - Al pointed anyone interested in the updated download charts to the
    backup section of the slides.

''' Open Software and Standards Projects - discuss workgroups and
timelines, discuss COSMOS project/Aperi involvement ''' - Martine
Wedlake

  - Martine discussed several workgroups, their purpose and timelines.
    Refer to [Aperi Open Standards
    Worgroups](http://wiki.eclipse.org/Aperi_Open_Standards_Workgroups)
      - Aperi Launch in Context Enablement Workgroup – formed to create
        standard mechanism to enable registration and discovery of
        device launch points - [Aperi Launch In Context Enablement
        Workgroup](http://wiki.eclipse.org/Aperi_Launch_in_Context_Enablement_Workgroup)
      - Production Ready Task Force Workgroup – formed to work with SNIA
        PRTF to improve CIM/SMI-S to meet the needs fo real-world
        solution [Aperi SNIA Production Ready Task Force
        Workgroup](http://wiki.eclipse.org/Aperi_SNIA_Production_Ready_Task_Force_Workgroup)
      - Aperi CMDB Integration – formed to work with CMDB federation and
        COSMOS to help define CMDB structure and interfaces leveraging
        our experiences with the Aperi repository[Aperi CMDB Integration
        Workgroup](http://wiki.eclipse.org/Aperi_CMDB_Integration)
      - Martine went through his
        [slides](http://wiki.eclipse.org/Image:Microsoft_PowerPoint_-_Marketing_Call_2008-03-27.pdf).
        Some highlighted points below:
          - Slide 2 is overall status.
          - Martine highlighted that if you cannot participate in the
            call, you can make use of the work pages to contribute. You
            can update them with your input or ideas at anytime.
          - For the COSMOS/Aperi, we need phase 3 before it is
            interesting.
          - Russ would like to see a demo of Aperi with Cosmos. Cosmos
            attracts more enterprise management customers so it would be
            good to show how Aperi fits in.
          - Fujitsu indicated interest in COSMOS.

**NOTE: For the next community meeting Russ will schedule it one hour
later.**

## Action items:

  - Allen will work with SNW participants to fill in schedule for
    manning the SNW booth for Spring SNW.
  - Russ will set up next meeting and send out invitations. NOTE: the
    new meeting time will be 1 hour later.