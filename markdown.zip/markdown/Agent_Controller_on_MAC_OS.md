This page is intended to document the process of Agent Controller (AC)
on MAC OS X support.

TPTP [Bug 68111](https://bugs.eclipse.org/bugs/show_bug.cgi?id=68111)has
been opened to track the process of AC development for MAC OX Support.
This page is created to help users and developers to understand the
status of the development, also as a center place for AC developers for
resources on the development.
\[**HELP WANTED**\] The development of MAC OX support depends largely on
community contribution to move forward. A copy of the latest build is
made available on this page to help interested party to start the
development process. Technical discussion and questions can be raised
and will be answered in TPTP Bug 68111.


## Download

Agent Controller for MAC OS X
[Download](http://www.eclipse.org/downloads/download.php?file=/tptp/macos/dev/ac_mac_osx104_TPTP462_20091020.zip)
 **Note**: This is not a fully function Agent Controller for MAC OS X
and it is provided AS-IS. It was built based on the latest CVS code base
and it is made available for evaluation and development purpose.



<table>
<tbody>
<tr class="odd">
<td><p><strong>Component<br />
</strong></p></td>
<td><p><strong>Progress</strong><br />
</p></td>
<td><p><strong>Notes</strong><br />
</p></td>
</tr>
<tr class="even">
<td><p>org.eclipse.tptp.platform.agentcontroller<br />
</p></td>
<td><p>Partially Ported<br />
</p></td>
<td><p>It builds and runs, some functionality is working.<br />
</p></td>
</tr>
<tr class="odd">
<td><p>org.eclipse.hyades.probekit<br />
</p></td>
<td><p>Not Yet Ported<br />
</p></td>
<td><p><br />
</p></td>
</tr>
<tr class="even">
<td><p>org.eclipse.tptp.platform.jvmti.runtime<br />
</p></td>
<td><p>Not Yet Ported<br />
</p></td>
<td><p><br />
</p></td>
</tr>
<tr class="odd">
<td><p>org.apache.harmony_vmcore_verifier<br />
</p></td>
<td><p>Not Yet Ported<br />
</p></td>
<td><p><br />
</p></td>
</tr>
</tbody>
</table>




## HowTo : Building AC on MAC OS X

Environment configuration script
[Download](http://www.eclipse.org/downloads/download.php?file=/tptp/macos/dev/env-run.sh)
(Right-click to *Save*)
The script above requires update on the first three environment
varilables to fit the development environmet:

    HOME_DIR=/Users/pklicnik/Desktop/racporthead/finalac
    JAVA_HOME=/System/Library/Frameworks/JavaVM.framework/Versions/CurrentJDK
    XERCESC_HOME=$HOME_DIR/xerces-c_2_8_0-x86-macosx-gcc_4_0

\[To be completed\]

## Resources

\[To Be Completed\]