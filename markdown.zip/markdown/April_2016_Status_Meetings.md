### 20160404

Andrew - Working on getting parser generator to create plugin
structure.
Robert - Working on ParaView documentation and bugs.

### 20160405

Jay - Fixed icon bugs in reflectivity bundle. Buidling binaries and
finishing up documentation.
Greg - Worked on PTP.
Andrew - Working on code generator for the parser generator.
Robert - Working on VisIt bugs and getting ParaView to launch from
ICE.

### 20160406

Robert - Getting ParaView to launch from within ICE.

### 20160407

Robert - Finishing up ParaView launch for internal web browser and the
Points Gaussian bug.
Ksenia - Testing ICE for bugs.

### 20160411

Greg - Working on ICE tutorial, reviewing various parts to check they
work.
Andrew - Working on the writer for the parser generator.
Robert - Creating demo bundle for Visualization tutorial.

### 20160415

Greg - Working on p2 site installation problems.
Andrew - Working on project generation bugs.
Robert - Working on ParaView bugs.
Ksenia - Fixing path problem for VisIt on Mac.

### 20160418

Greg - Trying to get the EAVP build working.
Andrew - Working on bug fixes.
Robert - Working on button controls for ParaView plot.

### 20160419

Jay - Working on various bug fixes and project planning.
Andrew - Updating the installer, continuing work on generated
reader/writer code.
Greg - Working on EAVP build.
Robert - Working on various EAVP bugs.

### 20160420

Jay - Working on tests with Ksenia.
Robert - Working on bugs/improvements for connections.
Ksenia - Working on EAVP bugs and learning about test writing.

### 20160421

Jay - Finishing bugs and documentation on reflectivity simulator.
Meeting with ParaView development team.
Greg - Working on p2 repository with Tycho.
Robert - Working on bugs and for Visit and ParaView
Andrew - Testing installer updates for Mac and Windows.

### 20160425

Greg - Working on repository problem.
Robert - Working on enabling JAXB for EAVP datastructures.
Andrew - Improving the way ICE traverses the parser syntax tree.

### 20160426

Jay - Looking at ICE for CADES. Might work on reflectivity.
Greg - Investigating repo plugin structure using JBoss plugin.
Robert - Working on JaxB support for EAVP structures.
Andrew - Improving the way ICE traverses the parser syntax tree.

### 20160427

Jay - Working on reflectivity build.
Greg - Continuing work on repos, following up on issue with Titan
account.
Robert - Working on redesigned xml structure for JAXB persistence
Ksenia - Working with bugs from GitHub issues.

### 20160429

Greg - Finishing up repo.
Robert - Working on improving structure of xml files for EAVP JAXB.
Ksenia - Working on bugs.