The ArCon project proposal is under review

The proposed improvements below will be done before the end of 2014 and
are for Ericsson in the context of Polarsys.

[ArCon](http://www.eclipse.org/arcon/) is currently undergoing
incubation under the [Technology](Technology "wikilink") top-level
project.

## Introduction

ArCon is a tool for architecture conformance validation of systems
modelled in UML/SysML. ArCon can provide an easy to use and intuitive
way of specifying architectural rules and a mechanism to automatically
validate that the system under development conforms to the rules
specified. ArCon can validate a model and detect errors in the models
breaking the defined rules.

## Ongoing work

1\. Improve ArCon user documentation

2\. Eclipse online help

3\. Improve robustness for handling erroneous models

4\. Integrate Command line start and GUI based online check

5\. Generate architecture document

6\. Multiple stereotypes handling

7\. Be integrated with Luna

8\. Expand functionality for check of meta properties of model elements

9\. Improve ability to express arbitrary rules

10\. Generate profile from multiple architecture models

## Activities 2013

1\. Be able to read combined architecture models

2\. Enable selection of model scope for analysis

3\. Enable command line start

4\. Perform proactive online check

5\. Provide domain specific modeling support based on the architecture
(meta) model

6\. Enable generation of architecture documentation

7\. Be able to create profile from architecture model

8\. Be able to handle one or more stereotypes for rule activation

9\. Be able to follow dependency to active architecture model

10\. Handle different severity levels

11\. Be able to filter warnings

12\. Be integrated with Kepler

13\. Provide infrastructure to express arbitrary rules (e.g. not
possible to express with ArCon static analysis)

14\. Display warning markers in model browser

## ![<File:arcon_logo_2.png>](arcon_logo_2.png "File:arcon_logo_2.png")rCon

![<File:ArCon.jpg>](ArCon.jpg "File:ArCon.jpg")

[Category:Eclipse Project](Category:Eclipse_Project "wikilink")