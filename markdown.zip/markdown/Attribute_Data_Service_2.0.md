{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}

See
<http://wiki.eclipse.org/Personal_Data_Service_Overview#Attribute_Data_Service>

[Category:Higgins 2](Category:Higgins_2 "wikilink")