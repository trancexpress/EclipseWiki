# Eclipse Automotive Tool Platform

This is work package 1 of the [Automotive Industry Working
Group](Automotive_Industry_Working_Group "wikilink").

  - WP Lead: Bosch (TBD)

## Intent

One key activity of the Eclipse Automotive IWG is to define and provide
an Eclipse Automotive Tool Platform consisting of selected existing
Eclipse components that are typically required and used in the
automotive industry. The intention of this platform is to provide a
reference for both vendors and users of Eclipse-based automotive
software design tools. It does not necessarily include much content that
is really specific to automotive (at least not at the beginning), but
will still be a great deal of help for the following reasons:

  - It points out which Eclipse projects and components are actively
    used in the automotive industry.
  - It gives an orientation regarding the Eclipse releases and component
    versions which Eclipse-based automotive software design tools are or
    should be based on.
  - It provides a reference enabling Eclipse-based automotive software
    design tools to be provided as pluggable components (update sites),
    as opposed to being shipped only in the form of complete products
    including the tool itself and the whole Eclipse Automotive Tool
    Platform.
  - It provides the basis for reliably and consistently integrating
    Eclipse-based automotive software design tools from different
    vendors and/or complementary in-house tools to user-defined design
    tool chains.
  - It is complemented by a cross-organizational strategy in order to
    support a development philosophy sustainable over years by defining
      - when and how often the Eclipse Automotive Tool Platform should
        updated to newer versions of Eclipse
      - for how long older versions of the Eclipse Automotive Tool
        Platform should be actively supported

The intention is to provide a platform to build automotive tools upon,
not to prescribe solutions. There might be optional addons to this
platform providing solutions for specific application fields.

## Concept

The Eclipse Automotive Tool Platform will be made available in the
following forms:

  - An Eclipse package named **Eclipse IDE for Automotive Software
    Developers** for download at
    [Eclipse.org](http://eclipse.org/downloads/index-developer.php)
  - A corresponding target platform definition for download at
    [EclipseLabs.org](https://code.google.com/a/eclipselabs.org/p/eclipse-auto-iwg/)

The downloadable packages may not contain all parts of the Eclipse
Automotive Tool Platform due to license issues, only EPL licensed
components can be shipped as part of an Eclipse.org distribution.

The Eclipse IDE for Automotive Software Developers is meant to address
the following use cases:

  - As is usage for working on embedded automotive control software
  - Base platform for composing user-defined automotive software design
    tool chains out of vendor-provided tools and complementary in-house
    tools
  - Reference platform for testing automotive software design tools
    being shipped as pluggable components (update sites)

The target platform definition is provided to support the following use
cases:

  - As is usage as target platform for the development of automotive
    software design tools
  - Starting point for defining target platforms for the development of
    automotive software design tools that include all Eclipse Automotive
    Tool Platform components and complementary components from the
    Eclipse ecosystem

## Compatibility

The Eclipse Automotive Tool Platform defines the notion of compatibility
with the platform which could be, e.g., used as a label for tool
marketing. There are two different roles for being compatible with the
Eclipse Automotive Tool Platform.

  - Tool vendors are compatible if their tools run on all currently
    supported Eclipse Automotive Tool Platform, i.e., it has to be
    validated that based on a target with all components defined below
    the tool runs without incompatibilities or defects.
  - Platform users are compatible if they use one of the currently
    supported Eclipse Automotive Tool Platform completely or in parts.

The criteria for being a platform user is that such an organization
distributes a whole Eclipse application and therefore is in control of
the Eclipse version to be used. Tool vendors provide tools as
components, e.g., as update sites, which are integrated into an Eclipse
instance by customers.

The Eclipse Automotive Tool Platform does not make any assumption
concerning operating system. Although the platform is independent on an
operating system, tools compatible to the platform might state further
restrictions on operating system without becoming incompatible. The
restriction on operating system has to be stated explicitly by the tool
vendor.

## Content

The Eclipse Automotive Tool Platform contains mainly EPL licensed
components out of the Eclipse release train. There are some projects
involved which are in incubating state and with Artop currently one
component licensed under the Artop Software License Based on Released
AUTOSAR Material (ASLR). Components under a different license than EPL
can only be linked and not provided directly as part of the Eclipse
Automotive Tool Platform.

The Eclipse Automotive Tool Platform is build of Eclipse projects and
other projects which are described in the corresponding platform version
page by name, version, status, and an optional comment. For the sake of
a better overview, the components are grouped in categories. The
component statuses can have the following values:

  - RECOMMENDED: The component is included in the Eclipse Automotive
    Tool Platform and recommended to be used for the development of in
    automotive software design tools or applications. It is also the
    preferred solution in case of multiple projects providing similar
    functionality. It has proven that it is a stable part of the Eclipse
    Ecosystem and it is not expected that it will cease support in the
    foreseeable time.
  - DEPRECATED: The component is still included in the Eclipse
    Automotive Tool Platform to ensure backward compatibility but no
    longer recommended to be used in new automotive software design
    tools or applications. There is a good reason, e.g., the component
    is not maintained anymore and there is a risk that it becomes
    incompatible with future versions of the platform.
  - INCUBATING: The component is proposed to become a new component of
    the Eclipse Automotive Tool Platform and already included for
    evaluation purposes. With such a component there is a higher risk
    that it will not make it to a stable part of the Eclipse Ecosystem.

To the best knowledge the components within the Eclipse Automotive Tool
Platform can be used in parallel without incompatibility. If an issue
arises concerning compatibility the platform will be adapted to achieve
again a state that components are compatible.

The Eclipse Automotive Tools Platform is a recommendation of Open Source
Components which have legal obligations and which are managed concerning
ip legality of the content. The platform does not take any
responsibilities on the content of the packages which still might have
ip issues. Using the Eclipse Automotive Tool Platform requires to keep
all obligations implies by the licenses of the contained components.

### Current Eclipse Automotive Tool Platforms

  - [Eclipse Automotive Tool Platform for Kepler (Eclipse
    4.3)](Eclipse_Automotive_Tool_Platform_for_Kepler_\(Eclipse_4.3\) "wikilink")

### Preliminary Eclipse Automotive Tool Platforms

  - [Eclipse Automotive Tool Platform for Luna (Eclipse
    4.4)](Eclipse_Automotive_Tool_Platform_for_Luna_\(Eclipse_4.4\) "wikilink")

### Deprecated Eclipse Automotive Tool Platforms

  - [Eclipse Automotive Tool Platform for Juno (Eclipse
    4.2)](Eclipse_Automotive_Tool_Platform_for_Juno_\(Eclipse_4.2\) "wikilink")
  - [Eclipse Automotive Tool Platform for Indigo (Eclipse
    3.7)](Eclipse_Automotive_Tool_Platform_for_Indigo_\(Eclipse_3.7\) "wikilink")

## Update, Maintenance & Migration Strategy

  - The Eclipse Automotive Tools Platform always comprises the two
    recent versions of the Eclipse release train and matching components
    from non release train projects.
  - There is a delay on the time the in June released Eclipse version
    becomes stable part of the Eclipse Automotive Tool Platform. That is
    the time the SR-2 is released (typically Februar). Until than an
    Eclipse version is a preliminary version to which compatibility is
    recommended but not required.
  - While a version of the Eclipse Automotive Tool Platform becomes
    stable in February, the oldest current version is removed from the
    current Eclipse Automotive Tool Platform versions and moved to the
    historic version section.
  - The Automotive IWG general meeting approves the state changes of
    Eclipse Automotive Tool Platform versions.
  - The versions of components which do not belong to the release train
    are managed in the Automotive IWG general meeting.
  - Content changes, i.e., addition of components, changes of the state
    of a component are managed in the Automotive IWG general meeting,
  - For all issue decided in the Automotive IWG general meeting, a
    proposal for a change is stated as an Agenda point. The meeting
    either decided to approve or reject the proposal or to start a
    coordination process which includes the discussion and improvement
    of the proposal in between the general meetings. The conclusion is
    than presented again in the next general meeting.

## Resources

  - Eclipse IDE for Automotive Software Developers:
    <http://eclipse.org/downloads/index-developer.php>
  - Target platform definitions for Eclipse IDE for Automotive Software
    Developers:
    <http://code.google.com/a/eclipselabs.org/p/eclipse-auto-iwg/downloads/list>
  - Eclipse bugzilla component for Eclipse Automotive IWG:
    <https://bugs.eclipse.org/bugs/buglist.cgi?classification=Eclipse%20Foundation&product=Working%20Groups&component=Automotive>
  - EclipseLabs project providing Git repos and downloads for Eclipse
    Automotive IWG:
    <http://code.google.com/a/eclipselabs.org/p/eclipse-auto-iwg>
  - Eclipse Packaging Project (EPP) bug related to Eclipse IDE for
    Automotive Software Developers:
    <https://bugs.eclipse.org/bugs/show_bug.cgi?id=369763>
  - Eclipse Automotive IDE Test Procedure:
    <http://wiki.eclipse.org/EPP/Package_Testing#Automotive_Package>

## Open Issues

  - Consider adoption of additional components:
      - OSLC/Lyo

[Category:Auto IWG](Category:Auto_IWG "wikilink")