# WP2: Big Model Support

This is work package 2 of the [Automotive Industry Working
Group](Automotive_Industry_Working_Group "wikilink").

  - WP Lead: ITEMIS (S. Eberle)

## Intent

Real world automotive engineering models (e.g., AUTOSAR) tend to become
so big that they are hardly manageable with existing Eclipse technology.
The results of this work package are meant to lay the basis for
significantly improving the scalability of Eclipse-based tools when
handling automotive engineering models as of today and making them proof
for the future where model sizes are expected to grow up even more.

## Concept

### Improvement approach 1: Integration of CDO in Sphinx Workspace Management

[Sphinx](http://www.eclipse.org/sphinx/) is a general purpose integrated
modeling tool platform. It is the basis for the
[Artop](https://www.artop.org/) project which provides a platform for
AUTOSAR design tools. Currently Sphinx (and Artop) are designed to work
on models that are persisted in files. However, when the models
instances become big, i.e, several tens or hundreds of mega bytes, it
becomes very hard to handle them in an efficient way. Long loading
latencies and excessive memory consumption are the almost unavoidable
consequences and give users a rather poor impression of the tool or even
block them from accomplishing their work.

The idea behind this improvement approach is to significantly improve
the situation by leveraging the model repository technology CDO. CDO
enables models to be persisted in locally or remotely located databases
and provides complete support for model version management. A key
enabler for handling big model instances are CDO's advanced memory
management capabilities. They ensure that only the interesting part of a
model gets loaded, support on-demand loading of other models parts later
on, and guarantee that model parts that are no longer needed can be
unloaded and garbage collected. The proposed approach for addressing the
previously mentioned performance problems is to setup and use a local
CDO model repository that is used as platform-internal model cache by
the Sphinx Workspace Management. From the users' point of view the
models will still appear file-based, but Sphinx actually imports/exports
them to/from the CDO-based model cache and Sphinx-based tools use the
latter for performing all editing and processing operations. This way,
Sphinx-based tools automatically benefit from CDO's memory management
capacities and come up with a much better performance when operating on
big models.

[Category:Auto IWG](Category:Auto_IWG "wikilink")