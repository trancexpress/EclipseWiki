## Abstract

Many Eclipse plugins require the user to specify the location of certain
programs or services running locally in order for them to work. Having
humans do this is unnecessary since services are commonly installed in
only a few fixed locations. Thus I propose writing an Eclipse plugin
that uses a number of heuristics to locate local services that other
Eclipse plugins need. I also propose including a number of utilities
that enable developers to easily write, extend, and distribute these
service 'scanners.'

## Proposal

Motivation: Many Eclipse plugins need to interact with programs that are
not part of the Eclipse ecosystem. Plugins such as the Ruby, C/C++, and
PHP Development Tools all require the user to specify the location of a
language interpreter or compiler. Often, this configuration is
unnecessary since, for instance in Linux machines, the GNU C compiler
binary is almost always /usr/bin/gcc. Heuristics like this do not have
to be for programs only. What port will a Web server on your local
machine be running on? Most Likely ports 80 or 8080, so the IDE might as
well scan them and offer you a list of servers with which to debug your
PHP script, for example. All in all, it is possible to automatically
discover the services running on a machine and to automatically
configure other plugins to use these services (think Autoconf for
Eclipse).

Benefits: Once plugin writers start to depend on this
"autoconfiguration", the plugin users will gain 2 things:

1\) It will reduce the time it takes to run "Hello, World" applications
for new plugins. Once the necessary software is installed, click on a
"Detect required services" button will do the configuration for them and
allow them to move on to the interesting task of running applications.

2\) It will reduce the tedium of reconfiguring plugins whenever a newer
version of a program/service is installed, or when setting up a
development environment on a new machine.

Objective: Thus, I propose to write an Eclipse plugin that discovers
services running on a system and then publicizes these services to other
Eclipse plugins using the Prefs API; the services "scan" will be run
whenever Eclipse is started. The plugin will also publish an API for
other plugins to request a scan for particular services even after the
Eclipse has been started.

In addition, I propose creating a mechanism for easily extending these
service "scanners", creating new ones, and publishing the whole lot.
This mechanism will consist of

1\) An interface for viewing all the scanners in an Eclipse
installation,

2\) A utility for packaging scanners into an archive format (perhaps
JAR) so that it can easily be distributed, and

3\) Another utility for unpacking these scanners and installing them.

With these utilities in place, the work of developing recognizers can
continue even after the Summer of Code is over (yay, open source).

How it'll be accomplished: At its core, this plugin will be composed of
a table of service names, each with a list of scanners for that service.
Each scanner returns 0 or more strings representing a resource
identifier. When a plugin requests locations for, say, the gcc compiler,
the scanner plugin runs all the scanners listed under the name "gcc" and
returns it to the requester.

I chose to store a list of scanners so that developers can easily extend
others' work without touching existing code. For instance, If someone
discovers a new heuristic for finding a service, they can write their
own scanner and when it is installed, it will add the list of matches it
finds to the matches found by other scanners.

Note also that I have refrained from using version numbers as an extra
identifier for locating services. This is in following the Autoconf
tradition of testing features and not versions, and will result in a
simpler implementation.

Deliverables:

1\) An eclipse plugin

2\) A manual for the Scanner API

3\) A sample scanner for the common PHPEclipse pre-requisites: Apache,
PHP, and MySQL

4\) Time permitting, scanners for C++ and Java compilers

Milestones: -- Take a stab at recognizing installed services. Weeks 1-3
--

1\. Gather heuristics for locating PHP pre-requisites on different
platforms.

2\. Write a program in Java that reliably finds those required services.
Turn this program into a plugin that publishes its results via the Prefs
API.

3\. Solicit feedback from the good folks at \#eclipse on the efficacy of
the recognizer.

\-- Design the plugin interface. Weeks 4-7 -- 4. Based on work done,
define and implement an API for easily writing recognizers for different
services.

5\. Write utility programs for packing, and unpacking recognizers.

6\. Drop a GUI on the plugin that enables users to manage installed
recognizers.

7\. Release this version of the plugin and solicit feedback.

\-- Debugging and refinement. Weeks 8-12 --

8\. Finish bug-fixes and incorporate ideas from the user feedback.

9\. Time permitting, implement recognizers for Java runtimes and C++
compilers.

If I am accepted to embark on this project, it shall be my sole
occupation for the Summer. I will give my all to it for 40 hours a week,
all 12 weeeks.

Contacts: I have been in contact with the folks at \#eclipse_soc
channel. Philippe Ombredanne (pombreda) initially brought up the idea of
this project and said he would be willing to mentor. Remy Chi Jian Suen
(rchern) read an initial draft of this proposal and suggested
improvements to it.

About Me: I am a first-year computer science Ph.D. student at the
Georgia Institute of Technology (http://www.gatech.edu). My resume is at
<http://www.cs.grin.edu/~nnadioge/ogechi_nnadi_resume.pdf>. I am most
interested in human-computer interaction, especially how programmer's
tools can be made easier to use. It was for this reason that I was drawn
to the Eclipse Summer of Code projects.

I have worked in Java and with Eclipse extensively. I spent Most of last
year designing a Ruby on Rails site (http://www.intermedsonline.com)
using the wonderful RadRails Eclipse plugin. Most of my Java programming
experience comes from a summer research project in which I and 2
teammates designed a P2P Web server.

However, I believe my greatest qualification is that software
architecture just turns me on. I have read the GNU coding standards,
Steve McConnell's "Code Complete" etc. and have found out first-hand how
coding the "Right Way" can enable changes, and produce more
understandable programs. I would love to write even higher quality code
for Eclipse.