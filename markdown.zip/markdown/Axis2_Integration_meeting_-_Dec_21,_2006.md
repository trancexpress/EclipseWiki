## Teleconference on Axis2 Integration into WTP - Dec 21, 2006

### Attendance

  - Chris Brealey \<cbrealey@ca.ibm.com\>
  - Kathy Chan \<kathy@ca.ibm.com\>
  - Lahiru Sandakith \<sandakith@wso2.com\>

### Minutes

  - Any questions/clarification on [Use cases for Axis2 Integration in
    WTP](Use_cases_for_Axis2_Integration_in_WTP "wikilink")?
  - LS: None.

#### Progress with prototyping addition of Axis2 runtime

  - LS: Do we want to limit projects to dynamic Web projects? Do we
    support Java projects?
  - KC: We support Java projects, provided the Web project is wired to
    the Java project and have Java project as the utility JAR and have
    it available during runtime.
  - KC: How far along are you?
  - LS: Got prototype of Web service creation partly working:
      - Defined the Axis2 runtime.
      - Introduced a small page into the wizard.
      - Included controls to change the server port.
      - Can start the service.
      - Working on client.
      - Plugins named org.eclipse.jst.ws.axis2.\*, split between
        ui/non-ui and between consumption and creation.
      - Will supply a patch for the service scenario.
  - KC: Could generate WSDL file and then test with WSE.
  - LS: Axis2 has an option to generate WSDL file during code
    generation.
  - CB: Should expose that as an option. However WSDL generation is not
    a must to use the WSE. You can use the WSE's WSDL Page and enter the
    "?WSDL" style URL to retrieve the WSDL from the Axis2 servlet. The
    more strategic approach, also one of the requirements, is to have
    the WSE locate Axis2 Web services using the Web services Finder
    framework.
  - LS: Should hot update deal with file system or just Eclipse
    workspace?
  - CB: Any operations other than import/export should deal with Eclipse
    workspace.
  - LS: Need pointer to how to use facet.
  - KC: There's a facet tutorial/article available. Here's the link to
    [Extending WTP using project
    facets](http://www.eclipse.org/articles/Article-BuildingProjectFacets/tutorial.html)
  - LS: How do I maintain the change history in the Java comment
    headers?
  - KC: We have a tool to help you do that. We'll send it / attach it to
    the tools section of the Web services Wiki.
  - LS: Are we planning to have a WS perspective?
  - CB: Nope. We don't have any WS specific perspectives or views. Web
    services can be developed from several existing perspectives, the
    J2EE perspective being perhaps the favored one. We need to look into
    manifesting Axis2 services and clients in the Project Explorer.

#### Discussion on general code development process

  - LS: Have developed some code. What's the upload procedure?
  - CB: Three steps:
    1.  Lahiru attaches code to the Bugzillas at regular intervals.
    2.  Chris, at regular but less frequent intervals, conveys attached
        code to Eclipse legal to approve.
    3.  Kathy technically reviews code and commits to CVS.
  - LS: What Eclipse / WTP base should be used for development?
  - KC: Eclipse 3.3 M4 IDE is required to target WTP 2.0 driver built on
    Eclipse 3.3 M4.
  - LS: Should development be done in Java 1.4.2 or Java 5?
  - CB: Though WTP 2.0 will prereq Java 5, we are advised to target
    Eclipse Java projects to J2SE 1.4.2 unless Java 5 exploitation is
    necessary.
  - LH: We don't have any specific dependencies on Java 5.
  - LS: How do I go about testing my own code?
  - CB: JUnits - The more the better. Strictly speaking, public API
    requires full class/method JUnit coverage.
  - KC: We'll need your help to run FVT testcases in the last week or
    two of a milestone.
  - KC: Need to stabilize the code towards the end of the milestone.
    Better to cut or defer function to preserve stability than to cram
    code into the last week or two of a milestone.

#### Requirement discussion

  - Discuss the list of the prioritized requirements for Axis2
    integration in WTP. Are any requirements missing? Is the priority
    about right? What's the rough sizing and a first cut on what could
    be achieved in which milestones?
  - KC: Note that the earliest target milestone in the requirement table
    is M5, not M4. Similarly, M5 should be M6. The [Requirements
    document for Axis2 Integration in
    WTP](Requirements_document_for_Axis2_Integration_in_WTP "wikilink")
    has been updated to reflect the correct target milestones.
  - LH: The order of requirements is about right, as is containability
    in M5. Import AAR should be higher priority than Export AAR, and
    should target M5. This has also been updated in the [requirements
    document](Requirements_document_for_Axis2_Integration_in_WTP "wikilink").
  - KC: Need to fill in sizings for the requirements.
  - LS: Instead of sizings, target dates for the requirements would be
    better. About 80% of my time is available over January and February.
    I'll update the requirements table.

#### Requirements for Axis2 Integration in WTP

Refer to [Requirements document for Axis2 Integration in
WTP](Requirements_document_for_Axis2_Integration_in_WTP "wikilink") for
details.

1.  User can choose the Axis2 runtime via the wizards, pop-up actions
    and Ant tasks to create bottom-up or top-down Java Web services and
    Web service clients fully exploiting the Web services creation
    framework (develop, assemble, deploy, install, start, test):
      - Wizard controls are defaulted based on Axis2 preference page.
      - Only commonly used controls are exposed. More advanced controls
        are hidden under sections, buttons or optional pages.
      - Axis2 code generators read from and write to resources in
        Eclipse workspace directory respecting Web service resource
        management preferences with no manual refresh necessary.
      - If the Web project already contains an existing Axis2 Web
        service, the services.xml is merged with that of the newly
        generated service.
      - Generated artifacts are organized into an exploded AAR for
        deployment to server without the need for an explicit builder to
        build an AAR.
2.  User can set Axis2 preferences in a Web service preferences page.
3.  User can specify which version of Axis2 to use by pointing to an
    Axis2 install location (i.e. not shipping Axis2 Jars in WTP).
4.  User can equip a project for Axis2 development without using the Web
    service wizards (i.e. by adding an Axis2 facet to the project).
5.  User can export an AAR.
6.  User can import an AAR.
7.  User can do hot deployment in which any change to the Java
    implementation class of a deployed Axis2 Web service is
    automatically loaded by the Axis2 servlet.
8.  User can do hot update in which any change to the services.xml file
    or service directory of a deployed Axis2 Web service prompts for or
    causes the servlet to be recycled.
9.  User can discover and test Axis2 Web services under their own
    category via the WSE.
10. User can test Axis2 Web services using automatically generated
    JUnits.
11. User can see Axis2 Web services in a branch of Project Explorer
12. Axis2 Web services and clients (e.g. services.xml) are validated.
13. The Axis2 Web service tools (emitters and wizards) are extensible so
    that support for other Axis2 Modules such as JAX-WS, Sandesha,
    Kandula2 and Rampart can be easily added at a later time.
14. User can test Axis2 Web services using Web services sample JSPs.
15. User can easily add, remove and edit handlers on Axis2 Web services
    and clients using a handler configuration wizard or a services.xml
    editor.
16. User can dynamically locate different versions of Axis2 Web service
    runtimes and tools available to install.