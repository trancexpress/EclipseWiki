## Teleconference on Axis2 Integration into WTP - Feb 22, 2007

### Attendance

  - Chris Brealey
  - Kathy Chan
  - Lahiru Sandakith

### Agenda

  - Progress on the RFEs:
      - [172186](https://bugs.eclipse.org/bugs/show_bug.cgi?id=172186) -
        Client scenario
      - [168765](https://bugs.eclipse.org/bugs/show_bug.cgi?id=168765) -
        User specified Axis2 install location
      - [168766](https://bugs.eclipse.org/bugs/show_bug.cgi?id=168766) -
        Adding Axis2 facet
  - KC: With the latest code submitted to RFE 168765, I can use Axis2
    runtime preference page to install Axis2 runtime (needs to run Ant
    command on <Axis2_install>/webapp directory, I can also add Axis2
    facet in a Web project and run through a bottom-up scenario.
    However, I ran into problems with skeleton and client scenario. See
    RFE 168765 for latest status.
  - Discuss design issues related to Axis2 install location
      - Should use Axis2 binary distribution, not Webapp directory
      - There should not be a need for the user to do an Ant build since
        we should not be copying axis2.war to the project we are adding
        Axis2 facet to.
  - Discuss design issues related to adding Axis2 facet
      - We all agreed that we should not be replacing WebContent when
        adding Axis2 facet, should merge Axis2 servlet with existing
        content.
      - LS: The code is currently not changing Java output directory
        when installing facet.
      - KC: I noticed that in the latest code attachments, hot deploy
        (updating of Java classes that implements the Web service) is
        already working. So this might not be needed.
  - CB: Axis2 facet should not depend on the jst.web facet.
      - KC: Instead, the Axis2 service runtime should require axis2.core
        and jst.web, Axis2 client runtime should either require
        axis2.core and jst.web, or axis2.core and jst.utility (similar
        to Axis1).
  - LS: When Axis2 jars are added to lib/ via the wizard, will the jars
    appear on the build path?
      - CB: Yes. This is handled by resource listeners deep in the WTP
        platform.
  - LS: Can the Axis2 facet ever conflict with other facets and leave a
    project in an inconsistent state?
      - CB: In theory, yes, but it's very unlikely. When a known
        conflict between facets exists, it is expressed in the facet
        extensions.
  - LS: Is it OK if some of my plugins depend on Java 5? If so, do I
    need to write code to handle cases where a user runs Eclipse on a
    Java 1.4.x JRE?
      - CB: Nope. Other components are starting to prereq Java 5 as
        well.
  - KC: Where does the code live?
      - Axis2 runtime management code should live in WST. Eg:
          - Axis2 installation location preferences page.
          - Core utility methods for copying jars from Axis2.
          - Core utility methods for simplifying invocation of the Axis2
            emitters.
      - Axis2 development tools should live in JST, in the axis2.core
        plugin. Eg:
          - Axis2 facet.
          - Axis2 emitter preferences page.
          - Axis2 emitter preference objects.
  - KC: Need to prepare stable bottom-up, top-down and client scenarios
    with user specified Axis2 install location and adding Axis2 facet in
    time for the March 5 EclipseCon. Let's aim at getting a stable
    driver by early next week and tutorial by Wednesday next week.
      - LS: OK. Will have first draft of design document soon too. Will
        attach to wiki.
  - LS: How do we proceed with Eclipse legal's question about the
    obscure "This is the cute way of making the namespaces columns
    editable" comment?
      - CB: You've traced the pedigree of the comment and the code
        around it back to Apache code, however, where that code came
        from isn't clear. Tell Sharon/Janet what you've discovered so
        far. If worse comes to worse, we can do a clean-room (Kathy)
        reimplementation of the suspect code. Remember that we can only
        staple "EPL" on code that (1) you have invented, not copied, and
        (2) you have authorized Eclipse to license (which you've done).
  - Schedule for other M6 RFEs (168937, 168938, 168939)
      - No time to discuss
  - [Outstanding Axis2 RFEs and
    defects](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=Axis2%3A&classification=WebTools&product=Web+Tools&component=jst.ws&component=wst.command&component=wst.ws&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=)
  - Next meeting rescheduled from March 8 to Feb 28 (same time), because
    of EclipseCon.