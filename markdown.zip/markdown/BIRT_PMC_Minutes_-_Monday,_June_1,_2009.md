# Meeting

Monday, June 1, 2009 @ 10am Pacific.

# Attendees

  - Wenfeng Li - BIRT PMC Lead - [Actuate
    Corporation](http://www.actuate.com)
  - Paul Clenahan - BIRT PMC - [Actuate
    Corporation](http://www.actuate.com)
  - Jason Weathersby - BIRT PMC - [Actuate
    Corporation](http://www.actuate.com)
  - Scott Rosenbaum - BIRT PMC - [Innovent
    Solutions](http://www.innoventsolutions.com)

## Unable to Attend

  - Mike Fox - BIRT PMC - [IBM Corporation](http://www.ibm.com)

# BIRT 2.3.2.2 Development

A BIRT 2.3.2.2 Release Candidate was made available for download
yesterday. The Community is encouraged to download the release and
provide feedback.

The [BIRT Project Plan for Release
2.3.2.2](BIRT_Project_Plan_for_Release_2.3.2.2 "wikilink") has been
published and lists the specific issues that we plan to address in this
release.

# BIRT 2.5 Development

BIRT 2.5 RC3 is due to release tomorrow, June 2. No issues to report and
the release is tracking on schedule.

We do not plan to release any further New and Notable documents for the
final Release Candidate builds. We will have a comprehensive New and
Notable for the final release on June 24.

## General Information for BIRT 2.5

BIRT 2.5 is the next major release of the BIRT project. It is part of
the [Galileo Simultaneous
Release](Galileo_Simultaneous_Release "wikilink").

For details on the release, see the [Eclipse BIRT Project Development
Plan
for 2.5](http://www.eclipse.org/projects/project-plan.php?projectid=birt).
The Milestone schedule for the release is available in the timeline
section of the [Galileo Simultaneous
Release](Galileo_Simultaneous_Release "wikilink") page. BIRT is a +2
project in the Galileo release.

For a list of bugs assigned to this release, refer to: [BIRT 2.5 Bugs
assigned in
Bugzilla](https://bugs.eclipse.org/bugs/buglist.cgi?classification=BIRT&product=BIRT&target_milestone=2.5.0&target_milestone=2.5.0+M1&target_milestone=2.5.0+M2&target_milestone=2.5.0+M3&target_milestone=2.5.0+M4&target_milestone=2.5.0+M5&target_milestone=2.5.0+M6&target_milestone=2.5.0+M7&target_milestone=2.5.0+RC0&target_milestone=2.5.0+RC1&target_milestone=2.5.0+RC2&target_milestone=2.5.0+RC3&target_milestone=2.5.0+RC4)

# Events

Webinar Series on BIRT Exchange:

BIRT Exchange has hosted a series of technical webinars on BIRT. For
archived and other upcoming webinars see the [Webinar
Page](http://www.birt-exchange.com/be/news-events/webinars) on BIRT
Exchange.

Other Upcoming Events:

  - [OSCON 2009](http://en.oreilly.com/oscon2009/public/schedule/detail/8256)
    on July 20 - 24, 2009 - San Jose, California - Introduction to BIRT

# Articles

BIRT articles are available on
[1](http://www.birt-exchange.org/devshare/). Check BIRT Exchange
regularly for new articles.

Tips and techniques, demos and other resources can also be found on the
[BIRT Exchange](http://www.birt-exchange.com) community site.

[Category:BIRT](Category:BIRT "wikilink") [Category:BIRT PMC
Minutes](Category:BIRT_PMC_Minutes "wikilink") [Category:BIRT
Project](Category:BIRT_Project "wikilink")