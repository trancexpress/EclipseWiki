## Chart Model

This project aims to provide a model for the BIRT Eclipse Chart Engine

**Specification Lead**

David Michonneau

**Description**

The Chart model is at the core of the Chart library and provides an API
to create and manipulate Charts. It is EMF based.

## Specification Document(s)

  - [General model
    description](http://www.eclipse.org/birt/release20specs/BPS36/BPS36%201.0.1%20Chart%20Model%20SPEC.pdf)
  - [Model Schema Documentation
    v1.0.x](http://www.eclipse.org/birt/release20specs/BPS36/ChartModelDoc%201.0.1/Eclipse%20BIRT%20Chart%20Object%20Model.html)
  - [Model Schema Documentation
    v2.0.x](http://www.eclipse.org/birt/release20specs/BPS36/ChartModelDoc%202.0.0/schema20.html)
  - [Model Schema Documentation
    v2.1.x](http://www.eclipse.org/birt/release20specs/BPS36/ChartModelDoc%202.1.0/schema210.html)
  - [Model Schema Documentation
    v2.2.x](http://www.eclipse.org/birt/release20specs/BPS36/ChartModelDoc%202.2.0/schema220.html)

[Category:BIRT BPS](Category:BIRT_BPS "wikilink")