This code snippet illustrates the connection to an Asset Administration
Shell (AAS) sub model using the Java SDK with the
`ConnectedAssetAdministrationShellManager` class. It illustrates the
connection to a sub model with a known ID, as well as reading and
updating of properties. It also illustrates connection to meta
properties.

The BaSys setup for this code snippet is the following:

|                                                                                                                                                 |
| ----------------------------------------------------------------------------------------------------------------------------------------------- |
| ![BaSyx.Snippet.AASConnectorConnection.Java.png](BaSyx.Snippet.AASConnectorConnection.Java.png "BaSyx.Snippet.AASConnectorConnection.Java.png") |

The BaSys setup consists of a Apache Tomcat server that runs BaSyx
Servlets. It contains a sub model provider that exports an example sub
model (see here for example). The snippet code runs in context of an
application. The application contains the example code and a precompiled
BaSyx directory that is used for resolving AAS and sub model IDs to
network addresses. The application code accesses the AAS sub model:

``` java

// Create manager using the directory stub and the HTTPConnectorProvider
ConnectedAssetAdministrationShellManager manager = new ConnectedAssetAdministrationShellManager(registry,
    // We connect via HTTP
    new HTTPConnectorProvider());


// Retrieve sub model (created by factory) with SDK connector
// - Create and connect SDK connector
IIdentifier aasId = new Identifier(IdentifierType.CUSTOM, "aas-001");
IIdentifier smId = new Identifier(IdentifierType.CUSTOM, "sm-001");
ISubModel subModel = manager.retrieveSubModel(aasId, smId);

// - Retrieve sub model values and compare to expected values
Map<String, ISubmodelElement> smElements = subModel.getSubmodelElements();
IProperty prop1 = (IProperty) smElements.get("prop1");
ISubmodelElementCollection prop2 = (ISubmodelElementCollection) smElements.get("prop2");
IProperty prop11 = (IProperty) prop2.getProperties().get("prop11");
IProperty prop3 = (IProperty) smElements.get("prop3");

assertEquals(smId.getId(), subModel.getIdentification().getId());
assertEquals("smName", subModel.getIdShort());
assertEquals("prop1", prop1.getIdShort());
assertEquals(234, prop1.get());
assertEquals("prop2", prop2.getIdShort());
assertEquals("prop11", prop11.getIdShort());
assertEquals(123, prop11.get());
assertEquals("prop3", prop3.getIdShort());
assertEquals(17, prop3.get());
```

The code first creates a connected Asset Administration Shell manager
that creates connections to Asset Administration Shells and AAS sub
models. It uses a ConnectionManager class to create the connection and
to resolve AAS and sub model IDs:

``` java
// Create manager using the directory stub and the HTTPConnectorProvider
ConnectedAssetAdministrationShellManager manager = new ConnectedAssetAdministrationShellManager(registry,
    // We connect via HTTP
    new HTTPConnectorProvider());
```

The following code connects to the sub model with ID "sm-001". It
returns a ISubModel instance that provides a local proxy for the remote
sub model.

``` java
// Retrieve sub model (created by factory) with SDK connector
// - Create and connect SDK connector
IIdentifier aasId = new Identifier(IdentifierType.CUSTOM, "aas-001");
IIdentifier smId = new Identifier(IdentifierType.CUSTOM, "sm-001");
ISubModel subModel = manager.retrieveSubModel(aasId, smId);
```

The following code accesses the meta property idShort of the sub model
and compares its value to the expected value "sm-001"

``` java
// - Retrieve sub model values and compare to expected values
assertEquals(smId.getId(), subModel.getIdentification().getId());
```

The following code accesses the meta property idShort of the sub model
property "prop1" and compares its value to the expected value "prop1"

``` java
// - Retrieve sub model values and compare to expected values
Map<String, ISubmodelElement> smElements = subModel.getSubmodelElements();
IProperty prop1 = (IProperty) smElements.get("prop1");
assertEquals("prop1", prop1.getIdShort());
```

The following code accesses the values of properties "prop1" and "prop3"
of the connected sub model compares their values to expected values.

``` java
// - Retrieve sub model values and compare to expected values
Map<String, ISubmodelElement> smElements = subModel.getSubmodelElements();
IProperty prop1 = (IProperty) smElements.get("prop1");
IProperty prop3 = (IProperty) smElements.get("prop3");
assertEquals(234, prop1.get());
assertEquals(17, prop3.get());
```

The following code accesses the idShort meta property of property
"prop2", as well as the contained property "prop11". Both requested
values are compared to expected values.

``` java
ISubmodelElementCollection prop2 = (ISubmodelElementCollection) smElements.get("prop2");
IProperty prop11 = (IProperty) prop2.getProperties().get("prop11");
assertTrue(subModel.getProperties().get("prop2").getId().equals("prop2"));
assertEquals(123, prop11.get());
```

The complete, executable code is available in the basyx.examples project
in package org.eclipse.basyx.examples.snippets.aas.submodels.

|                                                                                                                                                                                          |
| ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| BaSyx project links: [Project BaSyx main wiki page](BaSyx "wikilink") | [What is BaSyx?](BaSyx.WhatIsBasyx "wikilink") | [BaSyx Developer Documentation](BaSyx.Documentation "wikilink") |