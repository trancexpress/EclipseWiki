__TOC__

## BIRT POJO Viewer JBOSS Deployment

Install and Deploy Steps

1\. Download the BIRT Runtime and extract the contents.
2\. Remove org.apache.xerces and org.apache.xml.serializer from the
birt-runtime-version\\WebViewerExample\\WEB-INF\\lib folder.
3\. Copy the WebViewerExample directory to
jboss-version\\server\\default\\deploy directory.
4\. Rename WebViewerExample to birt.war.
5\. Start JBOSS Server.