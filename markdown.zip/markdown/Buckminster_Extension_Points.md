This document provides an overview of all existing Buckminster extension
points. It gives pointers to the extensions point mechanism, detailed
descriptions for each Buckminster extension, examples and guidelines for
extending Buckminster.

## Extending the Buckminster framework

  - [:Category:Buckminster
    Extension](:Category:Buckminster_Extension "wikilink")

## Extension Points

[Category:Buckminster](Category:Buckminster "wikilink")
[Category:Buckminster
Extensions](Category:Buckminster_Extensions "wikilink")