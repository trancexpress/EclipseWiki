We maintain three different update sites.

Maintenance of the current release. Nightly builds of the coming
release. Site for consumption of the release train.

In addition to those sites, we also maintain archives of all update
sites that have been produced.