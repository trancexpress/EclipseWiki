![Image:STEM TOP BAR.gif](STEM_TOP_BAR.gif "Image:STEM TOP BAR.gif")

**[Back](http://wiki.eclipse.org/Tutorials_for_Developers)**

## To build your own executable for STEM

1.  Go to the package: **org.eclipse.stem.ui**
2.  Open the file **stem.product**
3.  In the editor, Overview tab, click on **Eclipse Product Export
    Wizard**
4.  The dialog will appear:

<!-- end list -->

  - Product configuration should be:
    **/org.eclipse.stem.ui/stem.product**
  - Set the *root directory* as **stem** (you need to create this
    directory)
  - Set the *destination* as **Archive file**
  - Specify a directory for Export into: *e.g., c:\\stemBuild*
  - Use a name that reflects the date of the build (e.g.,
    **stem-win32-07242008** for July 24, 2008).
  - Select *Synchronize before exporting* and make sure that you've run
    update.xml if there have been any changes in internal data.
  - *Click Finish*