If you'd like to ship plugins pre-installed in hudson.war, you can do so
by placing your plugins inside hudson.war as /WEB-INF/plugins/\*.hpi.

These files will be extracted whenever Hudson is started. This feature
is new in Hudson 1.259.

## Sample

Here is a maven pom to build a hudson webapp bundled with your plugins

    <dependencies>

            <dependency>
                <groupId>org.jvnet.hudson.main</groupId>
                <artifactId>hudson-war</artifactId>
                <version>${org.jvnet.hudson.version}</version>
                <type>war</type>
            </dependency>

        </dependencies>

        <build>
            <plugins>

                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-dependency-plugin</artifactId>
                    <executions>
                        <execution>
                            <phase>generate-sources</phase>
                            <goals>
                                <goal>copy</goal>
                            </goals>
                        </execution>
                    </executions>
                    <configuration>
                        <artifactItems>
                            <artifactItem>
                                <groupId>${pom.groupId}</groupId>
                                <artifactId>my_plugin1</artifactId>
                                <version>${pom.version}</version>
                                <type>hpi</type>
                                <outputDirectory>${project.build.directory}/plugins</outputDirectory>
                            </artifactItem>
                            <artifactItem>
                                <groupId>${pom.groupId}</groupId>
                                <artifactId>my_plugin2</artifactId>
                                <version>${pom.version}</version>
                                <type>hpi</type>
                                <outputDirectory>${project.build.directory}/plugins</outputDirectory>
                            </artifactItem>
                        </artifactItems>
                    </configuration>
                </plugin>

                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-war-plugin</artifactId>
                    <configuration>
                        <webResources>
                            <resource>
                                <directory>${project.build.directory}/plugins</directory>
                                <targetPath>WEB-INF/plugins</targetPath>
                            </resource>
                        </webResources>
                    </configuration>
                </plugin>


            </plugins>
        </build>

Here is an Ant target that bundles all the plugins in the ./plugins
subdirectory into a new hudson.war file.

    <?xml version="1.0" encoding="UTF-8"?>
    <project basedir="." name="Hudson-Bundle">

        <property name="src.war" value="download/hudson.war" />
        <property name="dist" value="dist" />
        <property name="plugins.dir" value="plugins" />

        <target name="bundle" description="Merge plugins in ./plugins into a custom hudson.war">
            <mkdir dir="${dist}" />
            <zip destfile="${dist}/hudson.war">
                <zipfileset src="${src.war}" />
                <zipfileset dir="${plugins.dir}" prefix="WEB-INF/plugins" />
            </zip>
        </target>

        <target name="distclean">
            <delete dir="${dist}" />
        </target>

    </project>