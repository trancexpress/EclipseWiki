## Priority 1

  - CompositeUnitType
  - CompositeInstallableType
  - CompositeLocalizationType
  - LocalizationContentType
  - LanguageSelectionType
  - BaseContentType
  - SelectableContentType
  - FeatureType
  - FeaturesType
  - ReferencedPackageType
  - PackageFeatureReferenceType
  - ResultingResourceMapType
  - RequisitesType

## Priority 2 (these may be further subdivided)

  - GroupType
  - GroupsType
  - RelationshipType
  - RelationshipConstraintType
  - InternalDependencyType
  - ConstrainedResourceType
  - RequiredContentSelectionType
  - ContentElementReferenceType
  - ContentListGroup
  - MultiplicityConstraintType
  - ResourceMapType
  - ContentSelectionFeatureType
  - MultiplicityType
  - ResultingChangeMapType
  - DependencyType
  - MultiSelectType
  - FeatureReferenceType
  - NestedFeatureType
  - OptionalLanguagesType
  - UniquenessConstraintType