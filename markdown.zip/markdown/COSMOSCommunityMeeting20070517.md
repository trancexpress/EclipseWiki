## Minutes - May 17, 2007

**Attendees:** Toni, Tania, Mark, Rich, Don, Sheldon, Valentina, Steve

**Actions:**

  - Mark, Hubert and Joel will meet tomorrow to discuss the code that
    Joel has put together to do a periodic query of JMX properties
  - Don and Sheldon will provide feedback on the F2F minutes to Mark
    this week
  - Don will pull in and test the latest data collection driver to make
    sure it runs as expected
  - Toni will follow up with Valentina and Hubert on the candidate
    builds
  - Toni will sit down with Mark on Monday to talk about the timeline to
    get us to June, and determine the use case for that driver

**F2F Recap**

  - Mark is finalizing the minutes from the F2F. He would like Sheldon
    and Don to give input on various sections of the summary that he
    sent out, so we can get it on the web site as soon as possible. Don
    will compare/contrast with his notes and send Mark feedback
    tomorrow. We can make a first pass at the post-June release plans
    based on these minutes during next week's Community call.

<!-- end list -->

  - Both Don and Joel have their systems up an running now
  - Concern from Don: We have complicated things with the discussions
    about statistical persistence. I thought the goal for June was to
    deliver something more simplistic. We need to have some discussions
    with Wilson on the Data Collection call to determine what shortcuts
    we can take without closing out the option to do those things in the
    longer term. Joel has put together code to do a periodic query of
    JMX properties, which we have running at this point. Mark: Does it
    use the model that is in the DMS work (that is not EMF based)? Don:
    Not sure at this point. Mark, Joel and Hubert should set up time to
    talk about what Joel has tomorrow.

Are we on track for completing i3 work?

**Data Collection - Don**

  - Don't have details. Pretty much on track with what we said we
    intended to have done at this point. We have data collection
    components in place to do events based persistence, collection, and
    query. We intend to make a lot more improvements in i4.
  - Hubert got to the point where he was building the data collection
    components, but I don't know if anyone has tried pulling them in and
    using them.
  - Sheldon ran Joel's unit test in his development environment.
  - We need someone to pull in the drivers that are getting built and
    test them to make sure that they are working as expected. Don will
    drive this.

**Data Visualization - Sheldon**

  - Code currently checked into CVS is dependent on resource model
    repository layer and the data collection query layer. We still need
    to integrate with these layers. Still waiting for the interfaces to
    be defined.
  - We currently have no build to test against. So, there is no driver
    for data visualization.
  - We don't know if we have a clean build of the data collection layer,
    so we don't have an API that you can query. Therefore, we can build
    it, but we can't test until we have those pieces.
  - So, we need to get a clean build of the data collection layer. We
    need a rudimentary API around the repository. We need a convenience
    api on top of the qurey framework.

**Resource Modeling - Valentina**

  - We don't have an i3 candidate build. We checked in results and ran
    the testcases, but we can't test against a driver because we don't
    have one. We're now working on i4.

<!-- end list -->

  - Toni will follow up with Valentina and Hubert on the candidate
    builds
  - Toni will sit down with Mark on Monday to talk about the timeline to
    get us to June, and determine the use case for that driver