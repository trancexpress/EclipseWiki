## 6/7/07 Minutes - COSMOS Community Call

**Attendees:** Toni, Tania, Jagmit, Hubert, Joel, Sheldon, Valentina,
Rich

**Actions:**

  - Toni will post reminder to give feedback on test pass information
    that Valentina sent out
  - Richard will pull together a list of input he needs from the team
    and post it on the dev-list
  - Toni will post a request for votes on the proposal to move WSDM
    Tools to COSMOS
  - Tania will update the milestone plan with additional iterations

**Resource Modeling** - Valentina

  - We are working on the E2E use case scenario. We have a number of
    defects targeted for i4, but they are not major so they can move to
    next iteration once it has been created in bugzilla.
  - We have no issues with delivering use case by the end of this month.
    Next week when we are ready to start testing, we will report any
    issues that come out of the test pass.

**Data Collection** - Joel

  - The E2E scenario is working. Hubert is continuing to work on CBE
    items. The focus now is on the build and getting ready for the test
    pass.
  - Hubert has entered data collection code. He's writing test cases for
    the code he wrote. He's also looking at how to build the data
    visualization for Sheldon.

**Data Visualization** - Sheldon

  - Working with Valentina for E2E SML model. Also working with Hubert
    on the build for the Data Visualization component. What's left is to
    add test cases for Data Visualization.
  - Sheldon is working with Jagmit to get a report on the test pass.

**Build** - Jagmit

  - Jagmit will be working with Hubert for the build, and working with
    Sheldon on test pass reports.
  - Next week's meeting, we can walk through the test pass reports.

**Web Site** - Richard

  - Question for Richard: When will the documentation plug-ins for
    COSMOS be available?
      - Installation will be done Monday in HTML format, hoping to have
        Users Guide done as well. Right now it's HTML format, and Rich
        is not familiar with Eclipse plug-in format. This conversion
        should be done by Thurs. So, we can have this package in the
        driver at some point.
  - Richard has been getting COSMOS IP data all set on the web site, and
    mainly focused on SMLIF Users Guide
  - He will pull together a list of input he needs from the team and
    post it on the dev-list
  - Toni: 2 questions have come up that we should start focusing on
    after we finish the documentation and resource modeling work:
      - 1\. IP logs and how to find them and make sure they are current.
      - 2\. Documentation - determine where are we keeping it, getting
        links updated and primed with the information (e.g. How will we
        handle copyrights, testcases, etc.?)
  - Team should open a bug if they need something added to the web site

**Moving WSDM Tools to COSMOS** - Toni

  - We had a project leaders meeting today to review the proposal to
    move the WSDM tools to COMSOS. The discussion was positive; however,
    we did not have all project leaders present. So, Toni will post a
    request for votes from the project leaders to the mailing list. Harm
    and Toni will then take the proposal to the Technology PMC for
    approval.

**Iterations 5 & 6:**

  - We will be extending release plan to include i5 & i6. We should
    stick with the 4-6 week iterative schedule. Tania will use the dates
    Mark proposed as a basis for updating the milestone plan with
    additional iterations. Richard will get the link to be live to our
    web site to the draft milestone plan.

**Other Discussion:**

  - SAS would like to propose some work within the Management Enablement
    project. Toni asked the lead developer to write up the proposal of
    what they want to bring to the COSMOS project and post that to our
    mailing list. You will see that come forward in the next few days.
    We will then have SAS come present and we'll get a vote from the
    project leads.