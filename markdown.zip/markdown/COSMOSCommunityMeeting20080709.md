'''Attendees: ''' Ruth, Jagmit, Leonard, Hubert, Srinivas, JT, Sheldon,
Jack, Tina, Jimmy, David, Paul, Jason

  - Ruth to send an email to Anne Jacko to get confirmation of how soon
    before the release of 0.9 that we need to have the release review
  - bugzillas are partially there on the i12 page. At least the runtime
    portion of SDD we're still evaluating where we align with P2. Neck
    deep in code right now comparing P2 to COSMOS SDD. That makes it
    challenging figuring out which bugzillas need to be entered. On the
    tooling side, Eric is targeting i13 for the bulk of those. Any idea
    when you can finish that assessment? Not comfortable with a reliable
    estimate at this point because still exploring; in the next couple
    of weeks we should know. P2 engine and director stuff is rather
    extensive. Can assess during the first test week of i12 when we're
    working out the i13 plan.
  - Ruth to contact Bjorn to find out if we can 0.9 SML, 0.9 CMDBf,
    alpha SDD tooling, is that enough for approving the COSMOS 0.9
    release?

<!-- end list -->

  - i12 week 2
      - blocks just DV. Sheldon already fixed the bugs.

<!-- end list -->

  - Still not able to run JUnits yet. Bobby says that he requires ant
    1.7. Issue is that our build system is using Ant 1.6.5.
      - Package ant in our build on the server.
      - If can't package ant, then Bobby was going to contact Eclipse to
        see if the ant could be upgraded.
      - vanilla JUnits instead of TPTP JUnits? Won't make a difference.

<!-- end list -->

  -   - RM bugzillas still accurate? yes. 237921/237872 are started and
        on track. The rest is not started. Little concerned about
        completing all of this. When will you know when/if the plan
        needs to be reassessed? Depends on when those bugzillas are
        done; may not know for a couple of weeks. Ones for SML are
        i12/i13 overlapping. May be okay to assess the plan for this in
        two weeks or so. David to update the table to reflect Hubert's
        name in some rows. 237954 is complete. David to update the i12
        plan table and Ruth to update the status template so that it
        links to the i12 plan.
      - DV bugzillas still accurate? No. Some pushed to i13. Overall
        we're on track.
      - DC bugzillas still accurate? Had the DC call yesterday, went
        through some ERs that Hubert was down for. Hubert been
        reassigned to the SML enhancements, and potentially Bill will
        pick up some of those? There was interest in two, but only one
        in the end will be picked up: 233690. Second one, 238450, will
        discuss further. Jimmy will need to update the i12 table to net
        out the DC discussion. Overall status orange but still under
        assessment.
      - Doc. Richard said that everything would be available by July 3.
        Installation guide is checked in; Ruth to check with Richard the
        status of the other two guides.
      - Srinivas. QA on track.

<!-- end list -->

  - Legal
      - no update yet.
      - Sheldon to add a comment to the DOJO bugzilla to prod Eclipse
        Legal into saying if they know off of the top of their head if
        there's going to be a problem with this version like they had
        with the last version.