Att: David Jason Ruth

  - Jason will ping Jeff and Josh to link in the use cases in the
    Iteration 2 table
  - builds, Jagmit to teach Josh and Brad. May not have a candidate
    build until next week.
  - Ruth to check the bugzilla re: JAXB
  - Jason hasn't had a chance to speak with Mark about Architecture Lead
    and Project Lead responsibilities
  - Eric's bugzillas to be reassigned by Jason:
    <https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=Technology&product=Cosmos&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&emailassigned_to1=1&emailtype1=substring&email1=esrose&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Importance&field0-0-0=noop&type0-0-0=noop&value0-0-0=>
  - Other bugzillas to be reassigned by Ruth: Richard Vasconi, Ali
    Mehregani, Mark Weitzel