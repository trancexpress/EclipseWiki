## Agenda

  - Finalize agenda 5 min
  - Organization / procedural issues 5 min
  - Weekly candidate driver test status
    [1](http://wiki.eclipse.org/COSMOS/COSMOS_i10_No4_weeklycandidate)
    10 min
  - i10 bug status 10 min

## Attendees

  - Don Ebright
  - John Todd (JT)
  - Hubert Leung
  - Paul Stratton

## Discussion

  - Hubert and JT reported good progress with the web services changes
    (bug \#220949). There was some concern with such a significant
    refactoring this late in the iteration. Hubert does not expect this
    work to be complete until the close of the iteration on April 16.

<!-- end list -->

  - The status of Joel's Muse enhancements are still awaiting
    discussion, currently scheduled for Friday's summit call.

## Action Items

  - None