# COSMOS v1.1 iteration 7 plan

## Schedule for Iteration 7

[Schedule for Iteration 7](Cosmos_Release_Plan#iteration6 "wikilink")

## Design doc every enhancement

  - if the enhancement is really small, put in at least a paragraph and
    a link to the use case for QA and documentation.
  - if the enhancement is not small, the design doc needs to explain the
    change, anyone other than the assignee who is affected, how much
    work it is, any ramifications, and in general <b>please avoid any
    changes to 3rd party materials other than removing a dependency on
    it</b>. We have no guarantee that the change will be approved for
    COSMOS v1.1.

## Bugzillas for this iteration (Jimmy, David, Jason, Saurabh, QA, Doc)

Sizing legend:

  - Low - takes 1-3 days
  - Medium - takes a week
  - High - takes more than a week

Status to be filled in by:

  - Data Collection bugzilla status (**Jimmy Mohsin**)
  - Data Visualization bugzilla status (**Jimmy Mohsin**)
  - Resource Modeling bugzilla status (**David Whiteman**)
  - Management Enablement bugzilla status (**Jason Losh**)
  - RE/Build bugzilla status (**Saurabh Dravid**)
  - QA bugzilla status (**No owner**)
  - Doc bugzilla status (**No owner**)
  - Legal & release review prep and status (**Jason Losh**)

The Status column can have one of these values:

  - **COMPLETE**
  - <font color="green">On track</font>
  - <font color="orange">At risk</font>
  - <font color="red">Not containable</font>
  - <font color="blue">Defer</font> (no longer a priority for this
    iteration)
  - Not started



| Priority | Status       | Project or subteam    | Enhancement                                                    | Severity    | Description                                                             | Blocked by (if applicable) | Owner       | Sizing | Design Doc | Use Case |
| -------- | ------------ | --------------------- | -------------------------------------------------------------- | ----------- | ----------------------------------------------------------------------- | -------------------------- | ----------- | ------ | ---------- | -------- |
| Medium   | **COMPLETE** | Management Enablement | [281282](https://bugs.eclipse.org/bugs/show_bug.cgi?id=281282) | Enhancement | Resolve ResourcePropertyType variables                                  | N/A                        | Jeff Hamm   | Medium |            |          |
| High     | Not Started  | Management Enablement | [281288](https://bugs.eclipse.org/bugs/show_bug.cgi?id=281288) | Enhancement | Decompose operation handler into discreet operations                    | N/A                        | Josh Hester | High   | Needed     | Needed   |
| Medium   | **COMPLETE** | Management Enablement | [282024](https://bugs.eclipse.org/bugs/show_bug.cgi?id=282024) | Enhancement | Need to honor priority attribute for AlternateTypes and ConstraintTypes | N/A                        | Jeff Hamm   | Medium | N/A        | N/A      |
|          |              |                       |                                                                |             |                                                                         |                            |             |        |            |          |
|          |              |                       |                                                                |             |                                                                         |                            |             |        |            |          |
|          |              |                       |                                                                |             |                                                                         |                            |             |        |            |          |
|          |              |                       |                                                                |             |                                                                         |                            |             |        |            |          |
|          |              |                       |                                                                |             |                                                                         |                            |             |        |            |          |

## Use cases

  - [Use cases: SDD related
    function](COSMOS_Use_Cases#SDD_Related_Function "wikilink")
  - [SDD Deployment Use Cases (PDF
    file)](http://wiki.eclipse.org/Image:SDD_Deployment_Use_Cases_Condensed.pdf)
  - [COSMOS 1.0 use case page](COSMOS_Use_Cases "wikilink")
  - [COSMOS 1.1 use case page](COSMOS_Use_Cases_1.1 "wikilink")