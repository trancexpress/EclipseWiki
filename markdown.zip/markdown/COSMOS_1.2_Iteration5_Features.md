# COSMOS v1.2 iteration 5 plan

## Schedule for Iteration 5

[Cosmos_Release_Plan](Cosmos_Release_Plan "wikilink")

## Design doc every enhancement

  - if the enhancement is really small, put in at least a paragraph and
    a link to the use case for QA and documentation.
  - if the enhancement is not small, the design doc needs to explain the
    change, anyone other than the assignee who is affected, how much
    work it is, any ramifications, and in general <b>please avoid any
    changes to 3rd party materials other than removing a dependency on
    it</b>. We have no guarantee that the change will be approved for
    COSMOS v1.2.

## Bugzillas for this iteration

Sizing legend:

  - Low - takes 1-3 days
  - Medium - takes a week
  - High - takes more than a week

Status to be filled in by:

  - Management Enablement bugzilla status (**Jason Losh**)
  - RE/Build bugzilla status (**Brad Beck**)
  - QA bugzilla status (**SAS**)
  - Doc bugzilla status (**No owner**)
  - Legal & release review prep and status (**Jason Losh**)

The Status column can have one of these values:

  - <b>COMPLETE</b>
  - <font color="green">On track</font>
  - <font color="orange">At risk</font>
  - <font color="red">Not containable</font>
  - <font color="blue">Defer</font> (no longer a priority for this
    iteration)
  - Not started

<table border="1" cellpadding="1">

<tr>

<th>

Priority

</th>

<th>

Status

</th>

<th>

Project or subteam

</th>

<th>

Enhancement

</th>

<th>

Severity

</th>

<th>

Description

</th>

<th>

Blocked by (if applicable)

</th>

<th>

Owner

</th>

<th>

Sizing

</th>

<th>

Design Doc

</th>

<th>

Use Case

</th>

</tr>

<tr>

<td>

Medium

</td>

<td>

<font color="green">On track</font>

</td>

<td>

ME

</td>

<td>

[306014](https://bugs.eclipse.org/bugs/show_bug.cgi?id=306014)

</td>

<td>

Enhancement

</td>

<td>

RAP UI

</td>

<td>

</td>

<td>

Josh Hester

</td>

<td>

High

</td>

<td>

</td>

<td>

</td>

</tr>

<tr>

</tr>

<tr>

</tr>

</table>