| ***Note: The following graphic will be placed on the main COSMOS Web site.*** |
| ----------------------------------------------------------------------------- |

![Image:cosmos_announcement.png](cosmos_announcement.png
"Image:cosmos_announcement.png")

| '''''Note: When a user clicks the COSMOS announcement graphic on the main COSMOS Web page, a new window will be displayed describing the COSMOS announcement. Please review the following text. ''''' |
| ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |

## **COSMOS 0.4 is NOW available (version is 1.0.0-200706281537)**

**At a glance**

COSMOS 0.4 provides the following features:

  - Tools that support systems management data conforming to the Service
    Modeling Language (SML) and SML-Interchange Format (SML-IF)
    standards (http://www.w3.org/Submission/2007/01/), including SML and
    SML-IF document validation, SML-IF editing, import of SML-IF
    documents and export to SML-IF documents
  - Example data center described in SML format
  - Standard APIs for accessing COSMOS data from heterogeneous clients
  - Data collectors that gather data from Common Base Event (CBE) logs,
    JMX, and WSDM Event Format (WEF) sources
  - Data reporting tools for visualizing element-level and statistical
    reports
  - Data store to persist statistical information based on the standard
    SDMX specification (http://www.sdmx.org/)
  - Relational data store for the persistence of event information and
    statistical information
  - Web-based viewer of data from SML-IF documents, with extension
    points for complementary visualizations (For example, reports)

-----

**Download**

Download COSMOS 0.4 and reap the benefits:
<http://eclipse.org/cosmos/downloads/>

As always, we welcome your participation and feedback via this
newsgroup, and also hope you will actively "kick the tires" to report
bugs and feature requests via Bugzilla.

**The COSMOS Team**