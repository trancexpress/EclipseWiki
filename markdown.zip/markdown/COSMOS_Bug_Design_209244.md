For annotated classes, there are cases where the implementation needs
addressability to underyling management implementations. For example,
there is a need for a managed resource to be able to access it's WSDM
EPR.

In the current implementation, each management techonolgy (JMX, WSDM,
etc.) corresponds to an existing binding implementation. There is also a
mechanism that allows the annotation framework to bind references within
an implementation class. This mechanism could be used to wire in access
to the set of binding technologies that the annotated class is exposed
thruough. Each of these binding types could then be cast to
technology-specific interfaces.

This functionality is currently supported using the
@ManagedFrameworkAutowire annotation.

    /*
    * Copyright (c) 2005-2007 Compuware Corporation and others.
    * All rights reserved. This program and the accompanying
    * materials are made available under the terms of the
    * Eclipse Public License v1.0 which accompanies this
    * distribution, and is available at:
    * http://www.eclipse.org/legal/epl-v10.html
    *
    * Contributors:
    *     Compuware Corporation - initial API and implementation
    *
    */
    package org.eclipse.cosmos.dc.mgmt.annotations;

    import static java.lang.annotation.RetentionPolicy.RUNTIME;
    import static java.lang.annotation.ElementType.FIELD;

    import java.lang.annotation.Retention;
    import java.lang.annotation.Target;

    /**
     * Annotation used to support autowiring of Components within the management framework.
     */
    @Target(FIELD)
    @Retention(RUNTIME)
    public @interface ManagedFrameworkAutowire {
        /**
         * Name of the desired Component
         */
        String name();
    }

This annotation allows the framework to 'wire in' references to various
components. Currently, the framework only exposes Binding
implementations ("WSDM"), but additional components can be exposed using
the addAutowireTarget method using the ContributionManger instance.

An example of how to resolve an Endpoint for an managed object can be
found in the `org.eclipse.cosmos.dc.sample.components.source.WefSource`
class. Some excerpts are provided below:

Provide a setter method for the wiring mechanism to use.

```
    @ManagedFrameworkAutowire(name="WSDM")
    private Binding wsdmBinding;

    public void setWsdmBinding(Binding wsdmBinding){
        this.wsdmBinding = wsdmBinding;

    }
```

Using the Wired binding to access the EndpointReference

```
                ... code removed for clarity
        Object consumerObject = wsdmBinding.getBindingForObject(this);
        if(consumerObject != null && consumerObject instanceof WsResource){
            EndpointReference consumer = ((WsResource)consumerObject).getEndpointReference();
                ... code removed for clarity
```