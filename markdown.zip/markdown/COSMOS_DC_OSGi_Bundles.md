## Organizing code in CVS

COSMOS DC code is structured in OSGi bundles. This document is to
document how the code is structured in i5, and what changes are required
in i6. This is to help contributors of the project find out where should
new code reside, naming convention of package names, etc.

To start with, here are some requirements:

1.  Separation of framework and extension code: code that is intended
    for used as an example should reside in a different bundle as the
    framework code
2.  The framework bundles should roughly map to the components of the DC
    architecture (e.g. management domain, broker, MDR, etc)

## Existing bundles in the COSMOS DC project

Here are the bundles in the build as of i5:

Framework core bundles:

1.  org.eclipse.cosmos.dc.common: framework API and implementations
2.  org.eclipse.cosmos.dc.local.domain: management domain
3.  org.eclipse.cosmos.dc.local.registry: SDMX registry
4.  org.eclipse.cosmos.dc.remote.wsdm
5.  org.eclipse.cosmos.dc.mgmt.common
6.  org.eclipse.cosmos.dc.mgmt.wsdm

Bundles that contains extension code:

1.  org.eclipse.cosmos.dc.sample.components: sample component for the
    data collection assembly framework
2.  org.eclipse.cosmos.dc.sample.configurations: holds the assembly XML
    files of the sample components
3.  org.eclipse.cosmos.tptp.dependencies: TPTP dependency used by the
    GLA log parser example.
4.  org.eclipse.cosmos.dc.tptp.gla.components: the GLA data source
    component example
5.  org.eclipse.cosmos.dc.spec: Some WSDM capabilities defined by some
    query components
6.  org.eclipse.cosmos.dc.birt.helper: some helper methods for using the
    DC framework. The code should really belong to the client.

3rd party dependency

1.  org.apache.ibatis

## Bundles for i6 (Proposal)

Note: the bundle directory names should match the bundle ID. There are a
few bundles in the current codebase where the bundle directory name does
not match the bundle ID, which need to be corrected.

Client:

  - org.eclipse.cosmos.dc.remote.wsdm

Broker:

  - org.eclipse.cosmos.dc.broker (new)
  - org.eclipse.cosmos.dc.local.registry (to be replaced by
    org.eclipse.cosmos.dc.broker)

Data Manager/assembly:

  - org.eclipse.cosmos.dc.common (There are packages in this bundle that
    need to be refactored into another bundle, e.g. the registry API and
    implementations.)

Management domain:

  - org.eclipse.cosmos.dc.local.domain =\>
    org.eclipse.cosmos.dc.mgmt.domain

WSDM (common):

  - org.eclipse.cosmos.dc.mgmt.common =\> to be moved to the management
    enablement project
  - org.eclipse.cosmos.dc.mgmt.wsdm =\> to be moved to the management
    enablement project

Extension code:

  - org.eclipse.cosmos.dc.sample.components
  - org.eclipse.cosmos.dc.sample.configurations
  - org.eclipse.cosmos.tptp.dependencies
  - org.eclipse.cosmos.dc.tptp.gla.components
  - org.eclipse.cosmos.dc.spec =\> The capabilities will go in the
    bundles of the corresponding components. For example, the
    DataBrokerCapability.jara will go in the
    org.eclipse.cosmos.dc.broker bundle.
  - org.eclipse.cosmos.dc.birt.helper =\> (I think this is client code
    and should not be part of the dc project.)

## Packaging Requirements