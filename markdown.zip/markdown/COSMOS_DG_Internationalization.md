[COSMOS Wiki](COSMOS "wikilink") \> [COSMOS Document
Plan](COSMOS_Documentation_Plan "wikilink") \> [COSMOS Manual
Guide](COSMOS_Manual_Guide "wikilink")

## COSMOS Development Guide Internationalization

Category: [Development
Guide](http://wiki.eclipse.org/Category:COSMOS_Development_Guide)

|               |                                                                          |
| ------------- | ------------------------------------------------------------------------ |
| **Owner**     | Jimmy Mohsin                                                             |
| **Bug \#**    | [219154](https://bugs.eclipse.org/bugs/show_bug.cgi?id=219154)           |
| **Due dates** | [Schedule](COSMOS_Document_Schedule#COSMOS_Development_Guide "wikilink") |

## Outline

### Codebase Considerations

### GUI Considerations

### Message Handling Considerations

### i18n Checklist

## Content

i18n has been deemed as out of scope for COSMOS 1.0. However, it will be
one of critical requirements for COSMOS 1.1, which is due to be released
in late 2008.

[Category:COSMOS_Development_Guide](Category:COSMOS_Development_Guide "wikilink")