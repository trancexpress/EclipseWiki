[COSMOS Wiki](COSMOS "wikilink") \> [COSMOS Document
Plan](COSMOS_Documentation_Plan "wikilink") \> [COSMOS Manual
Guide](COSMOS_Manual_Guide "wikilink")

## COSMOS Development Guide Providing CMDBf Query and Registration Services

Category: [Development
Guide](http://wiki.eclipse.org/Category:COSMOS_Development_Guide)

|               |                                                                          |
| ------------- | ------------------------------------------------------------------------ |
| **Owner**     | Ali Mehregani                                                            |
| **Bug \#**    | [219142](https://bugs.eclipse.org/bugs/show_bug.cgi?id=219142)           |
| **Due dates** | [Schedule](COSMOS_Document_Schedule#COSMOS_Development_Guide "wikilink") |

## Outline

## Content

The content of this document has been merged with
<http://wiki.eclipse.org/COSMOS_DG_Constructing_a_Data_Manager>

[Category:COSMOS_Development_Guide](Category:COSMOS_Development_Guide "wikilink")