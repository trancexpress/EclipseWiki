[COSMOS Main Page](COSMOS "wikilink") \>

Minutes for Data Reporting sub-project call.

## Logistics

  - Date: 27-Aug-2008
  - Time: 9:30am EST

## Attendees

  - Paul
  - Sheldon
  - Leonard

## Agenda

### i13 [Aug 11 to Sept 3 (4 weeks)](http://wiki.eclipse.org/Cosmos_Release_Plan#Release_Milestones)

  - [ERs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=Technology&product=Cosmos&component=DataReporting&target_milestone=1.0i13&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&deadlinefrom=&deadlineto=&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&bug_severity=enhancement&emailtype1=exact&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&known_name=COSMOS&query_based_on=COSMOS&field0-0-0=noop&type0-0-0=noop&value0-0-0=)
  - [Bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=Technology&product=Cosmos&component=DataReporting&target_milestone=---&target_milestone=1.0i13&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&deadlinefrom=&deadlineto=&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&bug_severity=blocker&bug_severity=critical&bug_severity=major&bug_severity=normal&bug_severity=minor&bug_severity=trivial&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&known_name=COSMOS&query_based_on=COSMOS&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

## Notes

  - The following ER will be pushed out of i13 since they can not be
    contained.
      - 241815 should use the securityNamespace to prompt for credent...
      - 229800 Provide DOJO simple method descriptions for services
        avai...
  - Bug 224169 (Ability to resize dialog box.) is a limitation of dojo.
    We will not fix this bug.
  - Need to determine bugzilla owner for the DV component.
  - Going forward Sheldon will be available via email to answer
    questions and issues regarding the DV component.