## '''MDR (and Data Manager) deployment outside of OSGi environment '''

### **Change History**

<table>
<thead>
<tr class="header">
<th style="text-align: left;"><p>Name:</p></th>
<th style="text-align: left;"><p>Date:</p></th>
<th style="text-align: left;"><p>Revised Sections:</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p>John Todd</p></td>
<td style="text-align: left;"><p>01/22/2008</p></td>
<td style="text-align: left;"><ul>
<li>Initial version (was WIP)</li>
</ul></td>
</tr>
<tr class="even">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

# *' Workload Estimation*'

<table>
<caption>|Rough workload estimate in person weeks</caption>
<thead>
<tr class="header">
<th></th>
<th><p>Process</p></th>
<th><p>Sizing</p></th>
<th><p>Names of people doing the work</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p>Design</p></td>
<td><p>1PW</p></td>
<td><p>Hubert</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>Code</p></td>
<td><p>3PW</p></td>
<td><p>Hubert</p></td>
<td></td>
</tr>
<tr class="odd">
<td><p>Test</p></td>
<td><p>unknown</p></td>
<td><p>TBA</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>Documentation</p></td>
<td><p>unknown</p></td>
<td><p>TBA</p></td>
<td></td>
</tr>
<tr class="odd">
<td><p>Build and infrastructure</p></td>
<td><p>unknown</p></td>
<td><p>TBA</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>Code review, etc.*</p></td>
<td><p>unknown</p></td>
<td><p>TBA</p></td>
<td></td>
</tr>
<tr class="odd">
<td><p>TOTAL</p></td>
<td><p>unknown</p></td>
<td><p>TBA</p></td>
<td></td>
</tr>
</tbody>
</table>

'\* - includes other committer work (e.g. check-in, contribution
tracking)

# *' Terminologies/Acronyms*'

The terminologies/acronyms below are commonly used throughout this
document. The list below defines each term regarding how it is used in
this document:

<table>
<thead>
<tr class="header">
<th></th>
<th><p>Term</p></th>
<th><p>Definition</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p>MDR</p></td>
<td><p>Management Data Repository</p></td>
<td></td>
</tr>
<tr class="even">
<td></td>
<td></td>
<td></td>
</tr>
</tbody>
</table>

# Purpose

1.  Port the data manager and MDR Framework to allow data managers and
    MDRs to be deployed on a web server (Tomcat).
2.  Support non-MUWS clients.

# Requirements

\- annotation implementation in ME that supports J2EE - Axis2 JAX-WS
implementation

# Implementation details

Requirement: Update the framework to allow data managers be deployed on
Tomcat.

1.  Port the current implementation to use the annotation in ME
    subproject, and change some of the framework design (such as
    application configuration) to support both OSGi and web environment.
2.  A requirement is to make MDRs be interoperable with web service
    clients that don't support MUWS. Provide an alternativie set of APIs
    that support JAX-WS.

# ''' Test Coverage '''

list test cases here.

# ''' Open Issues '''

This task is still being scoped.

-----

[Category:COSMOS_Bugzilla_Designs](Category:COSMOS_Bugzilla_Designs "wikilink")