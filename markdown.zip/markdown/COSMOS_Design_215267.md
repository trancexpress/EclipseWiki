## ''' Provide support for adding a federating CMDB to COSMOS framework '''

This is the design for
[Bugzilla 215267](https://bugs.eclipse.org/bugs/show_bug.cgi?id=215267).

### **Change History**

<table>
<thead>
<tr class="header">
<th style="text-align: left;"><p>Name:</p></th>
<th style="text-align: left;"><p>Date:</p></th>
<th style="text-align: left;"><p>Revised Sections:</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p>David Whiteman</p></td>
<td style="text-align: left;"><p>1/18/2008</p></td>
<td style="text-align: left;"><ul>
<li>Initial version</li>
</ul></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p>Ali Mehregani</p></td>
<td style="text-align: left;"><p>1/18/2008</p></td>
<td style="text-align: left;"><ul>
<li>Completed design</li>
</ul></td>
</tr>
<tr class="odd">
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
<td style="text-align: left;"></td>
</tr>
</tbody>
</table>

# *' Workload Estimation*'

<table>
<caption>|Rough workload estimate in person weeks</caption>
<thead>
<tr class="header">
<th></th>
<th><p>Process</p></th>
<th><p>Sizing</p></th>
<th><p>Names of people doing the work</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p>Design</p></td>
<td><p>1 week</p></td>
<td><p>Ali Mehregani</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>Code</p></td>
<td><p>2 weeks</p></td>
<td><p>Ali Mehregani</p></td>
<td></td>
</tr>
<tr class="odd">
<td><p>Test</p></td>
<td><p>1 week</p></td>
<td><p>Ali Mehregani/QA team</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>Documentation</p></td>
<td><p>3 days</p></td>
<td><p>Ali Mehregani</p></td>
<td></td>
</tr>
<tr class="odd">
<td><p>Build and infrastructure</p></td>
<td><p>0</p></td>
<td><p>N/A</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>Code review, etc.*</p></td>
<td><p>0</p></td>
<td><p>N/A</p></td>
<td></td>
</tr>
<tr class="odd">
<td><p>TOTAL</p></td>
<td><p>4 weeks and 3 days</p></td>
<td></td>
<td></td>
</tr>
</tbody>
</table>

'\* - includes other committer work (e.g. check-in, contribution
tracking)

# *' Terminologies/Acronyms*'

The terminologies/acronyms below are commonly used throughout this
document. The list below defines each term regarding how it is used in
this document:

<table>
<thead>
<tr class="header">
<th></th>
<th><p>Term</p></th>
<th><p>Definition</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p>MDR</p></td>
<td><p>management data repository</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>CMDBf</p></td>
<td><p>specification for a CMDB that federates between multiple MDRs <a href="http://cmdbf.org/schema/1-0-0/CMDBf%20v1.0.pdf">1</a></p></td>
<td></td>
</tr>
<tr class="odd">
<td><p>federating CMDB</p></td>
<td><p>the CMDB that federates between MDRs, offering a common access point to clients and correlating identifying record data</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>CMDB</p></td>
<td><p>configuration management database</p></td>
<td></td>
</tr>
</tbody>
</table>

# Purpose

We needs to add support for adopters intending to register a federating
CMDB with COSMOS framework. This enhancement will include reusable code
for adopters intending to provide a server/client side implementation of
a federating CMDB.

# Implementation details

There is already code in place for adopters to use when implementing an
MDR. The following MDR plug-ins will be extended to provide support for
a federating CMDB:

`org.eclipse.cosmos.dc.mdr`
`org.eclipse.cosmos.dc.mdr.client`
`org.eclipse.cosmos.dc.mdr.common`

Three additional plug-ins will be introduced, each of which will be an
extension of its MDR counterpart:

`org.eclipse.cosmos.dc.federating.cmdb`
`org.eclipse.cosmos.dc.federating.cmdb.client`
`org.eclipse.cosmos.dc.federating.cmdb.common`

On server side two operations will be introduced:

  - Register
  - Deregister

On client side few variations of registration. All variations will also
apply to deregistration:

  - Registration based on a request
  - Registration of all items/relationships of a set of MDRs
  - Selective registration based on a CMDBf query on a set of MDRs

# ''' Test Coverage '''

Testing will be blocked by:
<https://bugs.eclipse.org/bugs/show_bug.cgi?id=214903>. A set of JUnit
tests will exercise the implementation. The tests will depend on an
environment to be set before being executed. The environment will at
least have one MDR along with a federating CMDB (implemented as part of
[214903](https://bugs.eclipse.org/bugs/show_bug.cgi?id=214903))
registered. The list below describes the set of tests created as part of
this effort:

## Test Case1: Registration/Deregistration by Request

1.  Register items/relationships of an MDR with federating CMDB using a
    registration request
2.  Assert response is successful
3.  Query federating CMDB for the set registered
4.  Assert result contains expected items/relationships
5.  Deregister items/relationships using a deregistration request
6.  Assert response is as expected
7.  Perform the same query on federating CMDB
8.  Assert the result is null

## Test Case2: Registration/Deregistration by Query

1.  Register items/relationships of an MDR with federating CMDB using a
    query request
2.  Assert response is successful
3.  Query federating CMDB for the set registered
4.  Assert result contains expected items/relationships
5.  Deregister items/relationships by query
6.  Assert response is as expected
7.  Perform the same query on federating CMDB
8.  Assert the result is null

## Test Case3: All-inclusive Registration/Deregistration

1.  Register items/relationships of all MDRs with federating CMDB
2.  Assert response is as expected
3.  Submit a query to federating CMDB to extract data originally
    belonging to multiple MDRs
4.  Assert the result set is as expected
5.  Deregister items/relationships of all MDRs
6.  Assert response is as expected
7.  Perform the same query on federating CMDB
8.  Assert the result is null

# ''' Open Issues '''

All reviewer feedback should go in the [Talk page for
215267](Talk:COSMOS_Design_215267 "wikilink").

-----

[Category:COSMOS_Bugzilla_Designs](Category:COSMOS_Bugzilla_Designs "wikilink")