[COSMOS Wiki](COSMOS "wikilink") \> [COSMOS Document
Plan](COSMOS_Documentation_Plan "wikilink")

### Documents

There will be three documents:

  - COSMOS User's Guide
  - COSMOS Developer's Guide
  - COSMOS Installation Guide
  - COSMOS API Document

### Availablility

  - Documents available two weeks before GA

### Milestones

The development of a document consists the following chronological
milestones.

1.  Outline draft of development contents on Wiki
2.  Devlopment content available to writer
3.  First draft
4.  Review
5.  Second and final draft (PDF and online helps)
6.  Review
7.  Approval copy
8.  Create PDFs
9.  Provide online helps

## COSMOS Documentation Schedule for GA

### COSMOS User's Guide

The COSMOS User's Guide will be available as HTML, PDF and online help.

| Activity              | Duration | Projected Date | Comments                                            |
| --------------------- | -------- | -------------- | --------------------------------------------------- |
| Development outline   | n/a      | **02/22/08**   | Provide an outline of your content on the Wiki      |
| Development input     | n/a      | **04/01/08**   | Completed information provided to writer            |
| First draft/edit      | _       | 04/16/08       | PDF file provided for markup and online help plugin |
| First review          | 5 days   | 04/22/08       | Send marked up PDF to writer                        |
| Second document draft | _       | 05/12/08       | PDF file for last review                            |
| Final review          | 5 days   | 05/19/08       | Send marked up PDF to writer                        |
| Approval              | _       | 06/04/08       | Signed approval                                     |
| HTML Helps version    | _       | 06/09/08       | Provide online help files                           |

### COSMOS Development Guide

The COSMOS Development Guide will be available as HTML on the
development server only. Online helps will not be provided for first
release.

| Activity              | Duration | Projected Date | Comments                                       |
| --------------------- | -------- | -------------- | ---------------------------------------------- |
| Development outline   | n/a      | **02/28/08**   | Provide an outline of your content on the Wiki |
| Development input     | n/a      | **04/22/08**   | Completed information provided to writer       |
| First draft           | _       | 05/13/08       | PDF file provided for markup                   |
| First review          | 5 days   | 05/17/08       | Send marked up PDF to writer                   |
| Second document draft | _       | 06/06/08       | PDF file for last review                       |
| Final review          | 5 days   | 06/10/08       | Send marked up PDF to writer                   |
| Approval              | _       | 06/24/08       | Signed approval                                |

### COSMOS Installation Guide

The COSMOS Installation Guide will be an HTML document that resides on
the Eclipse COSMOS development server.

| Activity              | Duration | Projected Date | Comments                                       |
| --------------------- | -------- | -------------- | ---------------------------------------------- |
| Development outline   | n/a      | **02/22/08**   | Provide an outline of your content on the Wiki |
| Development input     | n/a      | **04/08/08**   | Completed information provided to writer       |
| First draft/edit      | _       | 04/18/08       | PDF file provided for markup                   |
| First review          | 5 days   | 04/24/08       | Send marked up PDF to writer                   |
| Second document draft | _       | 05/20/08       | PDF file for last review                       |
| Final review          | 5 days   | 05/27/08       | Send marked up PDF to writer                   |
| Approval              | _       | 06/13/08       | Signed approval                                |

### COSMOS API document

Owner: TBD Completion date:

[Category:COSMOS_Documentation](Category:COSMOS_Documentation "wikilink")