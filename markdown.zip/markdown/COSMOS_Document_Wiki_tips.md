[COSMOS Wiki](COSMOS "wikilink") \> [COSMOS Document
Plan](COSMOS_Documentation_Plan "wikilink")

Feel free to add other Wiki references and examples in the section.

### Tips:

  - Wiki documents should make liberal use of section headings where
    appropriate (by using == around the section title) so that a table
    of contents is generated for easy navigation.

### References:

The following are Wiki references:

  - [Wikipedia:How_to_edit_a_page](http://en.wikipedia.org/wiki/Wikipedia:How_to_edit_a_page)
  - [Eclipsepedia Wiki tips](http://wiki.eclipse.org/Wiki_tips)
  - [MediaWiki
    Documentation](http://meta.wikimedia.org/wiki/Help:Contents)
  - [Editing Overview of
    MediaWiki](http://meta.wikimedia.org/wiki/Help:Editing)
  - [:Category:WikiTip](:Category:WikiTip "wikilink")