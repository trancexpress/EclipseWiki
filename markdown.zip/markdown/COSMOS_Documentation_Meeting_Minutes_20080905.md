These are the minutes for the Documentation meeting on 5 September 2008.

### Attendees

  - Paul (minutes)
  - Jack
  - Adriane
  - Pam
  - David
  - Jason
  - Jeff
  - Jimmy
  - Craig
  - Tina

### Agenda

We need to discuss the remaining items in the documentation and
decidewhat sections need to be updated, which ones that are empty need
to have something written in them, and which ones are non-critical and
should just be removed. Then each section should be assigned to someone
to complete for i14. Completing the section means making all additions
and updates to the HTML files in cvs and ensuring the formatting works.
Changing sections in the SML chapter of User Guide and chapter2 of the
Dev Guide will require also updating the help plugins for those sections
in addition to the main HTML.

### Discussion

#### Doc Overview

Doc originally put together by IBM tech pub resource using DITA. From
DITA source generated both HTML and PDF formats. However as proprietory
tools required to edit DITA source this has been abandoned in favor of
editing HTML directly for doc updates.

Three documents are planned for the 1.0 release.

  - Installation Guide
  - Users Guide
  - Development Guide

The HTML source is stored in CVS and can be viewed using CVS web
interface [COSMOS 1.0
documentation](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.cosmos/doc/vi12/?root=Technology_Project&sortby=log)

SML Tools employ help plugins that provide help topics (cntrl F1). Thses
will need manually updating to reflect any changes made to the SML
sections in the dev and userguide.

#### General Discussion

  - HTML files may be updated with the Eclipse environment, where the
    source files can be checked out and modified using HTML editor. This
    will require tech pubs resources to install Eclipse and get access
    to the COSMOS CVS through the CA firewall
  - To submit modified HTML files back to CVS will require COMMITTER
    status. Post Meeting Note: Non Comitters could post 'patches' and
    have a committer submit the patch
  - For general review of the documentation it would be useful to have a
    process that populates a WIKI page with the current HTML from CVS.
  - Reviewing the files within CVS is tedious due to the separation of
    text into different HTML files. The separation is not logical or
    intuitive and should be changed to 1 file per chapter.

#### Doc Ownership

To facilitate the updates the following overall owners were assigned
with Sub owners for individual sections

  - Installation Guide - Paul
      - Chapt 1 - Overview - Jimmy
      - Chapt 2 - Paul
      - Chapt 3 - Paul
      - Chapt 4 - Paul
      - Chapt 5 - Paul
      - Chapt 6 - Paul
      - Chapt 7 - Paul
      - Chapt 8 - Paul

<!-- end list -->

  - User Guide - Jimmy
      - Chapt 1 - Overview - Jimmy
      - Chapt 2 - Managing COSMOS Components - Jimmy
      - Chapt 3 -
      - Chapt 4 -
      - Chapt 5 - COSMOS WEB Component Library - Martin
      - Chapt 6 - Using SML - David
      - Chapt 7 - Running the example - Srinivas
      - Chapt 8 - COSMOS Web console - Martin
      - Chapt ?? - SDD - Jason

Dev Guide - David/Jack

  -   - Chapt 1 - Overview - Jimmy
      - Chapt 2 - Creating Data Manager - David
      - Chapt 3 - Extending Webuser interface framework - David
      - Chapt 4 -
      - Chapt ?? - SDD - Jason

### Action Items

  - Doc owners to Cordinate Updates to doc - Paul, Jimmy, David, Jack
  - Tech pubs to work with Dev to determine Doc update process - Paul,
    Adrianne