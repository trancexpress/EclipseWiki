## Minutes

Minutes for the 06JAN09 meeting were sparse. The group mainly caught up
on i1 and where things stand with it as well as discussed i2 plans as
well as work related to the profile module. We will be getting into more
detail on i2 plans as those get underway on 13JAN09.