## Logistics

  - Date: 24JUN08
  - Time: 11AM EST
  - Attendees: Charlie Halloran, Mark McCraw, Merri Jensen, Jeff Hamm,
    Robert DeMason, Jason Losh, Eric Rose, Chris Mildebrant, David
    Whiteman

## Agenda

1.  i11 status updates
      - i12 plan
          - <http://wiki.eclipse.org/COSMOS/COSMOS_iteration_i12_plan>
          - i12 to close first week of August
          - SDD candidate driver not containable - what will be
            delivered?
          - CMDBf toolkit enhancements
2.  Follow-up on action items
      - Jason to commit SAS zip extractor code, Mark to change packages
        to align with COSMOS requirements.
          - Changes have been made, ready to commit
      - Continue work on SDD for COSMOS
          - Dependent on DOJO situation (DOJO currently referenced in
            the draft SDD) - update ME team on DOJO situation
      - Jason to start documenting the Runtime similar to doc Chris has
        created for SDD Tooling (need URL).
          - Done for phase 1 - now alignment with P2
      - Eric to enter any additional Tooling ERs for i12?

Time permitting … alignment/integration topics

1.  P2/SDD runtime alignment
      - See <http://wiki.eclipse.org/COSMOS_ME_SDD_P2_Alignment>
2.  SML/CML/SDD/OVF alignment
      - Ongoing
3.  CMDBf integration
      - Ongoing

## Minutes

1.  i11 status update:
    <http://wiki.eclipse.org/COSMOS/COSMOS_i11_candidate_No3>
      - ERs still need status updates: 220639 - David - on track
        complete, 220594 - defer to i12, 230282 - move to i12.
2.  i12 closes the first week of August
      - Probably won't have SDD runtime ready, but will still need to
        list ERs that we will deliver for i12.
      - Ping Jason if you update the ME items in i12.
      - BTG going in for i13.
      - i12 is supposed to be more of a stability release, so aren't
        pushing many big development changes, but SDD is understandably
        an exception.
3.  Action Items:
      - Mark delivered refactored zip extractor code with unit tests w/
        TPTP, Jason to push later in the week.
      - SDD for COSMOS, done for the most part, but references DOJO -
        there is an issue with DOJO and COSMOS related to Eclipse Legal
        issue, they have a problem with redistribution and its use even
        as a pre-req. Trying to lean on Eclipse legal to get this worked
        out.
      - TAKE-AWAY -- be very careful about third party components/source
        especially those of a "dubious pedigree", where possible use
        components that have already been approved in ipzilla. -- Cannot
        push code with third party source without having entered an
        ipzilla. -- There is also considerations for which company
        checks in the code as well.
      - Doc'ing runtime is done, ER marked fixed.
      - Alignment with P2 - Jeff started deep diving into code, Charlie
        to post doc from earlier meeting with concept mappings between
        P2 and SDD. Jason and Jeff decided to mind meld (which seems a
        little sketchy to me ;-)
4.  Time Permitting Items:
      - SML - Julia on the hook to discuss SDD alignment with SML in a
        couple of weeks.
      - P2
          - Jason still needs to check on cross-project rules and
            gotchas.
          - Don't look at P2 with eye to "beat it into submission" but
            also don't look at it and say this is great but we're going
            to do it this way, we need to strike a balance between
            COSMOS goals and use case with those of P2.

## Action Items

1.  Jason to commit SAS zip extractor code.
2.  DOJO issues, remove from SDD for COSMOS?
3.  Eric to push code for Change Analyzer.
4.  Charlie to find out about Eclipse cross-project policies.
5.  Additional ERs for i12 need to be entered or sent to Jason.
6.  Continue looking at P2 code and see what it does.
7.  Julia to talk about SDD alignment with SML in a couple of weeks.
8.  Charlie to post P2/SDD concept mappings doc to wiki.