## **COSMOS QA Activities for i13**

This has been put together to address
[bugzilla 243998](http://bugs.eclipse.org/243998).

For all these activities, test execution has been tracked over
<http://wiki.eclipse.org/COSMOS_i13_QA_Phase_Execution>

## **Terminologies/Acronyms**

The terminologies/acronyms below are commonly used throughout this
document. The list below defines each term regarding how it is used in
this document.

<table>
<thead>
<tr class="header">
<th></th>
<th><p>Term</p></th>
<th><p>Definition</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p>Quality Expectations</p></td>
<td><p>Is a statement of some behaviour, characteristic or operational facility that a product must exhibit for it to be deemed ‘fit for purpose’. Quality expectations are normally grouped into four main categories: functional/behavioural, operational efficiency, inter operability factors; and admin/management factors (to control TCO).</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>Acceptance Criteria</p></td>
<td><p>This is a quantification of how a quality expectation is to be validated. For functional/behavioral quality expectations this is a simple Boolean test – it either works or it doesn’t. Hence, for most scope docs there is no need to specifically define functional acceptance criteria. However, other types of quality expectations – especially performance related areas – do require specific acceptance criteria because the quantification is normally some form of numeric threshold (with optional margin/tolerance) that states minimum levels of acceptable operational efficiency.</p></td>
<td></td>
</tr>
</tbody>
</table>

## **Scope Definition**

The COSMOS quality expectations and the matching acceptance criteria,
that would serve as a preamble to the COSMOS QA team while executing
their work, were completed via ER 214576.

**QA Scope for i13 testing:**

*Primary Tasks:*

1.  E2E testing on Windows XP, 2003 and Red Hat Enterprise Linux Server
    5.0 (http://wiki.eclipse.org/COSMOS_DEMO_i13)
2.  i13 ERs – JUnits/Manual Tests inspection
    (http://wiki.eclipse.org/Cosmos1.0Features\#Iteration_13_Enhancements)
3.  Data Visualization TPTP Manual Tests Execution
    (DataVisualization.UI.Component.Widget.testsuite /
    UI.Reports.testsuite)
4.  Execution of i13 supplement e2e tests(negative) from QA.
5.  MDR Toolkit and SML Tooling tests

*Secondary Tasks:*

1.  Basic operational efficiency tests (limited performance tests)

### **In scope i13 ERs**

Please refer to
<http://wiki.eclipse.org/COSMOS/COSMOS_iteration_i13_plan>
(OR)http://wiki.eclipse.org/Cosmos1.0Features\#Iteration_13_Enhancements
for the list of ERs that QA will need to test as part of the i13 testing
phase that runs from 08th Sept thru 19th Sept 2008.

### **In scope platforms, OS's & configurations**

For i13, QA will certify the following platforms:

1.  Microsoft Windows XP SP2
2.  Micorsoft Windows 2003 Server SP1
3.  RedHat Linux Enterprise Server 5.0 (Smoke test/Limited End2End
    testing only)

For i13, QA will use following softwares:

1.  Tomcat 5.5.25 & Axis2 1.3
2.  SUN JDK 1.5.0_15
3.  Firefox version (2.0.0.11)
4.  Internet Explorer (6.0.2900.2180.XP SP2)
5.  Eclipse 3.4
6.  DOJO 1.1.0
7.  BIRT 2.3

## **Iteration QA Entrance and Exit Criteria**

The following items need to be in place before the 2 weeks i13 QA phase
can commence:

1.  A stable i13 build that has undergone multiple integration build
    during the course of the Development phase which ends on Sept 05,
    2008
2.  The wiki page <http://wiki.eclipse.org/COSMOS_DEMO_i13> is completed
    (by Development)

The following items need to be in place before the 2 week i13 QA phase
can be declared complete:

1.  All ERs should have JUnits or a manual TPTP test in place. If JUnits
    are not applicable to a given ER, alternative verification means
    need to be specified. To reiterate, QA is not expected to run the
    JUnits. In i13, this activity will be completed as part of the
    weekly iteration builds. In future, this will be fully automated
    once ER 215135 is completed.
2.  The e2e tests for i13 (http://wiki.eclipse.org/COSMOS_DEMO_i13)
    are run against the final i13 build

## **i13 Test Cases**

All End2End tests from QA can be found here -
<http://wiki.eclipse.org/COSMOS_QA_End2End_Tests>

## **Resources & timeframe**

i13 QA will be completed by two dedicated CA resources. The i13 QA phase
will run from Sept 08 thru 19th Sept 2008 (2 weeks).

## **Task Breakdown**

This section includes the tasks required to complete this enhancement.

1.  Srinivas Reddy has generated this page to address
    [bugzilla 243998](http://bugs.eclipse.org/243998)
2.  The COSMOS team needs to review the relevant sections for this page.
3.  Srinivas, representing the QA team, is supposed to complete this
    activity by Sept 05, 2008. This is prior to the commencement of the
    QA phase for i13.

## '''Open Issues/Questions '''

All reviewer feedback should go in the [Talk page for 238087 "Define
scope and detail the i13 QA
activities"](http://wiki.eclipse.org/Talk:COSMOS_QA_i13_Activities).

-----

[Category:COSMOS_Bugzilla_Designs](Category:COSMOS_Bugzilla_Designs "wikilink")