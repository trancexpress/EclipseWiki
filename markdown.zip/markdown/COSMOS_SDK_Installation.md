This page provides instructions on how to install and run the COSMOS
SDK.

## Objective of the SDK

The COSMOS SDK provides the Eclipse-based tooling to develop and test a
Management Data Repository (MDR).

## Installation

### Download COSMOS Build and Prerequisites

This section provides instructions for installing and running the SDK
provided by COSMOS.

1.  Install your favorite web server supporting Java Server Pages (JSP)
    and servlet technology.
2.  From the [COSMOS download
    page](http://www.eclipse.org/cosmos/downloads/), click on the link
    of the stable build of your choice. Download the zip file under the
    "COSMOS SDK" section.
3.  Download the prerequisites for the SDK as specified in the
    Requirements section of the download page, including the
    Eclipse-hosted package for Dojo.
4.  Unzip Eclipse SDK to a directory along with WTP, EMF, XSD, GEF and
    the COSMOS SDK.
5.  Unzip the Dojo zip file to a separate directory.
6.  Download IBM Java SDK 5.0 or the Sun Java JDK 1.5\* to use with the
    COSMOS toolkit. IBM Java 5.0 can be found at
    <http://www.ibm.com/developerworks/java/jdk/> . Known issues with
    the Sun JRE:
    1.  You will need to do the following to configure Eclipse to avoid
        crashing the workspace with the internal web browser:
        1.  Select "General \> Web Browser" from the preferences dialog
            box
        2.  Select the "Use external Web browser" radio button
        3.  Check the "Firefox" entry as the external web browser
    2.  When using the SML-IF Validator with the Sun JRE, you need to
        ensure the Xerces libraries appear in the boot classpath
        \*before\* the JVM's core libraries; otherwise, an internal
        validation error appears. This can be resolved one of two ways:
        1.  Add the entry -Xbootclasspath/p:\<Path of
            org.apache.xerces_2.9.0.v200805270400.jar in your machine\>
            into eclipse.ini in the Eclipse folder.
        2.  Launch Eclipse from command line with: `eclipse -vmargs
            -Xbootclasspath/p:<Path of xerces.jar>`

### Configuring the COSMOS SDK

Before creating a MDR, you must set some configuration options in the
preferences page.

1.  Start up Eclipse.
2.  Open the preference page by selecting Windows\>Preferences. In the
    preferences dialog, select "Web Services \> Axis2 Preferences".
3.  Enter the Axis 2 directory in the "Axis2 runtime location" text box.
4.  Next, select "Server \> Runtime Environments" in the preference
    dialog box. Here you will specify the web server runtime.
5.  Click the "Add..." button. Select a runtime environment and click
    "Next".
6.  Enter the location of the web server directory in the
    "<Web server name> installation directory:" text box.
7.  Next select "System Management \> Web UI Viewer" in the preference
    dialog box. Specify the host and port on which you want to run the
    web UI viewer for testing MDRs; the defaults should suffice for most
    users.

Once you have configured the SDK, you can create a MDR by following the
"Constructing a Data Manager" section in the COSMOS Developer's Guide.

[Category: COSMOS](Category:_COSMOS "wikilink")