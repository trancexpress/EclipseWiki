Now that I6 is closed, please see [COSMOS M2
Dependencies](COSMOS_M2_Dependencies "wikilink")

  - Need IP approval for the schematron xsl used to validate SML rules;
    this is missing from the picture
  - Note that IBM jdk includes xerces jars while Sun jdk does not.
  - COSMOS i7 requires dojo 1.0 instead of 0.9

![Image:Cosmos-i6-dependencies.gif](Cosmos-i6-dependencies.gif
"Image:Cosmos-i6-dependencies.gif")