# COSMOS v1.1 Iteration 5 Week 4

## Testing Status of COSMOS Candidate Driver \<\>

Team, after you have updated your status on this page, send an email to
Saurabh Dravid (sadravid at in.ibm.com) so that he can track when all of
the status is posted and ready. To reduce noise on the mailing list,
report to cosmos-dev only if you find a problem that other people need
to know about and react to. Saurabh will post an email stating when the
driver has passed all tests.

### Data Collection and Visualization (Jimmy Mohsin)

For each of the following bullets, the team reporting testing status
also confirms that the build reports are clean for their component(s):

  - No usage of internal API outside of your own component, even within
    COSMOS
  - No plug-ins or features are missing About.html or other legal
    information
  - Copyright statements are present and correct in all files
  - All strings have been externalized as the team developed
  - All logging is consistent with COSMOS logging techniques
  - All bugzillas that are complete have been closed
  - All contributions from non-committers, if used, have been marked
    iplog+

#### Testing status for DC and DV

### Resource Modelling (David Whiteman)

For each of the following bullets, the team reporting testing status
also confirms that the build reports are clean for their component(s):

  - No usage of internal API outside of your own component, even within
    COSMOS
  - No plug-ins or features are missing About.html or other legal
    information
  - Copyright statements are present and correct in all files
  - All strings have been externalized as the team developed
  - All logging is consistent with COSMOS logging techniques
  - All bugzillas that are complete have been closed
  - All contributions from non-committers, if used, have been marked
    iplog+

#### Testing status for RM

### Management Enablement (Jason Losh)

For each of the following bullets, the team reporting testing status
also confirms that the build reports are clean for their component(s):

  - No usage of internal API outside of your own component, even within
    COSMOS
  - No plug-ins or features are missing About.html or other legal
    information
  - Copyright statements are present and correct in all files
  - All strings have been externalized as the team developed
  - All logging is consistent with COSMOS logging techniques
  - All bugzillas that are complete have been closed
  - All contributions from non-committers, if used, have been marked
    iplog+

#### Testing status for ME

## Bugzilla status

Enter the status on the Iteration 5 Feature plan [COSMOS v1.1
Iteration 5
Plan](http://wiki.eclipse.org/COSMOS_1.1_Iteration5_Features)

[Category:COSMOS_1.1.0_i5_Builds](Category:COSMOS_1.1.0_i5_Builds "wikilink")