{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}} The
Cache Service provide common way for other components to cache their
preformance sensitive data.

## Service

Manages configuration of [Cache Provider](Cache_Provider "wikilink")
which is used to cache data.

#### Responsibilities

  - Configure and provide access to one of [Cache
    Providers](Cache_Provider "wikilink") to be used for caching.
  - Provide reference "NoCache" implementation of [Cache
    Provider](Cache_Provider "wikilink") so Cache Service could be used
    even if there is no any other [Cache
    Provider](Cache_Provider "wikilink") available/configured.

[Category:Higgins Components](Category:Higgins_Components "wikilink")