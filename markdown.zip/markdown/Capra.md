Eclipse Capra is a configurable and extendable traceability management
tool based on EMF. It is created in the context of an ITEA funded
project called AMALTHEA4Public whose main aim is to develop a platform
that will improve the development of embedded multicore and many core
systems.

The project website can be found
[here](https://projects.eclipse.org/projects/modeling.capra).

# How it works

Eclipse Capra uses the Eclipse Modelling Framework (EMF) as its base
technology and stores the traceability model as an EMF model. Out of the
box, it provides a number of artifact handlers that allow using, e.g.,
Papyrus UML models, Java methods, C functions, or Hudson builds as
sources and targets for traceability links. New traceability links can
be created with drag and drop and changes to the artifacts that affect
the traceability links are shown in the Problems view.

The traceability metamodel is not fixed and can be defined by the user.
It relies on the Eclipse extension mechanism and provides an extension
point for artifacts types to be supported. To add a new type of
artifact, one simply needs to add an extension to this extension point
and implement the provided interfaces.

# Getting Started

## Installing Capra from the Update Site

Update sites with nightly builds, milestones and releases are available
at [1](http://download.eclipse.org/capra/). An update site with nightly
builds of the current development branch of Eclipse Capra is available
[here](https://download.eclipse.org/capra/nightlies/latest/). Use one of
the update sites to install Capra through Eclipse's "Install
Software..." functionality.

## Installing Capra from Sourcecode

As of Eclipse Capra 0.8.2, JDK 11 is the minimum requirement to build
Eclipse Capra. It is very important that both the Eclipse installation
in which the development is done as well as Maven actually use Java 11
since source code compatibility is not ensured when using later
JDKs/JREs in Java 11-mode\! In Eclipse, JRE 11 has to be activated and
JAVA_HOME should point to JDK 11 for Maven\! You can download JDK 11 at
[2](https://jdk.java.net/archive/).

### Using the Eclipse Installer

The easiest way to get up and running with Eclipse Capra is to use the
[Eclipse Installer](https://wiki.eclipse.org/Eclipse_Installer). It lets
you select which version of Eclipse to download and sets up everything
you need to run and develop Eclipse Capra automatically. Here's how to
use it:

1.  Download the [Eclipse
    Installer](https://wiki.eclipse.org/Eclipse_Installer).
2.  Open the Eclipse Installer. In the menu in the top-right corner,
    select the advanced mode.
3.  Select the "Eclipse for Eclipse Committers" package from the list.
    In the selection for "Product Version" below the list, select your
    favorite version of Eclipse (at least 2018.12) and JRE 11 as the
    runtime environment. Click "Next".
4.  In the list of Eclipse projects, select "Eclipse Capra". Make sure
    the checkbox in front of Eclipse Capra is checked and click "Next".
5.  In the next step, you get to select some variables. Most of these
    can remain on their default, but you have to select the correct
    target platform for the Eclipse product version you selected
    earlier. You might also want to provide credentials for your Eclipse
    account here to ensure that the git repository and the connections
    to Bugzilla and Gerrit are set up correctly. Change other variables
    such as installation and workspace location at your own discretion.
    Click "Next."
6.  The Eclipse Installer will now download the packages for your chosen
    Eclipse product version. You might have to agree to some licenses.
    After that, it will automatically start the Eclipse IDE it just
    installed and start setting up the development environment. That
    includes cloning the git repository, setting up connections to
    Bugzilla and Gerrit, and setting the target platform. This might
    take a while, but after all is said and done, you are all set\!

**On Windows 10**: Depending on from where you run the Eclipse
Installer, it might require Administrator privileges to download the
packages for the target platform. The easiest way to ensure that this
works is to execute the Installer with these privileges via the context
menu or using Ctrl + Shift + Click.

### Manual installation of the Eclipse development environment for Capra

Before downloading and using Eclipse Capra, download the [Eclipse
Modelling Environment](https://www.eclipse.org/downloads/packages/). All
dependencies will be downloaded automatically when Eclipse Capra is
installed. In particular, parts of
[Papyrus](https://eclipse.org/papyrus/), the [Java Development
Tools](https://www.eclipse.org/jdt), the [C/C++ Development
Tools](https://www.eclipse.org/cdt/),
[Xcore](https://wiki.eclipse.org/Xcore), and
[Xtend](https://eclipse.org/xtend/) will be installed.

### Get the source code manually

  - Open your Eclipse Environment
  - Go to File --\> Import and select Git --\> Projects from Git
  - Clone the [Eclipse Capra Git
    repository](https://git.eclipse.org/c/capra/org.eclipse.capra) and
    import all available projects to your workspace. Information about
    the developer resources and the source code repositories is
    available at [the project
    website](https://projects.eclipse.org/projects/modeling.capra/developer).
  - Make sure to switch to the `develop` branch if you want to use the
    current version of Eclipse Capra
  - To make sure Eclipse can resolve all dependencies, set the correct
    target platform file for your version of Eclipse. All target
    platform files can be found in
    `releng/org.eclipse.capra.releng.target`. Open the correct file and
    set it as the active target platform by opening it and clicking on
    "Set as Target Platform" in the upper right corner. Eclipse will now
    download all dependencies. Note that this will take a while. Check
    the progress in the lower right corner.
  - Build your workspace
  - Make sure that all the projects have no errors.

If compilation errors occur during the first build, check if any of the
dependencies above are missing. Cleaning all binaries also often helps
resolve issues.

### Start Capra

  - Make sure that all the projects have no errors.
  - Click on Run --\> Run Configurations and create a new Eclipse
    Application Configuration
  - Select your running workspace
  - Click "Apply", then "Run"
  - Once the new workspace opens, create or import projects that you
    want to use to create traceability links
  - Go to perspectives and switch to the Capra perspective
  - Follow [this video](https://youtu.be/XRtLs5OT_yM) to create and
    visualize traceability links.

## Install Graphviz

In order to use the trace link visualisation based on PlantUML,
`graphviz` needs to be installed on the system. If it cannot be found,
the Capra PlantUML viewer will display an error message. Please follow
the [installation instructions](https://graphviz.gitlab.io/download/) on
the Graphviz website to install the tool in your system.

# Customizing Capra

Eclipse Capra has been designed for extensibility and configurability.
Many aspects of Capra can be changed by implementing a new plugin and
registering it to the right extension points. This includes which
artifacts Eclipse Carpa can handle, how the traceability links are
persisted, and of course the traceability link types.

[Adding a custom traceability
meta-model](Capra/CustomTraceabilityMetaModel "wikilink")

# Contributing to Capra

The Capra project uses the Eclipse infrastructure for development,
source code management, building, and bug tracking. Please refer to
[Capra/Contributing](Capra/Contributing "wikilink") for details on how
to contribute and to
[Capra/PreparingForRelease](Capra/PreparingForRelease "wikilink") for
information on release engineering.

[Category:Capra](Category:Capra "wikilink")