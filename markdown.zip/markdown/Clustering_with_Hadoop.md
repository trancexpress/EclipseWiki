## Introduction

The quest for performance optimization has been tirelessly pursued since
the invention of computers. We are perpetually seeking to streamline
machine performance, by increasing speed, expanding memory, and
improving accuracy. As researchers desire to deal with larger and larger
data sets, such optimizations become necessities rather than comforts.

Many programming models have been developed to combat this issue;
currently, one of the most popular is
[MapReduce](http://en.wikipedia.org/wiki/MapReduce). Useful across many
domains, one specific application for which the [MapReduce
paradigm](http://cacm.acm.org/magazines/2010/1/55744-mapreduce-a-flexible-data-processing-tool/fulltext)
has been explored is knowledge discovery from nuclear reactor simulation
data, as it is imminent that this data will quickly become large-scale.
[Hadoop](http://hadoop.apache.org/), a well-known open-source
implementation of MapReduce, was used for this study.

For preliminary investigation, [k-Means
clustering](http://nlp.stanford.edu/IR-book/html/htmledition/k-means-1.html),
available from [Mahout](http://mahout.apache.org/) was employed. The
results were similar to the ones we published in the paper, ["Knowledge
Discovery from Nuclear Reactor Simulation
Data"](http://www.ntis.gov/search/product.aspx?ABBR=DE20131092256).

## Process

Here are the steps we used for working with Hadoop:

  - Successfully install Hadoop from their
    [Releases](http://hadoop.apache.org/releases.html) page. I used a
    [tutorial by Michael
    Noll](http://www.michael-noll.com/tutorials/running-hadoop-on-ubuntu-linux-single-node-cluster)
    to install Hadoop on my laptop, running on Fedora 17, as a single
    node cluster. (Note that this tutorial is only helpful for certain
    Linux users.)
  - The database used was [Hadoop Distributed File
    System](http://hadoop.apache.org/docs/r1.0.4/mapred_tutorial.html).
    A helpful tutorial on HDFS can be found here.
  - Successfully install Mahout, a scalable machine learning and data
    mining library, from their
    [Downloads](http://mahout.apache.org/general/downloads.html) page.
    Examples on how to run various machine learning algorithms on Mahout
    can be found in /mahout/examples/bin.
  - Put the requisite data for analysis on HDFS. My data files are in
    the .csv format. Mahout's k-Means clustering expects the data to be
    formatted into a Mahout-specific SequenceFile format. A Java utility
    was written to convert our data into a dense sequence file format,
    as needed by the k-Means clustering algorithm. Please note that the
    examples for k-Means in Mahout mostly work with [converting text
    data into sparse vector
    format](http://mahout.apache.org/users/basics/creating-vectors-from-text.html).
    However, this was not the case with our data.
  - Run k-Means with the -cl option. For example:
      - mahout kmeans -i /data/diff_unc_trans_seq/part-m-00000 -o
        /data/diff_unc_trans_kmeans_op -x 20 -k 2 -c
        /data/analysis_clusters -cl

Information on the various command line options for k-Means can be found
[here](http://mahout.apache.org/users/clustering/k-means-commandline.html).

  - Get the clusteredPoints directory out of HDFS into your local
    directory.
  - Run mahout seqdumper to output them. For example:
      - mahout seqdumper -i
        /data/diff_unc_trans_kmeans_op/clusteredPoints/part-m-00000
        -o \~/Data_orig/diff_unc_trans_hadoop_op/.

This can be further processed for analysis.

## Resources

For more information on Hadoop, see [their
website](http://hadoop.apache.org/), which contains many useful
resources, including a
[tutorial](http://hadoop.apache.org/docs/r1.0.4/mapred_tutorial.html) on
how to use Hadoop.

More details on Mahout and its uses can be found at the [Apache Mahout
website](http://mahout.apache.org/). The developers keep the website
very well maintained, and you can find a [great introduction to k-Means
clustering](http://mahout.apache.org/users/clustering/k-means-clustering.html),
in addition to information on many other methods.

Some further helpful materials on MapReduce include:

  - [Chapter 2](http://infolab.stanford.edu/~ullman/mmds/ch2.pdf) of
    Mining of Massive Datasets by Anand Rajaraman and Jeffrey David
    Ullman.
  - [MapReduce: A Flexible Data Processing
    Tool](http://cacm.acm.org/magazines/2010/1/55744-mapreduce-a-flexible-data-processing-tool/fulltext),
    a seminal paper by Google Fellows Jeffrey Dean and Sanjay Ghemawat,
    published in 2010.

## Related

[CSV Clustering via Mahout (on local
machine)](CSV_Clustering_via_Mahout_\(on_local_machine\) "wikilink")
[Developer
Documentation](https://wiki.eclipse.org/ICE_Developer_Documentation)