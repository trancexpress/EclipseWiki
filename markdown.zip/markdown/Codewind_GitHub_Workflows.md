Follow these instructions to make contributions to [Eclipse
Codewind](https://projects.eclipse.org/projects/ecd.codewind).

# Signing the ECA

Before you can contribute to any Eclipse project, you need to sign the
[Eclipse Contributor Agreement
(ECA)](https://www.eclipse.org/legal/ECA.php).

1.  To verify that you signed the ECA, sign in to [your Eclipse
    account](https://accounts.eclipse.org/).
2.  View your **Status** and make sure that a check mark appears with
    the **Eclipse Contributor Agreement**.
3.  If the check mark does not appear, click the **Eclipse Contributor
    Agreement** in the **Status** box to go to the agreement that you
    need to sign.
4.  Fill out the form and click the **Accept** button.

# Associating your Eclipse profile with your GitHub ID

1.  From [your Eclipse account](https://accounts.eclipse.org/), select
    **Edit Profile**.
2.  On the **Personal Information** tab, go to the **Social Media
    Links** section and add your GitHub user name to the **GitHub
    Username** field.
3.  Answer the **Have you changed employers** question
4.  Enter your Eclipse password in the **Current password** field and
    then click **Save**.

# Creating or finding an issue

Codewind uses GitHub for issues and source control. To make a
contribution, locate an issue that is currently open and relevant to
your contribution. If you can't find an open issue that's relevant, open
a new issue.

## List of Codewind repositories

The following links point to repositories that are included in the
Codewind project:

  - The main Codewind repository: <https://github.com/eclipse/codewind>
  - Installer: <https://github.com/eclipse/codewind-installer>
  - Codewind Eclipse development plug-in:
    <https://github.com/eclipse/codewind-eclipse>
  - OpenAPI implementation for Codewind Eclipse development:
    <https://github.com/eclipse/codewind-openapi-eclipse>
  - Codewind Visual Studio Code extension:
    <https://github.com/eclipse/codewind-vscode>
  - OpenAPI implementation for Codewind Visual Studio Code development:
    <https://github.com/eclipse/codewind-openapi-vscode>
  - File Watcher: <https://github.com/eclipse/codewind-filewatchers>
  - Staging area for Codewind documentation:
    <https://github.com/eclipse/codewind-docs>
  - Codewind Eclipse Che plugin:
    <https://github.com/eclipse/codewind-che-plugin>
  - Profiler for Node:
    <https://github.com/eclipse/codewind-node-profiler>
  - Profiler for Java:
    <https://github.com/eclipse/codewind-java-profiler>
  - Codewind ODO extension:
    [1](https://github.com/eclipse/codewind-odo-extension)

# Git or Gerrit?

The Codewind project uses Git instead of Gerrit for the code review
process. Most of the Eclipse development documentation related to code
review has instructions related to both Git and Gerrit. Refer to the Git
section for the Codewind project.

# Setup Git Environment

Follow this doc to setup your Codewind Git repository before submitting
a pull request: [Setup Git Environment for Codewind
Development](https://wiki.eclipse.org/Codewind_Git_Repo_Setup)

# Making a pull request

Refer to the following instructions that are relevant to Codewind:

1.  Before submitting a pull request, complete the [Signing the
    ECA](https://wiki.eclipse.org/Codewind_GitHub_Workflows#Signing_the_ECA)
    instructions.
2.  Issue a standard GitHub pull request.
3.  Ensure that you have an ECA and that you add a sign-off statement to
    the commit record before you issue the request. For more
    information, see [The Commit
    Record](https://wiki.eclipse.org/Development_Resources/Contributing_via_Git#The_Commit_Record).
    Both VS Code and Eclipse have options for automatically signing-off
    commits.

See [Development Resources/Contributing via
Git](https://wiki.eclipse.org/Development_Resources/Contributing_via_Git)
for full documentation on contributing code.

# The committer reviews and accepts the request

Refer to the following instructions that are relevant to Codewind:

  - If the PR is done by a non-committer, assign the PR to the author of
    the PR for tracking purpose
  - [Git contributions
    overview](https://wiki.eclipse.org/Development_Resources/Handling_Git_Contributions#Overview)
  - [Code Pull request review process in
    Git](https://wiki.eclipse.org/Development_Resources/Handling_Git_Contributions#Git)
  - [Git contributions with multiple
    authors](https://wiki.eclipse.org/Development_Resources/Handling_Git_Contributions#Multiple_Authors)
  - When merging, it is recommended to use "Rebase and Merge" option
    instead of the default merge option

See [Development Resources/Handling Git
Contributions](https://wiki.eclipse.org/Development_Resources/Contributing_via_Git#via_GitHub)
for full documentation on handling code contributing by committer.