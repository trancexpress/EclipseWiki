코어 익스프레션은 org.eclipse.core.expresion 플러그인을 기반으로 하는 선언적 혹은 프로그래밍적인
표현식입니다.

# 익스프레션과 커맨드 프레임워크

[Platform Command Framework은](Platform_Command_Framework "wikilink")
핸들러나 프로그래밍 문맥의 활성화 등을 위한 enabledWhen과 activeWhen, 그리고 메뉴의 가시성 여부
결정을 위한 visibleWhen에 코어 익스프레션을 이용합니다. 커멘드 프레임워크는 커맨드 코어 익스프레션들이 평가될 수 있는
IEvaluateContext를 제공합니다.

IEvaluationContext는 평가를 위한 기본 변수 및 다양한 변수 이름들을 제공합니다. 특별히 평가 대상을 지정하지 않는
경우, 기본 평가 대상 변수로 전역 선택 목록(Global Selection)이 `java.util.Collection`로
제공합니다. (역자: 셀렉션 서비스를 생각하세요) 이 경우 평가 대상은 비어있을 수도 있고 오직 하나의 엔트리만을
가지고 있을 수도 있습니다. (만약 ISelection이 ITextSelection과 같은 것인 경우), 혹은
IStructuredSelection가 될 수도 있습니다.

<with/> 엘리먼트를 지정함으로서 자식(With의) 익스프레션 엘리먼트들이 평가를 수행할 대상을 명시적으로 지정할 수
있습니다.

# 변수와 커맨드 프레임 워크

커맨드 프레임워크의 평가에 사용되는 변수들은
[ISources.java](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.ui.workbench/Eclipse%20UI/org/eclipse/ui/ISources.java?view=co)에
목록화 되어있습니다.

몇몇 변수들은 평가 시점의 어플리케이션 문맥에따라 세팅되지 않을 수도 있습니다.

<table border="1">

<tr>

<th>

변수명

</th>

<th>

타입

</th>

<th>

설명

</th>

<th>

버전

</th>

</tr>

<tr>

<td>

activeContexts

</td>

<td>

`java.lang.String`들로 구성된 `java.util.Collection`

</td>

<td>

활성 문맥ID 들의 리스트입니다. 대체로 <iterate/> and <count/>와 함께 이용됩니다. 또한
`org.eclipse.common.expressions.PropertyTester`와 함께 사용될 수도 있습니다.
**3.3**버전의 Action Set들은 `org.eclipse.ui.actionSet`를 부모로하는 문맥에 의해
미러링되어, 활성 문맥안에서 리스트 형태로 존재하게 됩니다.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activeActionSets

</td>

<td>

`IActionSetDescriptor[]`

</td>

<td>

**Note:** 이것은 현재 내부 클래스를 가리키고, 그 타입이 언제라도 변경될 수 있으므로 지금은 사용되지 않는다

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activeShell

</td>

<td>

`org.eclipse.swt.widgets.Shell`

</td>

<td>

현재 활성화된 쉘, 다이얼로그나 워크벤치 윈도우 쉘이 될 수 있습니다.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activeWorkbenchWindowShell

</td>

<td>

`org.eclipse.swt.widgets.Shell`

</td>

<td>

현재 활성화된 워크벤치 윈도우 쉘.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activeWorkbenchWindow

</td>

<td>

`org.eclipse.ui.IWorkbenchWindow`

</td>

<td>

활성화된 워크밴치 윈도우.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activeWorkbenchWindow.isCoolbarVisible

</td>

<td>

`java.lang.Boolean`

</td>

<td>

활성화된 워크밴치의 쿨바 가시성 여부.

</td>

<td>

3.3

</td>

</tr>

<tr>

<td>

activeWorkbenchWindow.isPerspectiveBarVisible

</td>

<td>

`java.lang.Boolean`

</td>

<td>

현재 워크밴치 윈도우의 퍼스펙티브바 가시성 여부.

</td>

<td>

3.3

</td>

</tr>

<tr>

<td>

activeEditor

</td>

<td>

`org.eclipse.ui.IEditorPart`

</td>

<td>

현재 활성화된 에디터. 에디터 파트가 아니라 뷰파트가 활성화되있더라도 마지막 에디터 파트가 기억됩니다.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activeEditorId

</td>

<td>

`java.lang.String`

</td>

<td>

활성화된 에디터의 ID. 에디터의 타입을 평가하기 위해 사용할 수 있습니다.r expressions on the editor
type.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activePart

</td>

<td>

`org.eclipse.ui.IWorkbenchPart`

</td>

<td>

활성화된 Part.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activePartId

</td>

<td>

`java.lang.String`

</td>

<td>

활성화된 Part의 ID.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activeSite

</td>

<td>

`org.eclipse.ui.IWorkbenchPartSite`

</td>

<td>

활성화된 파트의 Site.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

selection

</td>

<td>

`org.eclipse.jface.viewers.ISelection`

</td>

<td>

전역 선택 목록. <test/>엘리먼트 안이나 프로그래밍적인 코어 익스프레션에서
`org.eclipse.core.expressions.PropertyTester`와 함께 이용될 수 있습니다.
**3.3**버전부터 <test/>와 함께 <iterate/> 와 <count/>도 함께 쓸 수 있습니다.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activeMenu

</td>

<td>

A `java.util.Collection` of `java.lang.String`

</td>

<td>

현재 보여지고 있는 문맥 메뉴의 ID리스트. \#TextEditorRuler나 Part ID같은 예가 있을 수 있습니다. 대게
<iterate>, <count>와 함께 이용됩니다. <test>,
`org.eclipse.common.expressions.PropertyTester`와 함께 이용할 수도 있습니다.

</td>

<td>

3.2

</td>

</tr>

<tr>

<td>

activeMenuSelection

</td>

<td>

`org.eclipse.jface.viewers.ISelection`

</td>

<td>

팝업 메뉴가 보이는 동안 사용가능한 셀렉션입니다. 셀렉션 프로바이더에 등록된 팝업 메뉴의 셀렉션을 가리키며 보통
`getSite().registerContextMenu(*)`를 통해 등록됩니다. 이것은 대체로 `selection` 변수와
동일한 것 같지만 항상 그렇지는 않습니다. 좀더 레거시한 호환성을 보장합니다.

</td>

<td>

3.3

</td>

</tr>

<tr>

<td>

activeMenuEditorInput

</td>

<td>

`org.eclipse.jface.viewers.ISelection`

</td>

<td>

에디터 영역에서 팝업 메뉴가 보이는 동안 사용가능한 셀렉션입니다. 이 셀렉션은 에디터 인풋으로 부터 가져옵니다.
Selection보다 좀 더 Legacy한 호환성을 제공합니다.

</td>

<td>

3.3

</td>

</tr>

<tr>

<td>

activeFocusControl

</td>

<td>

`org.eclipse.swt.widgets.Control`

</td>

<td>

[IFocusService](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.ui.workbench/Eclipse%20UI/org/eclipse/ui/swt/IFocusService.java?view=co)에
등록된 포커스를 획득한 Control객체 입니다.

</td>

<td>

3.3

</td>

</tr>

<tr>

<td>

activeFocusControlId

</td>

<td>

`java.lang.String`

</td>

<td>

`org.eclipse.ui.swt.IFocusService`에 등록된 포커스를 획득한 Control의 ID를 가리킵니다.

</td>

<td>

3.3

</td>

</tr>

</table>

# 프로퍼티 테스터

이클립스 SDK는 코어 익스프레션에서 사용할 수 있는 몇개의 프로퍼티 테스터를 제공합니다. 익스프레션에서 프로퍼티 애트리뷰트를
지정하고, 테스터의 구현에 따라 아큐먼트의 조합을 가지게 됩니다. 프로퍼티 애트리뷰트는 네임스페이스와 프로퍼티 이름의
조합으로 이루어집니다. 예를 들어 IResouce의 name을 테스트하기 위해 프로퍼티 애트리뷰트는
`org.eclipse.core.resources.name`와 같이 나타내어야 합니다.

<table border="1">

<tr>

<th>

Namespace

</th>

<th>

Type

</th>

<th>

Implementation

</th>

</tr>

<tr>

<td>

org.eclipse.core.runtime

</td>

<td>

`org.eclipse.core.runtime.Platform`

</td>

<td>

[PlatformPropertyTester.java](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.core.expressions/src/org/eclipse/core/internal/expressions/propertytester/PlatformPropertyTester.java?view=co)

</td>

</tr>

<tr>

<th>

Property

</th>

<th colspan="2">

Description

</th>

</tr>

<tr>

<td>

product

</td>

<td colspan="2">

Test the id of the currently active product.

</td>

</tr>

<tr>

<td>

isBundleInstalled

</td>

<td colspan="2">

Test if a given bundle is installed in the running environment. Use the
args attribute to pass in the bundle id.

</td>

</tr>

<tr>

<th>

Namespace

</th>

<th>

Type

</th>

<th>

Implementation

</th>

</tr>

<tr>

<td>

org.eclipse.core.resources

</td>

<td>

`org.eclipse.core.resources.IResource`

</td>

<td>

[ResourcePropertyTester.java](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.core.resources/src/org/eclipse/core/internal/propertytester/ResourcePropertyTester.java?view=co)

</td>

</tr>

<tr>

<th>

Property

</th>

<th colspan="2">

Description

</th>

</tr>

<tr>

<td>

name

</td>

<td colspan="2">

A property indicating the file name (value `"name"`). "\*" and "?" wild
cards are supported.

</td>

</tr>

<tr>

<td>

path

</td>

<td colspan="2">

A property indicating the file path (value `"path"`). "\*" and "?" wild
cards are supported.

</td>

</tr>

<tr>

<td>

extension

</td>

<td colspan="2">

A property indicating the file extension (value `"extension"`). "\*" and
"?" wild cards are supported.

</td>

</tr>

<tr>

<td>

readOnly

</td>

<td colspan="2">

A property indicating whether the file is read only (value
`"readOnly"`).

</td>

</tr>

<tr>

<td>

projectNature

</td>

<td colspan="2">

A property indicating the project nature (value `"projectNature"`).

</td>

</tr>

<tr>

<td>

persistentProperty

</td>

<td colspan="2">

A property indicating a persistent property on the selected resource
(value `"persistentProperty"`). If two arguments are given, this treats
the first as the property name, and the second as the expected property
value. If only one argument (or just the expected value) is given, this
treats it as the property name, and simply tests for existence of the
property on the resource.

</td>

</tr>

<tr>

<td>

projectPersistentProperty

</td>

<td colspan="2">

A property indicating a persistent property on the selected resource's
project. (value `"projectPersistentProperty"`). If two arguments are
given, this treats the first as the property name, and the second as the
expected property value. If only one argument (or just the expected
value) is given, this treats it as the property name, and simply tests
for existence of the property on the resource.

</td>

</tr>

<tr>

<td>

sessionProperty

</td>

<td colspan="2">

A property indicating a session property on the selected resource (value
`"sessionProperty"`). If two arguments are given, this treats the first
as the property name, and the second as the expected property value. If
only one argument (or just the expected value) is given, this treats it
as the property name, and simply tests for existence of the property on
the resource.

</td>

</tr>

<tr>

<td>

projectSessionProperty

</td>

<td colspan="2">

A property indicating a session property on the selected resource's
project. (value `"projectSessionProperty"`). If two arguments are given,
this treats the first as the property name, and the second as the
expected property value. If only one argument (or just the expected
value) is given, this treats it as the property name, and simply tests
for existence of the property on the resource.

</td>

</tr>

<tr>

<th>

Namespace

</th>

<th>

Type

</th>

<th>

Implementation

</th>

</tr>

<tr>

<td>

org.eclipse.core.resources

</td>

<td>

`org.eclipse.core.resources.IFile`

</td>

<td>

[FilePropertyTester.java](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.core.resources/src/org/eclipse/core/internal/propertytester/FilePropertyTester.java?view=co)

</td>

</tr>

<tr>

<th>

Property

</th>

<th colspan="2">

Description

</th>

</tr>

<tr>

<td>

contentTypeId

</td>

<td colspan="2">

A property indicating that we are looking to verify that the file
matches the content type matching the given identifier. The identifier
is provided as the expected value.

</td>

</tr>

<tr>

<th>

Namespace

</th>

<th>

Type

</th>

<th>

Implementation

</th>

</tr>

<tr>

<td>

org.eclipse.core.resources

</td>

<td>

`org.eclipse.core.resources.IProject`

</td>

<td>

[ProjectPropertyTester.java](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.core.resources/src/org/eclipse/core/internal/propertytester/ProjectPropertyTester.java?view=co)

</td>

</tr>

<tr>

<th>

Property

</th>

<th colspan="2">

Description

</th>

</tr>

<tr>

<td>

open

</td>

<td colspan="2">

A property indicating whether the project is open (value `"open"`).

</td>

</tr>

<tr>

<th>

Namespace

</th>

<th>

Type

</th>

<th>

Implementation

</th>

</tr>

<tr>

<td>

org.eclipse.core.resources

</td>

<td>

`org.eclipse.core.resources.mapping.ResourceMapping`

</td>

<td>

[ResourceMappingPropertyTester.java](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.core.resources/src/org/eclipse/core/internal/propertytester/ResourceMappingPropertyTester.java?view=co)

</td>

</tr>

<tr>

<th>

Property

</th>

<th colspan="2">

Description

</th>

</tr>

<tr>

<td>

projectPersistentProperty

</td>

<td colspan="2">

A property indicating a persistent property on the selected resource's
project. (value `"projectPersistentProperty"`). If two arguments are
given, this treats the first as the property name, and the second as the
expected property value. If only one argument (or just the expected
value) is given, this treats it as the property name, and simply tests
for existence of the property on the resource.

</td>

</tr>

<tr>

<th>

Namespace

</th>

<th>

Type

</th>

<th>

Implementation

</th>

</tr>

<tr>

<td>

org.eclipse.ui

</td>

<td>

`org.eclipse.ui.IWorkbench`

</td>

<td>

[ActivityPropertyTester.java](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.ui.workbench/Eclipse%20UI/org/eclipse/ui/internal/activities/ActivityPropertyTester.java?view=co)

</td>

</tr>

<tr>

<th>

Property

</th>

<th colspan="2">

Description

</th>

</tr>

<tr>

<td>

isActivityEnabled

</td>

<td colspan="2">

Test if the activity in args is enabled.

</td>

</tr>

<tr>

<td>

isCategoryEnabled

</td>

<td colspan="2">

Test if the category in args is enabled.

</td>

</tr>

<tr>

<th>

Namespace

</th>

<th>

Type

</th>

<th>

Implementation

</th>

</tr>

<tr>

<td>

org.eclipse.ui.workbenchWindow

</td>

<td>

`org.eclipse.ui.IWorkbenchWindow`

</td>

<td>

[OpenPerspectivePropertyTester.java](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.ui.workbench/Eclipse%20UI/org/eclipse/ui/internal/OpenPerspectivePropertyTester.java?view=co)

</td>

</tr>

<tr>

<th>

Property

</th>

<th colspan="2">

Description

</th>

</tr>

<tr>

<td>

isPerspectiveOpen

</td>

<td colspan="2">

Tests if any perspective is open.

</td>

</tr>

</table>

# Expression examples

Here are some examples. I'll pretend all of the examples are deciding
when a handler is active.

## Basic IStructuredSelection

A view provides a structured selection through its selection provider.
An example would be the InfoView in
<b>org.eclipse.ui.examples.contributions</b>. You can browse the
[plugin.xml](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.ui.examples.contributions/plugin.xml?content-type=text%2Fplain&view=co)
and
[InfoView.java](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.ui.examples.contributions/src/org/eclipse/ui/examples/contributions/view/InfoView.java?view=co)
files. The InfoView provides an `IStructuredSelection` with 0 or more
`org.eclipse.ui.examples.contributions.model.Person`.

When using the default variable, you must treat it as an
`java.util.Collection`. That means using <count> or <iterate>

<activeWhen>
`   `<iterate>
`      `<instanceof value="org.eclipse.ui.examples.contributions.model.Person"/>
`   `</iterate>
</activeWhen>

## Package Explorer IStructuredSelection

The Package Explorer is a mixture of
`org.eclipse.core.resources.IResource`,
`org.eclipse.jdt.core.IJavaElement` and other classes. If you are trying
to find all of the \*.java files, you would need to:

1.  Iterate through the default variable
2.  adapt the selection elements to your class, in this case `IResource`
3.  use one of the org.eclipse.core.resources property testers to test
    the IResource property

For example:

<activeWhen>
`   `<iterate>
`      `<adapt type="org.eclipse.core.resources.IResource">
`         `<test property="org.eclipse.core.resources.name"
                value="*.java"/>
`      `</adapt>
`   `</iterate>
</activeWhen>

## Active editor type

If you want your handler to be active for a specific type of editor, you
can use <b>activeEditorId</b> to target your handler.

<activeWhen>
`   `<with variable="activeEditorId">
`      `<equals value="org.eclipse.ui.DefaultTextEditor"/>
`   `</with>
</activeWhen>

# 3.3 버전에서의 새로운 코어 익스프레션

3.3 버전에서 두개의 새로운 코어 익스프레션이 추가되었습니다.

## count 와 iterate

Count and iterate have always worked against `java.util.Collection`. The
<count/> and <iterate> elements can now be used on any variable that
adapts to `org.eclipse.core.expressions.ICountable` and
`org.eclipse.core.expressions.IIterable` or implements the interfaces
directly. It wasn't possible to use the java 1.5 constructs for
iterable.

The workbench provides an adapter for `ISelection` and
`IStructuredSelection`.

## definitions

The <b>org.eclipse.core.expressions.definitions</b> extension point was
introduced. You can create core expression definitions, and then
reference them from other core expressions.

<extension point="org.eclipse.core.expressions.definitions">
`   `<definition id="org.eclipse.ui.examples.contributions.view.inView">
`      `<with variable="activePartId">
`         `<equals value="org.eclipse.ui.examples.contributions.view"/>
`      `</with>
`   `</definition>
</extension>

Then:

<activeWhen>
`   `<reference definitionId="org.eclipse.ui.examples.contributions.view.inView"/>
</activeWhen>

The referenced expression will be evaluated at this point.

[Category:Eclipse Project](Category:Eclipse_Project "wikilink")