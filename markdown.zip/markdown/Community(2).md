This is example wiki page that shows how wiki content can be used to
define main eclipse.org site (as discussed in [Bug 410338 - Community
Portals page needs an
update](https://bugs.eclipse.org/bugs/show_bug.cgi?id=410338))

**<http://www.eclipse.org/community/>**

**Status**: Currently no changes suggested. Deprication is discussed
(Though content like Events, Evangelism, Campus is not so good for
[Using Eclipse...](http://www.eclipse.org/users/) page).