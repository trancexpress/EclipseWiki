**[back to STEM Contents Page](http://wiki.eclipse.org/index.php/STEM)**

| __TOC__ |
| ----------- |

![Ebola.jpg](Ebola.jpg "Ebola.jpg")

During the Ebola outbreak, the STEM Community hosted a series of weekly
phone calls (between 2014-2015) to support open discussion of Ebola
Modeling. Researchers studying Ebola Epidemiology, Modeling, and working
on Ebola Response, were all invited. Our goal was to accelerate research
by helping members of the scientific community interact, share data,
questions, and ideas with each other, and to connect researchers with
operational people. It was not necessary or required to be a user or
contributor to STEM. All discussion were open and non-confidential.

`The Ebola community call was scheduled to take place most every Weds at 11AM Pacific Daylight time (2PM Eastern Time)`
`Please find below the past minutes for each call along with the agendas and presentations.`

### Join the Community Call

`The special Ebola Calls have now been merged back with our ongoing monthly modeling call.`
`For more information, to add to the agenda, or if you wish to join that call, please send `[`mailto:judyvdouglas@verizon.net`](mailto:judyvdouglas@verizon.net)
`and please see the `[`STEM``
 ``Community`](Join_the_STEM_Community "wikilink")` page.`

### Participants

`List of all current and previous `[`Ebola``   ``Call``
 ``Participants`](Ebola_Call_Participants "wikilink")

### **Next Community Call with Deep Dive Presentation**

#### **Watch this spot for date, time, topic, and speaker**

### **April 29, 2015 Call with Deep Dive Presentation**

Phone call will begin at 2PM Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

for **April 29th**

Moderator: Stefan Edlund

1.  Welcome and Introductions
2.  News
3.  Items from Participants
4.  Deep Dive topic: Gerardo Chowell-Puente will present "Characterizing
    the Epidemic Growth of Ebola Epidemics."
    1.  Slides will be posted before the talk.
5.  Planning
    1.  Who would like to moderate future meetings?
    2.  What will be the deep dive topic?
    3.  Please send brief items for the agenda to
        judyvdouglas@verizon.net
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Future calls
        1.  Schedule?
        2.  Volunteers?

#### **Minutes**

Welcome by Stefan as moderator On the call: Selcuk, Kun, Simone, Judy,
Adrienne, Kun, Bill, Jamie Now on downhill slope of Ebola incidence
Calls once weekly now more sporadic News: Stefan gave overview of cases
as of April 26; Guinea 3500, Liberia 10K, Sierra Leon 12K; Case reported
as of March 27 of interest: female in her 40s with sexually transmitted
case well after time considered safe; recommendation is now for safe sex

Deep Dive Presentation by Selcuk Candan of Arizona State University who
has been working with Gerardo Chowell-Puente of Georgia State U and one
other scientist on two NSF grants; Demo shared using web conference.
Selcuk: asking three questions (1) what accounts for the difference
between incidence in Guinea and Sierra Leone? (2) why is Nigeria so much
lower? (3) what will happen in the future? Can plug in simulations
created with different models; how do the simulations look based on
assumptions? Right now the database is fixed

May reconvene in two weeks; will check to see whether Gerardo can
present more on the modeling; will follow up with Gerardo and Selcuk

##### **Attendees**

Stefan Edlund, IBM Almade Selcuk Candan, Arizona State University Kun
Hu, IBM Almaden Simone Bianco, IBM Almaden James Kaufman, IBM Almaden
Adrienne Bingham, William and Mary Bill Tetzlaff, IBM

### **CANCELLED March 18, 2015 Call CANCELLED**

Phone call will begin at 2PM Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

for **March 18th**

Moderator: TBA

1.  Welcome and Introductions
2.  News
3.  Items from Participants
4.  Deep Div Topics
5.  Planning
    1.  Who would like to moderate future meetings?
    2.  What will be the deep dive topic?
    3.  Please send brief items for the agenda to
        judyvdouglas@verizon.net
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Future calls, on biweekly schedule
        1.  April 1: Volunteers?===

#### **Minutes**

##### **Attendees**

### **March 4, 2015 Call**

Phone call will begin at 2PM Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

for **March 4th**

Moderator: TBA

1.  Welcome and Introductions
2.  News
3.  Items from Participants
4.  Focused Examination: Comeback of Ebola in Sierra Leone as described
    in the New York Times
    [1](http://www.nytimes.com/2015/03/01/world/africa/nearly-beaten-in-sierra-leone-ebola-makes-a-comeback-by-sea.html?_r=0)
5.  Planning
    1.  Who would like to moderate future meetings?
    2.  What will be the deep dive topic?
    3.  Please send brief items for the agenda to
        judyvdouglas@verizon.net
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Future calls, on biweekly schedule
        1.  March 18: Volunteers?
        2.  April 1: Volunteers?===

#### **Minutes**

##### **Attendees**

1.  Sheldon Jacobson, Univ of Illinois Urbana-Champaign
2.  Kun Hu, IBM Research
3.  Judy Douglas, IBM Research
4.  Leah Shaw, William and Mary
5.  Adrienna Bingham, William and Mary
6.  Richard Stovkis, Cures United
7.  Ilan Rubin, Cornell - GATech
8.  Bill Tetzlaff, IBM Watson
9.  Kasim Selcuk Candan, Arizona State University

##### **Welcome and Introductions**

Selcuk Candan of Arizona State University introduced himself and his
colleague and described two projects funded by NSF that they are working
on: one is more general and is using STEM for epidemiological
simulations of disease; the other is trying to understand how human's
mobility of affected areas could impact on Ebola transmission. They are
looking at mobility, its effect on disease, and on social and behavioral
shifts.

##### **News and Items from Participants**

Kun: New York Times story appeared this week on the comeback of Ebola in
Sierra Leone. Richard: Surprised that there is surprise at the comeback.
SL has not been able to mobilize enough to address real issues, i.e.,
early diagnosis, early treatment, and prevention. The idea that there
are no therapies persists, even though only two patients evacuated to US
or Europe died early in the epidemic. Will see changes when the rainy
season comes in May; social behaviors change (people may stay in or may
walk from village to village; road conditions will slow intervention.
Selucuk: Interested in impact of rainy season on behavior; using STEM to
model, planning to put in mobility, run multiple ensembles of
simulations (100K+) with parameters in different ranges. Plan to use
Ebola data with mobility patterns, match mobility patterns with
evolution of disease. Trying to get flight data from commercial flights
(before canceled); interested in charter flights. Bill: Interested in
Nate Silver’s approach to prediction...possible relevance to running
large numbers of simulations. Ilan: If there is a data jam at Georgia
Tech, will probably be by phone, not a physical meeting. Richard: As
transmission rates change, infectivity and contact may change; more
cases may mean more mutation in the virus.

##### **Planning Future Meetings**

Ilan will speak with Kun about presenting on March 18. Gerardo will
present his talk in April. Selcuk could talk about his work on Epidemic
Modeling and Ebola in 1 month.

### **February 4, 2015 Call**

Phone call will begin at 2PM Eastern Standard Time (11AM Pacific
Standard Time)

From this week, the call will be held by-weekly.

#### **Agenda**

for **February 4th**

Moderator: Ilan Rubin, Cornell University/ Georgia Tech

1.  Welcome and Introductions
2.  News
3.  Items from Participants
4.  Deep Dive Talk: Joshua Weitz, Georgia Tech, [Limits to Confidence in
    R0 as Inferred from Case
    Data](https://wiki.eclipse.org/images/0/0b/Weitz_gt_ebola_R0_v2_feb2015.pdf)
5.  Planning
    1.  Who would like to moderate future meetings?
    2.  What will be the deep dive topic?
    3.  Please send brief items for the agenda to
        judyvdouglas@verizon.net
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Future calls
        1.  February 18: Volunteers?
        2.  March 4: Volunteers?

#### **Minutes**

##### **Attendees**

1.  Simone Bianco, IBM Research
2.  Sheldon Jacobson, Univ of Illinois Urbana-Champaign
3.  Kun Hu, IBM Research
4.  Jamie Kaufman, IBM Research
5.  Stefan Edlund, IBM Research
6.  Judy Douglas, IBM Research
7.  Leah Shaw, William and Mary
8.  Adrienna Bingham, William and Mary
9.  Richard Stovkis, Cures United
10. Joshua Weitz, Georgia Tech
11. Bradford, Georgia Tech
12. Ilan Rubin, Cornell - GATech
13. Bill Tetzlaff, IBM Watson

##### **Welcome and Introductions**

##### **News and Items from Participants**

1.  Joshua on Open Data Jam held January 22-23: over 100 attendees from
    HHS, CDC, IBM, Intel, academic institutions, etc.; 10,000 word
    factual report (from students’ notes) to be released at the end of
    the week; Simone will receive to share via link. Main point: need
    for modelers to be more specific in their data needs.
2.  Joshua on discussion with Steve Adler: Atlanta role still in
    question. Jamie & Kun: IBM is not focused on a product; voluntary
    participation; open. Joshua: some other companies there had
    different open access issues; he and Caitlin will suggest low
    hanging fruit even if not involved in other ways.
3.  Simone: paper coming out with evidence as to transmission by
    asymptomatic individuals; need to incorporate in models; forwarding
    all the link
4.  Joshua: also paper coming out on Guinea
5.  Simone: Stuart Nichol has returned to his duties as Chief of the
    Viral Special Pathogens Brand and is no longer serving as the Chief
    Science Officer (CSO) for the CDC Emergency Operations Center for
    the Ebola outbreak response. \*Bill: New York Times reported over
    the weekend that Ebola in Liberia “is over”; perhaps prematurely.
    Stefan: It is winding down.

##### **Deep dive talk**

Dr. Joshua Weitz, Georgia Tech, on Limits to Confidence in R0 as
Inferred from Case Data

Simone: with Ebola, larger uncertainty at the beginning of the outbreak
and larger effect of transmission routes. Can Joshua account for
stochastic effect?

Joshua: major problem is outbreaks with different R0 look the same at
the start; Ilan is looks at what data people have used to look at R0 and
the effect of model structure; Bradford is looking at stochastic models,
trying to integrated.

Joshua: recognizing stochastic element might lead to a more directed
response; estimating R0 needs a hybrid approach.

Joshua: paper will be out in next 2 weeks with a few new things not in
the archive article.

Bill: R0 always a moving target, affected by interventions.

Joshua: training sessions (shown on slides) up to end of August, but
didn’t see changes then; thinks changes in behavior are what counted; R0
at the onset a function of the virus and the context in which it
emerged.

##### **Planning Future Meetings**

Next call will be February 18th: MOVING TO BIWEEKLY SCHEDULE.

Deep Dive slot open for February 18th; email Judy Douglas if you would
like to present and she will put on the wiki.

### **January 28, 2015 Call**

Phone call will begin at 2PM Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

for **January 28th**

Moderator: Simone Bianco, IBM Research - Almaden

1.  Welcome and Introductions
2.  News
3.  Items from Participants
4.  Deep Dive Talk: Simone Bianco, IBM Research - Almaden, will
    summarize the
    [workshop](https://wiki.eclipse.org/File:Ebm_agenda_public_011515.pdf)
    hosted by Georgia Tech last week
5.  Planning
    1.  Who would like to moderate future meetings?
    2.  What will be the deep dive topic?
    3.  Please send brief items for the agenda to
        judyvdouglas@verizon.net
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Future calls
        1.  February 4: Volunteers?
        2.  February 11: Volunteers?

#### **Minutes**

##### **Attendees**

1.  Leah Shaw, William and Mary
2.  Adrienna Bingham, William and Mary
3.  Richard Stovkis, Cures United
4.  Ira Schwartz, US Naval Research Laboratory
5.  Caitlin Rivers, VA Tech
6.  Ilan Rubin, Cornell - GATech
7.  Simone Bianco, IBM Research
8.  Kun Hu, IBM Research
9.  Jamie Kaufman, IBM Research
10. Stefan Edlund, IBM Research
11. Judy Douglas, IBM Research

##### **Welcome and Introductions**

Today the deep dive talk will summarize the workshop in Atlanta

There will be a detailed report with minutes of the workshop (out in a
few days)

Will provide a link

##### **Discussion**

News item: There will be a second data Jam - please see the email from
Judy

##### **Deep dive talk**

Summary of the "Modeling the Spread and Control of Ebola in West Africa"
workshop, GATech.

[GATech Workshop full slides deck](http://bit.ly/ebm_gt_slides_onepdf)

A few major themes of the GATech Workshop:

1.  The outbreak is past: Let's analyze how it went down and what
    happened in West Africa
2.  Data collection and data sharing is a major issue. Not enough data
    and low data quality
3.  What data is needed? What does it mean to have "real time" data?
4.  Phylogenic data can be used instead of epidemiological data to
    estimate parameters
5.  Sub-clinical infections can be a major player
6.  Modeling logistics can be a great help in planning a response
7.  Effective communication of modeling results as a key part of
    successful response

##### **Planning Future Meetings**

Joshua Weitz, GATech, will present next week.

Ilan Rubin will moderate.

### **January 21, 2015 Call**

Phone call will begin at 2PM Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

for **January 21st**

Moderator: Kun (Maggie) Hu, IBM Almaden

1.  Welcome and Introductions
2.  News
3.  Items from Participants
4.  Deep Dive Talk: Kun Hu, IBM Research - Almaden, will report on IBM
    Open Data Jam project and
    event.[2](https://wiki.eclipse.org/images/4/44/OpenDataJam.pdf)
5.  Planning
    1.  Who would like to moderate future meetings?
    2.  What will be the deep dive topic?
    3.  Please send brief items for the agenda to
        judyvdouglas@verizon.net
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Future calls
        1.  January 28: Simone Bianco will present the deep dive
            (tentative)
        2.  February 4: Volunteers?

#### **Minutes**

##### **Attendees**

1.  Kun Hu, IBM Almaden
2.  Sheldon Jacobson, Univ of Illinois Urbana-Champaign
3.  Judy Douglas, IBM Almaden
4.  Stefan Edlund, IBM Almaden
5.  Bill Tetzlaff, IBM Watson
6.  Ilan Rubin, Georgia Tech (visiting from Cornell)
7.  Joshua Weitz, Georgia Tech

##### **Welcome and Introductions**

New to call: Ilan Rubin, a student (from Cornell) who is working with
Dr. Weitz’s group on Ebola modeling at Georgia Tech; Dr. Weitz, who was
busy preparing for tomorrow’s workshop, also joined the call during
Kun’s presentation. Dr. Weitz’s team is doing work on contact tracing,
post-death transmission, calculation of the Ro, etc.

Kun: Call will be short today; Simone Bianco traveling to Georgia for
workshop where he will present a poster on work with US Navy Research
Lab on contact tracing;

##### **Discussion**

Kun: Last year CDC predicted 1.4 million cases by this January; now have
21,000. Good news—but the impact on the economy has been negative, with
food security problems arising because people are afraid to go to the
market. Farmers haven’t been able to sell their products.

Bill: Interview on Politico with the man appointed the US Ebola czar who
has now stepped down. His task was political—he worked to reassure the
US population and coordinate US military and health workers. US
Governmental interest is now at a low level.

Bill: After Hurricane Sandy, a project at Watson focused on coordinating
different groups bringing relief; smartphone based, ad hoc support for
data and communications

Kun: This project was represented at the IBM internal meeting last week

Kun: Modeler and scientist have to have reliable data to produce
validated model for scenario test and prediction; the Open Data Jam is
addressing this with a website listing public available datasets; will
have Ebola Open Data Jam II in various places in February; is open to
public.

##### **Planning Future Meetings**

Joshua: He will exchange emails with Kun, look at possible topics for
February 4th or after

Bill: Possible topic might be titled “The Proper Place for Ebola
Modeling”; data used in early models “flaky”, need to get data on the
group, evaluate effects of different types of remediation

### **January 14, 2015 Call**

Phone call will begin at 2PM Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

"for" **January 14**

Moderator: Stefan Edlund, IBM Research, Almaden (Simone will be at a
meeting)

1.  Welcome and introductions
2.  News
3.  Items from participants
4.  Deep dive talk: Alex J. Jones, Operon Labs, will talk on [new
    diagnostics on the
    market](https://wiki.eclipse.org/File:IBM_Deep_Dive_Topic_1_pdf.pdf)
5.  Planning 2015's agenda
    1.  Who would like to moderate?
    2.  What will be the deep dive topic?
    3.  Please send short agenda items to judyvdouglas@verizon.net by
        Monday
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Future calls
        1.  January 21, TBD
        2.  January 28, TBD

#### **Minutes**

##### **Attendees**

1.  Sheldon Jacobson, Univ of Illinois Urbana-Champaign
2.  Richard Stovkis, Chief Medical Officer of Cures United
3.  Judy Douglas, IBM Almaden
4.  Stefan Edlund, IBM Almaden
5.  Michael Perrone, IBM Watson
6.  Bill Tetzlaff, IBM Watson
7.  Alexander J. Jones, OperonLabs, NIH
8.  Alexe Bojovschi, IBM Research, Australia

##### **Discussion**

News/Items from participants Judy: China sending large Ebola relief team
to West Africa – Associated Press

Sheldon: Situation worsening in Sierra Leone, now at 50 cases/day;
Liberia at 20/day, Guinea at 4/day. Country population: Sierra Leone 6
million, Liberia 2.5 million, Guinea 12 million

Alex: Sierra Leone is where Liberia was in October; media frenzy in US
down, issue seems to have fallen off Americans’ radar screen

Richard: “Still a mess“ in Sierra Leone; reported cases vary
dramatically day-to-day

Michael: 4 hour meeting on Ebola yesterday at Yorktown to brainstorm
solutions, corporate strategies; attendees from across IBM, including
Kenya; two from DoD; resources are available

Michael: Wants to bring different groups together, will send Judy his
lists

Bill: As long time emeritus IBM researcher, knows how IBM supports
efforts, also knows people in the company; need isn’t for high-tech apps

Stefan: Focus of these calls is on modeling

Michael: Can give names of those attending his groups who have an
interest in modeling

Alex: Would join another group

Bill: Would serve as bridge between Yorktown and Almaden groups

Discussion: Sierra Leone has old mobile phones, good network; but not
smart phones (for data); free texting is being used to track disease,
e.g., “my husband has symptoms”

##### **Deep Dive talk**

Alexander J. Jones, OperonLabs on Diagnostic and Ebola. Presentation
available in agenda.

Richard: Lots of mucosal involvement in Ebola; if catch in first 3 days,
not so bad; knowing viral load might be helpful

Discussion: Lack of FDA approval for RT-PCR devices; off label use of
FDA approved drugs with known risk; seemingly a problem in Africa, but
not in US or Europe

Richard: We’re where we were with HIV/AIDS 10-20 years ago

Richard & Alex: Approval process is a stumbling block; shouldn’t wait;
question in years ahead will be why didn’t we treat earlier, why did we
let so many people die?

Richard: His team will use Q-RT-PCR machines

Alex: Collecting data from the RT-PCR machines could be valuable;
comparison of viral loads on different days might help treatment,
epidemiological modeling, decisions in the field

Alex is currently visiting a company building an open source Q-RT-PCR in
the bay area.

##### **Planning**

1.  No volunteers at this time
2.  Tentative schedule: Kun on January 21, on Yorktown meeting; Simone
    on January 28

### **Jan 7, 2015 Call**

Phone call will begin at 2pm Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

*for* **Jan 7**

Moderator: Kun (Maggie) Hu, IBM Research, Almaden

1.  Welcome and Introductions
2.  News
3.  Items from participants
4.  Deep dive talk: ["Passenger Screening for Ebola: The New Security or
    the New
    Threat?"](https://wiki.eclipse.org/images/2/27/2015-1_Ebola_Screening_SH_Jacobson.pdf)
    Presented by Prof. Sheldon Jacobson, Univ of Illinois
    Urbana-Champaign
5.  Planning 2015's agenda
    1.  Who would like to moderate in Jan 2015?
    2.  What will be the deep dive topic?
    3.  Please send short agenda items to judyvdouglas@verizon.net by
        Monday
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  **Future Calls:**
        1.  Jan. 14, TBD
        2.  Jan. 21, TBD

#### **Minutes**

##### **Attendees**

1.  Sheldon Jacobson, Univ of Illinois Urbana-Champaign
2.  Richard Stovkis, Chief Medical Officer of Cures United
3.  Judy Douglas, IBM Almaden
4.  Leah Shaw, William and Mary
5.  Simone Bianco, IBM Almaden
6.  Stefan Edlund, IBM Almaden
7.  James Kaufman, IBM Almaden
8.  Kun (Maggie) Hu, IBM Almaden
9.  Michael Perrone, IBM Watson
10. Bill Tetzlaff, IBM Watson
11. Alexander J. Jones, OperonLabs, NIH

##### **Discussion**

Kun (Maggie): Welcome to the first call of 2015, and thanks to all for
last year’s participation

Michael Perrone: New to call, from IBM Research Yorktown, was in Ebola
jam last October, has been working on Ebola app with a group there since
then, would like to get them involved with the Modeling call

Other potential new participants: Meenal Pore (she’s 8 hours ahead of
us) from IBM Africa Research Lab, also China CDC Vice General Director
(it’s 3 am there)

Simone: Workshop January 22-23, Modeling Spread and Control of Ebola in
West Africa, at Georgia Tech,
[3](http://petitinstitute.gatech.edu/modeling-spread-and-control-ebola-west-africa).
Will give report on workshop as Deep Dive the following week, January 28

Kun: China CDC Director wants to join in call; need to work on a time he
can do so

Richard: Making slow but steady progress, will start intervention in
Sierra Leone in February; will talk with Kun following the call re their
shared modeling effort, items not yet ready for dissemination

##### **Deep Dive talk**

Prof. Sheldon Jacobson’s presentation: Passenger Screening for Ebola:
The New Security or the New Threat; powerpoint available in agenda.

Query: Why no actual blood screening at airports? Seems to be only test
that’s reliable

Answer (Sheldon): Doesn’t know reason why

Query (Simone): Any resources being shifted from security to Ebola?

Answer (Sheldon): Thinks not, but don’t have evidence

Discussion: Cost of treatment lower with testing due to earlier
diagnosis, also cost in US $0.5-1 Million, in West Africa $2K

Bill T: Most leaving are aid workers, need to offer those tested
treatment, evacuation to Europe or US

Alex: Blood test reliable only if close to coming down with the disease;
other tests not reliable; genetics are involved

James: 2 ways to think about screening: (1) to ID those who are sick and
keep from traveling or (2) to track and help (contact tracing,
treatment)

Sheldon: Yes, need to clarify the objective; exit screening is critical

Alex: The greater the number of people with the disease, the greater the
chance the virus will adapt

Sheldon: Yes, compare with Spanish flu

Alex: Disease shows wave pattern; emergent behavior; West Africa borders
are artificial, with different ethnic groups

##### **Planning**

1.  January 14: Alex will moderate, give Deep Dive on new diagnostics on
    the market
2.  January 21: Kun (Tentative, Deep Dive report on meeting she’s
    attending in New York next week; to be confirmed)
3.  January 28: Simone to give Deep Dive on Georgia Tech workshop
4.  Kun will write Director of China CDC to invite him to give a talk;
    will give alternate dates, ask what time works for him

### **December 17, 2014 Call**

Phone call will begin at 2pm Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

*for* **December 17**

Moderator: Kun (Maggie) Hu, IBM Research, Almaden

1.  Welcome and Introductions
2.  News
3.  Items from participants
4.  Planning 2015's agenda
    1.  Who would like to moderate in 2015?
    2.  What will be the deep dive topic?
    3.  Please send short agenda items to judyvdouglas@verizon.net by
        Monday
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  **Future Calls:**
        1.  Jan. 7, Prof. Sheldon Jacobson, Univ of Illinois
            Urbana-Champaign
        2.  Jan. 14, TBD

#### **Minutes**

##### **Attendees**

1.  Kun (Maggie) Hu, IBM Research, Almaden
2.  Sheldon Jacobson, Univ of Illinois Urbana-Champaign
3.  Bill Tetzlaff, IBM Watson
4.  Judy Douglas, IBM Research, Almaden
5.  Richard Stovkis, Chief Medical Officer of Cures United
6.  Roslyn Hickson, IBM Australia
7.  Alexe Bojovschi, IBM Research, Australia
8.  Alexander J. Jones, OperonLabs

##### **Discussion**

Welcome and Introductions Alexe Bojovschi, IBM Australia, new to call;
PhD in molecular biology, working on computation aspect of Ebola,
possibility of modeling the virus and how it inserts into cell

Open Discussion (no Deep Dive) Bill: Report in yesterday’s New York
Times suggested that the rate of unreported Ebola may lower than
previously estimated, perhaps half of what it was thought to be

Kun: Other news story suggested cases not report, bodies not claimed at
a diamond mine in Sierra Leone

Richard: Huge differences in un-reporting between the 3 countries;
Sierra Leone probably highest

Bill: CNN show on “ordinary heroes” reported on nursing student in
Liberia who treated her family, saved 3 of 4 members, using some drugs
and improvised equipment

Richard: Most patients in US survived if they got early treatment

Bill: Cases in CNN story suggest an intermediate data point

Alex (US): Most recent data points suggest rates going down: Liberia
16/day, Guinea, 23.5/day (with slow increasing rate), Sierra Leone
60/day

Richard: Situation in Sierra Leone hasn’t improved much; reporting may
be bad; WHO gets data from ministries of health in Sierra Leone; 11-12
December 100 cases, 13 December 40, 14 December 4 0, 15 December 64, 16
December none reported, 17 December 55; some days missing, wide
fluctuation

Bill: Nature of reporting—don’t really know

Alex (US): Have found Ebola virus in guinea pig genome, could be 60
million years old, or the estimate could be way off; looking for
ancestor of protein; genetic archeology, fossilized genes; also in bats,
one marsupial, etc.; Ebola and other pathogens not particularly lethal
except in humans

Richard: True of Marburg virus as well; also bats no much affected; if
intervention starts early enough, survival goes way up; children have
best chance; age group a factor as in Spanish flu, difference in host
response

Alex (US): Compare Ebola and avian flu—class 1 fusion, same form of
fusion protein

Richard: Published work of Steven Opel @ Brown, other scientist @ UVA on
host response, Ebola and flu

Alex (US): Host response modification, calcium entry blockers may
prevent penetration of Ebola virus into cell; possibly testing of
various medications affect on Ebola; may affect proteins molecular
docking

Alexe (Australia): Also electrolytes stop entry...

Alex (US): Studying protein folding would be of interest; better
software now than 10 years ago

Richard: Try to deal with this outbreak now, do other things later
(remember last May when the outbreak was thought to be over); issues
with approval process and prescribing off label

##### **Deep Dive talk**

None scheduled for this week.

##### '''Planning '''

1.  January 7: Professor Jacboson
2.  January 14: SEND SUGGESTIONS TO KUN, JUDY
3.  Roslyn: May be able to share in February, after confidentiality
    restrictions are lifted

### **December 10, 2014 Call**

Phone call will begin at 2pm Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

*for* **December 10**

Moderator: Richard Stovkis, Chief Medical Officer of Cures United

1.  Welcome and Introductions
2.  News
3.  Items from participants
4.  Simone Bianco from IBM research will share his latest trip to D.C.
    for 2 conferences/panels
    1.  Responding to Global Health Crises – Technology & Policy
        Innovation. Organized by ITI and Intel
    2.  Ebola: Meet the experts - A reverse procurement launch.
        Organized by the Corporate Council on Africa and the House
        Committee on Foreign Affairs
5.  Planning Next week's agenda
    1.  Who would like to moderate in Jan 2015?
    2.  What will be the deep dive topic?
    3.  Please send short agenda items to judyvdouglas@verizon.net by
        Monday
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  **Future Calls:**
        1.  Dec. 17, Mehmet H Gunes, title pending
        2.  Jan. 7, TBD

#### **Minutes**

##### **Attendees**

1.  Kun (Maggie) Hu, IBM Almaden
2.  Judy Douglas, IBM Almaden
3.  Stefan Edlund, IBM Almaden
4.  Simone Bianco, IBM Almaden
5.  Melissa Cefkin, IBM Almaden
6.  Richard Stovkis, Chief Medical Officer of Cures United
7.  Bill Tetzlaff, IBM Watson
8.  Ada Yan, Univ of Melbourne
9.  Alexander J. Jones, OperonLabs, NIH

##### **Discussion**

Alex: Situation stabilized in Liberia at 10 new cases a day; situation
deteriorating in Sierra Leone, moving up from 10 to 100 new cases a day;
junior doctors are on strike.

Richard: Seems to be moving west in Sierra Leone.

Alex: Read that 70% of infections com from funerals.

Richard: Funeral rituals in Sierra Leone have not changed much, but the
70% is questionable.

Richard: Not enough beds in Sierra Leone; people not admitted into
hospital get no treatment, need to go out and get food, fuel
transmission; also, raining season is over so people move around more.

Alex: Outbreak in Liberia has moved back out from city to country at 10
new cases a day.

Kun: Panelist mentioned travel very difficult in Sierra Leone—what does
that mean for Richard’s mobile lab?

Richard: Roads are like “trails,” sometimes have to walk to remote
villages but majority of people reachable by road if you have 4 wheel
drive; basically the more mobile labs you have, the more patients you
can reach.

Richard: Plan to reach 90-95% in new year, compared to 20% now.

Alex: Read doing lockdowns in Sierra Leone; the striking junior docs
want access to western medical care.

Richard: British and American run army hospitals have 40% mortality;
other treatment centers have 70% (no hydration, not drugs); 40% still
far too high; only 3 deaths among patients treated in US and Europe.

Richard: Only getting snippets of information on what treatment people
get.

Bill: Who is staffing US and British hospitals? Richard: Army docs and
nurses.

Richard: Quality still not high enough; we don’t supply enough drugs,
etc. at the moment.

Alex: Number of cases now probably 2 times what’s report—but still below
number modeled in September.

##### **Deep Dive talk**

Simone Bianco, Report on two panels he attended last week in Washington
DC, one sponsored by the House Committee on Foreign Affairs, the other
by the IT Council and Intel

Focus: What is the role of technology in this crisis

Panel 1: Attendees a mix of doctors, nurses from on the ground, plus
representative of the modeling and scientific communities; plus US
government officials (White House advisor, etc.)

USAID official: Now that the number of new cases in Liberia is below 10,
need to shift from intervening to sustaining the effort

Take-away: There is a disconnect between what people do in the tech
field and what is happening on the ground; no middle ground; people on
ground didn’t want iPads, they wanted bicycles

Challenge: Build bridge to transition from science to policy—but
difficult to implement policy. Need to empower locals, general
government; need to introduce ideas from basic science

Challenge: Policies require an understanding of what is actually going
on from a sociological and anthropological point of view

Panel 2: Attendees from companies proposing technical devices to address
epidemic, e.g., one company proposed medical probes, etc., small
electronic devices that we don’t even have here in US hospitals

Take-away: Need to connect existing technologies to what’s actually
happening. One government official just back from Sierra Leone showed
his welcome home kit for self monitoring Can take a couple of weeks or
up to a couple of months to use some devices, depending on medical
expertise; more important to have docs on the ground than to have lots
of fancy equipment

Problems with data collection—who do you report to? Data is being
collected but getting harder and harder to get ahold of; US government
is engaging in talks re data sharing with three of the affected
countries

Richard: Where do you put the bar for treatment? A $3K probe for
checking hydration works as well as a much more expensive device; need
to have doc who can use; with early diagnosis and treatment, survival
goes up, transmission goes down

Melissa: Structural considerations, not just behavioral ones; if basics
are not there (and fancy stuff is), mistrust results

Simone: IBM Kenya Lab has system in Sierra Leone that allows people to
call in (per Richard, almost everyone has a cell phone) to report a dead
body, road block, etc.; people bombarded by public service
announcements; messages have to be ones that people can relate to

Richard: Like response to HIV testing in Africa; don’t want to be tested
if not offered something in return; don’t want diagnosis if it means
they have to go to a treatment center where chances of survival are one
in ten

Bill: Some estimate cost of putting in a $15K Ebola testing machine in
Sierra Leone as high as $½ to 1M counting in cost of skilled
technicians, assurances they will be evacuated if they become ill

Richard: Can’t just put diagnostic machines; need staff; highest cost
(probably more than ½ of total) is cost of insurance for evacuation,
life insurance, etc.; cost $2-3M to evacuate to US

##### '''PLANNING NEXT WEEK’S AGENDA"

Consensus: Will have call for discussion, no deep dive planned

Kun will moderate; this will be the last call in 2014; will resume with
regular call on January 7, 2015

### **December 3, 2014 Call**

Phone call will begin at 2pm Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

*for* **December 3**

Moderator: Mary Helander, IBM

1.  Welcome and Introductions
2.  News
3.  Items from participants
4.  20 minute deep dive topic: Richard Stovkis, Chief Medical Officer of
    Cures United on intervention, with Kun (Maggie) Hu, IBM, on "quick
    modeling" [**Ebola Early Diagnosis and Treatment
    Model**](https://wiki.eclipse.org/File:InterventionModel_CuresUnited_IBM_updated.pdf)
5.  Planning Next week's agenda
    1.  Who would like to moderate in two weeks?
    2.  What will be the deep dive topic?
    3.  Please send short agenda items to judyvdouglas@verizon.net by
        Monday
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  **Future Calls:**
        1.  Dec. 10, tbd (PLEASE SEND IDEAS TO JUDY DOUGLAS)
        2.  Dec. 17, Mehmet H Gunes, title pending

#### **Minutes**

##### **Attendees**

1.  Kun (Maggie) Hu, IBM Almaden
2.  Judy Douglas, IBM Almaden
3.  Stefan Edlund, IBM Almaden
4.  Richard Stovkis, Chief Medical Officer of Cures United
5.  Bill Tetzlaff, IBM Research
6.  Ada Yan, Univ of Melbourne
7.  Roslyn Hickson, IBM Australia
8.  Mary Helander, IBM Watson
9.  Leah Shaw, William and Mary
10. Sheldon Jacobson, Univ of Illinois Urbana-Champaign

##### **Discussion**

Mary: opened call; no new participants; group opted to move directly to
deep dive (no news, no items from participants) Maggie (Kun): posted
slides on wiki Richard: sent slides by email

##### **Deep Dive talk**

DEEP DIVE: Richard opened and closed; Maggie reviewed modeling in middle

Richard: his group will be on the ground in Sierra Leone in early
January if funding will be available soon.

Richard: protective garb frightening to patients; suits shown in Berlin
show healthcare professionals’ faces and can undergo chemical showers
for more safety

Richard: diagnosis in first 3 days decreases mortality, decreases
transmission (as shown in slide)

Bill: is it rational for a patient to decide to stay at home?

Richard: we don’t know, but do know patient could do better at home with
meds

Richard: in US and EU all patients diagnosed and treated early survived

Richard: in intervention and treatment, small things make a difference,
e.g., need potassium in hydration but potassium is not in standard
hydration

Richard: antiviral “cocktails”

Richard: be agnostic, try both pre-exposure and post-exposure

Richard: don’t have a vaccine now, and vaccines difficult to distribute
safely in Africa

Bill: New York Times article on treatment center (one nurse, ten
patients, couldn’t do a lot); underscores need for trained people

Richard: will bring 120 people to Sierra Leone in January; interventions
to include food packages for patients who stay at home

Richard: IBM Kenya working with mobile phones, 90 minutes to get a test
result

Maggie: gave presentation on preliminary model in earlier call; has
worked with Richard (slide 11) to include day of diagnosis as a
compartment

Mary: how to know when person diagnosed?

Maggie: when symptoms first appear

Maggie: open sourced Ebola model on wiki can be used to model different
interventions (e.g., social distancing such as airport travel
restrictions)

Stefan: what is day zero in the simulation

Maggie: November 18, used CDC reported case data to initialize the
simulation

Richard: believes his group can keep outbreak under control “quite
rapidly” and have very few patients in 3 months; will use mobile
diagnostics; won’t wait on vaccines

Bill: even with vaccine, healthcare workers will need protective gear;
no vaccine 100%

Richard: no vaccine has 100% efficacy; hope to collect data in Sierra
Leone to feed back into model

Bill: changing dynamics, parameters (gear, drug) can affect model

Maggie: with more data, can improve, extend model

Mary: thanks to speakers for informative, substantive talk\!

##### '''PLANNING NEXT WEEK’S AGENDA"

Richard will moderate

Ada will check with colleagues and get back to Maggie

Richard: would like to hear from IBM Kenya

Maggie: would like to hear research questions from Ada’s group, possibly
collaborate with them

Sheldon: may give deep dive in January, but cannot commit as of yet (not
sure about time)

### **November 19, 2014 Call**

Phone call will begin at 2pm Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

*for* **November 19**

Moderator: Leah Shaw, College of William and Mary

1.  Welcome and Introductions
2.  News
3.  Items from participants
4.  20 minute deep dive topic: Leah Shaw, College of William and Mary
    [**Impact of Exposed Compartment on Modeling Disease
    Dynamics**](https://wiki.eclipse.org/File:ShawEbolaConfCall.pdf)
5.  Planning Next week's agenda
    1.  Who would like to moderate in two weeks?
    2.  What will be the deep dive topic?
    3.  Please send short agenda items to judyvdouglas@verizon.net by
        Monday
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  **Future Calls:**
        1.  Nov. 26, THANKSGIVING HOLIDAY
        2.  Dec. 3, tbd
        3.  Dec. 10, tbd
        4.  Dec. 17, Mehmet H Gunes, title pending

#### **Minutes**

##### **Attendees**

1.  Simone Bianco, IBM Research
2.  Richard Stovkis, Chief Medical Officer of Cures United
3.  Leah Shaw, William and Mary
4.  Ada Yan, Univ of Melbourne
5.  Judy Douglas, IBM Research
6.  Ira Schwartz, US Naval Research Lab
7.  Sheldon Jacobson, Univ of Illinois Urbana-Champaign
8.  Tridane Abdessamad, UAE University
9.  Melissa Cefkin, IBM Research
10. Bill Tetzlaff, IBM Research
11. Mehmet Gunes, Univ Nevada Reno

##### **Discussion**

Bill Tetzlaff: Healthcare population size, articles suggest that
Healthcare workers that become infected are those who work in regular
healthcare, where the ebola patients come first. The workers that have
contracted ebola in ebola clinics also work on general healthcare. In
Liberia: 5M people, 5000 healthcare workers, 51 doctors (1 in 16 already
infected). 1 in 2000 general population are infected with ebola. The
medical staff are going to be decimated in the coming months. if model
could be separated into 2 populations, crisis is for healthcare workers;
focus on them might drive need for test kits

Simone: some models allow for separation. Kun has done some work here;
and Simone are Kun are not the only ones to do so (but are the only ones
to do spatially); it’s complicated. Tried to see effect of number of
healthcare workers, size of population; haven’t seen data to show
change; access to personal protective gear is better---has this had an
impact?

Simone: Is there any trend in these two populations? Downward, upward,
stable? Not much data is collected/shared

Richard: Many clinics are closed to prevent general access. Also 10% of
patients with ebola have active malaria, and they have problem with
false negatives and false positives.

##### **Deep Dive talk**

Leah Shaw, College of William and Mary [**Impact of Exposed Compartment
on Modeling Disease
Dynamics**](https://wiki.eclipse.org/File:ShawEbolaConfCall.pdf)

Ordinary differential equations (ODE) vs. delayed differential equations
(DDE), effect on modeling dynamics, parameter fittings, tried two
different ways to write ODE models. Models were integrated in MatLab,
deterministic model, numerical integration

Ada: how much contact tracking data? how many compartments? Using 1
exposed compartment and then go to more compartments by fitting the
data, by including contact tracing data.

Leah: fixed latent vs. exponentially distributed Infectious period;
implication-how long to monitory people

Leah: Look at Wearing paper on reproduction rate (cited on last slide)

Simone: SEIR with only one Exposed compartment? Reproductive number less
than 2 underestimating?

Leah: Most using multiple I classes, only one E class

Simone: Any epidemiological basis that confirms E period?

Richard: some info, not much; depends on testing used (viral load?); no
hard scientific evidence that people shed virus only after symptoms
appear

Richard: Is it possible to do age stratification? It is possible to
divide exposed in age groups, since age is an important component of the
infection. The disease develops in younger people to a much higher
chance of survival for people over 20.

Ada: Correct distribution in exposed is important. What effects would it
have the impact of infections? Anything that interacts with time (like
intervention on exposed) may be impacted on by this. How would this
affect parameter fitting?

Sheldon: how would it affect prophylaxis, vaccination?

Leah: would like to talk more, work with those interested

### **November 12, 2014 Call**

Phone call will begin at 2pm Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

*for* **November 12**

Moderator: Dr. Melissa Cefkin IBM Research, Almaden

1.  Welcome and Introductions
2.  News
3.  Items from participants
4.  20 minute deep dive topic: [Some Insights from Anthropologists on
    Ebola](https://wiki.eclipse.org/File:InsightsFromAnthropologistsCefkin.pdf)
5.  Planning Next week's agenda
    1.  Who would like to moderate in two weeks?
    2.  What will be the deep dive topic?
    3.  Please send short agenda items to jhkauf@us.ibm.com by Monday
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Next week's deep dive: Dr. Melissa Cefkin IBM Almaden. Topic
        *"Some Insights from Anthropologists on Ebola"*
    6.  **Future Calls:**
        1.  Nov. 19, moderator: Leah Shaw, College of William and Mary
            *subject tbd*
        2.  Nov. 26, THANKSGIVING HOLIDAY
        3.  Dec. 3, tbd
        4.  Dec. 10, tbd
        5.  Dec. 17, Mehmet H Gunes, title pending

#### **Minutes**

##### **Attendees**

1.  Sheldon Jacobsen, Dept of Computer Science, University of Illinois,
    Urbana
2.  James Kaufman
3.  Pat Selinger
4.  Melissa Cefkin
5.  Mary Helander December 3rd
6.  Richard Stokvis, Chief Medical Officer of Cures United, the
    Netherlands
7.  Simone Bianco
8.  Stefan Edlund
9.  Leah Shaw
10. Nic Geard University of Melbourne
11. Alexander J. Jones
12. Michael Washington from CDC modeling Unit
13. Mehmet Gunes
14. Caitlin Rivers
15. Bill Tetzlaff

##### **Discussion**

Alex: Total is 13594 confirmed cases. May underestimate by factor of 3.

5160 - 5400 Deaths Nurse died in Mali Imam died in Mali Africa Cup
cancelled U.S. Nurses (Kaiser SF) on strike over Ebola measures and
training Article on poverty and transmission, plan to model based on
lights at night

Pat: Syndemics references could motivate new models.

Caitlin: WHO just posted new data portal

Alex: Question. Early in the outbreak we were able to rely on
underreporting as constant rate or value. But it seems to be changing.
Can we look at data to estimate changing rate of underreporting?

##### **Deep Dive talk**

Alex: JFK hospital referred to locally as "Just for Killing" even before
Ebola

Richard: Half the people die in the modeling. What could be done when
you treat people properly - how would it change the outcome and develop
trust in the treatment centers? 400 nurses and doctors died because they
did not have the required protected gear.

JK: How does treatment change mortality rate

Richard: Patient in Hamburg recovered. Patient in NY treatment not
published yet successful treatments only partially published Consensus
among infectious disease experts is that there is chance of recovery of
95% with proper treatment Statins and other drugs are thought to be
quite effective. It's not just treating the virus but also treating the
patient

Alex: Local practices that may even emerge from "Myths" sometimes lead
to quarantine (not based on germ theory but still effective)

Bill T: Looked population statistics on health workers. modeling running
out of health workers. We need numbers on health workers

Discussion between Alex and Richard on Melatonin: Richard indicates
there may be \>50 compounds that help. With proper treatment people
survive. The doctors mix and match. A lot of things seem to work. We
need to see more published protocols. Fujifilm offered compound T-705
(Avagan registered in Japan for Flu, stockpiled for flu) WHO is trying
to decide if when we should do a clinical trial - it's sitting idle.
With \> 50% mortality don't need placebo controlled trials, just do
something. In Africa the protective gear equipment is like "cardboard"
compared to gear in the US (not possible to remove it without touching
skin). PH affects weather the chlorine works. 400 workers die - most of
them are locals. Treatment and equipment is not based on science.

10% of Ebola patients ALSO have active malaria. People with Malaria went
for treatment and contracted Ebola in the clinic.

### **November 5, 2014 Call**

Phone call will begin at 2pm Eastern Standard Time (11AM Pacific
Standard Time)

#### **Agenda**

*for* **November 5**

Moderator: Dr. Emma McBryde University of Melbourne

1.  Welcome and Introductions
2.  News
3.  Items from participants
4.  20 minute deep dive topic: **Ebola Infectivity over time**
    Presenter: Dr. Emma McBryde. [Please click HERE for the
    slides](https://wiki.eclipse.org/File:DeepDiveEbolaEMcBryde.pdf)
5.  Planning Next week's agenda
    1.  Who would like to moderate in two weeks?
    2.  What will be the deep dive topic?
    3.  Please send short agenda items to Judy by Monday
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Next week's deep dive: Dr. Melissa Cefkin IBM Almaden. Topic
        *"Some Insights from Anthropologists on Ebola"*
    6.  Next week's moderator: Melissa Cefkin IBM Almaden

#### **Minutes**

##### **Attendees**

1.  James Kaufman, IBM Almaden
2.  B.Tetzlaff, IBM Watson
3.  S.Bianco, IBM Almaden
4.  J. Douglas, IBM Almaden
5.  Jodie McVernon, University of Melbourne
6.  Kraig Butrum, Skoll Global
7.  Matt Davis, IBM Australia
8.  James Mccaw, University of Melbourne
9.  Stefan Edlund, IBM Almaden
10. Ira Schwartz, US Naval Research Laboratory
11. Emma McBryde, University of Melbourne
12. Melissa Cefkin, IBM Almaden
13. Kun Hu, IBM Almaden
14. Alexander J. Jones, OperonLabs, NIH
15. Leah Shaw, College of William and Mary
16. Nic Geard, University of Melbourne
17. Klimka Szwaykowska, US Naval Research Laboratory
18. Pat Selinger, IBM Almaden
19. Mehmet Gunes, University of Nevada, Reno

##### **Discussion**

**News**

B Tetzlaff: Read in *Science* health workers are still getting infected
both in hazard suites but also in triage (without suits) Model does not
segregate people who are with different risks. Can we extend model to
distinguish clinical workers? Also people who are involved in burial,
and friends and family in contact with sick family members outside of
hospital

Emma: A number of people are thinking about how to model different risk
groups. Alex: As model gets more complex have more granularity but
sometimes data you feed the model is not available. Jamie: Agrees with
Alex. Bill: Agrees....

Emma: All agree would be nice to have more model complexity but there
are problems in doing that in particular finding appropriate parameters
from the data and introducing unknown parameters. Word in newspapers is
that things are slowing down in Liberia.

Alex: WHO gone from 3%/day increase to 1% but 2.5% factor
under-reporting. Seems like a slowing in the rate of growth in Liberia
Sierra Leone is accelerating. Difficult to separate out the noise. We
really don't know and won't know for 1-2 months.

B Tetzlaff: Under-reporting is a guess and estimate is continuously
changing.

Alex: If we take reports at face value there is a deceleration in
Liberia and acceleration in Sierra Leon but we don't really know.

Emma: H Nishira did a model in Eurosurveilance looked at three countries
as a system. R0 in Guinea\<1 but for whole system R0 \>1. This could
happen again as various countries try to bring Ebola under control.

Alex: Rate accelerating in area around Freetown. Avg \# daily cases is
6x higher than 2 months ago.

##### **Deep Dive talk**

**Ebola Infectivity over time** Presenter: Dr. Emma McBryde. [Please
click HERE for the
slides](https://wiki.eclipse.org/File:DeepDiveEbolaEMcBryde.pdf)

Infectiousness increases continuously over time from infectious onset to
death slide 2 shows level in blood as fn of days after detection then
drops off (for both fatal and nonfatal) Paper by Yemen and Galvani Anals
of Internal Medicine. Oct 28th published online Example of a model that
does microsimulations including infectivity by day Also looked at
contacts drawn contract from a distribution. Assume same for everyone
except during last stages of disease should we model change infection
over time. If we want detail in interventions (eg training family for
nursing at home) there is a delay between onset of fever and
interventions - this should be captured in the model. showed how to
extend the previous ebola model only additional parameters in this
simple extension were transitions between infectious compartments. Three
new transitions

Slide 7:

Q: Pat people die too early so peak happens too soon

E: That is correct. Slide 8 shows this

Patt: If we turn off hospitalization we would see this peak (breakdown
in hospitalization)

Emma: Correct.

Alex: Useful to look at that.

`The model results are very sensitive to assumptions around interventions on duration in the infectious compartment`
`Sensitivity extends to assumptions about shape of infectiousness and shape of interventions`
`These may need to be considered when thinking of interventions like home quarantine`

Q from Simone: should we have fewer deaths from I1,I2 than I3,I4 how
would that change the results ? Emma: Agree. Selecting from a parametric
distribution of observed cases would give a more realistic model. The
goal here was just to see if changing infectious changes the outcome of
interventions. Lots of parameter changes would not matter much in this
model but in reality might be very important. Starting from scratch want
to use more realistic values in each compartment

##### **Items from Participants**

Item from Emma. Q for STEM people about issue of data sharing

Is creative commons ok for Eclipse.

Jamie: Probably it is. We just need to follow the submission process and
Eclipse attorneys will review the license.

Jamie will update wiki on stochastic solvers

Leah Shaw will moderate in two weeks

### **October 29, 2014 Call**

Phone call will begin at 2pm ET (11AM PDT)

#### **Agenda**

*for* **October 29**

Moderator: Simone Bianco, IBM Almaden Research Center

1.  Welcome and Introductions
2.  News
3.  Any follow-up items?
4.  Items from participants
5.  20 minute deep dive topic: **Modeling news on recent sensitivity
    analysis, SEIR++Parameters.** Presenters: Kun Hu and Simone Bianco.
    Please click here for the slides
    [4](https://wiki.eclipse.org/File:EbolaModel_STEM.pdf)
6.  Next week's agenda
    1.  Who would like to moderate in two weeks?
    2.  What will be the deep dive topic?
    3.  Please send short agenda items to Judy by Monday
    4.  Please suggest other themes and guests for
        presentation/discussion
    5.  Next week's deep dive: Dr. Emma McBryde, University of
        Melbourne. Topic to be announced
    6.  Next week's moderator: Dr. Emma McBryde

#### **Minutes**

##### **Attendees**

1.  Simone Bianco (Moderator) IBM Almaden
2.  Dr Abdessamad Tridane for UAE University
3.  Ada Yan University of Melbourne
4.  Jodie McVernon, UoM
5.  Alexander J. Jones Operon Labs
6.  Lauren Barthel Operon Labs
7.  Ira B. Schwartz US Naval Research Laboratory
8.  Luis Mier-y-Teran John's Hopkins, NRL
9.  Klimka Szwaykowska US Naval Research Laboratory
10. Emma McBryde University of Melbourne
11. Bradford Green CDC Modeling Task force
12. Mehmet Gunes, University of Nevada, Reno
13. Nick Geard, University of Melbourne
14. James Kaufman IBM Almaden
15. Mary Roth IBM Almaden
16. Melissa Cefkin IBM Almaden
17. Kun Hu IBM Almaden
18. Judy Douglas IBM Almaden
19. Pat Selinger IBM Almaden
20. Stefan Edlund IBM Almaden
21. Bill Tetsloff IBM Watson
22. Mary Helander IBM Watson
23. Matthew Davis IBM Australia
24. Rosalyn Hickson IBM Australia

##### **Discussion**

NEWS

Nick G: 2-year-old girl was sick on bus to Mali (now tracing 40+
contacts). She passed away.

Bill Tetsloff, NY, NY: People distrust information from CDC, etc.; are
very afraid and need to be educated.

Alex (?): Lack of education in the media; cover is way to one side or
the other. Becoming a political issue.

Judy: Woman taken to Maine will file suit tomorrow if they don't release
her from quarantine.

Alex: Sent out public data sets on cell phone data. Most are private.
Found one set with 146 people.

##### **Deep Dive talk by Kun Hu and Simone Bianco**

Kun and Simone presented STEM epidemiological model

##### *' Further Discussion*'

Emma: might find more uncertainty if use a different error function
(binomial vs Poisson) Post mortem transmission rate is outside the
literature range.

Kun: Yes, that's what our fit showed.

Alex: created a STEM model SEIR - model looks useful. NEJM paper has a
weighted average for Ro from several models. comes up with 1.84. Q how
Kun got Ro.

Kun Answer is: in the slides, expression for R0 + data in table.

Simone: C. Chavez, Vespignani and others have different values but all
have R0\<2.

Tridane: This model assumes everybody susceptible. Majority of ?happened
at beginning of epidemic. Can you split S to those that work in
Healthcare and those that do not. Many people do not go to hospital.
Suggestion to split the susceptibles

Kun: Yes, one can split S into clinical workers and others. This could
be a future extension to the model.

JK this would be particularly valuable if we could get statistics on
clinical workers infected vs non-clinical. Otherwise it's easy to create
the model but difficult to calibrate.

Emma: Epidemic peak time. Under any parameter that the epidemic had not
peaked after 3 years

Kun: Not for these three countries. All the peaks times for three
countries happen within 3 years.

Tridane: Do you plan to use model to examine efficiency of screening His
group has model for vector born disease which shows difficulty of border
screening

Kun: We've had this discussion during our call on Oct/15th. We've done
some preliminary exploration and confirmed by participants from CDC
during the call.

Alex great model but it is a limitation we don't have more data to seed
the compartments especially burial rates

Simone burial rate is the most difficult to get. In SL if they suspect
Ebola they have to report and then someone must come test body Very
difficult to happen quickly. The delay is up to a week. Some people
wait. Some people proceed with burial, some actually put bodies on
street.

##### **Items from Participants**

Melissa will moderate and give deep dive in 2 weeks

Emma's topic for next week "has anybody mapped infectivity over time?"

Alex has paper about asymptomatic infectious over time

Tentative title "Ebola Infectivity over Time"

### **October 22, 2014 Call**

Phone call will begin at 2pm ET (11AM PDT) to accommodate participants
from Australia

#### **Agenda**

*for* **October 22**

Moderator: Ira B. Schwartz, US Naval Research Laboratory

1.  Welcome and Introductions
2.  News
3.  NIHR UK Follow-up: Asymptomatic carriers will pass through screening
    undetected
4.  Items from participants
5.  20 minute deep dive topic: **Adaptive human behavior to control
    epidemics** Ira B. Schwartz, US Naval Research Laboratory. Please
    click here for the slides
    ![<File:Ebola_AN_deep_dive.pdf>](Ebola_AN_deep_dive.pdf
    "File:Ebola_AN_deep_dive.pdf")
6.  Next week's agenda
    1.  Simone Bianco, IBM will moderate next week. Who would like to
        moderate in two weeks?
    2.  Please send short agenda items to Judy by Monday
    3.  Please suggest other themes and guests for
        presentation/discussion
    4.  Next week's deep dive topic: Kun Hu & Simone Bianco model news
        on recent sensitivity analysis, SEIR++ Parameters
    5.  Next week's moderator Simone Bianco
    6.  In two weeks Dr. Emma McBryde, University of Melbourne will
        moderate and present Deep Dive next topic: "need title"

#### **Minutes**

##### **Attendees**

1.  Alexander J. Jones, OperonLabs
2.  Jamie Kaufman, IBM Research
3.  Ira Schwartz, US NRL
4.  Ada Yan, University of Melbourne
5.  Niina Haiminen, IBM Research
6.  Kun Hu, IBM Research
7.  Judy Douglas, IBM Research
8.  Matt Davis, IBM Research
9.  James McCaw, Melbourne School of Population and Global Health
10. Leah Shaw, College of William and Mary
11. Simone Bianco, IBM Research
12. Pat Selinger, IBM Research
13. Chang Chang, Peking University
14. Melissa Cefkin, IBM Research
15. Raul Andino, UC San Francisco
16. Emma McBryde, University of Melbourne
17. Nic Geard, University of Melbourne

##### **Discussion**

Jamie Kaufman: OperonLabs model contribution, to be contributed
officially to Eclipse

Alex Jones, James McCaw, Jamie Kaufman: Need for an air travel model
Adding escape rate with stability analysis of possible interest. There
is a need to track people. US is enforcing travel restrictions to
passengers from West African countries, to land in specific airports.
Proposed joint collaboration to address air travel model.

Alex: Bats are a known reservoir. However, bats are not affected, just
carriers, with mortality increasing upon transmission to human hosts.
The reason why are bats not affected is still unknown. Bats are 30% of
all mammals - why are they not affected by most virus? Bat interferon
activates different genes. Interferon thought to be the link to an
increased T cell response.

Time conflict with NEJM web update noted

#### Deep Dive talk by Ira B. Schwartz

**Adaptive human behavior to control epidemics** Ira B. Schwartz, US
Naval Research Laboratory. Please click here for the slides
![<File:Ebola_AN_deep_dive.pdf>](Ebola_AN_deep_dive.pdf
"File:Ebola_AN_deep_dive.pdf")

**Discussion Notes**

  - Emma McBryde: Hepatitis C network dynamics analysis shows that the
    most connected people can be found by following an edge.
  - Likely to be connected to people with high degree distribution so
    the infection quickly goes to a hub.
  - Hep C has been shown to spread among friends.
  - Find high degree nodes and use ring vaccination strategy.
  - Alex: Social distancing affects on Ebola (being afraid of your
    friend).
  - Ira: Leah Shaw and he looking at social distancing, but it's hard to
    get any kind of data.
  - Study on manipulation (put wash basin outside of men's room - people
    can see if you wash your hands or not). Use peer pressure to modify
    behavior.
  - Some behaviors early in the epidemic were counterproductive
  - Leah: Although there is a lack of data, modeling in her group shows
    that, if your social distancing increases as epidemic ramps up, and
    then goes back,

you can trigger oscillations.

  - James M.: Absolutely true. Shown for Influenza that social
    distancing can cause oscillatory dynamics (Australia, 2009 swine
    flu, other examples, Stephen Reilly paper
  - James will put references on the wiki
  - Emma: Seen in SARS but hard to resolve when simultaneous government
    intervention and decision making
  - Nic: Question on on clustering emerging in Ira's model: Does it
    break the network? At what scale?
  - Rewiring - can be reduction in efficacy if nearby people are also
    infectious (probably true)
  - Alex: Cell phone data sets hard to get. Suggestion to use 4SQ
  - Ira: In the first paper (Barabasi group), cell phone data was not
    quite anonymous
  - Want to get distribution function that describes peoples movements
    (??network topology??)
  - Alex: Nokia mobility data challenge data set is public. Will send
    link
  - Emma: global air travel. Group in Melbourne is quite interested.
    Would like to fill in regions for Australia. Offer to help refresh
    the data
  - Kun: several teams are deploying vaccines. Different vaccination
    strategies could me modeled and it might be worth discussing over.
  - Ira: Stratification of population - age dependence.

##### **Items from Participants**

Next Week Simone will moderate.

In two weeks Emma will moderate.

### **October 15, 2014 Call**

Phone call will begin at 2pm ET (11AM PDT) to accommodate participants
from Australia

#### **Agenda**

*for* **October 15**

Moderator: Alexander J. Jones, Operon Labs

1.  Welcome. Introducing
    1.  Dr. Emma McBryde, Head of Mathematical Modeling, Burnet
        Institute, Univ of Melbourne, Victorian Infections Disease
        Service
    2.  Prof. Jodie McVernon, Modelling and Simulation Group, Centre for
        Epidemiology and Biostatistics and Vaccine and Immunisation
        Research, Murdoch Children's Research Institute and Melbourne
        School of Population and Global Health
    3.  Prof. James Mccaw, Modelling and Simulation Group, Centre for
        Epidemiology and Biostatistics and Vaccine and Immunisation
        Research, Murdoch Children's Research Institute and Melbourne
        School of Population and Global Health
2.  News
    1.  Added link to
        [stem-ebola](https://dev.eclipse.org/mhonarc/lists/stem-ebola/threads.html#00022)
        summary on the [home page](https://www.eclipse.org/stem/)
    2.  Added Summary of Pub-Med news Items to our [Ebola Reference
        Data](Ebola_Reference_Data "wikilink") page.
    3.  Please copy (quantitative) new updates to the [Ebola Reference
        Data](Ebola_Reference_Data "wikilink"). This way we can track
        the dates of key events (ie if we want to tally imported and
        secondary cases outside of W. Africa over time.
3.  Questions on expanding the community: Pro Med and other mechanisms
    (Alex, Jamie)
4.  Caitlin Update on VT hack-a-thon
5.  20 minute deep dive topic: Ebola Deep-Dive Topic: Mutation and
    Fitness Landscape
    1.  Ebola 2014 Mutation Rate: Comparison to previous Ebola outbreaks
        & Other Viruses
    2.  Potential Impact of Ebola Mutations (tissue tropism, fitness
        landscape)
    3.  Superinfection: Mathematical Properties / Evolutionary Dynamics
    4.  Ebola Virulence vs Infectivity: Confounding Variables
    5.  Recombination: Evidence for Horizontal Gene Transfer in Ebola
6.  Next week's agenda
    1.  Ira B. Schwartz, NRL will moderate next week. Who would like to
        moderate in two weeks?
    2.  Please send short agenda items to Judy by Monday
    3.  Please suggest other themes and guests for
        presentation/discussion
    4.  Next week's deep dive topic: Kun Hu & Simone Bianco model news
        on recent sensitivity analysis, SEIR++ Parameters
7.  Items from participants
    1.  Question from NIHR UK

#### **Minutes**

##### **Attendees**

1.  Alexander J. Jones, Operon Labs, Moderator
2.  Jodie McVernon, Murdoch Children's Research Institute and Melbourne
    School of Population and Global Health
3.  James Kaufman, IBM Research
4.  Kun Hu, IBM Research
5.  Melissa Cefkin, IBM Research
6.  Judy Douglas, IBM Research
7.  Roslyn Hickson, IBM Research Australia
8.  Leah Shaw, William and Mary
9.  Stefan Edlund, IBM Research
10. James Mccaw, Murdoch Children's Research Institute and Melbourne
    School of Population and Global Health
11. Ira B. Schwartz, US Naval Research Laboratory
12. Luis Mier, US Naval Research Laboratory
13. Caitlin Rivers, Virginia Tech
14. Raul Andino, UCSF
15. Martin Meltzer, CDC Modeling Unit, Ebola Task Force
16. Manoj Gambhir, CDC Modeling Unit, Ebola Task Force
17. Thomas Gift, CDC Modeling Unit, Ebola Task Force
18. Stuart Nichols, CDC Modeling Unit, Ebola Task Force
19. Simone Bianco, IBM Research

##### **Discussion**

Question from NIHR in the U.K.. At what rate will (asymptomatic)
individuals infected with Ebola pass undetected through airport
screening at arrival airport if that screening involves only taking
temperature?

`IBM Research analysis: If we assume the passengers do not know they are infected, and if exponential growth continues, we estimate 80% will go undetected.`
`CDC Modeling Unit analysis: Based on the CDC model, if the passenger boards the plane in the asymptomatic state,`
`about 90% will pass through the arrival airport undetected. `*`At``
 ``best`*` 20% would be detected.`

Caitlin Rivers gave a short talk with slides describing the recent
![Virgina Tech Hackathon](_VirginiaTechHackathonOct15.pdf
"Virgina Tech Hackathon") held on Oct 15th.

#### Deep Dive talk by Alexander J. Jones

Oct 15th Deep Dive Discussion Slides up on the Operon site:
<http://www.operonlabs.com/?q=node/18>

![File:
Deep_Dive_Oct_15_Operon_Labs_v1.pdf](_Deep_Dive_Oct_15_Operon_Labs_v1.pdf
"File: Deep_Dive_Oct_15_Operon_Labs_v1.pdf") \<--- \* Download PDF of
Operon 'Deep Dive' Slides

**Discussion Notes**

  - Discussed two definitions: Virulence vs infectivity
      - Virulence - mortality, morbidity
      - Infectivity - basic reproduction number. Inherent ability to
        spread
  - Impact of mutations so far: RNA virus - error prone polymerase.
    Churns out SNPs as well as insertions and deletions
  - Frame shift mutation might lead to unfit offspring that will die.
    Some may have better some worse fitness
  - Current outbreak, most common ancestor is 2007/2008 Congo outbreak
      - Absolute parent E. Zaiher is the 1976 concensus strain
      - Current virus 97% similar to concensus strain
      - \~400-500 mutations/substitutions = 3% difference
  - Fig 2b 3 clades small guinea clade. 3-4 subtypes. Feb-March is
    different from May/June. May be functionally the same but it is
    changing
  - Fig 3 shows 7 transcribed genes
  - 4 subclades of virus can be identified in different regions.
  - Don't know the impact on fitness
  - Virus mutation rate is accelerating
      - Rate is twice the mutation rate before this outbreak
      - This agrees complete with predictions by Bianco and Andino
  - Andino: The mutation rate is not uniform along the viral sequence,
    but depends on the type of mutation and position in the genome;
    Also, standard NGS may not be accurate enough to capture all the
    mutations; Finally, synonymous mutations may be important just as
    well as non-synonymous mutations, as they may have non-zero fitness
    effects and may contribute to the complex genetic landscape of the
    virus.

##### **Items from Participants**

Change of plans for next week's call. Ira Schwartz will moderate next
week and give the deep dive

Simone Bianco will moderate in two weeks and give the Kun Hu/S. Bianco
deep dive that week

So *by convention* going forward the Deep Dive speaker will be their own
moderator (keeping their time to 20 minutes)

### **October 8, 2014 Call**

#### **Agenda**

*for* **October 8**

1.  Welcome
2.  Vote on time change for call
3.  News
4.  New Eclipse tools
    1.  Ebola community mailing list ( [please sign
        up](https://dev.eclipse.org/mailman/listinfo/stem-ebola) )
    2.  Data page on wiki
    3.  Literature references page
5.  20 minute deep dive topic: Caitlin on Contact Tracing (lots of
    chatter from various sectors this past week)
6.  Next week's agenda
    1.  Who would like to moderate?
    2.  Please send short agenda items to Judy by Monday
    3.  Please suggest next week's themes for presentation/discussion
    4.  Next week's deep dive topic: Alex on SEIR Parameters (average or
        median regional values? values from a single paper? how to
        select for simulations?)
7.  Items from participants

#### **Minutes**

##### **Attendees**

1.  Caitlin Rivers, Virginia Tech *Moderator*
2.  L. Shaw, William and Mary
3.  Simone Bianco, IBM Research
4.  Kun Hu, IBM Research
5.  James Kaufman, IBM Research
6.  Judy Douglas, IBM Research
7.  Stefan Edlund, IBM Research
8.  Alexander J. Jones, Operon Labs
9.  Ira B. Schwartz, US Naval Research Laboratory
10. Melissa Cefkin, IBM Research
11. Mehmet Gunes, University of Nevada, Reno
12. Pat Selinger, IBM Research

##### **Discussion**

Motion to hold the call one hour later for Australian Participants.

`Motion passes without objection`

Jamie: reviewed new community tools

Caitlin: Deep dive on contact tracing one of most basic public health
interventions (interview patients to identify contacts) Contacts
followed through incubation period In W Africa there are \>20,000 active
contact right now. Not going very well. G, SL public projects on
following contacts they miss hundreds every day

Q from Simone: Once identifies as contact are they asked to quarantine
themselves A no they are not isolated they go about their normal days
until symptomatic

Q Alex: What is the maximum contact tracing can reduce an outbreak by??
A Varies by disease. If infectious during incubation it's not effective
but with Ebola it is infective

Q is 50% reasonable A if worked perfectly it would be 100% effective. In
practice it's 50-75% effective

Q can we use the contact tracing effectiveness data do detect secondary
cases (ie from asymptomatic if there are any) A Ira: It's difficult due
to uncertainty in the incubation period - was the secondary case
asymptomatic or not.

Q Ira Do we know how tight communities are? DO they try to isolate
communities from General population A Some natural isolation

Jamie: Firestone example

[`NPR`](http://www.npr.org/blogs/goatsandsoda/2014/10/06/354054915/firestone-did-what-governments-have-not-stopped-ebola-in-its-tracks)
[`USA``
 ``Today`](http://www.usatoday.com/story/news/world/2014/10/08/ebola-firestone-liberia/16908853/)

Caitlin Two primary ways it can go wrong

  - contacts not seen (true now)
  - contacts lost to follow up (ie avoiding the tracing teams)

Montserrado county in Liberia has \>200 lost to follow up

This is a major problem for control Call to modelers to think about this
as a network problem or resource allocation problem

How can we be more efficient - place the monitors and bring the contacts
to the modelers? Melissa: The network of people being traced. If we knew
who are their family members (is that the network)? Caitlin: Could track
them as well the contact teams should have that info

Ira: Watching videos. 1 contact tracing team for what seemed like 1/4 of
the country. Has the situation improved? Caitlin: Not improved. LIberia
does not have enough vehicles. No organization in how town is laid out
(address associated with people not places)

Ira: Is there a model that would work in west africa that is not being
tried? Local teams vs top down approach?

Jamie: Could we airdrop thermometers and send a text if you have a
fever. IBM Kenya lab has cell phone reporting system... ie contact trace
everyone.

Caitlin has DOD contacts asking for this. Jamie will connect to Kenya
lab contacts

`Done`

Simone: Met with Raul Andino about the probability Ebola will become
airborne. Prob is zero. Will it evolve so asymptomatic individuals shed
the disease he said this is more likely. Any RNA based virus can evolve
to have higher viral load without showing symptoms. We could implement
Ira and Carlos' ideas to ask how would epidemic change if we get
asymptomatic transmission. Alex: Highly probably but not enough cases
yet (3000 people is not enough. with millions of people we might see
case fatality rate go down but transmission could go up. There is a
great book called Evolutionary dynamics (how virus explore). But depends
on very large number of cases. Fatality might go down but not down that
far)

Next Weeks Agenda Alex will moderate next week. Topic will be virology.
Caitlin will also brief us on the hack-a-thon

Ira will moderate week after next will think about deep dive topic (and
we can ask melissa)

##### **Items from Participants**

Items form Participants Kun would like to know about the hackathon at
Virginia Tech Caitlin Today is the first day. Next three days are all
out on it. Check back early next week.

Caitlin will invite people from DOD to this call. Ira: there are
tri-service people that might be interested in joining (they are focused
on pandemic modeling). Ira/Simone will exchange email viral evolution.

### **October 1, 2014 Call**

#### **Agenda**

1.  Introductions
2.  Timing for Community Calls
3.  Purpose
    1.  Not to push one model
    2.  Not to advocate one tool
    3.  Support Ebola response efforts
4.  Eclipse Community Tools
    1.  This Call
    2.  Newsgroup
    3.  Mailing list
        [instructions](https://wiki.eclipse.org/Join_the_STEM_Community)
5.  Overview of [Ebola Model](https://wiki.eclipse.org/Ebola_Models) and
    four Ebola Scenarios uploaded to Eclipse
    1.  Admin 0 three country model for West Africa
    2.  Admin 2 three county models for West Africa
    3.  All Africa Model
    4.  The Global Model
    5.  How to easily change from deterministic to stochastic
    6.  Running [STEM Headless](STEM_Headless "wikilink") on server
6.  Discussion on Literature models - please add references to [this
    page](https://wiki.eclipse.org/Ebola_References)
7.  Discussion on model parameters (latest wisdom, sensitivity analysis)
    1.  Should we create a wiki page for ongoing discussion?
    2.  Should we create a newsgroup topic for ongoing discussion?
8.  Next week's agenda
    1.  Who would like to moderate ? We can rotate.
    2.  Please send short agenda items to Judy by Monday
    3.  Please suggest longer themes for presentation/discussion
9.  Items from participants

To receive agenda updates form our mailing list please:

`Get an Eclipse ID: `[`5`](https://dev.eclipse.org/site_login/createaccount.php)
`Subscribe to the mailing list `[`6`](https://dev.eclipse.org/mailman/listinfo/stem-dev)
`See information on the STEM Community `[`Join``   ``the``   ``STEM``
 ``Community`](Join_the_STEM_Community "wikilink")

Model documentation will be available on the wiki page [Ebola
Models](Ebola_Models "wikilink")

#### **Minutes**

##### **Attendees**

1.  James Kaufman, IBM Research
2.  Kun Hu, IBM Research
3.  Simone Bianco, IBM Research
4.  Judy Douglas, IBM Research
5.  Stefan Edlund, IBM Research
6.  Caitlin Rivers, Virginia Tech
7.  Sherry Towers, Arizona State University
8.  Bob Pinner, CDC
9.  Mehmet Gunes, University of Nevada, Reno
10. Ira B. Schwartz, US Naval Research Laboratory
11. Christian Althaus, ISPM, University of Bern
12. Pat Selinger, IBM Research
13. Vincent Ruslan, Operon Labs
14. Carlos Castillo-Chavez, Arizona State University
15. Melissa Cefkin, IBM Research
16. Bryan Lewis, Virginia Tech

##### **Discussion**

Christian:

  - Science paper did not look at how mutations have changed properties
    of the virus
  - Population structure and control measures are quite different from
    countries
  - Parameters similar to previous outbreaks

Carlos:

  - This is a much bigger outbreak

Sherry:

  - The current Ebola outbreak seems to have relative low fatality rate
    compare to 90% in the record
  - Is asymptomatic transmission playing a role?

Bryan:

  - Is case mortality lower?

Sherry:

  - It seems to be lower.

Caitlin:

  - Up to 80% case fatality
  - Infectious period seems to be twice times than the previous
    outbreak.

Vincent:

  - What is the role of asymptomatic transmission. some numbers suggest
    something is different.

Jamie:

  - What is R0 for community, hospital, vs funeral transmission?

Sherry:

  - Suggested the transmission at funeral is 2-5 times higher.
  - Will provide some papers discussing different R0

Christian:

  - Really difficult to quantify different elements of transmission -
    restricted to total incidence data

Simone:

  - Conflicting data on under reported cases.

Sherry:

  - Who is collecting data?

Caitlin:

  - MOH of respective countries

Bryan Lewis:

  - Telecon with Neil Ferguson. Analysis of case listings.
  - The current endeavor is to explore these questions.
  - The data is partial

Christian:

  - STD transmission is probably minor

Everyone:

  - We need to get all the literature references in one place

##### **Items from Participants**

Caitlin:

  - Suggests we create a wiki page on Data
  - Ok to link to Caitlin's git hub and blog

`Done: `*`see``   ``new``   ``pages``   ``and``   ``please``   ``feel``
 ``free``   ``to``   ``add``   ``content`*
*`Literature`*` `[`Ebola``
 ``References`](Ebola_References "wikilink")
*`Data`*` `[`Ebola``   ``Reference``
 ``Data`](Ebola_Reference_Data "wikilink")

Sherry:

  - As a statistician, the work is data driven
  - We need better data to inform our models

Vincent:

  - Also concerned about asymptomatic transmission

Ira:

  - Interested in how people adapt their behavior in response to the
    epidemic outbreak
  - Also concerned about asymptomatic infectious classes. Can we back
    this out to predict asymptomatic?
  - Interested in agent-based model to study these type of questions

Christian:

  - Interest in opportunity for transmission in different small outbreak
    in Nigeria on how R0 (reproductive number) changes in a better urban
    setting where interventions were effective.
  - How does R0 depend on healthcare system of the country?

Pat:

  - Being in a community, how can we efficient and effective work
    together, what would help people respond more quickly?
  - Using a maillist does not address the issue when people want to
    share dataset.

Vincent:

  - Suggest to have a Ebola mailing
  - Parameters show this outbreak is going to be a 12-24 month long

Carlos:

  - Asymptomatic individuals: are they infectious or not? Very important
    in Influenza
  - Explore time dependent value of parameter
  - Critical to determine which of the additive factors contribute the
    most to R0 and Reff
  - Parameters change with different populations, different practices,
    different environment that may facilitate the transmission.

##### **Follow up**

  - Stefan Edlund created a new mail list stem-ebola@eclipse.org that
    will be active within 24 hours
  - Simone Bianco posted these minutes
  - James Kaufman created a new wiki page [Ebola Reference
    Data](Ebola_Reference_Data "wikilink")