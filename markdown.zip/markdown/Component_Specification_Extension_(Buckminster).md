## General Description

A Component Specification Extension allows you to decorate a [Component
Specification](Component_Specification_\(Buckminster\) "wikilink") in a
powerful way. It is possible to add, override (and remove)
specifications in the underlying CSPEC. The use of a CSPEX is
particularily valuable when the underlying CSPEC is generated from meta
data found in a component.

# TBD TBD

[Category:Archived Buckminster
Documentation](Category:Archived_Buckminster_Documentation "wikilink")