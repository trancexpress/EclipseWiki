This page describes the definitions and table formatting conventions
used on these pages: [Components](Components "wikilink").

## Definitions

  - See [Diagram Key](Diagram_Key "wikilink")

## Three kinds of tables

There are three kind of tables on these
[Components](Components "wikilink") pages:

  - Single project
    tables that describe a single Component and implement it with a
    single Project (row).
    [Example](Components_1.X#I-Card_Service_Web_App "wikilink").
  - Alternatives
    tables that describe a single Component but contain multiple
    alternative implementation Projects (rows).
    [Example](Components_1.X#IdAS_Context_Provider "wikilink").
  - Package
    tables that describe a set of rows each of which is a Component.
    [Example](Components_1.X#IdAS "wikilink").

## Table Format

The tables on the [Components](Components "wikilink") page uses these
templates:

  - [Template:HigCompTblHead2SingleRow](Template:HigCompTblHead2SingleRow "wikilink")
    - table header for **single project** component (excepting test,
    config, etc. supporting projects) that implements the component
    service description (see definitions above)
  - [Template:HigCompTblHead2](Template:HigCompTblHead2 "wikilink") -
    table header for **alternatives table** (see above)
  - [Template:HigCompTblHead2Package](Template:HigCompTblHead2Package "wikilink")
    - table header for a **package table** (see above)
  - [Template:HigCompTblSec2](Template:HigCompTblSec2 "wikilink") - grey
    table section rows
  - [Template:HigCompTblRow2](Template:HigCompTblRow2 "wikilink") -
    Eclipse project row
      - [Template:HigCompTblRow2Wiki](Template:HigCompTblRow2Wiki "wikilink")
        - Eclipse project row with regular wiki page \<-- preferred over
        \*2Note
      - [Template:HigCompTblRow2Note](Template:HigCompTblRow2Note "wikilink")
        - Eclipse project row with "note" wiki page \<-- alternate to
        \*2Wiki \[deprecated\]

### Table Header

Left-most column

  - <Component Name> - wiki page describing this Component. Should
    follow [Component Description
    Template](Component_Description_Template "wikilink")
  - bugzilla shortcuts - create, open, closed

### Table Section Row

Left-most column

  - Indicates the runtime environment supported by the project-rows in
    this section (e.g. Java 1.4 or Adobe Flex, etc.)

### Project Rows

Each regular row of the table is a project.

  - **type** of project
      - *Interface* - this project defines the interface for the
        component separately from its implementation
      - *Impl.* - implementation
      - *Alt. Impl* - one of N alternative implementations of the
        component interface
      - *Test* - unit test project
      - *Misc* - misc supporting implementation project
  - **project name** (Second-from-left-most column)
      - If the project is shared with other components the word
        "(shared)" will appear after the project name
  - **Repository** - **svn** link to the SVN source files and
    **viewsvn** link. Note

<!-- end list -->

  -
    Use either the https link given, or substitute svn+ssh for https as
    the svn URL in order to access the code for a project

<!-- end list -->

  - **Downloads** - link to the mostly recently generated nightly on
    build.eclipse.org \[Some day: this page will also include all stable
    builds\]. If the project can't be autobuilt (i.e. there are not
    downloads) then add a downloadurl param with value "no" (this
    appears as "\[no downloads\]" in the HTML
  - **Test** - For each of the java sub-projects of each Component
    listed in all of these tables there exists a second project a sister
    ".test" project exists containing unit tests. These tests are
    \[well, will soon be\] automatically run during the nightly build
    process. This cell should contain a status word related to these
    tests:
      - **none** - no sister ".test" project exists
      - **minimal** - a few unit tests exist in the ".test" project
      - **good** - reasonable coverage of functionality exists in the
        ".test" project
  - **H1.0** \[MANDATORY\] - green LED if this component is part of 1.0
    (red otherwise)
  - **H1.1** \[MANDATORY\] - green LED if this component is part of 1.1
    (red otherwise)
  - **Owner** - email of the owner of this component

## Old Template

  - [Old Components Page
    Conventions](Old_Components_Page_Conventions "wikilink") using older
    templates