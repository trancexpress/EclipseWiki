<div style="float:right;border:1px solid #000000;padding:5px">

__TOC__ [Related
Topics](Special:Whatlinkshere/Configuring_an_EIS_Composite_Collection_Mapping_\(ELUG\) "wikilink")

</div>

For information on how to create EclipseLink mappings, see [Creating a
Mapping](Creating%20a%20Mapping%20\(ELUG\)#CBBHHHJC "wikilink").

This table lists the configurable options for an EIS composite
collection mapping.

<span id="Table 78-1"></span>

<table>
<thead>
<tr class="header">
<th style="text-align: left;"><p><strong>Option to Configure</strong></p></th>
<th style="text-align: left;"><p><strong>Workbench<br />
</strong></p></th>
<th style="text-align: left;"><p><strong>Java</strong></p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Configuring_XPath" title="wikilink">XPath</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><a href="Configuring%20an%20EIS%20Mapping%20(ELUG)#Configuring_Reference_Descriptors" title="wikilink">Reference Descriptors</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Method_or_direct_field_access_at_the_mapping_level" title="wikilink">Configuring Method or Direct Field Accessing at the Mapping Level</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Configuring_Read-Only_Mappings" title="wikilink">Read-only mappings</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Configuring_Container_Policy" title="wikilink">Configuring Container policy</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Configuring_Mapping_Comments" title="wikilink">Mapping comments</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="unsupport.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
</tbody>
</table>


For more information, see the following:

  - [EIS Composite Collection
    Mapping](Introduction%20to%20EIS%20Mappings%20\(ELUG\)#EIS_Composite_Collection_Mapping "wikilink")
  - [Configuring an EIS
    Mapping](Configuring%20an%20EIS%20Mapping%20\(ELUG\)#CHDHFGAH "wikilink")
  - [Configuring a
    Mapping](Configuring%20a%20Mapping%20\(ELUG\)#CEGFEFJG "wikilink")

-----

*[Copyright
Statement](EclipseLink_User's_Guide_Copyright_Statement "wikilink")*

[Category: EclipseLink User's
Guide](Category:_EclipseLink_User's_Guide "wikilink") [Category: Release
1](Category:_Release_1 "wikilink") [Category:
Task](Category:_Task "wikilink") [Category:
EIS](Category:_EIS "wikilink")