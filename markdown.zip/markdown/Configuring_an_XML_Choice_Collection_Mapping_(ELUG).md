<div style="float:right;border:1px solid #000000;padding:5px">

__TOC__ [Related
Topics](Special:Whatlinkshere/Configuring_an_XML_Choice_Collection_Mapping_%28ELUG%29 "wikilink")

</div>

For information on how to create EclipseLink mappings, see [Creating a
Mapping](Creating%20a%20Mapping%20\(ELUG\) "wikilink").

This table lists the configurable options for an XML choice collection
mapping.

<span id="Table 169-1"></span>

<table>
<thead>
<tr class="header">
<th style="text-align: left;"><p><strong>Option to Configure</strong></p></th>
<th style="text-align: left;"><p><strong>Workbench<br />
</strong></p></th>
<th style="text-align: left;"><p><strong>Java</strong></p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Configuring_XPath" title="wikilink">XPath</a></p></td>
<td style="text-align: left;"><p><img src="unsupport.gif" title="fig:Unsupported" alt="Unsupported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><a href="Configuring%20an%20XML%20Mapping%20(ELUG)#Configuring_the_Choice_Element" title="wikilink">Choice element</a></p></td>
<td style="text-align: left;"><p><img src="unsupport.gif" title="fig:Unsupported" alt="Unsupported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Configuring_Method_or_Direct_Field_Accessing_at_the_Mapping_Level" title="wikilink">Method or direct field access</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Configuring_Read-Only_Mappings" title="wikilink">Read-only</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="odd">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Configuring_Container_Policy" title="wikilink">Container policy</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
</tr>
<tr class="even">
<td style="text-align: left;"><p><a href="Configuring%20a%20Mapping%20(ELUG)#Configuring_Mapping_Comments" title="wikilink">Comments</a></p></td>
<td style="text-align: left;"><p><img src="support.gif" title="fig:Supported" alt="Supported" /><br />
</p></td>
<td style="text-align: left;"><p><img src="unsupport.gif" title="fig:Unsupported" alt="Unsupported" /><br />
</p></td>
</tr>
</tbody>
</table>

For more information, see the following:

  - [XML Choice Collection
    Mapping](Introduction%20to%20XML%20Mappings%20\(ELUG\)#XML_Choice_Collection_Mapping "wikilink")
  - [Configuring an XML
    Mapping](Configuring%20an%20XML%20Mapping%20\(ELUG\) "wikilink")
  - [Configuring a
    Mapping](Configuring%20a%20Mapping%20\(ELUG\) "wikilink").

-----

*[Copyright
Statement](EclipseLink_User's_Guide_Copyright_Statement "wikilink")*

[Category: EclipseLink User's
Guide](Category:_EclipseLink_User's_Guide "wikilink") [Category: Release
1](Category:_Release_1 "wikilink") [Category:
Task](Category:_Task "wikilink") [Category:
XML](Category:_XML "wikilink")