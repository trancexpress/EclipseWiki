![Higgins_logo_76Wx100H.jpg](Higgins_logo_76Wx100H.jpg
"Higgins_logo_76Wx100H.jpg")

## Version

This page describes the concept of a [ContextId](ContextId "wikilink")
as used in [Context Data Model 2.0](Context_Data_Model_2.0 "wikilink").

## Definition

  - An identifier of a [Context](Context "wikilink")
  - A *Context UDI* as defined in [UDI
    Syntax](http://www.azigo.com/udi/udi-syntax.html)

[Category:Context Data Model
2.0](Category:Context_Data_Model_2.0 "wikilink")