{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}

## Overview

A [Context Provider](Context_Provider "wikilink") adds support for one
or more kinds of Contexts to the [Identity Attribute
Service](Identity_Attribute_Service "wikilink") framework. These
Contexts contain Nodes/Entities that hold attributes. A context provider
is responsible for its internal data management, security, encryption,
persistence, etc. The provider provides the uni- or bi-directional
transformation of data from its internal structures to the normalized
IdAS data model. In many cases these Context Providers act as adapters
or "wrappers" of existing services such as communications systems,
collaboration systems, social networks, identity providers, games,
enterprise apps, and so on. In addition to web services, [Context
Providers](Context_Provider "wikilink") can also adapt client-side
applications such as email clients, IM and other messaging and
collaboration apps.

Here is [a list](Components#IdAS_Context_Provider "wikilink") of
existing Higgins [Context Providers](Context_Provider "wikilink").

## Relationship between Context Providers, Context Factories, and Contexts

  - Multiple Context Factories may be registered with a single
    [IdAS](Identity_Attribute_Service_\(IdAS\) "wikilink")
  - A Context Provider is a packaging/deployment wrapper around one or
    more Context Factories, which in turn produce Context instances and
    the data they hold
  - A Context Factory may provide access to multiple Contexts
  - Multiple Context Providers (using their associated Context
    Factories) may provide access to the same Context.
      - An example of this might be using different LDAP engines to
        access the same underlying data store

## Responsibilities of a ContextFactory

1.  createContext(URI) - create a Context object for a given reference
2.  getContexts(String filter) - return the set of Context References
    (URIs) that are currently open and are managed by this provider
    \[this method is under review\]
3.  getPolicy() - returns the policy in effect for this Context
    Provider. This policy must include a list of the required and
    optional Claims required to open any (is the word "any" correct
    here?) context managed by this provider

## Responsibilities of an IContext implementation

1.  Maintain the set of objects that exist in this context and conform
    to its schema.
      - The underlying bits that represent the objects might be in an
        LDAP directory, a text file, or an IM chat client The Context
        Provider's IContext implementation is responsible for
        translation and mapping from the underlying representation to
        the [Context Data Model](Context_Data_Model "wikilink").
      - The Context Provider certainly needs to know what the storage
        technology is and how to use it. It could also source data from
        many different formats, presenting the results as a unified
        Context with a specific schema.
      - But the Context Provider also represents a specific vendor's (or
        author's) code to implement that transformation. So it's
        possible to have a Novell-LDAP provider and an IBM-LDAP
        provider.
2.  Support addition, deletion, and navigation of contained objects as
    allowed by the context's policy
3.  Support update and deletion of attributes of contained objects as
    allowed by the context's policy
4.  Provide the ability to export and import the contents of a context
    to an RDF data stream
5.  Act as a container of references to sub-Contexts
6.  Maintain (and return on request) the policies related to various
    kinds of access to objects
7.  Provide access to the schema which governs the form of objects in
    this context
8.  Open the context for a particular Digital Identity as allowed by the
    context's policy.
9.  Close context, preventing further access via this object.

Optional IContext implementation responsibilities

1.  Authentication to add a new object to the context
2.  Authorization of access to object attributes using role-based access
    control lists
3.  Support for finding objects by query
4.  Ability to associate objects to other objects within the same
    context
5.  Support for adding tag properties to objects and on the associations
    between objects
6.  Replication/distribution/synchronization of context data with
    external systems (and directly or indirectly, other Higgins
    frameworks)
7.  Persistence and encryption of context data
8.  Reputation computation

## Current Java Impl

In the Java reference implementation a [Context
Provider](Context_Provider "wikilink") implements the IContextFactory
and IContext interfaces. Implementations of this interface and the
associated IContextProvider interface are usually packaged as an Eclipse
plug-in (or more properly an OSGI bundle). See also: [IdAS
Registry](IdAS_Registry "wikilink")

## See Also

  - [IdAS Registry](IdAS_Registry "wikilink")
  - [Identity Attribute Service](Identity_Attribute_Service "wikilink")

[Category:Higgins Components](Category:Higgins_Components "wikilink")