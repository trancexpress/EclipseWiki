## Attendees

  - Valentina Popescu
  - Martin Simmonds
  - Paul Stratton
  - Hubert Leung
  - Bill Muldoon
  - John Todd
  - Don Ebright
  - Joel Hawkins
  - Leonrd Richardson
  - Tania Makins
  - Sheldon Leeloy
  - Ali Mehregani
  - Shivvy
  - David Whiteman
  - Jimmy Mohsin

# Minutes

## Verify bugzillas for i8

<https://bugs.eclipse.org/bugs/buglist.cgi?short_desc_type=allwordssubstr&short_desc=&product=Cosmos&target_milestone=1.0i8&long_desc_type=allwordssubstr&long_desc=&bug_status=RESOLVED&resolution=FIXED&order=Importance>

  - For enhancements, the QA Team should be responsible for verifying
    the enhancement according to the use case.
  - For bugs, the originator should verify the bug. Note: if the
    originator is the same person who implemented the code, then someone
    else should verify the bug.

According to our defined development process, the exit criteria for the
iteration is that all defects and enhancements are closed or otherwise
addressed, e.g. moved into the next iteration. We want to go into the
next iteration with a clean slate of bugzilla.

We would like to have the test cases run automatically as part of the
build, but this is not currently setup.

We would like to verify the bugs as part of the test pass.

## Define holistic (i.e. integration / system / et al) testing requirements for i9 \[ Jimmy Mohsin \]

On Friday's (4-Jan-08) summit meeting we need to define the end-to-end
testing for i8. We felt that at the end of i7, we had a bit of a "fire
drill" to identify what we needed to do to validate the end-to-end. We
want to avoid this for i8.

## Establish testing expectations for i8 \[ Jimmy Mohsin \]