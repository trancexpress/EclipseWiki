## Attendees

  - Ali Mehregani
  - Mark Weitzel
  - Bill Muldoon
  - Hubert Leuyng
  - Valentina Popescu
  - Sheldon Leeloy
  - David Whiteman
  - Jimmy Mohsin
  - Don Ebright
  - Joel Hawkins
  - John Todd
  - Maosheng Liang

## Minutes

## UI Framework discussion

Would like to migrate the existing CA ui onto the open framework in
COSMOS. There is some work that CA has done to reconcile and move the
code. John Todd and Monica will be evaluate what needs to happen. Any
new work items for i7 & i8 will be finalized at the next Data
Visualization call (Thursday 11).

## Management Domain

  - The Management Domain's job is only to hold onto the initial
    endpoints.
  - Need a generic operation for adding an epr at an identifier.

<!-- end list -->

  - For i7 & i8, we will have only one databroker and all MDRs will
    register with the databroker
  - The databroker will be a property on the management domain. It will
    be accessed via the WS-RF.
      - The resource property will be: defaultDataBroker the URI will
        be: <http://>
      - The first (and for only) databroker that starts up will become
        the defualt. We will need a more robust way of determining which
        broker is "the default" broker.

<!-- end list -->

  - We'll do a run through on the code on Friday to determine what we
    need to do to adapt to these changes

## Qualities of Service

  - Limited qualities of service for i7 & i8