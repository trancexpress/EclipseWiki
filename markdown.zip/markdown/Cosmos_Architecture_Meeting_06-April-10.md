## Attendees

  - Brad
  - Mark
  - Jeff
  - Jason

## Minutes

Team members have all been busy with deadlines at their respective
companies over the past two weeks. Today's agenda focused solely on
quick status updates from folks. Brad indicated that the integration
build failed on Friday but it wasn't clear why it failed. It ran
successfully on Saturday. The team will need to keep an eye on this.
Jeff hasn't been able to pick up the P2 work again. He should have
cycles later this iteration to start moving that effort forward again.
Josh was OOO so no updates from him. Mark indicated he has been buried
as well. Jason has made progress on CL2 SDDs and is about 90% complete
with an exemplary composite SDD. The composite includes several key CL2
features which will help drive CL2 implementation plans. Jason also
noted that he has the RAP bundle info from Josh and will be checking on
IP process for these. In addition he has the action item to update the
project metadata this week.

## Action items

  - Brad to continue working on using Hudson for COSMOS builds (ongoing)
  - Jason to check on RAP IP
  - Jason to check updated DS and WTP bundles as part of updating build
    to Eclipse 3.5.2
  - Jason to get CL2 SDDs in the example project
  - Jason to update project metadata
  - All - continue P2 work as time allows