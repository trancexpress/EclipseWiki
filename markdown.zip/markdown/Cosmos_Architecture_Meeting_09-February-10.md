## Attendees

  - Brad
  - Josh
  - Jeff
  - Jason

## Minutes

Today's meeting was fairly brief as the team was side tracked with other
issues during the past week. The call started with Josh going over his
design and implementation for storing SDDs. Everyone agreed with the
design and no re-work to the implementation will need to be done.

The discussion then turned to P2. Jeff has made a little more progress
on P2 but nothing noteworthy to share this week. He has ordered the
McAffer OSGi book and has been reading through it. Chapter 14 was shared
with several of the team as reference material prior to next week's call
with the P2 team. Jason indicated that this week P2 progress should
continue. He will create a few slides that frame the conversation with
the P2 team. Jeff will continue his research and refine any demos to be
shared via Live Meeting.

The team then reviewed action items from last week. Current status is
reflected below.

No other topics today. Adjourn.

## Action items

  - Brad to work on using Hudson for COSMOS builds
  - Jeff to continue P2 research and document steps he has completed
    thus far
  - Jason to put together P2/COSMOS slides
  - Brad and Mark to continue UI research on Swing and RAP respectively
  - Brad and Jason to itemize CL2 features
      - Jason has started enumerating CL2 features and priority for SAS
      - <http://wiki.eclipse.org/CL2_Features_by_Priority>