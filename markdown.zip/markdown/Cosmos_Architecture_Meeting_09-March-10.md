## Attendees

  - Brad
  - Josh
  - Jeff
  - Mark
  - Jason

## Minutes

Today's meeting was a quick recap of actions from last meeting and then
more P2 discussion. The team also hit on progress to date on using a RAP
based UI. Brad has been busy and not had a chance to further explore
using Hudson for the COSMOS builds. Josh has picked up the RAP project
and moved it forward. He has a simple RAP "hello world" user interface
on top of the SDD runtime. However, he his running into problems with
the way RAP sessions are spawned. These seem to lose handles to
previously created objects which means variable references are getting
lost as views are spawned. Josh, Jeff and Brad talked at length about
this. Brad threw out some suggestions to pursue. Josh and Jeff agreed to
take the action to work through some of the issue further and if need be
will post an example that exhibits the problem(s) they are seeing. Jason
indicated that he has started but not completed exemplary CL2 SDDs. He
did confirm that CA and SAS have very similar CL2 requirements based on
reconciling the information Brad posted to the dev list with the CL2
examples SAS had assembled. Jeff has made a little P2 progress but was
side tracked working on the RAP UI. Efforts around P2 will pick back up
between now and next week.

No other items for today. Adjourn.

## Action items

  - Brad to work on using Hudson for COSMOS builds
  - Brad and Mark to continue UI research on Swing and RAP respectively
  - Brad and Jason to itemize CL2 features
      - Jason has started enumerating CL2 features and priority for SAS
      - <http://wiki.eclipse.org/CL2_Features_by_Priority>
      - Jason to scrub and send exemplary CL2 SDDs around for the team
        to reference. These will be added to the examples.