These are the minutes for the [Architecture
Meeting](COSMOS_Architecture_Meetings "wikilink") for 5/22/08.

### Attendees

### Agenda

  - 20 min: Followup on COSMOS Architectural discussions from May 1
    (Jimmy Mohsin et al)
      - Jimmy to send out updated slides (please link here, Jimmy, as
        part of the email reduction act of 2008 ;-)
      - Discuss updates to the two current state slides
      - Discuss the future state slide:
          - We need to decide when / if the Domain will return.
          - We need to determine a realistic timeframe for supporting
            multiple Brokers for scalability / performance
            considerations. I get asked this question a lot from the
            transactionally-intensive products...
          - What is our position vis-a-vis WSDM / WEF for future
            releases?
  - 15 min: 231343 Need getQueryServiceMetadataFromAllMDRs method on the
    COSMOS Broker
      - Can this be done in i12?
      - Does this impose any requirements at the individual MDR level to
        ensure that the metadata in consistent?
  - 15 min: 231400 MDR requiring authentication (login-id and password)
    [COSMOS_Design_231400](COSMOS_Design_231400 "wikilink") -- Bill

### Minutes