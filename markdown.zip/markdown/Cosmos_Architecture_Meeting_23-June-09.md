## Attendees

  - David (IBM)
  - Brad (CA)
  - Jeff (SAS)
  - Josh (SAS)
  - Ed (SAS)
  - Jason (SAS)
  - Mark (SAS)

## Agenda

  - i5 status
      - Test phase/TPTP tests
  - i6 plans
  - RM update
  - SDD update
  - Around the room

## Minutes

i5 test phase is wrapping up. Josh has completed his TPTP tests for i5
and they are running cleanly. Jason created the i6 feature page and
items deferred from i5 and new enhancements for i6 are being added. The
major push for i6 will be focused on the SDD. David anticipates little
change for resource modeling and will use i6 as a chance to get a
headstart on stabilization.