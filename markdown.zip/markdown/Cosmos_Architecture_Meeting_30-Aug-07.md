### Attendees

  - Dave Whiteman
  - Ali Mehregani
  - Don Ebright
  - Mark Weitzel
  - Martin Simmonds
  - Bill Muldoon
  - Paul Stratton
  - Mau
  - Hubert Leuyng
  - John Todd

## Minutes

### COSMOS Dependencies / Platform Support

This discussion was tabled b/c we would like to have Jimmy present

### Discussion of Data Broker Design [COSMOS_Design_192493](COSMOS_Design_192493 "wikilink")

  - Close on IPv6
  - [Java Packages & OSGi Packaging](COSMOS_DC_OSGi_Bundles "wikilink")

<!-- end list -->

  -
  - IPv6