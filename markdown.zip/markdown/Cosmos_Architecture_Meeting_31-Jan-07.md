## Attendees

Sheldon Lee Loy

Ali Mehregani

Craig Thomas

Don Ebright

Joel Hawkins

Vsevolod Sandomirskiy

Marius Slavecu

Steve Jerman

## Minutes

We are still trying to get a complete end-to-end scenario working. There
were several issues that the team needs to address.

  - It is still not clear how the notion of context and navigation will
    work and what APIs should be used.
      - Sheldon & Marius will work on this and post their conclusion on
        the wiki
  - There was an issue around how the initial configuration would be
    bootstrapped.
      - Sheldon mentioned that using report parameters would be a stop
        gap way to get around this for the demo
      - Marius will take an initial pass at how this will work long term
          - Bugzilla here
  - The CBE Events report, or the code that loads the data needs to be
    modified to use the data access layer
      - <https://bugs.eclipse.org/bugs/show_bug.cgi?id=172538>
  - Sheldon has created a statistical report that needs to be integrated
      - <https://bugs.eclipse.org/bugs/show_bug.cgi?id=172536>
  - We need a pre-canned database that contains the log and statistical
    data for the demo. This will be a derby db.
      - We will need to define the sample data set
      - <https://bugs.eclipse.org/bugs/show_bug.cgi?id=172540>
  - The Production.XML file needs to be update to have parent-\>child
    relationships, not just the child-\>parent.
      - <https://bugs.eclipse.org/bugs/show_bug.cgi?id=172541>
  - Need to determine if we need to have a top level “topology” element
      - <https://bugs.eclipse.org/bugs/show_bug.cgi?id=172545>
  - We need to determine whether we should allow editing of genic/phenic
    documents inside the SML-IF editor
      - Currently the user is able to modify the content that appears in
        the identity element, add/remove/modify document aliases, and
        add/remove genic/phenic documents. We need to determine if we
        want to allow the user to modify the <b>content</b> of
        genic/phenic documents inside the SML-IF editor. In a previous
        discussion Valentina argued that modifying the content of
        genic/phenic documents in the SML-IF editor is not a valid use
        case. Her argument was that the signature of an SML-IF document
        can be void if the content of genic/phenic documents are
        modified. Since we are already allowing editing of other parts
        of the document (e.g. aliases), then the user can still void the
        document signature. This needs to be sorted out in the resource
        modeling call. Providing an editor with very little editing
        capabilities doesn't have much use to the community.

Joel walked us through the set of work that he has done around adding a
WSDM-based control interface for the agent.

  - This was done using some annotations that add management support
      - NOTE: This adds a dependency on Java 1.5
  - Next step is to incorporate the persistence API
  - We need to work in how we check in the code in CVS