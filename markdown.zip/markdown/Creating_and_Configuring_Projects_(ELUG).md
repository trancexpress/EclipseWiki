This part describes the EclipseLink artifact used to contain mapping and
data source-specific information. It contains the following sections:

  - [Creating a Project (ELUG)](Creating_a_Project_\(ELUG\) "wikilink")
    – Contains procedures for creating EclipseLink projects.

<!-- end list -->

  - [Configuring a Project
    (ELUG)](Configuring_a_Project_\(ELUG\) "wikilink") – Explains how to
    configure EclipseLink project options common to two or more project
    types.

**[Related
Topics](Special:Whatlinkshere/Creating_and_Configuring_Projects_\(ELUG\) "wikilink")**

-----

*[Copyright
Statement](EclipseLink_User's_Guide_Copyright_Statement "wikilink")*

[Category: EclipseLink User's
Guide](Category:_EclipseLink_User's_Guide "wikilink") [Category:
Concept](Category:_Concept "wikilink")