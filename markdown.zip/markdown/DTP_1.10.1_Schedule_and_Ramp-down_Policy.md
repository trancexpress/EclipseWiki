## Purpose

This document defines a schedule and set of ramp-down policies for the
DTP 1.10.1 service release.

## Schedule

DTP is on the Juno SR1 release train as a +1 project. Those dates are
[1](http://wiki.eclipse.org/Juno/Simultaneous_Release_Plan%5Bhere%5D).

  - 1.10.1 RC1 - 8/20/12
  - 1.10.1 RC2 - 9/3/12
  - 1.10.1 RC3 - 9/10/12
  - 1.10.1 RC4 - 9/17/12
  - 1.10.1 Release - 9/28/12

## Things to Keep in Mind

  - During the regular development phase and through RC1 and RC2,
    nightly builds take place from Monday to Thursday. Integration
    builds are done on Friday.
  - DTP builds will take place at [5am (Shanghai
    time)](http://www.timeanddate.com/worldclock/fixedtime.html?month=2&day=29&year=2008&hour=5&min=0&sec=0&p1=237).
    (That is 2 PM PST.)
  - Builds are pushed to the DTP update site on Tuesday AM Shanghai
    time. (Monday evening PST)
  - During the RC phases, team lead or PMC approval is needed to update
    the code base. We will not be doing nightly builds, but will build
    as needed if "must fix" problems are found and fixed.

## Ramp-down Cycles

**Note:** Builds occur on the days noted, at [5am (Shanghai
time)](http://www.timeanddate.com/worldclock/fixedtime.html?month=2&day=29&year=2008&hour=5&min=0&sec=0&p1=237).
The I-builds occur on the Friday before the +1 RC date.

  - RC1
      - After the RC1 build, we will be in a Test and Fix phase and only
        delivering critical fixes
      - We will continue to do RC2 nightly builds during this period
      - If a RC1 re-spin is required, it will be requested on an
        as-needed basis
      - All commits must be approved by a team lead
      - After release, the code base will again be open for code
        delivery

<!-- end list -->

  - RC2
      - After this build, we will be in a Test and Fix phase and only
        delivering critical fixes
      - We will continue to do nightly RC3 builds during this period
      - If a RC2 re-spin is required, it will be requested on an
        as-needed basis
      - All commits must be approved by a team lead
      - After release, the codebase will again be open for code delivery

<!-- end list -->

  - RC3
      - After this build, we will be in a Test and Fix phase only and
        delivering critical, show-stopper bug fixes as necessary
      - There will be no nightly or integration builds during this
        period
      - If a build is required, it will be requested on an as-needed
        basis and any re-spin will be considered our RC4 candidate. If
        no build is required, the final RC3 candidate will become our
        RC4 candidate
      - Committers must annotate bugs proposed for inclusion in the
        release with risks and nature of fix
      - Committers must petition the DTP PMC using BZ for inclusion of
        specific bugs

<!-- end list -->

  - Release

[Category:Data Tools Platform](Category:Data_Tools_Platform "wikilink")