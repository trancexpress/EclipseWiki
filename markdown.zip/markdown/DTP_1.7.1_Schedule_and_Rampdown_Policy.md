## Status

  - 6/11/09 - Draft, to be reviewed by PMC
  - 8/11/09 - Updated to match RC dates for Galileo SR1 after PMC
    meeting

## Note

  - Specific milestone dates have not been set yet by the planning
    council for 1.7.1

## Purpose

This document defines a schedule and set of ramp-down policies for DTP
1.7.1. The goal is to ensure that DTP stability and completeness
converges on the 1.7.1 release dates, while allowing mechanisms for
changes as necessary.

## Schedule

  - 1.7.1RC1 - 8/11/09
  - 1.7.1RC2 - 9/1/09
  - 1.7.1RC3 - 9/8/09
  - 1.7.1RC4 - 9/15/09
  - 1.7.1 Release - 9/25/09 (last Friday of September)
      - Galileo SR1 release train as a +1 project. Those dates are
        [1](http://wiki.eclipse.org/Galileo#Coordinated_Service_Releases%5Bhere%5D).

## Things to Keep in Mind

### Builds Reminder

  - Nightly builds take place from Monday to Thursday. Integration
    builds takes place on Friday.
  - During a test phase, there are no builds. We take the build before
    the test phase and test it. If we run across extreme issues, we will
    respin and retest.
  - During the test/fix phase for the RC, we will do regular daily
    builds. Once we are in the test/fix phase, where PMC approvals are
    needed, we will not build nightly, but will build as needed (9/8/09
    and beyond).
  - On Push days, we will take the Monday Shanghai build (which is our
    Sunday at 2pm PST) and if it's good, we will push it to the update
    site that Monday evening (SH Tuesday a.m.). If things are not good,
    we will fix the issues and respin the build, taking the respun build
    and pushing it to the update site.
  - DTP builds will take place at [5am (Shanghai
    time)](http://www.timeanddate.com/worldclock/fixedtime.html?month=2&day=29&year=2008&hour=5&min=0&sec=0&p1=237).
  - In general, builds occur Mon - Fri at 2pm Shanghai time, which is
    equivalent to Sun - Thu 2pm PST.
  - **DTP committers should refrain from updating map files for +/- 30
    minutes around the start of the build, to avoid version
    inconsistencies in the map file set.**
  - See the Build Transition page for additional details about regular
    [DTP builds](http://wiki.eclipse.org/DTP_Build_Transition)

## Integration Builds

Starting on Friday, 8/7/09, and continuing through Tuesday, 9/15/09, the
latest available DTP 1.7.1 integration build (done each Friday, as noted
above) will be tested for promotion. If no substantial defects are
found, then the build will be promoted.

## Testing & Fix Pass

A period of intensive testing, including bug fixes based on the approval
policies described below. Nightly build will be produced during this
period as necessary to make bug fixes available to the DTP community.

## Rampdown Cycles

**Note:** Builds occur on the days noted, at [5am (Shanghai
time)](http://www.timeanddate.com/worldclock/fixedtime.html?month=2&day=29&year=2008&hour=5&min=0&sec=0&p1=237).

  - 1.7.1RC1 I-build occurs on 8/7/09(SH time)
      - After this build, we will be in a Test and Fix phase and only
        delivering critical fixes
      - We will continue to do RC2 nightly builds during this period
      - If a RC1 respin is required, it will be requested on an
        as-needed basis
      - All commits must be approved by a team lead
      - After release, 1.7.1 will again be open for code delivery

<!-- end list -->

  - 1.7.1RC2 I-build occurs on 8/28/09(SH time)
      - After this build, we will be in a Test and Fix phase and only
        delivering critical fixes
      - We will continue to do RC3 nightly builds during this period
      - If a RC2 respin is required, it will be requested on an
        as-needed basis
      - All commits must be approved by a team lead
      - After release, 1.7.1 will again be open for code delivery

<!-- end list -->

  - 1.7.1RC3 I-build occurs on 9/4/09 (SH time)
      - After this build, we will be in a Test and Fix phase only and
        delivering critical, showstopper bug fixes as necessary
      - There will be no nightly or integration builds during this
        period
      - If a build is required, it will be requested on an as-needed
        basis and any respin will be considered our RC4 candidate. If no
        build is required, the final RC3 candidate will become our RC4
        candidate
      - Committers must annotate bugs proposed for inclusion in 1.7.1
        with risks and nature of fix
      - Committers must get modifications reviewed by one other
        committer on project
      - Committers must petition DTP PMC using BZ for inclusion of
        specific bugs
      - Three positive PMC votes allows modifications to fix a specific
        bug to be delivered (unless a PMC member is abstaining, in which
        case all remaining PMC members must still vote positive)
      - Though we would like to have our final RC3 candidate build ready
        by 9/4/09, we can perform builds as late as 9/14/09 to be ready
        for EPP packaging. We would prefer to have a RC4 candidate done
        by 9/4/09 at the latest, but can build (if a critical,
        showstopper bug appears) as late as 9/14/09.

<!-- end list -->

  - 1.7.1 Release - 9/25/09

[Category:Data Tools Platform](Category:Data_Tools_Platform "wikilink")