←[Back to DTP Connectivity Project Committers' Meeting
Page](DTP_Connectivity_Project_Committers_Meeting "wikilink")

## Attendees

  - Brian Fitzpatrick
  - Linda Chan
  - Larry Dunnell

## Regrets

## Agenda

  - Open discussion

## Minutes

## Action Items

[Category:Data Tools Platform](Category:Data_Tools_Platform "wikilink")