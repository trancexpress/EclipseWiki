## Status

**OBSOLETE**

**\[3/5/08\]:** The build process described in this document is now
obsolete. Refer to the [DTP Releng page](DTP_Releng "wikilink") for
updated information.

This document, and its associated build tools archive download, was
updated last on **2/21/08**.

## Introduction

This document describes the DTP 1.6 ("Ganymede") build process. The
intention is to enable community-based builds of DTP 1.6 using the
current DTP build process. This document is not a substitute for the
detailed build instructions contained in the DTP 1.6 build tools
archive, nor is it a tutorial for building plug-in distributions using
Eclipse. Rather, the goal is simply to introduce the DTP 1.6 build tools
archive and answer some Frequently Asked Questions (FAQ) about the DTP
1.6 build process. Finally, this page will be updated as new versions of
the build tools archive become available and as new content (especially
in the FAQ section) is added.

## Disclaimer

DTP, as an Eclipse Foundation project, is subject to the Eclipse terms
of use. For more information or questions, check out the [Eclipse
Foundation legal page](http://www.eclipse.org/legal/).

## DTP Build Tools

An archive file containing the necessary build tools for DTP 1.6 is
available from the [DTP download
server](http://www.eclipse.org/downloads/download.php?file=/datatools/downloads/drops/N_releng/dtp_1.6_buildtools_200802211.zip).
Detailed instructions for building DTP 1.6 are found in the pdf document
at the root of the build tools archive. Those interested in generating
the same DTP 1.6 build bits as what is posted on the DTP download site
should obtain and study this archive.

## FAQ

  - **Q:** Does DTP 1.6 use the Eclipse (headless) PDE base builder?
      - **A:** No, DTP 1.6 does not use the PDE base builder.
  - **Q:** Does DTP 1.6 have map files?
      - **A:** DTP 1.6 is built from the HEAD of the DTP CVS modules.
        While it would be very simple to produce corresponding map file,
        there is no need for it in the current DTP 1.6 build process.
  - **Q:** The DTP feature definitions are not what we expected. Why is
    this?
      - **A:** The DTP feature definitions were determined by a long and
        thorough consultation with the DTP community, concentrating on
        the "slices" of DTP that adopters want to consume. For this
        reason the feature structure (including plug-ins appearing in
        more than one feature definition) are not what you'd expect, *if
        your expectations are that feature definitions are for the
        benefit of the PDE base builder.*
  - **Q:** Does DTP plan to migrate to the PDE base builder, or perhaps
    another build system, during DTP 1.6 (that is, Ganymede)?
      - **A:** Current staffing levels do not allow such a migration at
        this point.
  - **Q:** Is DTP open to suggestions or help in evolving the DTP build
    process?
      - **A:** Yes, of course we're happy to receive help. Please be
        aware, however, that such suggestions are much more likely to be
        adopted if the offer evolutionary improvement to the current
        system. Larger changes, such as moving to the PDE base builder,
        would be considered only if there were associated staffing
        willing to take ownership and responsibility for the DTP builds
        going forward.

[Category:Data Tools Platform](Category:Data_Tools_Platform "wikilink")