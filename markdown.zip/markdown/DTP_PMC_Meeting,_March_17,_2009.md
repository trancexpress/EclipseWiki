←[Back to DTP PMC Meeting Page](DTP_PMC_Meeting "wikilink")

## Attendees

  - Brian Fitzpatrick
  - Linda Chan
  - John Graham
  - Brian Payton

## Regrets

## Agenda

  - Happy St. Patrick's Day\! Luck of the Irish to ya and all that...
  - Galileo status
  - EclipseCon presentation status
      - Do we want to try and have a PMC face to face at EclipseCon?
  - Need to hear from incubator folks soon -- 1st week of April?
  - Open discussion

## Minutes

## Action Items

## Tabled for Later Discussion

[Category:Data Tools Platform](Category:Data_Tools_Platform "wikilink")