←[Back to DTP PMC Meeting Page](DTP_PMC_Meeting "wikilink")

## Attendees

  - Brian Fitzpatrick
  - Linda Chan
  - John Graham
  - Sheila Sholars
  - (Brian Payton)

## Regrets

## Agenda

  - Open discussion

## Minutes

## Action Items

## Tabled for Later Discussion

[Category:Data Tools Platform](Category:Data_Tools_Platform "wikilink")