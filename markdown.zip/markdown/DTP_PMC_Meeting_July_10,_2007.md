←[Back to DTP PMC Meeting Page](DTP_PMC_Meeting "wikilink")

## Attendees

  - John Graham
  - Sheila Sholars
  - Linda Chan

## Agenda

  - John on vacation 7/23 -- 8/3: What to do about 1.5.1 builds?

## Minutes

  - Discussion about build alternatives during vacation
  - Discussion about DTP 1.5.1 rampdown. Propose to project leads next
    Monday:
      - Last planned DTP 1.5.1 on 9/12
      - Testing/petitioned bug fixes from 9/12 -- 9/26
      - Upload of DTP 1.5.1 build on 9/27

## Action Items