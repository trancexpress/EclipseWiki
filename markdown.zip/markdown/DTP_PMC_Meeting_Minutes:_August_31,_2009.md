←[Back to DTP PMC Meeting from 2009, July through September
Page](DTP_PMC_Meeting_from_2009,_July_through_September "wikilink")

## Attendees

  - Brian Fitzpatrick
  - Linda Chan
  - Brian Payton

## Minutes

No meeting minutes were taken for this meeting.

[Category:Data Tools Platform](Category:Data_Tools_Platform "wikilink")