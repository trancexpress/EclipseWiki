←[Back to DTP PMC Meetings from 2009, October through December
page](DTP_PMC_Meeting_from_2009,_October_through_December "wikilink")

## Attendees

  - Brian "Fitz" Fitzpatrick (Red Hat)
  - Linda Chan (Actuate)
  - Brian Payton (IBM)

## Minutes

  - EclipseCon
      - Linda said she will be able to go to EclipseCon.
      - Fitz said he will submit a talk proposal on distributed
        development in Eclipse
      - Brian said he will re-submit the talk he was going to give last
        year, but didn't (because it was the very last session of
        Eclipse, and nobody showed up for the talk\!)
  - Linda has been appending to a newsgroup topic on an ODA driver for
    EMF.
  - We discussed the latest version of the Eclipse Simultaneous Release
    requirements doc
      - Brian raised Fitz's concern about the doc being too wordy at the
        Eclipse Planning Council meeting.
      - There is a new version of the document to review. (See
        [1](http://www.eclipse.org/helios/planning/EclipseSimultaneousRelease.php).)
  - Random news item: there is a new version of the ICU plugin coming in
    Helios. We should be OK given our plugin tolerance setting for the
    ICU plugin.