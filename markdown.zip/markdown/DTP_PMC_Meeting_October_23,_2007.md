←[Back to DTP PMC Meeting Page](DTP_PMC_Meeting "wikilink")

## Attendees

  - John Graham
  - Linda Chan
  - Sheila Sholars

## Regrets

## Agenda

  - (John): Update - MaxDB contribution
    ([BZ197806](https://bugs.eclipse.org/bugs/show_bug.cgi?id=197806))
  - (John): Process for contributions to DTP
  - (John): Connectivity leadership

## Minutes

  - MaxDB discussion
  - Brian Fitzpatrick will be leaving as the lead of Connectivity as of
    11/15. Need to work with the community to determine the best path
    forward.

## Action Items