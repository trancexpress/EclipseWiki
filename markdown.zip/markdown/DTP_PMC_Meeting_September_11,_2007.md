←[Back to DTP PMC Meeting Page](DTP_PMC_Meeting "wikilink")

## Attendees

  - John Graham
  - Sheila Sholars

## Regrets

## Agenda

  - No PMC meeting next week (travel to Eclipse Members' meeting)
  - Update on "build-as-changed" proposal for DTP 1.6 (from last week)

## Minutes

Discussion about VisQ builder:

  - There's a lot to do: what is realistic in 1.6?
  - Given its probable state in 1.6, what is the best way to describe
    it?
      - "Incubator" is a reserved word at Eclipse, so not that
      - "Prototype" sound less solid than it (likely) will be
      - Let's talk to the rest of the VisQ team about this...
  - Encourage the VisQ team to seek out and work with early adopters

## Action Items