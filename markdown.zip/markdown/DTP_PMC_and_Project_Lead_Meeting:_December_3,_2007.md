←[Back to DTP PMC and Project Lead Meeting
page](DTP_PMC_and_Project_Lead_Meeting "wikilink")

## Attendees

  - John Graham
  - Larry Dunnell
  - Sheila Sholars
  - Der-Ping Chou
  - Brian Payton

## Regrets

  - Linda Chan
  - Hung Hsi

## Agenda

  - No meeting next week (12/10): John traveling
      - At Eclipse Board meeting on Wed (12) and Thurs (13)
      - Traveling on Friday (14)
  - New web site format coming soon
      - Project leads: Please update your project wiki pages
      - Description of content and distribution between wiki and web
        site
  - DTP 1.6M4 due to Ganymede on 12/17 (M)
      - Suggest candidate build this Friday (12/7)
      - Testing and *necessary* adjustments next week
      - Need time to build update site and attempt jar signing
      - Need time to test update site
  - Any vacation plans for December -- January?
      - Sybase company vacation 12/24 - 1/2
      - Others?
  - Open discussion

## Minutes

  - (John): Items from agenda

## Action Items