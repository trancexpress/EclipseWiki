←[Back to DTP PMC and Project Lead Meeting
page](DTP_PMC_and_Project_Lead_Meeting "wikilink")

## Attendees

  - John Graham
  - Hung Hsi
  - Sheila Sholars
  - Linda Chan
  - Brian Payton
  - Brian Fitzpatrick

## Regrets

## Agenda

  - (John): Update from Eclipse Summit Europe
      - Overall impressions
      - DTP presentation
      - DTP discussions
  - (John): DTP 1.6 update
  - (John): Call for EclipseCon 2008 submissions
  - Open discussion

## Minutes

  - Updates from John (agenda)
  - No items from rest of team

## Action Items