←[Back to DTP PMC and Project Lead Meeting
page](DTP_PMC_and_Project_Lead_Meeting "wikilink")

## Attendees

  - Brian Fitzpatrick
  - John Graham
  - Hung Hsi
  - Hemant Kolwalkar
  - Brian Payton
  - Linda Chan

## Regrets

  - Emily Kapner
  - Larry Dunnell
  - Sheila Sholars
  - Der Ping Chou

## Agenda

  - Bug to keep an eye on for SWTUtil
    (https://bugs.eclipse.org/bugs/show_bug.cgi?id=253798)
  - EclipseCon 2009 discussion (current \# of presentations, tutorial
    question)
      - Currently 7 submissions (3 long talks, 1 tutorial (2 hours), 2
        30-minute short talks, 1 10-minute short talk)
      - Do we want to have John do his tutorial and add a 2nd 2-hour
        block with Brian Payton & Linda Chan leading it?
  - Galileo & 1.6.2 status (from team leads & others)
  - \[Weekly Nag\] We are at \~30 bugs with no target milestone set that
    need to be dispositioned. Please keep at this list daily if at all
    possible. [the query.](http://tinyurl.com/6robrj%5BHere's)\]
  - Open discussion

## Minutes

## Action Items

  - Need to determine what to do about the tutorial slot. John has 2
    hours. Brian P and Linda have content for the other half, but we'd
    like to split it up to better advertise both talks (one talk
    description might be confusing). Ask at EC Program Committee meeting
    tomorrow. Also ask about "How to make tutorials more enticing?" to
    try and increase attendance
  - How many people attended last year's DTP tutorial(s)?

[Category:Data Tools Platform](Category:Data_Tools_Platform "wikilink")