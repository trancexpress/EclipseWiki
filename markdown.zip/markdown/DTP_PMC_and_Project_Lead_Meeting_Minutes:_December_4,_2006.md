←[Back to DTP PMC and Project Lead Meeting
page](DTP_PMC_and_Project_Lead_Meeting "wikilink")

## Attendees

  - John Graham
  - Der-Ping Chou
  - Hung Hsi
  - Sheila Sholars
  - Brian Payton
  - Rob Cernich

## Regrets

  - Linda Chan

## Agenda

  - Status of RC1 promotion
  - Review of action items from Nov 27 meeting
  - Individual project status

## Minutes

  - Review of RC1 promotion
  - Review of items open for RC1, RC2 and 1.0
  - Discussion of BZ145694 (Synonym appearing for non-Derby databases)
      - Rob describes the problem
      - Group agrees to defer these to 1.5
  - Discussion of BZ129326 (Add "nullable" and "defaultValue" to
    Parameter)
      - Der-Ping agrees to investigate for RC2
  - Discussion of BZ154619 (Properties for SQL objects)
  - Discussion of BZ152046 (Offline support)
      - Brian Payton will resolve as "handled by default support"
  - Updates from project teams
  - John: Update on EclipseCon 2007 DTP proposals
  - Sheila: Daylight savings time issues in DTP

## Action Items

  - **John:** Add aggregate BZ query to collect all remaining DTP 1.0
    items
      - Update, 12/5: Complete; added query to [Use
        Queries](DTP_1.0_Useful_Bugzilla_Queries "wikilink") page.
  - **Project Leads:** Review DTP API statement and submit any questions
    to [dtp-pmc](mailto:dtp-pmc@eclipse.org)