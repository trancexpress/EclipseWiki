←[Back to DTP PMC and Project Lead Meeting
page](DTP_PMC_and_Project_Lead_Meeting "wikilink")

## Attendees

  - John Graham
  - Hung Hsi
  - Brian Fitzpatrick
  - Der-Ping Chou
  - Sheila Sholars
  - Linda Chan
  - Larry Dunnell
  - Brian Payton

## Regrets

## Agenda

  - Reminder: DTP Incubator project creation review this Wednesday at
    11PT.
  - Announcement: John out of the office this Thursday. Email access
    expected late in the day.
  - Announcement: Date stamp format of DTP download zips changing
    starting next Monday. See
    [BZ209412](https://bugs.eclipse.org/bugs/show_bug.cgi?id=209412) for
    details.
  - Review of [bugs with no target milestone
    set](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=DataTools&product=Data+Tools&target_milestone=---&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=).
  - Discussion: When is a Ganymede milestone "done?"
  - Discussion: What to do about driver templates that don't show (at
    least) partial DSE content?
  - Open discussion

## Minutes

## Action Items