←[Back to DTP PMC and Project Lead Meeting
page](DTP_PMC_and_Project_Lead_Meeting "wikilink")

## Attendees

  - John Graham
  - Hung Hsi
  - Sheila Sholars
  - Der-Ping Chou
  - Rob Cernich
  - Linda Chan

## Regrets

  - Brian Payton

## Agenda

  - Europa (DTP 1.5) planning:
      - Eclipse Legal has set **January 31** as the deadline for
        submission of contribution requests for Europa. Therefore,
        inclusion of any external contributions or third party libraries
        **must** be in the Eclipse Legal pipeline on the 31st to be
        included in Europa.
      - Our milestone dates are determined by the Europa schedule as
        posted in the [Milestones and Release
        Candidates](http://wiki.eclipse.org/index.php/Europa_Simultaneous_Release#Projects)
        section of the Europa Wiki page. Note that DTP is in the "+1"
        category.
      - By the Europa schedule, the next DTP 1.5 milestone will be on
        **February 16 (M5)**. There are a number of items, in addition
        to regular enhancement and bug fixes, that we should seriously
        consider for this milestone:
          - Specify the VM version requirements for each plug-in (see
            item 8 in "Must Do" section of Europa Wiki page)
          - Compress the DTP build using "pack 200" (see item 2 in "Must
            Do" section of Europa Wiki page). This will be done as part
            of the DTP build process, so only further testing is
            required by the team.
          - Jar DTP plug-ins: In DTP 1.0, about half of the plug-ins
            were in directory format. Europa will look for us to reduce
            this number significantly, if not completely. We should
            start jarring as many plug-ins as possible, with the aim of
            being complete by M6 (March 30).
      - The PMC intends to have the high-level project plan posted by
        the end of January. I (John) propose that each project have
        their detailed 1.5 plans posted by the M5 (Feb. 16) Europa date.
        These detailed plans should include planned enhancements, major
        bug fixes, and as additional information about work projected
        for 1.5 as possible.
      - Build environment
          - The PMC has been discussing the build environment and set of
            supported configurations
          - We would to preserve the ability to run DTP 1.5 in Eclipse
            3.2.x, EMF 2.2 and GEF 3.2 on a 1.4 VM if possible. But the
            offical environment for Europa is Eclipse 3.3, EMF 2.3 and
            GEF 3.3 on a 1.5 VM.
          - We therefore propose that DTP 1.5 be built on Eclipse 3.2.x,
            EMF 2.2 and GEF 3.2 with a 1.4 but tested primarily on
            Eclipse 3.3, EMF 2.3 and GEF 3.3 with a 1.5 VM. To check
            compatiblity, test builds against Eclipse 3.3, EMF 2.3, GEF
            3.3 on a 1.5 VM will be run to ensure that the code compiles
            in this environment, but **all** DTP 1.5 posted builds
            (nightly, milestone, rc and release) will be built on the
            Eclipse 3.2.x, EMF 2.2, GEF 3.2 and 1.4 VM stack.
          - Obviously this implies that any EMF model generation be done
            on EMF 2.2.
      - We are being encouraged to move to the standard PDE build system
        for Europa. Whatever we decide, our build procedure needs to be
        clearly documented as part of Europa \[optional\] requirements
        (item 3,4 in "Should Do" category of Europa Wiki page). We need
        to find staffing to support this.
  - Individual project status

## Minutes

  - Discussion of Europa plan per agenda. The team agree with the
    planning dates.
  - Need to keep in mind that adopters need a ramp-down toward each
    milestone, so they can start testing before their deadlines too.
  - Discussion of DTP 1.5M5 work items:
      -   - VM levels: good idea to add for this milestone
          - Pack 200: If possible. Note that Pack 200 applies only for
            update site, not zipped downloads.
          - Jarring plug-ins: We should start during M5.
  - Discussion of build environment: Team agrees with the proposal in
    the agenda, reserving the right to drop Eclipse 3.2.x support if it
    becomes too difficult later. Given the Europa API freeze on 3/30, if
    we can handle both until then, we'll probably be fine for Europa.
  - Project retrospective: Collected retrospective will be circulated
    this week on dtp-dev/dtp-pmc. We can discuss on those mailing lists
    and the PMC can take under advisement any changes required.
  - Administrative note: Not team meeting next week, due to travel and
    Eclipse Council meetings

## Action Items

  - **John:** Restart nightly builds from DTP head based on agreed
    enviroment
  - **John:** Post retrospective comments to dtp-dev/dtp-pmc by end of
    this week
  - **PMC:** Publish high-level plan for DTP 1.5 by end of January
  - **Project Leads:** Publish detailed project plans by Feb 16