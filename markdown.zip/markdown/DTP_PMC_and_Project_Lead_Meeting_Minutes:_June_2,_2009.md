←[Back to DTP PMC and Project Lead Meeting
page](DTP_PMC_and_Project_Lead_Meeting "wikilink")

## Attendees

  - Brian Fitzpatrick
  - Linda Chan
  - Larry Dunnell
  - Hung Hsi
  - John Graham
  - Brian Payton
  - Emily Kapner
  - Hemant Kolwalkar

## Regrets

## Agenda

  - \[TBD\]
  - Status
  - \[Weekly Nag\] We are at \~X bugs with no target milestone set that
    need to be dispositioned. Please keep at this list daily if at all
    possible. [the query.](http://tinyurl.com/6robrj%5BHere's)\]
  - Open discussion

## Minutes

## Action Items

[Category:Data Tools Platform](Category:Data_Tools_Platform "wikilink")