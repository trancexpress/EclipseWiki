←[Back to DTP Project Lead Meeting Minutes: 2009, October through
December
page](DTP_Project_Lead_Meeting_Minutes:_2009,_October_through_December "wikilink")

## Attendees

  - Brian "Fitz" Fitzpatrick (Red Hat)
  - Linda Chan (Actuate)
  - Brian Payton (IBM)
  - Hemant Kolwalkar (IBM)

## Minutes

  - The PMC will work on the Helios project plan during the PMC meeting
    tomorrow
  - Fitz said that Larry Dunnell (IBM) will no longer be involved with
    the DTP project. This leaves a gap in coverage for the Connectivity
    project. Brian P. will find out whether anyone else from IBM will be
    working on Connectivity in Larry's place
  - Hemant said he still needs to look into the Modelbase defect that
    has a target of 1.7.2
  - Fitz said that as of the last time he checked, the Sybase was on
    track for delivering the doc source files to DTP by the end of
    October