## Attendees

  - Linda Chan (Actuate)
  - Hemant Kolwalkar (IBM)
  - Brian Payton (IBM)

## Minutes

  - Hemant reported on the bugs listed in the previous meeting. He said
    one is already fixed (and just needed to be closed). The other is
    regarding trimming schema names in the model. We decided the
    proposed fix should not be applied, since it doesn't work for all
    database vendors.
  - Linda reopened the SQLQuerySourceWriter bug, since the fix wasn't
    complete.
  - Brian P. has a bunch of SQL Dev Tools bugs that need their target
    milestone set