## Attendees

  - Brian "Fitz" Fitzpatrick (Red Hat)
  - Linda Chan (Actuate)
  - Hemant Kolwalkar (IBM)
  - Brian Payton (IBM)

## Minutes

  - Regarding regenerating the javadoc for DTP: Linda has asked Xiao
    Ying (Actuate build team) to create a separate properties file that
    contains the included and excluded packages, which we can put in a
    place we can get to (TBD) so we can update it again in the future.
  - Hemant will update the WebPublish'd Rose diagrams for the SQL models
    and send it to Brian P.
  - Brian P. updated the release metadata for Modelbase.
  - The conference call number we are using is going away. Brian P. will
    send out a new one to use starting next year.
  - Hemant is investigating how to support the max length specifier for
    varchar, varbinary for M'soft SQL Server