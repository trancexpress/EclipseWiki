## Attendees

  - Brian "Fitz" Fitzpatrick (Red Hat)
  - Linda Chan (Actuate)
  - Brian Payton (IBM)

## Minutes

  - We discussed combining our EclipseCon talks, since apparently there
    aren't enough schedule slots for all the talks that the organizers
    would like to accept.
  - We discussed the Capabilities request from David Williams. (See the
    posting to the "cross-project-issues-dev" mailing list on 01/11/2010
    by David Williams, title "capability bundles to be removed from
    Helios build aggregation".) Fitz appended to the bug 299344 to ask
    what we need to do.
  - We still need to update the project info for DTP. Fitz told us how
    to get to the right place in the Eclipse portal.
  - We discussed some bugs:
      - 294136 -- This is a generate DDL bug. What do we do with this
        one? Brian P. will see if there is someone in the IBM team who
        knows this area.
      - 289725 -- This is an ODA issue. Linda will look into it.
  - There are lots of SQL Dev Tools bugs still to address.
  - DTP 1.7.2 RC1 is coming up soon, so we need to make any final 1.7.2
    fixes now.