## Attendees

  - Linda Chan (Actuate)
  - Brian "Fitz" Fitzpatrick (Red Hat)
  - Brian Payton (IBM)

## Minutes

  - Brian P. asked about the Connection Repository, since he is updating
    the translation test document. Fitz explained how it works.
  - We discussed a bug that Linda found in the new Import Connection
    Profile method. We should fix this one.
  - There has been some activity in the mailing lists regarding the
    Results View
  - The 3.5 SR2 problem has been resolved. The files were uploaded but
    the PHP page linking to them was not updated
  - The Actuate build team would like to build DTP only when something
    has changed, rather than running a build every day. The PMC had no
    objection.
  - The Actuate build team is considering moving the DTP build to
    Eclipse.org build machines. They are trying to find out if there is
    any disadvantage to doing this.
  - Fitz is working on his EclipseCon talk. He said Motorola can have
    2/3 the time, since Brian P. won't be able to participate.
  - Linda and Fitz will host a "Birds of a Feather" session on DTP
    during EclipseCon. Fitz will find out how to arrange this. The BOF
    submission deadline is this week Friday