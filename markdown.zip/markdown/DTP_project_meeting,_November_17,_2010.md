## Attendees

  - Brian "Fitz" Fitzpatrick (Red Hat)
  - Linda Chan (Actuate)
  - Hemant Kolwalkar (IBM)
  - Brian Payton (IBM)

## Minutes

  - Brian P. is going to ask Fitz to review a change in Connectivity. He
    will open a bug for it shortly.
  - We have removed Hui Cao as a committer due to inactivity. (The
    Eclipse IP person Sharon Corbett is handling it.)
  - We don't have any EclipseCon talks for DTP planned so far.
  - There is a question in the news group regarding editing data and
    schemas. Brian P. will respond.
  - Brian P. and Hemant will continue working on updating the DB2
    database definitions.