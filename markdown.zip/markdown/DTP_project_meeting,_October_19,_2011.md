## Attendees

  - Linda Chan (Actuate)
  - Brian Payton (IBM)

## Minutes

  - At an Eclipse Architecture Council meeting, we heard that the Orion
    team has worked out a way to do builds from Git that doesn't involve
    tagging. (Or rather, the tagging is hidden form the developers.)
    Linda said she will talk to the Build team to see if they can adopt
    that technique. (Tagging is a big pain with Git.) Brian P. will
    contact John Arthorne (Orion lead) if Linda needs more information.
  - Brian P. has been putting in various fixes for IBM product
    integration purposes.
  - Linda asked about getting an update to the IBM database definitions.
    Brian P. said the problem with putting updated ones in DTP is that
    IBM products have "ibm.com" versions of those database definitions,
    and it might be a problem to have both DTP and IBM versions of those
    files. Linda said there is an override property for
    connections...perhaps that can help
  - Linda has finished her security extension point enhancement
  - We will ask Pierre Quiennec if he wants to become a committer for
    Enablement (Postgres) due to the quality of his patches.