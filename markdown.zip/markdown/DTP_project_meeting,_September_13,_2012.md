## Attendees

  - Linda Chan (Actuate)
  - Brian Payton (IBM)

## Minutes

  - Still need to update the metadata for DTP 10.1 and 10.2. Also need
    to update the wiki.
  - We decided to branch 10.1 out now and carry on with "head" for 10.2.
    Linda will ask the Build team do to that.
  - We will be using the "head" as both the 10.2 and Kepler contribution
    for now. We discussed whether or not we need a version 11.0 for
    Kepler or whether we can do a 10.3 version (since likely not much
    going in for that release).
  - There have been several NLS bugs opened by the IBM translation
    testers. Linda fixed several for ODA. There is at least one on the
    Sybase enablement, and we don't have any developer coverage for
    that. Brian will try to find some time to look into it.