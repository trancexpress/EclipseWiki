## Attendees

  - Linda Chan (Actuate)
  - Brian "Fitz" Fitzpatrick (Red Hat)
  - Hemant Kolwalkar
  - Brian Payton (IBM)

## Minutes

  - Fitz has added an Indigo section to the DTP wiki pages
  - Linda asked whether we should be still be building on 3.4.2 or on
    some later version?
      - Linda was concerned that we can't take advantage of anything in
        Eclipse later than 3.4.2
      - Officially our policy is to support two releases back, so we
        should be able to move off 3.4.2 now
      - There are still lots of products running on 3.4.2.
      - We decided to keep things as they are for 1.8.2, but will
        re-evaluate for 1.9. Can switch in 1.8.2 if there is a real need
      - Brian P. will clarify IBM policy in this area
  - Went through Connectivity bugs in the DTP bug list that were still
    at 1.8 milestone
  - Linda will add the 1.9 milestone for Bugzilla