[Dali 3.0](Dali_3.0 "wikilink")

## Dali 3.0.1 Manual Testing

<table>
<caption><strong>Manual Testing for 3.0.1 Release</strong></caption>
<tbody>
<tr class="odd">
<td><p><strong>Bug No.</strong></p></td>
<td><p><strong>Description</strong></p></td>
<td><p><strong>Test Steps</strong></p></td>
<td><p><strong>Test Step Results</strong></p></td>
</tr>
<tr class="even">
<td><p>316022</p></td>
<td><p>NPE refreshing out of sync entity</p></td>
<td><p>Create JPA Project, Create Entity for the project</p></td>
<td><p>Project and Entity are created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Close the project and open the entity (ex. employee.java) in a text editor outside of eclipse and change something (ex. @Column(name="MANAGER_ID") to @Column(name="MANAGERID") ) Save the file</p></td>
<td><p>File is updated and saved</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Go back to Eclipse and open the project, open the edited entity by using the Project Explorer&gt;JPA Content tree and double clicking the entity</p></td>
<td><p>Verify no errors appear in log and message states you need to refresh</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Hit F5 to refresh</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>338413</p></td>
<td><p>NPE moving orm.xml to a subfolder in META-INF</p></td>
<td><p>Create a new JPA 2.0, Generic 2.0 project</p></td>
<td><p>Project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on project and Add JPA orm.xml mapping file</p></td>
<td><p>JPA orm.xml mapping file is added successfully in the META-INF folder.</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create a new subfolder in META-INF</p></td>
<td><p>Subfolder is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Drag the orm.xml file to the subfolder (move)</p></td>
<td><p>Verify orm.xml is moved into the subfolder without error</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Move orm.xml out of subfolder and back into META-INF folder</p></td>
<td><p>orm.xml is moved back successfully without error</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on orm.xml and select Move</p></td>
<td><p>Move Resources dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select the subfolder and click on OK button</p></td>
<td><p>Verify orm.xml is moved into subfolder without error</p></td>
</tr>
<tr class="odd">
<td><p>338948</p></td>
<td><p>Cancel rename of an attribute and the diagram still gets edited</p></td>
<td><p>Create JPA 1.0, Generic 1.0 project</p></td>
<td><p>JPA Project is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create a JPA entity with 2 or 3 attributes and make sure there is at least one validation error (ex. use an incorrect column name for an attribute)</p></td>
<td><p>Entity is created and some validation errors appear</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the project, Select JPA Tools &gt; Open Diagram...</p></td>
<td><p>Diagram editor is opened</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click in the Diagram editor and select Show all Entities</p></td>
<td><p>Verify the Entity appears in diagram and the attribute shows an error</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on the attribute name (that has the error) twice and rename the attribute and hit the enter button on the keyboard</p></td>
<td><p>Rename Method dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on the Cancel button</p></td>
<td><p>Verify the dialog closes and the name is not updated</p></td>
</tr>
<tr class="odd">
<td><p>339418</p></td>
<td><p>Incorrectly enabled converter widgets in virtual orm.xml attribute</p></td>
<td><p>Create JPA 2.0, EL 2.1.x project, Create an Entity with 2 or 3 attributes</p></td>
<td><p>Project and Entity are created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>For an attribute withing the entity in the JPA Details select Converted radio button and select serialized from the converter name drop down</p></td>
<td><p>Verify editor is updated with @Convert("serialized") for the attribute</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add an eclipselink-orm.xml mapping file to the project</p></td>
<td><p>eclispelink-orm.xml mapping file is added successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add the Entity to the el-orm.xml mapping file and select the attribute you added the converter too</p></td>
<td><p>Verify the Converted radio button is selected but grayed out and the Converter name drop down shows serialized but is also grayed out.</p></td>
</tr>
<tr class="odd">
<td><p>342624</p></td>
<td><p>ASTTools.findTypeInHierarchy() does not handle parameterized type reference</p></td>
<td><p>Create JPA 2.0, EclipseLink 2.2.x project, Create JPA Entity and make sure it is added to the persistence.xml</p></td>
<td><p>Project and entity are created successfully and the entity appears in persistence.xml</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create a New Interface with the following - import org.eclipse.persistence.config.DescriptorCustomizer;</p>
<p><code>  public interface MyInterface</code><T><code> extends DescriptorCustomizer {</code><br />
<code>  }</code></p></td>
<td><p>The Interface is added successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create a new class that implements the interface:</p>
<p><code>  import org.eclipse.persistence.descriptors.ClassDescriptor;</code><br />
<code>  public class MyClass implements MyInterface</code><Object><code> {</code><br />
<code>     public void customize(ClassDescriptor descriptor) throws Exception {</code><br />
<code>     }</code><br />
<code>  }</code></p></td>
<td><p>Verify the Class is added successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select the Entity in the JPA Structure Pane, Expand the Advanced section in the JPA Details pane, Click on the Browse button for Customizer Class</p></td>
<td><p>Class Selection dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select the New class you added previously and click on the OK button, Save the Project.</p></td>
<td><p>Verify the project is saved successfully and no errors appear</p></td>
</tr>
<tr class="even">
<td><p>344645</p></td>
<td><p>IllegalStateException when clicking Daily expiry radio button more than once</p></td>
<td><p>Create a JPA 2.0 EclipseLink 2.2.x Project, create 2 or 3 entities from tables</p></td>
<td><p>JPA project and entities are created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select an entity in JPA Structure Pane and in JPA Details Pane expand caching section</p></td>
<td><p>Caching information appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Expand Advanced section and click on Daily Expiry radio button twice</p></td>
<td><p>Verify no errors appear and the radio button is selected</p></td>
</tr>
<tr class="odd">
<td><p>345031</p></td>
<td><p>ClassCastException: SourceField/SourceMethod cannot be cast to JavaResourceAbstractType</p></td>
<td><p>Create JAXB Project</p></td>
<td><p>JAXB Project is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on JAXB Project and select New &gt; Class</p></td>
<td><p>New Java Class dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Enter a package name (ex. model) and Name (ex. Foo)and click on Finish</p></td>
<td><p>Class is created successfully without error</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add the following to the class and Save</p>
<p><code>       private Integer Address_ID;</code><br />
<code>    private String City;</code></p>
<p><code>    public Integer getAddress_ID() {</code><br />
<code>       return this.Address_ID;</code><br />
<code>   }</code></p>
<p><code>    public String getCity() {</code><br />
<code>       return this.City;</code><br />
<code>   }</code></p></td>
<td><p>Class is updated and no errors appear</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add the following to the Class before public class Foo</p>
<p><code>  import javax.xml.bind.annotation.XmlType;</code><br />
<code>  @XmlType</code></p></td>
<td><p>Verify no errors appear in problems pane or Error Log</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Enter @XmlType prior the the first field and Save</p></td>
<td><p>Verify no errors appear in error log but 2 errors appear in Problems pane</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Remove @XmlType from before the first field to be in the middle of the two fields and Save</p></td>
<td><p>Verify the errors in the problems pane remain the same and no errros appear in Error log</p></td>
</tr>
<tr class="even">
<td><p>345293</p></td>
<td><p>Add JPA entity - Create new mapping file (orm.xml) cannot continue</p></td>
<td><p>Create New &gt; JPA Project using all default values</p></td>
<td><p>JPA Project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select New &gt; JPA Entity, Enter package, Enter Name, Check the Add to entity mappings in XML checkbox and Click on Browse button</p></td>
<td><p>Mapping File dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on the New button</p></td>
<td><p>New Mapping File dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Leave the default location and file name (orm.xml), Click on Finish</p></td>
<td><p>Verify orm.xml appears for Choose mapping file</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on OK button</p></td>
<td><p>Verify META-INF/orm.xml appears in the mapping file text field, Verify the Next button is enabled.</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Remove the text from the mapping file field</p></td>
<td><p>Verify Next button is disabled, Verify message states The mapping file does not exist.</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add META-INF/orm.xml back into the mapping file text field</p></td>
<td><p>Verify Next button is enabled.</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on Next button, Add 2 or 3 fields to the Entity and click on Finish</p></td>
<td><p>Verify JPA Entity is created successfully without error</p></td>
</tr>
<tr class="even">
<td><p>346997</p></td>
<td><p>Customizing of generated entities with interfaces and superclasses does not work</p></td>
<td><p>Create JPA project (with connection to DB), create Interface and Class (using defaults)</p></td>
<td><p>Project, Interface and Class are all created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on project select JPA Tools &gt; Generate Entities from Tables...</p></td>
<td><p>Generate Custom Entities dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select two tables and click on the Next button 3 times</p></td>
<td><p>The last page of the Wizard appears Customize Individual Entities</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select an Entity and click on the Add button for the Interface and select the Interface you created and Click on OK</p></td>
<td><p>Verify the Interface appears in the list</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on the other Entity</p></td>
<td><p>Verify no Interface appears for this Entity</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click back and forth on the two entities</p></td>
<td><p>Verify the Interface always appears for the Entity it was assigned to and none appears for the other Entity</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select the Entity that does not contain the Interface and click on the Browse button</p></td>
<td><p>Superclass Selection dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select the Class you created and click on the OK button</p></td>
<td><p>Verify the selected class appears in the Superclass field</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click back and forth on the two entities</p></td>
<td><p>Verify the Interface always appears for the Entity it was assigned and no Superclass appears for that one and then a Superclass appears for the other but no Interface</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select the entity with the Interface and remove the interface</p></td>
<td><p>Verify the Interface is removed</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click back and forth on the two entities</p></td>
<td><p>Verify the Superclass still appears for the entity it was assigned and no Interface appears for the Entity that it was removed from.</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select the entity with the Superclas and remove the superclass</p></td>
<td><p>Verify the Superclass is removed</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click back and forth on the two entities</p></td>
<td><p>Verify no superclass or interface appears for either entity</p></td>
</tr>
<tr class="odd">
<td><p>347219</p></td>
<td><p>NullPointerException: Change a mapping to element collection mapping</p></td>
<td><p>Create JPA Project, create Entities from tables, Create orm mapping file</p></td>
<td><p>Project, entities and mapping file are created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on the mapping file in the JPA Structure tab and select Add Class</p></td>
<td><p>Add Class dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select an entity that you created (ex. Employee) and click on OK</p></td>
<td><p>Class appears in the orm mapping file</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on an attribute in the JPA Structure tab, select Add Attribute to XML and Map...</p></td>
<td><p>Add Attribute dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on ok button</p></td>
<td><p>Attribute is added to xml and mapping file</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the added attribute and select Map As &gt; Element Collection</p></td>
<td><p>Verify xml and mapping is updated without any errors</p></td>
</tr>
<tr class="odd">
<td><p>347814</p></td>
<td><p>NullPointerException: Change a mapping to many-to-one or one-to-one mapping</p></td>
<td><p>Create JPA project, create Entities from tables, create orm mapping file</p></td>
<td><p>Project, entities and mapping file are created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add Class (ex. Employee) to the mapping file via the JPA Structure Pane</p></td>
<td><p>Class is added successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>In the JPA structure pane, right-click an attribute and add it to the XML</p></td>
<td><p>Attribute is added to orm mapping file without error</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Again right-click the added attribute and try to change the type of it to many-to-one or one-to-one</p></td>
<td><p>Verify the orm mapping file is updated with the selected type and no errors appear</p></td>
</tr>
<tr class="odd">
<td><p>347977</p></td>
<td><p>Exception in error log while renaming entity</p></td>
<td><p>Create JPA project, R-Click and select JPA Tools &gt; Open Diagram</p></td>
<td><p>Project is created successfully and diagram is opened in editor</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create a JPA entity within the diagram</p></td>
<td><p>Entity is created in the diagram successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the entity in the diagram and select Refactor Entity Class &gt; Rename</p></td>
<td><p>Rename Compliance Unit dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Enter a new name into the New Name field and click on Next button, then click on the Finish button</p></td>
<td><p>Verify name is updated and no errors appear in the Error Log</p></td>
</tr>
<tr class="odd">
<td><p>348143</p></td>
<td><p>NullPointerException: Add entity to XML</p></td>
<td><p>Create a brand new JPA project with a mapping xml created along with it (selecting "Create mapping file (orm.xml) checkbox" when creating the JPA project)</p></td>
<td><p>Project is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Right-click the created JPA project and select New -&gt; JPA Entity to create an entity, select "Add to entity mappings in XML" checkbox when it shows, create a couple of fields for the entity (make at least 1 of them an ID, Key), and hit Finish.</p></td>
<td><p>Verify the Entity is created without any errors and the fields appear correctly as you entered them.</p></td>
</tr>
<tr class="odd">
<td><p>348667</p></td>
<td><p>Delete diagram editor, then Save, receive errors</p></td>
<td><p>Create a JPA project then R-Click on the project and select JPA Tools &gt;Open Diagram.</p></td>
<td><p>Verify diagram.xml opens in editor</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Delete the diagram folder (which contains the diagram.xml)</p></td>
<td><p>Verify the diagram editor closes without error</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the project and select JPA Tools &gt; Open Diagram, Add a Java Entity to the diagram editor</p></td>
<td><p>Entity appears in the editor without error</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Delete the diagram.xml file</p></td>
<td><p>Verify the diagram editor closes without error</p></td>
</tr>
<tr class="odd">
<td><p>349031</p></td>
<td><p>[EclipseLink] descriptor customizer validation incorrect when default zero arg constructor</p></td>
<td><p>Create JPA 2.0, EclipseLink 2.2.x project</p></td>
<td><p>Project is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create JPA Entity (MyCustomizer), with one field (Id)</p></td>
<td><p>Entity is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Change implements Serializable to implements DescriptorCustomizer, and import DescriptorCustomizer and then add public void customize (ClassDescriptor descriptor) throws Exception { } &amp; then remove the serializable warning items and Save Project</p></td>
<td><p>Project is saved without warnings</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Remove public MyCustomizeClass() {</p>
<p><code>   super();</code><br />
<code>   }    and then Save the project</code></p></td>
<td><p>Verify no errors appear</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Go to the Entity JPA Details pane, Expand Advanced, Add MyCustomizer to the Customizer Class field and then Save the project</p></td>
<td><p>Verify no errors still appear for the project</p></td>
</tr>
<tr class="even">
<td><p>349071</p></td>
<td><p>[EclipseLink] eclipselink 2.3 schemas not up to date</p></td>
<td><p>Get latest Dali build and install, open eclipse&gt;plugins&gt;org.eclipse.jpt.common.eclipselink.cor_1.0.0.jar file</p></td>
<td><p>Verify the latest files exist - eclipselink_orm_2_3.xsd file from 7/25/11, eclipselink_oxm_2_3.xsd from 6/24/11, eclipselink_persistence_map_2_3.xsd from 6/24/11</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>For workaround, go to an older install, launch Eclipse, Select Window&gt;Preferences</p></td>
<td><p>Preferences dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select XML Catalog, Select User Specified Entries, click on Add button</p></td>
<td><p>Add XML Catalog Element dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on File system and browse to the latest version of the eclipselink_orm_2_3.xsd file, select open, for the Key enter the same value as the key for the .xsd file you are replacing in the plugin entries and click on ok button</p></td>
<td><p>Verify the entry appears under the User Specified Entries and no errors appear.</p></td>
</tr>
<tr class="even">
<td><p>349337</p></td>
<td><p>[API] CCE generating metamodel classes</p></td>
<td><p>Create a Generic 2.0 JPA project with an orm.xml file</p></td>
<td><p>JPA project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the JPA Project and select properties,</p></td>
<td><p>Properties dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Set a canonical metamodel source folder and click on OK</p></td>
<td><p>Properties dialog closes successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add the following JPA entity - @Entity public class Bar {</p>
<p><code>   @Id</code><br />
<code>   private int id;</code></p>
<p>}</p></td>
<td><p>Entity is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Go to the orm.xml file in the JPA Structure pane and Add the entity to the orm.xml mapping file</p></td>
<td><p>Verify the entity is added to the orm.xml without error</p></td>
</tr>
<tr class="odd">
<td><p>349722</p></td>
<td><p>NPE deleting generator name from "Generator name" combo</p></td>
<td><p>Create JPA project, Create Entity that contains an ID mapping</p></td>
<td><p>Project and Entity are created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select the Id mapping in the Entity in the JPA Structure pane</p></td>
<td><p>Id mapping appears in the JPA Details view</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Expand the Primary Key Generation section in the JPA Details pane</p></td>
<td><p>Primary Key checkbox is not checked and the Strategy and Generator Name fields are enabled</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Enter 'Testing' into the Generator Name field</p></td>
<td><p>Verify the following annotation appears in the editor for the entity - @GeneratedValue(generator = "testing")</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Delete the generator name (either by removing it from the Entity editor and removing it from the field in the JPA Details pane</p></td>
<td><p>Verify the generator name is removed from the editor and the JPA Details pane without error</p></td>
</tr>
<tr class="even">
<td><p>351409</p></td>
<td><p>Strange event when saving the diagram</p></td>
<td><p>Create JPA project, R-Click on the project and select JPA Tools &gt; Open Diagram...</p></td>
<td><p>Project is created successfully and diagram is open in the editor</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add a JPA Entity via the diagram editor and Save</p></td>
<td><p>Entity is added and saved successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Highlight the Entity, R-Click and Select Remove All Entities From Diagram &gt; ...and Save Changes</p></td>
<td><p>Verify Entity is removed and the Diagram is saved</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add a JPA Entity via the diagram editor and Save</p></td>
<td><p>Entity is added and saved successfully and the diagram remains open</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the Entity and Select Remove All Entities From Diagram &gt; ... and Discard Changes</p></td>
<td><p>Remove All Entities From Diagram dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on the Cancel button</p></td>
<td><p>Verify the Entity is not removed</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the Entity and Select Remove All Entities From Diagram &gt; ... and Discard Changes and Click on OKbutton</p></td>
<td><p>Verify Entity is removed from the Diagram and diagram remains open</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the Diagrams Folder in the Project Explorer Pane and select Delete</p></td>
<td><p>Verify the Diagram folder is deleted and the diagram editor is closed successfully</p></td>
</tr>
<tr class="even">
<td><p>353017</p></td>
<td><p>Validation show problems with NamedQuery with subquery in where clause</p></td>
<td><p>Create JPA project, Create JPA Entity</p></td>
<td><p>JPA project and Entity are created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select Entity in the JPA Structure pane, Expand the Queries section in the JPA Details pane for the Entity and click on the Add button</p></td>
<td></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Enter a name for the query and select Named Query from the from the Type drop down and click on OK button</p></td>
<td><p>Query appears in entity editor</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add the following query into query text editor in JPA Details - select t from Address t where t.id = (select max(tt.id) from Address tt) and Save the project</p></td>
<td><p>Project is saved and the</p></td>
</tr>
<tr class="even">
<td><p>353146</p></td>
<td><p>Make Persistent Wizard: Cannot select mapping file from the folder other than META-INF</p></td>
<td><p>Create JPA project</p></td>
<td><p>JPA Project is created successfully and verify the following error does not appear - The identification variable ' ' is not defined in the FROM clause</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create a new folder under the src folder</p></td>
<td><p>New folder is created under src folder</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the new folder and select New&gt;JPA orm mapping file</p></td>
<td><p>New Mapping File dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on Next and then Finish</p></td>
<td><p>Verify orm.xml exists under the new folder in the src folder</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add the orm.xml mapping file to the persistence.xml</p></td>
<td><p>orm.xml is added to persistence.xml successfully without error</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on the project and select New &gt; Class</p></td>
<td><p>New Java Class dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Leave the defaults and Add the new class</p></td>
<td><p>New Class is added successfully to Project without error</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the new class and select JPA Tools &gt; Make Persistent...</p></td>
<td><p>Make Persistent dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select Add to XML mapping file radio button and click on Browse button</p></td>
<td><p>Mapping File dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select the orm.xml file and click on OK</p></td>
<td><p>Verify you return to the Make Persistent dialog and the orm.xml appears in the Mapping File text field without any errors.</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on the finish button</p></td>
<td><p>Verify dialog closes and no errors appear</p></td>
</tr>
<tr class="odd">
<td><p>353555</p></td>
<td><p>Inconsistent diagram name</p></td>
<td><p>Create a JPA Project</p></td>
<td><p>Project is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Open persistence.xml in the editor, Go to the General and change the name (from JPA Project name to something else)</p></td>
<td><p>Verify name is updated</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on project and select JPA Tools &gt; Open Diagram</p></td>
<td><p>Diagram opens in editor and verify the name of the diagram is the name of the project.xml</p></td>
</tr>
<tr class="even">
<td><p>354363</p></td>
<td><p>Delete entity from diagram doesn't remove it from the project tree</p></td>
<td><p>Create JPA Project</p></td>
<td><p>JPA project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the JPA project and select JPA Tools &gt; Open Diagram...</p></td>
<td><p>Diagram editor is opened</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add a Java Entity to the diagram via the editor</p></td>
<td><p>Entity is added in the diagram editor and in the project tree under the src/org.persistence/ folder</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the Entity in the diagram editor and select Delete or select the Entity in the editor and click on the Trash can icon</p></td>
<td><p>Confirm Delete dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on No button</p></td>
<td><p>Verify entity is not deleted in the editor or the project tree</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the entity in the diagram editor and select Delete and click on the Yes button in the Confirm Delete dialog</p></td>
<td><p>Verify the entity is removed from the diagram editor and is also removed from the src/org.persistence folder in the project tree.</p></td>
</tr>
<tr class="even">
<td><p>354444</p></td>
<td><p>Invalid ORM ElementCollection target-class validation with package element</p></td>
<td><p>Launch Eclipse, Import the example project attached to the bug</p></td>
<td><p>Element collection project appears in Project Explorer</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the project and click on properties and add the needed library and click on OK</p></td>
<td><p>The project is updated and most errors are removed.</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the project and select validate</p></td>
<td><p>Verify Validation Results dialog appears with results</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on OK button to close validation results dialog</p></td>
<td><p>Verify the following error appears - Collection table "PropertyRecord_parcels" cannot be resolved</p></td>
</tr>
<tr class="even">
<td><p>354669</p></td>
<td><p>Invalid map key class validation in orm.xml element collection</p></td>
<td><p>Create JPA 2.0, Generic 2.0 project</p></td>
<td><p>Project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create JPA Entity, with 2 fields (one as Id type and the other as a Collection type)</p></td>
<td><p>Entity is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add orm.xml mapping file to the project and add the JPA entity to the orm.xml mapping file</p></td>
<td><p>Entity is added to orm.xml mapping file successfully without error</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Go to the JPA Structure pane for the Entity Mappings (orm.xml) and R-Click on the Collection Type attribute and select Add Attribute to XML and map...</p></td>
<td><p>Add Attribute dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select Element Collection from the Map As drop down and click on OK button</p></td>
<td><p>Verify it is added to orm.xml mapping file and the error stating 'Map key class is not defined does not appear in the Problems pane as an error</p></td>
</tr>
<tr class="odd">
<td><p>355502</p></td>
<td><p>Invalid ORM id-class validation with package element</p></td>
<td><p>Select File &gt; Import, Select General &gt; Existing Projects into Workspace and Import the project attached to this bug</p></td>
<td><p>Project is imported successfully but contains errors</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on the imported project and select Properties, Add the EclipseLink 2.3.0 - Indigo library and click on OK button</p></td>
<td><p>Verify errors are removed from project</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on the project and select Validate</p></td>
<td><p>Verify no errors appear on validation</p></td>
</tr>
<tr class="even">
<td><p>355978</p></td>
<td><p>NPE adding persistence-unit-defaults element to eclipselink-orm.xml file</p></td>
<td><p>Create JPA 2.0, EL 2.0 project</p></td>
<td><p>Project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the project and select New - Eclipselink ORM Mapping File</p></td>
<td><p>The eclipselink-orm.xml is opened in the editor</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add the following to the source and Save <persistence-unit-metadata> <persistence-unit-defaults></persistence-unit-defaults></persistence-unit-metadata></p></td>
<td><p>Verify it is saved successfully and no errors appear</p></td>
</tr>
<tr class="odd">
<td><p>356292</p></td>
<td><p>Validation error for entities with @AttributeOverride on attribute marked as @Version in mapped superclass</p></td>
<td><p>Create a JPA 2.0, Generic 2.0 project with connection to a db</p></td>
<td><p>Project is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create two JPA entities copy the entity information for A and for B from the bug attachments</p></td>
<td><p>JPA Entities are created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Fix the few validation errors by making the db table connection corrections</p></td>
<td><p>Verify all errors are removed and error stating - Attribute override "version" cannot be resolved to an attribute on the mapped superclass "A" does not appear|</p></td>
</tr>
</tbody>
</table>