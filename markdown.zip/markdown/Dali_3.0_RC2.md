[Dali QA Testing](Dali_QA_Testing "wikilink")

## Dali 3.0 RC2 Manual Testing

<table>
<caption><strong>Manual Testing for 3.0 RC2 Release</strong></caption>
<tbody>
<tr class="odd">
<td><p><strong>Bug No.</strong></p></td>
<td><p><strong>Description</strong></p></td>
<td><p><strong>Test Steps</strong></p></td>
<td><p><strong>Test Step Results</strong></p></td>
</tr>
<tr class="even">
<td><p>339399</p></td>
<td><p>Exception thrown when changing the persistence.xml version to an invalid version</p></td>
<td><p>Create new Java project, R-click on project and select properties</p></td>
<td><p>Properties dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select Project Facets, click on Convert to faceted form...</p></td>
<td><p>Project Facets page appears in dialog</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Check the JPA checkbox and Click on OK button</p></td>
<td><p>Dialog closes and no errors appear</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Open the persistence.xml and go to the source, Insert 1 in the version header, version="2.0" becomes version="12.0"</p></td>
<td><p>Verify no errors appear in the error log</p></td>
</tr>
<tr class="even">
<td><p>341415</p></td>
<td><p>Exception thrown when JPA version is 2.0 but ORM version is 1.0</p></td>
<td><p>Create a new JPA project with JPA version 2.0</p></td>
<td><p>JPA Project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create a new entity and a new JPA ORM Mapping file</p></td>
<td><p>Entity and ORM Mapping file are created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Add the new entity to the ORM Mapping as an entity</p></td>
<td><p>Entity is added to the ORM mapping file and appears in the source</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>In the source editor of the orm.xml, change version 2.0 to 1.0</p></td>
<td><p>Verify no errors appear in the error log</p></td>
</tr>
<tr class="even">
<td><p>341811</p></td>
<td><p>Generate Entities from Tables receive syntax error on attributes</p></td>
<td><p>Create JPA project with connection to Oracle DB</p></td>
<td><p>Project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on project select JPA Tools &gt; Generate Entites from Tables..</p></td>
<td><p>Generate Custom Entities dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Generate entities for Address, Employee and Phone</p></td>
<td><p>Verify entities are created and no syntax error appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Repeat for DB2 database connection</p></td>
<td><p>Verify entities are created and no syntax error appears</p></td>
</tr>
<tr class="even">
<td><p>342987</p></td>
<td><p>User Library is not checked to ensure Schema Compiler present</p></td>
<td><p>Select File&gt;New</p></td>
<td><p>New dialog appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select JAXB &gt; JAXB Project, click on Next, Enter a Name, click on Next twice</p></td>
<td><p>JAXB Facet page appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select Generic JAXB for the Platform, Select a User Library that does not contain the following jar files - com.sun.tools.xjc_*.jar, com.sun.xml.bind_*.jar</p></td>
<td><p>Verify no error message appears and you can Finish the project without error</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Go back to the JAXB Facet page and select EclipseLink JAXB for the Platform, Select a User Library that does not contain the following jar files - com.sun.tools.xjc_*.jar, com.sun.xml.bind_*.jar</p></td>
<td><p>Verify error message appears stating - Class generation may not be available if com.sun.tools.xjc and com.sun.xml.bing jars are not on project classpath. Verify Finish is still enabled to complete the project successfully.</p></td>
</tr>
<tr class="even">
<td><p>345312</p></td>
<td><p>Missing appropriate "Undo..." menu item name/label</p></td>
<td><p>Create JPA project and add some entities</p></td>
<td><p>Project and entities are created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on project and select JPA Tools &gt; Open Diagram</p></td>
<td><p>diagram editor opens and appears blank</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on the editor and select "Show all entities"</p></td>
<td><p>Verify the created entities appear</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on editor and notice the undo menu item</p></td>
<td><p>Verify it says "Undo Show All Entities"</p></td>
</tr>
<tr class="even">
<td><p>345323</p></td>
<td><p>Delete confirmation doesn't provide complete information</p></td>
<td><p>Create JPA project and add some entities</p></td>
<td><p>Project and entities are created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on project and select JPA Tools &gt; Open Diagram</p></td>
<td><p>diagram editor opens and appears blank</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on the editor and select "Show all entities"</p></td>
<td><p>Verify the created entities appear</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select an entity and click on delete</p></td>
<td><p>Verify Confirm Delete dialog appears with the following message - Do you want to remove the entity "xxx" from the diagram and delete the corresonding Java resouce "packagename.xxx"?</p></td>
</tr>
<tr class="even">
<td><p>345467</p></td>
<td><p>JAXB Schemas Properties Page: OK with nothing entered in Add Schema dialog results in blank entry</p></td>
<td><p>Create a JAXB project</p></td>
<td><p>JAXB Project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Right-click a JAXB project and select Properties</p></td>
<td><p>Properties dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Expand JAXB, Select Schemas</p></td>
<td><p>Schemas page appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Click on the Add button</p></td>
<td><p>Verify the Add Schema Location dialog appears and the OK button is not enabled</p></td>
</tr>
<tr class="even">
<td><p>345486</p></td>
<td><p>JAXB Schemas Properties Page: Exception when editing a specified schema w/o target namespace</p></td>
<td><p>Create a JAXB project</p></td>
<td><p>JAXB Project is created successfully</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Right-click a JAXB project and select Properties</p></td>
<td><p>Properties dialog appears</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Expand JAXB, Select Schemas</p></td>
<td><p>Schemas page appears</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>On the Schemas page, click Add button to open Add a new schema location page and Select a schema without target namespace and click OK button.</p></td>
<td><p>Namespace shows <no namespace></p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>On the Schema page, select the added schema and click Edit button</p></td>
<td><p>Verify Edit Schema Location dialog appears and no errors appear</p></td>
</tr>
<tr class="odd">
<td><p>345725</p></td>
<td><p>No delete relation confirmation</p></td>
<td><p>Create JPA project and add some entities with relations</p></td>
<td><p>Project and entities are created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on project and select JPA Tools &gt; Open Diagram</p></td>
<td><p>Diagram editor opens and appears blank</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-click on the editor and select "Show all entities"</p></td>
<td><p>Verify the created entities appear</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Select an entity relationship, R-click and select delete</p></td>
<td><p>Verify Confirm Delete dialog appears with the following message - Do you want to remove this relation from the diagram and update the corresonding Java resouces?</p></td>
</tr>
<tr class="odd">
<td><p>346307</p></td>
<td><p>Invalid JAXB packages shown in project explorer when member classes are annotated</p></td>
<td><p>Create a new JAXB project</p></td>
<td><p>JAXB project is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Create a new class named Parent within a package named test</p></td>
<td><p>Class is created</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Edit the class in the editor with the following and save - package test;</p>
<p>import javax.xml.bind.annotation.XmlType; @XmlType public class Parent {</p>
<p><code>   @XmlType</code><br />
<code>   public static class Child {</code></p>
<p><code>   }</code></p>
<p>}</p></td>
<td><p>Verify the class is updated</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>Go to project explorer and expand JAXB Content folder</p></td>
<td><p>Verify JAXB Content\test\Parent and JAXB Content\test\Parent.Child appear only</p></td>
</tr>
<tr class="odd">
<td><p>346728</p></td>
<td><p>NPE during creation of new diagram</p></td>
<td><p>Create a New JPA 1.0, Generic 1.0 project, Expand the created project</p></td>
<td><p>Verify project is created successfully</p></td>
</tr>
<tr class="even">
<td><p>...</p></td>
<td><p>...</p></td>
<td><p>R-Click on the project and select JPA Tools &gt; Open Diagram</p></td>
<td><p>Verify diagrams\diagram.xml appears in Project explorer under the project and diagram opens in the editor without error</p></td>
</tr>
<tr class="odd">
<td><p>...</p></td>
<td><p>...</p></td>
<td></td>
<td></td>
</tr>
</tbody>
</table>