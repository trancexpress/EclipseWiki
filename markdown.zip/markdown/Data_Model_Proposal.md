A summary of the data model being proposed (needs updating to replace
Properties with metadata):

1.  A Context is a container of DigitalSubject objects
2.  A Context has a set of associations to other Contexts. These
    associations are called ContextRelationships.
3.  A ContextRelationship is a kind of Relationship
4.  A Relationship encapsulates properties of a relationship between
    identities, contexts, etc.
5.  A DigitalSubject has a set of Attributes (roughly equivalent to what
    are today called Properties in 0.2)
6.  A DigitalSubject has a set of one or more Identifiers exactly one of
    which is a CUID (Contextually Unique IDentifier).
7.  An Identifier is a kind of Attribute
8.  The value of an Attribute can be a simple literal or a compound
    object.
9.  Attributes may have Metadata
10. Metadata information about an Attribute or a Relationship.
11. A special kind of Metadata is a "Source" for the Attribute data. A
    Source holds an SubjectRelationship (may or may not be resolveable)
    that references the DigitalSubject that is the source of the value
    of this Attribute
12. An SubjectRelationship is an association between two DigitalSubjects
    in the same or different Contexts. An SubjectRelationship is a kind
    of Relationship
13. SubjectRelationships may have Metadata

Also discussed:

1.  Attributes (and Properties??) use URIs to indicate their type