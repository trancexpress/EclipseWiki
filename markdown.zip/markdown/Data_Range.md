{{\#eclipseproject:technology.higgins}}
![Higgins_logo_76Wx100H.jpg](Higgins_logo_76Wx100H.jpg
"Higgins_logo_76Wx100H.jpg")

## Version

This pages describes the concept of [Data Range](Data_Range "wikilink")
used in [Context Data Model 1.1](Context_Data_Model_1.1 "wikilink").

## Definition

  - A [Data Range](Data_Range "wikilink") defines the range of values of
    an [Attribute](Attribute "wikilink")
  - A [Data Range](Data_Range "wikilink") MUST have a base XML Schema
    type (e.g. String)
  - A [Data Range](Data_Range "wikilink") MAY include a set of
    constraining "facets" on its value(s). The names and semantics of
    these facets are taken from the [Constraining
    Facets](http://www.w3.org/TR/xmlschema-2/#rf-facets) section of XML
    Schema Part 2. They include:
      - Enumeration (e.g., must be one of {"red", "green", "blue"})
      - Pattern (e.g. regular expression)
      - Bounding (e.g. less than 5, more than 100)

See the [Constraining
Facets](http://www.w3.org/TR/xmlschema-2/#rf-facets) section of XML
Schema Part 2 for detailed specifications and examples.

## Examples

  - An [Attribute](Attribute "wikilink") might have a value whose [Data
    Range](Data_Range "wikilink") was defined in the schema of its
    [Context](Context "wikilink") as "telephone number". This telephone
    number [Data Range](Data_Range "wikilink") might have a base type of
    [string](http://www.w3.org/TR/xmlschema-2/#string) as defined by XML
    Schema Part 2, but for use in auto-dialing, it might also have a
    [pattern](http://www.w3.org/TR/xmlschema-2/#rf-pattern) facet that
    constrains the syntax to be valid phone number in North American
    (e.g. it is of the form (NNN)-NNN-NNNN).

[Category:Context Data Model
1.1](Category:Context_Data_Model_1.1 "wikilink")