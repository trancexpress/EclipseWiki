{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}
![Higgins_logo_76Wx100H.jpg](Higgins_logo_76Wx100H.jpg
"Higgins_logo_76Wx100H.jpg")

## Prerequisites

This guide assumes you have the following software:

  - Apache Tomcat 5.5 or later (or other servlet container)
  - "rpps-axis.war" file must be made before deploying (i.e. RPPS-web
    project must be built. For information on how to build the web
    applications, look here: [Building the Higgins I-Card
    Service](Building_the_Higgins_I-Card_Service "wikilink")).

### Deploying the Service

  - MySQL-database must be installed. Create a user which will be used
    for accessing to database ( e.g “higgins_rpps”). It is necessary to
    create two mysql-schema. The first schema will be created for
    working with icard-providers. The second schema will be created for
    working with UserProfile. Assign all operation privileges for these
    schemata to “higgins_rpps” user

<!-- end list -->

  - Driver MySQL must be placed in the "lib" folder, in the directory
    where Tomcat was installed. Drivers can be downloaded
    [here](http://dev.mysql.com/downloads/connector/j/5.1.html).

<!-- end list -->

  - Project directory **\*\\org.eclipse.higgins.rpps.web** contains the
    folder *“conf”*. It includes zip-archive files and folders which are
    needed for running RPPS-web in Tomcat. Extract all files and
    folders.

<!-- end list -->

  - Contents of the extracted directory must be placed in a home
    directory of the current user.

<!-- end list -->

  -
    {|style="background:transparent"

|-valign=top |Folder *“.higgins”* contains three folders: *“.icard”,
“.ontology”, “.iss”*. |-valign=top | In a folder *“.icard”* there are
files of a configuration for icard-providers:
*“org.eclipse.higgins.icard.provider.cardspace.managed.db”* and
*“org.eclipse.higgins.icard.provider.cardspace.personal.db.ini”*. They
have equal structure. It is necessary to change three parameters: |}

<parameter name="db.username" value="'''username for login to databse'''"/>
<parameter name="db.password" value="'''password for login to databse'''"/>
<parameter name="db.url" value="jdbc:mysql://'''hostname for MySQL server/First_Schema_name'''?autoReconnect=true"/>

  -
    {|style="background:transparent"

|-valign=top |In
“org.eclipse.higgins.icard.provider.cardspace.personal.db.ini” you
need to change the “defaultImage.file” parameter. It contains absolute
path to default card image file. |}

<parameter name="defaultImage.file" value="'''/usr/share/higgins/ConfigurationFile/higgins.jpg'''"/>

  -
    {|style="background:transparent"

|-valign=top |Path *“/usr/share/higgins”* is the path to our user home
folder. |-valign=top |For filling schema-tables in database you must
execute SQL script **mysql.sql**. It be found in folder
*"\*\\org.eclipse.higgins.icard.provider.cardspace.db.mysql\\sql"*
|-valign=top |In
“org.eclipse.higgins.icard.registry.userProfileService.ini” file you
need to change “idasContext.id” and “idasDiscovery.filename” parameters.
They contain the absolute path to “userProfileContext.xrds” and
“contextfactories.xrds” accordingly. |-valign=top |For example: |}

<parameter name="idasContext.id" value="/usr/share/higgins/.higgins/.icard/xrds/userProfileContext.xrds"/>
<parameter name="idasDiscovery.filename" value="/usr/share/higgins/.higgins/.icard/xrds/contextfactories.xrds"/>

  -
    {|style="background:transparent"

|-valign=top |In *“userProfileContext.xrds”* you need to change
parameter *“schema.file”* if userProfile.owl is placed in another
folder. This parameter contains a path to *“userProfile.owl”*. You can
use *“@user.home”* constant instead of path to user home folder. |}

<Setting Name="schema.file" Type="xsd:string">`@user.home/.higgins/.ontology/userProfile.owl`</Setting>

  -
    {|style="background:transparent"

|-valign=top |In a subfolder *“xrds”*, in the file
userProfileContext.xrds three fields should be changed: |}

<Setting Name="db.password" Type="xsd:string">**`username``   ``for``
 ``login``   ``to``   ``databse`**</Setting>
<Setting Name="db.user" Type="xsd:string">**`password``   ``for``
 ``login``   ``to``   ``databse`**</Setting>
<Setting Name="db.url" Type="xsd:string">`jdbc:mysql://`**`hostname``
 ``for``   ``MySQL``
 ``server/Second_Schema_name?autoReconnect=true`**</Setting>

  -
    {|style="background:transparent"

|-valign=top |The necessary tables for second schema will be created
automatically. |-valign=top |Folder *“.iss”* contains configuration
files for Icard selector service (iss). Folder *“ConfigurationFile”*
contains two configuration files for Security Token Service (sts):
*“ClientConfiguration.xml”* and *“PersonalConfiguration.xml”*.
|-valign=top

  - For the final step, copy **rpps-axis.war** from the folder
    **\*\\org.eclipse.higgins.rpps.web\\build\\war** into *Tomcat folder
    "/webapps"* and restart Tomcat for deploy Web Application.

|}