  - **[Buckminster Architecture](Buckminster_Architecture "wikilink")**
    - provides an overview of the architectural details of Buckminster.
      - This can be short document.
      - It is intended as an entry point for anyone wanting to know more
        about "How Buckminster does things" rather than "what it does".
        Extension point implementers should find this useful.
  - **[Buckminster UI Guide](Buckminster_UI_Guide "wikilink")** - usage
    guidance for the existing Buckminster IDE extensions
  - **[Buckminster Component
    Readers](Buckminster_Component_Readers "wikilink")** - a summary of
    all implement component readers, the reader extension point and
    requirements of existing readers with regard to third-party
    components, version converter assumptions, etc.
  - **[Buckminster Extension
    Points](Buckminster_Extension_Points "wikilink")** - an overview of
    all Buckminster extension points with examples.
  - API documentation
      - **[Buckminster API](Buckminster_API "wikilink")** - can be a
        pointer to Javadocs.