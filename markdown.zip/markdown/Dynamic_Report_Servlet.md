## Dynamic Report Servlet

Moved to the new examples area. [Java - Dynamic Report Servlet
(BIRT)](Java_-_Dynamic_Report_Servlet_\(BIRT\) "wikilink")

[Category:BIRT](Category:BIRT "wikilink") [Category:BIRT Example
OLD](Category:BIRT_Example_OLD "wikilink")