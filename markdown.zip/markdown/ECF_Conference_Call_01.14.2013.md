## Agenda for 1.4.2014 Hangout

### Zookeeper Discovery Provider

  - Technical Q\&A with Wim
  - Discussion of plans for 3.8.0 release and beyond

### ECF 3.8.0 Release Planning

  - Content: Bugs, Enhancements, Additions...e.g.
    [409787](https://bugs.eclipse.org/bugs/show_bug.cgi?id=409787)
  - Timing and Releng questions (e.g. minor release review materials
    prep)
  - Relationship to OSGi R6 work...bugs
    [424304](https://bugs.eclipse.org/bugs/show_bug.cgi?id=424304),
    [422752](https://bugs.eclipse.org/bugs/show_bug.cgi?id=422752),
    [423708](https://bugs.eclipse.org/bugs/show_bug.cgi?id=423708),
    [424059](https://bugs.eclipse.org/bugs/show_bug.cgi?id=424059)