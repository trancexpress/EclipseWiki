## Attendees

## Agenda

  - ECF access to OSGi TCK status
  - ECF impl of Remote Service Admin (RSA) status...see
    [bug 324215](https://bugs.eclipse.org/bugs/show_bug.cgi?id=324215)
  - ECF documentation project status

(please add items here prior to the call)