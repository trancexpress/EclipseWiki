Code contribution to Eclipse

  - Java runtime - whatever state it's in at the start of the iteration
  - IDE - all of the code we've developed. Alice is doing some cleanup
    first
  - Justin to run code scan, Lisa to analyze
  - Run copyright tool first, and also remove Author tags
  - CQ - needs to be done by a committer. We can do a single CQ for both
    Javagen and IDE

Roll I3 tasks out to I5:

  - Separate build that is SDK only- move out I5 (done)
  - Create EGL project
  - Justin's current I4 stuff

**Alice**

  - Extensibility of the editor - actions that are commented out that we
    aren't inheriting form Eclipse now - we need to investigate what
    these are, identify the work. Also additional editor function that
    we just haven't carried over from RBD. Alice to create stories /
    tasks, and assign to EDT 1.0 backlog (EDT 1.0 Plan) or iteration 4
  - Editor - model APIs - this is also a priority now - for Alice to
    populate in RTC
  - Editor preferences, using eclipse preferences - ditto

**Paul**

  - Design & create of a utility to create IRs from source code. Also
    implementing anything that is blocking Jeff from generation. Also
    continue on front end of core. Define stories & tasks for iteration
    4 in RTC

**Joe**

  - handling of any type in services - design a lean implementation that
    could then be taken back to RBD. Also SOAP 1.2 - overall SOAP
    services design. Define Stories & tasks for iteration 4

**Justin**

  - hook the SMAP stuff up to the debugger. This will allow Jeff to
    start running his code, to identify problems - so sooner is better
    in the iteration.

**Jeff**

  - SMAP debugger stuff - we want to get this hooked up to debugger so
    that it can be exercised, but that will require Justin's time - this
    should be Justin's focus. Also work on Language elements that don't
    require runtime. Work with Paul to resolve anything that you need
    from the IRs

**Scott**

  - define stories, identify work for I4. Also javascript generation