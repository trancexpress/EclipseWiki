## Schedule for EDT 0.8.2

0.8.2 will be the next incubator release for EDT. In this release we
plan to deliver significant updates to the extensible core of EDT. The
proposed release date is the beginning of January, 2013. Due to the
significant amount of work involved in this release, we will be
extending our milestones by 1 week, from 3 weeks to 4 weeks, and we will
be scheduling a total of 4 milestones.

  - Milestone 1
      - Development (Jul 30 - Aug 17)
      - Function Test (Aug 20 - Aug 24)
  - Milestone 2
      - Development (Aug 27 - Sep 21)
      - Function Test (Sep 24 - Sep 28)
  - Milestone 3
      - Development (Oct 1 - Oct 26)
      - Function Test (Oct 29 - Nov 2)
  - Milestone 4
      - Development (Nov 5 - Nov 30)
      - Function Test (Dec 3 - Dec 7)
  - System Test (Dec 10 - Dec 28)
  - Release Candidate (Jan 11)
  - 0.8.2 Release (Jan 18)



## Proposed Content for EDT 0.8.2

### Extensibility

  - Complete the implementation of the EDT extensible compiler
  - Complete the implementation of the EDT Java core generator
  - Complete the implementation of the EDT JavaScript core generator

### Language

  - EGL Language Specification (draft)
  - Implement all remaining core EGL Language elements that were not
    supported in 0.8.1

[Planning notes](EDT:Planning_notes "wikilink")

[Category:EDT](Category:EDT "wikilink")