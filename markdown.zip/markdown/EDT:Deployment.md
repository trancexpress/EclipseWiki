Please see the parent of this page, [EDT:Components and
Functionality](EDT:Components_and_Functionality "wikilink")

## General

In general Deployment will function as it does in RBD.


<table>
<tbody>
<tr class="odd">
<td><p><strong>functionality<br />
</strong></p></td>
<td><p><strong>JavaScript</strong><br />
</p></td>
<td><p><strong>Java</strong><br />
</p></td>
</tr>
<tr class="even">
<td><p>Generate JAXWS wrapper<br />
</p></td>
<td><p>NA<br />
</p></td>
<td><p>(15d)<br />
</p></td>
</tr>
<tr class="odd">
<td><p>Generate EGL REST RPC config file<br />
</p></td>
<td><p>NA<br />
</p></td>
<td><p>(2d)<br />
</p></td>
</tr>
<tr class="even">
<td><p>Migrate REST RPC servlet from RBD<br />
</p></td>
<td><p>NA<br />
</p></td>
<td><p>(1d)<br />
</p></td>
</tr>
<tr class="odd">
<td><p>Copy files<br />
</p></td>
<td><p>(0.5d)<br />
</p></td>
<td><p>(0.5d)<br />
</p></td>
</tr>
<tr class="even">
<td><p>Generate bind files</p></td>
<td><p>(1d)<br />
</p></td>
<td><p>NA</p></td>
</tr>
<tr class="odd">
<td><p>Generate HTML</p></td>
<td><p>(10d)</p></td>
<td><p>NA</p></td>
</tr>
<tr class="even">
<td><p>Copy jar files<br />
</p></td>
<td><p>(0.5d)</p></td>
<td><p>(0.5d)<br />
</p></td>
</tr>
<tr class="odd">
<td><p>configure web.xml</p></td>
<td><p>(0.5d)<br />
</p></td>
<td><p>Add environment entries (3d)</p>
<p>Add REST RPC servlet to web.xml (0.5d)</p></td>
</tr>
</tbody>
</table>