## General Notes

  - Text <span style="background:#FFA500">with an orange
    background</span> shows differences in features supported by both
    EDT and RBD.
  - **Developers:** include a link to Bugzilla for features not done
    yet, and mark items "Complete" when you're finished.

## IDE divided by sub components

  - [EDT:IDE Core](EDT:IDE_Core "wikilink")  *includes functions for
    Core EDT. e.g. EGL Editor, Project Wizard, Functions to provide
    extensibility*
  - [EDT:IDE EGLar](EDT:IDE_EGLar "wikilink") *is also considered part
    of Core EDT*
  - [EDT:IDE RUI](EDT:IDE_RUI "wikilink")
  - [EDT:IDE Service](EDT:IDE_Service "wikilink")
  - [EDT:IDE Deployment](EDT:IDE_Deployment "wikilink")
  - [EDT:IDE Test Server](EDT:IDE_Test_Server "wikilink")
  - [EDT:Debug](EDT:Debug "wikilink")

[Category:EDT](Category:EDT "wikilink")