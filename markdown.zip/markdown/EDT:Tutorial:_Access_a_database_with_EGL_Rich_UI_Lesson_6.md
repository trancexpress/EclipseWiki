Please go to [EDT:Tutorial: RUI With DataBase Lesson
6](EDT:Tutorial:_RUI_With_DataBase_Lesson_6 "wikilink")