# 日本語の不具合を報告してください

  - 不具合を報告することも貢献になります。なお、Babelの翻訳者メーリングリストの[アーカイブ](http://dev.eclipse.org/mhonarc/lists/babel-translators/maillist.html)を見るだけならユーザ登録は不要です。

<!-- end list -->

  - Babel翻訳者メーリングリストは世界中の人が使っています。日本語での報告は、他言語のユーザには文字化けに見えるので、**Subject
    に "\[ja\]" を書いておいてください。**これで識別します。

## babel-translators にユーザ登録する (Subscribing to babel-translators)

  - あなたの貢献は全て eclipse.org の [Terms Of
    Use](http://www.eclipse.org/legal/termsofuse.php)
    に従います。ぜひ事前に目を通してください。

<!-- end list -->

  - Eclipse Foundation の Web へのあなたのアクセスや、あなたが自身について提供した情報は、[Privacy
    Policy](http://www.eclipse.org/legal/privacy.php) に従います。

<!-- end list -->

  - Your email address: と Pick a password: を入力してください。Your name
    はオプションで、必須ではありません。毎日ダイジェストをメールで受け取りなら、Would you
    like to receive list mail batched in a daily digest? を Yes とします。

<!-- end list -->

  - ユーザ登録すると、確認を求めるメールが届きます。これは、他人があなたに成りすましてユーザ登録するのを防ぐためです。スパム・メール・フィルタを使用している人はご注意ください。確認メールを受信し、リアクションしないと、ユーザ登録は完了しません。完了するまでフィルタをオフにするなどしてください。なお、本メンバのリストは、リストの管理者以外には公開していません。

<!-- end list -->

  - あなたの登録を他人が妨害するのを防ぐため、パスワードを設定しています。ただし、あなたの非常に重要なパスワードを使うのは避けてください。そのパスワードをメール本文に含めて返信することがあります。

<!-- end list -->

  - もしパスワードを入力しなかったら、自動的に生成して確認メールで送信します。登録の確認に使用してください。

<!-- end list -->

  - あなたがパーソナル・オプションを編集したときには、いつでもパスワード返信をリクエストできます。

<!-- end list -->

  - babel-translators
    のアカウントを解除するには、パスワードを入力してください。もしくは、オプション変更には、登録時のメール・アドレスを入力してください。

　　　それでは、実際にログインしてみましょう。[こちらへ](https://dev.eclipse.org/mailman/listinfo/babel-translators)

## babel-translators にメッセージを送る (Using babel-translators)

  - Babel
    翻訳者全員にメッセージを送るには、[こちら](mailto:babel-translators@eclipse.org)へメールしてください。

<!-- end list -->

  - ただし、Babel
    翻訳者は世界中にいて、日本語が通じるのは極一部であることに注意してください。不用意に日本語メールを流すと、世界中から顰蹙を買いかねません。