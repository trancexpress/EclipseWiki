This wiki is intended to share information for EMFStore and ECP
developers. We use the wiki to make it easy for you to update the
information.

Guidelines:

  - [Plugin/Feature Configuration
    Guidelines](Plugin/Feature_Configuration_Guidelines "wikilink")
  - [Extension Point Guidelines](Extension_Point_Guidelines "wikilink")
  - Exception Handling Guidelines (tbd)