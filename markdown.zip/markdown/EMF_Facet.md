## **The project is now suspended and archived.**

Because of limited resources, the project exited from the release train
in 2019-03, and then was archived in May 2020. Last EMF Facet release
number is 1.3.0.201805181509. Archived resources can be found at
<https://www.eclipse.org/projects/archives.php>

# Overview

Cf. **[EMF Facet Home
page](http://www.eclipse.org/modeling/emft/facet/)**

# Install

## Using Eclipse Release Update Site **(Recommended)**

To install the latest EMF Facet release, just point your [Install
Manager](http://help.eclipse.org/indigo/index.jsp?topic=/org.eclipse.platform.doc.user/tasks/tasks-129.htm)
to the pre-defined Eclipse simultaneous release update site:
<http://download.eclipse.org/releases/__release_name__>. For instance:

  - in an Indigo (3.7) installation the update site will be :
    <http://download.eclipse.org/releases/indigo/>
  - in an Juno (4.2) installation the update site will be :
    <http://download.eclipse.org/releases/juno/>
  - in an Kepler (4.3) installation the update site will be :
    <http://download.eclipse.org/releases/kepler/>
  - in an Luna (4.4) installation the update site will be :
    <http://download.eclipse.org/releases/luna/>
  - in an Mars (4.5) installation the update site will be :
    <span style="font-size:large; padding: 0 5px 0 5px; background-color:#ffbf00; border-color:green"><http://download.eclipse.org/releases/mars/></span>

Then, you can select the "**EMF Facet SDK (Incubation)**" feature under
the "**Modeling**" category.

### Update site locations

  - Update sites:
      - **releases** :
        <http://download.eclipse.org/facet/updates/release/>
  - Alternative update sites:
      - **milestones** 1.0.x:
        <http://download.eclipse.org/facet/updates/milestones/1.0>
  - Dependences:
      - SWTBot:
        <http://download.eclipse.org/technology/swtbot/helios/dev-build/update-site>

### Update site uses

The **releases** update site :

  - contains the release (GA) and the service releases (SR1, SR2, etc.)
  - should be used by all regular users

The **milestones** update sites:

  - contain the milestones and release candidates: M1, M2, M3, M4, M5,
    M6, M7, RC1, RC2, RC3, RC4 (=GA), SR1 RC1, SR1 RC2, SR1 RC3, SR1 RC4
    (=SR1), SR2 RC1, SR2 RC2, SR2 RC3, SR2 RC4 (=SR2)

The **integration** update sites:

  - contain the integration build
  - are referenced by
    [emft-emffacet.b3aggrcon](http://git.eclipse.org/c/simrel/org.eclipse.simrel.build.git/tree/emft-emffacet.b3aggrcon).
      - the version declared in
        [emft-emffacet.b3aggrcon](http://git.eclipse.org/c/simrel/org.eclipse.simrel.build.git/tree/emft-emffacet.b3aggrcon)
        must be used by the builds of other Eclipse projects engaged in
        the release train.

## Using an archived update Site **(Not Recommended)**

You can download the archive of the EMF Facet updates sites from the
[EMF Facet download
page](http://www.eclipse.org/modeling/emft/facet/downloads/) but **you
will have to resolve the dependencies and find the corresponding
archived update sites manually**. The EMF Facet team does not provide
the list of the archived update sites needed to satisfy the
dependencies, because it is too complicated to maintain. That's why
**this kind of installation is not recommended**.

# Documentation

## User documentation

  - [0.4.0 documentation](http://help.eclipse.org/luna/nav/17)

## Screencasts & Slides

  - [EMF
    Facet 0.1.0](http://www.slideshare.net/GregoireDupe/emf-facet-nantesdemocamp),
    [Eclipse DemoCamp Indigo in
    Nantes](Eclipse_DemoCamps_Indigo_2011/Nantes "wikilink"), 2011
  - (frensh) [MDT : Papyrus : état actuel et
    perspectives](http://neptune.irit.fr/images/files/Neptune2011/Transparents/s13_vlorenzo.pdf):
    Les journées NEPTUNE, May 2011.
      - A presentation of Papyrus and of the use of the EMF Facet table
        by Papyrus.
  - [EMF Facet - A Non-Intrusive Tooling to Extend
    Metamodels](http://www.slideshare.net/fmadiot/emf-facet-eclipsecon-2011-audition-6175334),
    EMF Facet EclipseCon 2011 Audition, December, 2010.
  - [EMF Facet - A Non-Intrusive Tooling to Extend
    Metamodels](http://www.slideshare.net/fmadiot/emf-facet-ese2010):
    Eclipse Summit Europe 2010, November, 2010.

## Examples

The EMF Facet SDK contains example plug-ins. To use or inspect this
plug-in :

  - Open the wizard File \> Import
  - Select "Plug-ins and Fragement" and press "Next"
  - Select :
      - "The active target platform"
      - "Select from all plug-ins and fragments found at the specified
        location"
      - Project with source folder
  - Press "Next"
  - Type "emf.facet.\*example" in the "Filter Available Plug-ins ans
    Fragments" fields
  - Press "Add All -\>"
  - Press "Finish"

Example plug-in are now available in your workspace.

## Project documents

  - [IP
    log](http://www.eclipse.org/projects/ip_log.php?projectid=modeling.emft.emf-facet)
  - [Project
    plans](https://projects.eclipse.org/projects/modeling.emft.emf-facet)
  - [Project metrics](http://download.eclipse.org/facet/metrics.html)
  - [API
    Policy](http://git.eclipse.org/c/facet/org.eclipse.emf.facet.main.git/tree/org.eclipse.emf.facet.doc/mediawiki/API_Policy.mediawiki)
  - [EMFFacet UI issues](EMFFacet_UI_issues "wikilink")
  - [EMFFacet Accessibility
    issues](EMFFacet_Accessibility_issues "wikilink")

### Release Train Required Documents

  - [Indigo (EMF Facet 0.1)](EMF_Facet/Indigo "wikilink")
  - [Juno (EMF Facet 0.2)](EMF_Facet/Juno "wikilink")
  - [Kepler (EMF Facet 0.3)](EMF_Facet/Kepler "wikilink")
  - [Luna (EMF Facet 0.4)](EMF_Facet/Luna "wikilink")
  - [Mars (EMF Facet 1.0)](EMF_Facet/Mars "wikilink")

### Project Creation Documents

  - [EMF Facet Project
    Proposal](http://www.eclipse.org/proposals/emf-facet/)
  - [Creation review
    docuware](https://bugs.eclipse.org/bugs/attachment.cgi?id=176904)
  - [Project
    Provisioning](https://bugs.eclipse.org/bugs/show_bug.cgi?id=322170)

# Support

  - [EMFT
    Forum](http://www.eclipse.org/forums/index.php?t=thread&frm_id=19&S=afdd0d7947722ed22234f5cbd7a69131)
  - [Report a
    bug](https://bugs.eclipse.org/bugs/enter_bug.cgi?product=EMFT.facet)
  - [Opened
    bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced;bug_status=UNCONFIRMED;bug_status=NEW;bug_status=ASSIGNED;bug_status=REOPENED;bug_status=VERIFIED;component=Main;component=Web;product=EMFT.facet;classification=Modeling)

# Getting Involved

## Rule and process

  - EMF Facet uses the [MoDisco Developer
    Guide](MoDisco/DeveloperGuide "wikilink").
  - EMF Facet contributers and commiter must follow the EMF Facet [Bug
    process](EMF_Facet/Bug_Process "wikilink").
  - Developer mailing list : facet-dev@eclipse.org ([registration
    page](https://dev.eclipse.org/mailman/listinfo/facet-dev),
    [archives](https://dev.eclipse.org/mhonarc/lists/facet-dev/))

## Source repository

  - Git web browser:
    <http://git.eclipse.org/c/facet/org.eclipse.emf.facet.main.git/>
  - Gerrit :
      - <https://git.eclipse.org/r/#/admin/projects/facet/org.eclipse.emf.facet.main>
      - <ssh://committer_id@git.eclipse.org:29418/facet/org.eclipse.emf.facet.main>
      - cf.
        [Bug 467506](https://bugs.eclipse.org/bugs/show_bug.cgi?id=467506)
  - Git repository:
    <git://git.eclipse.org/gitroot/facet/org.eclipse.emf.facet.main.git>
  - SVN:
    <http://dev.eclipse.org/svnroot/modeling/org.eclipse.emft.facet>
    (Read only)

## Build

  - HIPP: <https://hudson.eclipse.org/emf-facet/>
  - Hudson Master Job:
    <https://hudson.eclipse.org/hudson/job/emffacet-nightly/>
  - Hudson Maintenance Job:
    <https://hudson.eclipse.org/hudson/job/emffacet-nightly-maintenance/>

## Technical Architecture rules

### coding rules

Please, before to contribute a patch be sure to conforms with:

  - the PMD rule set :
    <http://git.eclipse.org/c/facet/org.eclipse.emf.facet.main.git/tree/org.eclipse.emf.facet.archi.tech.rules/pmd/ruleset.xml>
  - the checkstyle rule set :
    <http://git.eclipse.org/c/facet/org.eclipse.emf.facet.main.git/tree/org.eclipse.emf.facet.archi.tech.rules/checkstyle/EmfFacet.checkstyle>
  - all the JDT warnings.

### naming rules

  - \*.metamodel contains the EMF implementation.
  - \*.core contains classes which are not depended to any framework
    interacting with the GUI.
  - \*.ui contains classes which are depended to any framework
    interacting with the GUI.

## Bug tracking

  - [Error reporting
    application](https://dev.eclipse.org/recommenders/committers/confess/#/projects/5547ade3e4b02db8ca2ffb48)

### Bugzilla Queries

#### Tracking

  - [Non enhancement opened bugs sort by
    importance](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced;order=Importance;bug_severity=blocker;bug_severity=critical;bug_severity=major;bug_severity=normal;bug_severity=minor;bug_severity=trivial;bug_status=UNCONFIRMED;bug_status=NEW;bug_status=ASSIGNED;bug_status=REOPENED;bug_status=VERIFIED;product=EMFT.facet)
    (P1=planed for the next milestone, P2=planed for the next release,
    P3=not planned yet, P4=planed for the next "non service" release,
    P5=delayed)
  - [Enhancement opened bugs sort by
    importance](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced;bug_severity=enhancement;bug_status=UNCONFIRMED;bug_status=NEW;bug_status=ASSIGNED;bug_status=REOPENED;bug_status=VERIFIED;product=EMFT.facet)
    (P1=planed for the next milestone, P2=planed for the next release,
    P3=not planned yet, P4=planed for the next "non service" release,
    P5=delayed).
  - [Unit Test
    Failures](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced;short_desc=%5BUnit%20Test%20Failure%5D;bug_severity=blocker;bug_severity=critical;bug_severity=major;bug_severity=normal;bug_severity=minor;bug_severity=trivial;bug_severity=enhancement;bug_status=UNCONFIRMED;bug_status=NEW;bug_status=ASSIGNED;bug_status=REOPENED;bug_status=RESOLVED;bug_status=VERIFIED;bug_status=CLOSED;short_desc_type=allwordssubstr;product=EMFT.facet)
  - [Deprecated](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced;short_desc=%5BDeprecated%5D;bug_severity=blocker;bug_severity=critical;bug_severity=major;bug_severity=normal;bug_severity=minor;bug_severity=trivial;bug_severity=enhancement;bug_status=UNCONFIRMED;bug_status=NEW;bug_status=ASSIGNED;bug_status=REOPENED;bug_status=RESOLVED;bug_status=VERIFIED;bug_status=CLOSED;short_desc_type=allwordssubstr;product=EMFT.facet)

#### Checking

  - [Bugs not flaged indigo+, juno+ or
    kepler+](https://bugs.eclipse.org/bugs/buglist.cgi?bug_status=RESOLVED&bug_status=CLOSED&f0=OP&f1=OP&f10=OP&f11=flagtypes.name&f12=CP&f13=OP&f14=flagtypes.name&f15=CP&f16=CP&f2=flagtypes.name&f3=CP&f4=OP&f5=flagtypes.name&f6=CP&f7=OP&f8=flagtypes.name&f9=CP&j1=OR&j10=OR&j13=OR&j4=OR&j7=OR&o11=notsubstring&o14=notsubstring&o2=notsubstring&o5=notsubstring&o8=notsubstring&product=EMFT.facet&query_format=advanced&resolution=FIXED&v11=luna%2B&v14=mars%2B&v2=indigo%2B&v5=juno%2B&v8=kepler%2B)
    (must be empty)

<!-- end list -->

  - [Fixed but not assigned
    bugs](https://bugs.eclipse.org/bugs/buglist.cgi?list_id=1692264;resolution=FIXED;emailtype1=substring;emailassigned_to1=1;query_format=advanced;bug_status=RESOLVED;bug_status=CLOSED;email1=emft.facet-inbox%40eclipse.org;product=EMFT.facet)
    (must be empty)

<!-- end list -->

  - [Resolved but not closed
    bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced;list_id=1707400;bug_status=RESOLVED;product=EMFT.facet)
    (should be empty)

<!-- end list -->

  - [Attachments not flagged with iplog+ or
    iplog-](https://bugs.eclipse.org/bugs/buglist.cgi?o5=regexp&f1=OP&list_id=5601178&f0=OP&classification=Modeling&o2=notsubstring&f4=OP&v5=.%2B&query_format=advanced&j1=OR&f3=CP&f2=flagtypes.name&j4=OR&f5=attachments.description&f6=CP&component=Main&v2=iplog&f7=CP&product=EMFT.facet)

<!-- end list -->

  - [Not closed bugs having an
    iplog+](https://bugs.eclipse.org/bugs/buglist.cgi?o5=regexp&f1=OP&list_id=5603982&f0=OP&classification=Modeling&o2=substring&f4=OP&v5=.%2B&query_format=advanced&j1=OR&f3=CP&f2=flagtypes.name&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&bug_status=RESOLVED&bug_status=VERIFIED&j4=OR&f5=attachments.description&f6=CP&component=Main&v2=iplog%2B&f7=CP&product=EMFT.facet)

<!-- end list -->

  - [IP Contribution
    Review](http://eclipse.org/projects/tools/ip_contribution_review.php?id=modeling.emft.emf-facet)

<!-- end list -->

  - [Attachments not flagged with iplog+ or iplog- in resoled or closed
    bugs](https://bugs.eclipse.org/bugs/buglist.cgi?o5=regexp&f1=OP&list_id=5667942&f0=OP&classification=Modeling&o2=notsubstring&f4=OP&v5=.%2B&query_format=advanced&j1=OR&f3=CP&f2=flagtypes.name&bug_status=RESOLVED&bug_status=CLOSED&j4=OR&f5=attachments.description&f6=CP&component=Main&v2=iplog&f7=CP&product=EMFT.facet)
    (should be empty)

<!-- end list -->

  - [Fixed without target
    milestone](https://bugs.eclipse.org/bugs/buglist.cgi?list_id=11524146&order=Importance&product=EMFT.facet&query_format=advanced&resolution=FIXED&target_milestone=---)
    (should be empty)

<!-- end list -->

  - [RESOLVED
    FIXED](https://bugs.eclipse.org/bugs/buglist.cgi?bug_status=RESOLVED&product=EMFT.facet&query_format=advanced&resolution=FIXED)
    (Should be empty after each release)

#### Reports

  - [Opened bugs by
    severity](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=version&y_axis_field=bug_severity&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&product=EMFT.facet&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&longdesc_type=allwordssubstr&longdesc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_id=&bug_id_type=anyexact&votes=&votes_type=greaterthaneq&emailtype1=substring&email1=&emailtype2=substring&email2=&emailtype3=substring&email3=&chfieldvalue=&chfieldfrom=&chfieldto=Now&field0-0-0=noop&type0-0-0=noop&value0-0-0=&format=table&action=wrap)
  - [Bug resolution by
    milestones](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=target_milestone&y_axis_field=version&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&product=EMFT.facet&longdesc_type=allwordssubstr&longdesc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_severity=blocker&bug_severity=critical&bug_severity=major&bug_severity=normal&bug_severity=minor&bug_severity=trivial&emailtype1=substring&email1=&emailtype2=substring&email2=&bug_id_type=anyexact&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)
  - [Enhancements by
    milestones](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=target_milestone&y_axis_field=version&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&product=EMFT.facet&longdesc_type=allwordssubstr&longdesc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_severity=enhancement&emailtype1=substring&email1=&emailtype2=substring&email2=&bug_id_type=anyexact&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

#### Others

  - [Closed
    bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced;bug_status=RESOLVED;bug_status=VERIFIED;bug_status=CLOSED;product=EMFT.facet;classification=Modeling)
  - [Non-committer
    attachments](https://bugs.eclipse.org/bugs/buglist.cgi?classification=Modeling&field0-0-0=attachments.submitter&list_id=1712821&product=EMFT.facet&query_format=advanced&type0-0-0=nowordssubstr&value0-0-0=nbros%20fgiquel%20gdupe%20gbarbier%20fmadiot&order=bug_status%2Cpriority%2Cbug_severity&query_based_on=)

## Useful links

  - [The Eclipse Simultaneous
    Release](http://eclipse.org/indigo/planning/EclipseSimultaneousRelease.php)

## Miscellaneous

  - [Web documentation update](EMF_Facet/Web_Documentation "wikilink")
  - Test scenarios
      - [Table UI Test](EMF_Facet/Table/UI_Test "wikilink")
  - [Releng : How to Use](EMF_Facet/Releng/How_to_Use "wikilink")
      - [Release train aggregation
        file](http://dev.eclipse.org/viewcvs/viewvc.cgi/org.eclipse.indigo.build/emft-emffacet.b3aggrcon?view=markup&root=Callisto)