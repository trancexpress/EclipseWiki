See [EMF_Search](EMF_Search "wikilink") for general search overview.
Ecore Search Page have two main query kinds : Textual & OCL

  - Textual queries
      - normal (?, \* available)
      - case sensitive
      - regex (Java regular expression based)

Textual queries are very similar to JDT, PDE or File ones. Query
evaluation is done against meta elemnt names as users can see in Ecore
editors. Thanks to the fact Most Ecore elements are inheriting from
ENamedElement, exposing a usefull getName:String method, it is possible
evaluate regex pattern against them.

  - OCL queries

OCL queries for Ecore are simple OCL invariants evaluations, these
queries are ran against a particular meta element. OCL contextual
edition is allowed according to a meta element user selection. Thus,
users wanting to evaluate invariant expression against an EClass would
have to set the OCL Expression wigdet context set to 'EClass' before
being able to edit the invariant body.

As a result an OCL query expression body can take advantage of syntax
coloring & contextual completion proposal.

#### Ecore Textual Search

Ecore Textual Search Page is composed of two parts : query &
participants.

  - Query : Textual expression edit area with normal, case sentitive &
    regex support
  - Participants : All Ecore meta elements possibly particpating to
    Ecore Textual query

The figure below depict a user textual query against selected
participant meta elements.

Here, the user want find all EClass elements with name matching
"Movie\*" regex.

Note that the search scope can be chosen between Workspace, Selected,
Resource, Working Set.

Note also that query participants can be filtered in order to ease
elements selection user experience.

![EcoreTextualSearchPage.png](EcoreTextualSearchPage.png
"EcoreTextualSearchPage.png")

Ecore Results page collects and display matches for Ecore queries. An
header label summarize the query configuration in terms of expression,
participants and scope.

Matches are display in black, hierarchical intermediary results are
colored in gray and get number of match occurences their sub tree owns.

![EcoreTextualResultPage.png](EcoreTextualResultPage.png
"EcoreTextualResultPage.png")

#### Ecore OCL Search

OCL queries for Ecore are simple OCL invariants evaluations, these
queries are ran against a particular meta element. OCL contextual
edition is allowed according to a meta element user selection.

Thus, users wanting to evaluate invariant expression against an EClass
would have to set the OCL Expression wigdet context set to 'EClass'
before being able to edit the invariant body.

As a result an OCL query expression body can take advantage of syntax
coloring & contextual completion proposal.

Below we can see the completion proposal list obtained by hitting
"Ctrl+Space" from the OCL Expression widget.

![EcoreOCLSearchPage.png](EcoreOCLSearchPage.png
"EcoreOCLSearchPage.png")

Results are collected and displayed accordingly to the resource & OCL
invariant they have been evaluated against.

![EcoreOCLResultPage.png](EcoreOCLResultPage.png
"EcoreOCLResultPage.png")