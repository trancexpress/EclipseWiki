# org.eclipse.emf.search.ui.openDiagramParticipants

User wanting to register a particular diagram editor as participant to
open action must extend this extension point. As result user wanting
selecting open in diagram option for given meta element will have all
registred participant offered as possible selection.

`* `**`id`**` - unique open diagram participant handler ID`
`* `**`openDiagramHandler`**` - open diagram handler which have responsability to handle a diagram editor opening from a given meta element selection`

``` xml
   <extension
         point="org.eclipse.emf.search.ui.openDiagramParticipants">
      <diagramParticipant
            id="http://www.eclipse.org/uml2/2.1.0/UML"
            openDiagramHandler="org.eclipse.uml2.diagram.clazz.search.handlers.OpenUML2ClassDiagramHandler">
      </diagramParticipant>
   </extension>
```