## EPIC Participation Outreach and Value Survey

### Transaction history

  - Meeting July 17, 2006 Eric, Mike Skip generated the first draft of
    this document

### Audience

  - Members
  - Non Members
  - Visitors to EPIC
  - Visitors to www.eclipse.org
  - Producers of Eclipse Technology
  - Consumers of Eclipse technology

### Segmentations

  - Members
  - Non-Members
  - Plug-in Providers
  - Managers
  - Developers
  - Information visitors (non developers)

### Participation incentives

  - eMail to Members
  - post to news groups
  - Button off main page
  - Button off EPIC page
  - eMailing to EclipseCon participants

### Tool to use for Survey

  - Suggestion for using survey module as part of EPIC
  - Use survey monkey tool
      - <http://www.surveymonkey.com>.
      - Costs is $20 USD per Month
  - Explore a question of the day for the www.eclipse.org and EPIC site

### Incentives for audience to respond

  - Make sure “your voice is heard” and is of value
  - We are committed to post summary of results to site
  - We are committed to send complete set of responses to participants
  - Books, plug-ins give away
  - Amazon give away
  - Gadget give away
  - Random select 3 individuals who provide plug-ins so they can be part
    of

the Plug-In of the day feature.

### Schedule:

|                           |            |          |
| ------------------------- | ---------- | -------- |
| Preliminary questionnaire | Skip       | July 20  |
| Survey finalized          | SkipMike T | August 1 |
|                           |            |          |
|                           |            |          |