Part of [Eclipse Summit
Europe 2010](http://www.eclipsecon.org/summiteurope2010)

Sign up today\! Just fill in your name, the days you'll be
participating, and your email address below.
Questions? [Email Perri](mailto:perri.lavergne@eclipse.org).

## *Don't miss out on all the fun – sign up now for the daily run\!*

## Time and Place

  - Tuesday, November 2 through Thursday, November 4
  - Meet in the lobby of the Nestor Hotel at 7am

## A Few Benefits

  - Feel energized
  - Get a great start to a full day
  - Meet members of the community, and get to know them better
  - Help your mind get ready to focus on the outstanding talks Eclipse
    Summit Europe has to offer
  - Burn off some calories and get the blood circulating
  - Breathe in the crisp, clean autumn air

## Route

Through Ludwigsburg's beautiful Favoritepark;

details
[here](http://www.dailymile.com/routes/48171-running-route-in-ludwigsburg-de)
or even more detailed
[here](http://openrouteservice.org/index.php?start=9.1944839,48.8911803&end=9.1947521,48.8910722&via=9.1887950,48.9086500%20&pref=Pedestrian&lang=en&noMotorways=false&noTollways=false&zoom=14&lat=48.89987&lon=9.19256&layers=TB000FFFTTTTTTF)

## Participants

Add your name here\! Include your email address, and the days you'll be
running or walking.

1.  Chris Aniszczyk, Tuesday, Wednesday, Thursday
    [1](mailto:caniszczyk@gmail.com)
2.  Perri Lavergne, Tuesday, Wednesday, Thursday
    [2](mailto:perri.lavernge@eclipse.org)
3.  Michael Pellaton, Tuesday, Wednesday, Thursday
    [3](mailto:michael.pellaton@netcetera.ch)
4.  Oisín Hurley, Tuesday, Wednesday, Thursday
    [4](mailto:oisin.hurley@gmail.com)
5.  Marc Hoffmann, Wednesday, Thursday
    [5](mailto:hoffmann@mountainminds.com)
6.  Daniel Meisen, Wednesday, Thursday, Thursday
    [6](mailto:d.meisen@co-services.de)
7.  James Sugrue, Tuesday, Wednesday, Thursday
    [7](mailto:james@dzone.com)
8.  Ayushman Jain, Tuesday, Wednesday, Thursday
    [8](mailto:amj87.iitr@gmail.com)
9.  ~~Tonny Madsen, Tuesday, Wednesday, Thursday
    [9](mailto:tonny.madsen@rcp-company.com)~~ by Doctors orders...
10. Aurélien Pupier, Wednesday, Thursday
    [10](mailto:aurelien.pupier@bonitasoft.com)
11. Mickael Istria, Wednesday, Thursday,
    [11](mailto:mickael.istria@bonitasoft.com)
12. Martin Woodward, Tuesday, Wednesday, Thursday
    [12](mailto:martinwo@microsoft.com)
13. Kai Tödter, Tuesday, Wednesday, Thursday
    [13](mailto:kai@toedter.com)
14. Leandro Caniglia, Tuesday, Wednesday, Thursday (and would run Mon &
    Fri too) [14](mailto:leandro.caniglia@fast.org.ar)