The distribution of eBAM is composed by a runtime and a designer
component, the runtime is composed by OSGI plugins that implement the
specific runtime features of the platform, for example:

1.  Adapter Management
2.  Rules and Events engines Management
3.  Alarm Management

So, the componets of the runtime are responsible of the management of
the eBAM information flow. The runtime is released as a server built
over Equinox, that can be automatically started by the
<u>runtime.bat</u> file. The eBAM designer is composed by eclipse
plugins that run inside eclipse and activate a new Menu Item to use the
wizards to configure eBAM. An Eclipse Helios distribution with eBAM
designer is released. Both the runtime and the design interact with the
metamodel which contains all the informations managed by ebam. In the
release, the DBMS H2 is used to interact with the metamodel, through
eclipse link, however is easy to modify the DBMS, as explained in the
[related
chapter](http://wiki.eclipse.org/Ebam/Configuration#Modifying_Database)