## Configuration Files

eBAM has several configuration files that allow to modify the behaviour
of the runtime. Here is the list of the configuration files you can
modify:

  - `/conf/configuration.xml` inside the runtime plugin
    /plugins/org.eclipse.ebam.adapter_x.x.x.jar
  - `/conf/configuration.xml` inside the runtime plugin
    /plugins/org.eclipse.ebam.eventmanager_x.x.x.jar
  - `/conf/mail.xml` inside the runtime plugin
    /plugins/org.eclipse.ebam.eventmanager_x.x.x.jar
  - `/ebamDB/url.properties` inside the runtime plugin
    /plugins/org.eclipse.ebam.h2_x.x.x.jar
  - `/src/META_INF/persistence.xml` inside the runtime plugin
    /plugins/org.eclipse.ebam.modelconnector_x.x.x.jar

Moreover, in each plugin you can find the logback.xml file to the
configuration of logging of plugins.All the log file are under the
/CATALINA_IS_UNDEFINED folder in the runtime

## Configuring adapter manager and adapters

To configure the adapter manager and source adapters, you have to modify
the `/conf/configuration.xml` inside the runtime plugin
/plugins/org.eclipse.ebam.adapter_x.x.x.jar. How to configure the
behaviour of the source adapter is explained in the previous chapter. To
configure the behaviour of the adapter manager you have to modify the
properties of the manager in configuration.xml



<table>
<tbody>
<tr class="odd">
<td><p><manager type = "osgi"></p>
<p><property name="caching" value="true"/></p>
<p><property name="transform" value="true"/></p>
<p><dispatcher></p>
<p><engine name="BASE" class="org.eclipse.ebam.customengine.CustomEngine"></engine></p>
<p></dispatcher></p>
<p></manager></p></td>
</tr>
</tbody>
</table>


the property caching if set to true, allow the storing of the messages
arrived form the log adapter and sent to the engines.

For the messages that comes to the log adapter, they are xml messages
and to cache them the adapter manager extracts all fields of xml
messages using the x-path written below, so if the xml message changes
and you want to cache it, you have to configure the xpath in that way.


<ebam-message-rules>

<journal>

<property name="error" value="//*/HDR/ERRORE" />

<property name="phaseName" value="//*/HDR/PHASE_NAME"/>

<property name="phaseDescr" value="//*/HDR/PHASE_DESCR"/>

<property name="phaseProg" value="//*/HDR/PHASE_PROG"/>

<property name="state" value="//*/HDR/STATE"/>

<property name="sourceName" value="//*/HDR/SRC_NAME"/>

<property name="serviceSrc" value="//*/HDR/SRV_SRC"/>

<property name="startDate" value="//*/HDR/START_TS"/>

<property name="endDate" value="//*/HDR/END_TS"/>

<property name="execTime" value="//*/HDR/EXEC_TS"/>

<property name="serviceInstLabel" value="//*/HDR/SRV_INSTANCE"/>

<property name="serviceStartDate" value="//*/HDR/SRV_START_TS"/>

<property name="serviceEndDate" value="//*/HDR/SRV_END_TS"/>

<property name="serviceInstState" value="//*/HDR/SRV_INSTANCE_STATE"/>

<property name="msgType" value="//*/HDR/MSG"/>

<property name="serviceName" value="//*/HDR/SRV"/>

</journal>`   `</ebam-message-rules>

`In this file you have to insert all Adapters configuration`, you can
find some information about this in the previous chapter
[here](http://wiki.eclipse.org/Ebam/Getting_Started#Log_File_Adapter):

## Modifying Database

To modify the DBMS used to connect to the database, you have to modify
the plugin /org.eclipse.ebam.modelconnector_x.x.x.jar in
`/META_INF/persistence.xml` . This plugin is even in the eclipse runtime
and eclipse designer and you have to configure both.


<property name="javax.persistence.jdbc.driver" value="org.h2.Driver"/>

<property name="javax.persistence.jdbc.url" value="jdbc:h2:tcp://localhost/~/ebam"/>

<property name="javax.persistence.jdbc.user" value="ebam"/>

<property name="javax.persistence.jdbc.password" value="ebam"/>


If you want to change DBMS uncomment the part concerning your DBMS.
However, eBAM runtime when start automatically tries to start up an H2
Server, so you have to disable this feature, disabling the plugin
org.eclipse.ebam.h2_x.x.x.jar that is in the runtime. To do it, go in
the file
eBAM-x.x.x-runtime\\configuration\\org.eclipse.equinox.simpleconfigurator\\bundles.info
and delete the line
`org.eclipse.ebam.h2,x.x.x,plugins/org.eclipse.ebam.h2_x.x.x.jar,1,true`

***`You can find some information about persistance.xml in EclipseLink
documentations.`***

## Configuring event manager

You can configure the event manager to enable the feature of sending
alarm and emails. The configuration files are in :

  - `/conf/configuration.xml`
  - `/conf/mail.xml`

inside the runtime plugin
/plugins/org.eclipse.ebam.eventmanager_1.0.0.jar. In
**configuration.xml**, you can enable a thread that search for event
that generates an alarm, and you can set in the timeout how often the
thread has to search for alarms.
<CONF>
<SEND_ALARM_THREAD>false</SEND_ALARM_THREAD>
<TIMEOUT>60000</TIMEOUT>
</CONF>

In **mail.xml** you can modify the profile of the system that sends the
mail, after generating an alarm.

<MAIL>
<PROFILES>
\<PROFILE name="alarm"
smtphost="mail.eclipse.org"
smtpport="110"
from="ebam@eclipse.org"
user="user"
password="\*\*\*\*"/\>
</PROFILES>
</MAIL>

## Reading cache

The model connector boundle use Eclipse Link to read/write data on DBMS,
it has a simple cache to improve the performance. 

This cache keep some Domain Data in memory.

To configure the cache you have to change this file:
org.eclipse.ebam.modelconnector\\conf\\cache.xml:

<cache-configuration>
<property name="'''enable'''" value="true" />

<property name="'''timeout'''" value="600"/>
</cache-configuration>

timeout: the refresh time of the cache