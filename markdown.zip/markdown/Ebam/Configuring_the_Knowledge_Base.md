## Adding a new service

In the eBAM vision, a service can be seen as the definition of a
sequence of steps in a process, in which each step generates a message.
To add a new Service to the ebam knowledge base, you can use the
configuration wizard in eBAM
Designer[1](http://www.eclipse.org/ebam/download_ebam.php). Open the
eclipse Helios released with eBAM Designer, and in the main Eclipse menu
go to Ebam --\> Service Definition.

![Image:Adding new service.jpg](Adding_new_service.jpg
"Image:Adding new service.jpg")

The start/end date are only information, in this moment there are not
any influence on eBAM runtime.

## Adding a new message

Logs can be parsed using the definition of messages and their relevant
data. To add a new Message to the ebam knowledge base, you can use the
configuration wizard in eBAM Designer. Open the eclipse Helios released
with eBAM Designer [2](http://www.eclipse.org/ebam/download_ebam.php),
and in the main Eclipse menu go to Ebam --\> Message Definition. The
message is linked to the service, and he has to be associated to the
definition of the engine that process it.

This wizard is composed by 3 TAB: Message Detail, engine and Relevant
Data.

  - Detail: you havo to assign some data and sercive
  - Engine: you have to select the Engine that will manage this type of
    messages
  - Relevant Data: the relevant data that you want to extract from
    message

![Image:Add new mess1.jpg](Add_new_mess1.jpg "Image:Add new mess1.jpg")

![Image:Add new mess2.jpg](Add_new_mess2.jpg "Image:Add new mess2.jpg")

## Adding new relevant data of a message

To add a new Relevant Data to the ebam knowledge base, you can use the
configuration wizard in eBAM Designer. Open the eclipse Helios released
with eBAM Designer
[3](http://www.eclipse.org/downloads/download.php?file=/ebam/eBAM-0.7RC-designer.zip),
and in the main Eclipse menu go to Ebam --\> Message Definition

![Image:Add rel data.jpg](Add_rel_data.jpg "Image:Add rel data.jpg")

## Adding new engine rule

To add a new rule in an engine, you have to use this wizard from
Ebam-\>rule definition menu:

![Image:Ebam RuleMenu.JPG](Ebam_RuleMenu.JPG "Image:Ebam RuleMenu.JPG")

`This wizard show you this windows:`

`Firt of all, you have to select this information:`

  - Type of Engine : now you can select only BASE Engine
  - Service: you have to select the service, all the message of that
    service will be send to this Engine
  - Threshold ( optional ): you can select the threshold.

After that, you have to insert the expression rule's: a simple xml.

![`Image:Ebam``   ``rule``   ``detail.JPG`](Ebam_rule_detail.JPG
"Image:Ebam rule detail.JPG")


And now you can create an EVENT, if you have to create some output
generated from the rule you have to create one EVENT and assign this
event to this rule:

![Image:Ebam rule detail event.JPG](Ebam_rule_detail_event.JPG
"Image:Ebam rule detail event.JPG")


The rule has to be associated to the engine definition that is in the
table SBI_DOMAINS. To each rule is associated the definition of the
event that will generate and a possible threshold already defined.
Select flag Persist if you want to persist the event on DBMS.

For example you can create an event to manage an alert.

## Adding new threshold

To add a new threshold to the ebam knowledge base, you can use the
configuration wizard in eBAM Designer. Open the eclipse Helios released
with eBAM Designer [4](http://www.eclipse.org/ebam/download_ebam.php),
and in the main Eclipse menu go to Ebam --\> Threshold Definition

![Image:Menu Ebam.PNG](Menu_Ebam.PNG "Image:Menu Ebam.PNG")

A window wizard will open in which compares all the availables thershold
and you can create your own threshold in it.

![Image:InsertNewThreshold.PNG](InsertNewThreshold.PNG
"Image:InsertNewThreshold.PNG")

You can also configure many values for a threshold and associate to it a
lot of features.

![Image:InsertNewThresholdValue.PNG](InsertNewThresholdValue.PNG
"Image:InsertNewThresholdValue.PNG")

## Adding new contact for an alarm

If you want to send an email after the generation of an alarm, you can
set the contact to whom send the email in the wizard under Ebam --\>
Contact Definition ![Image:Contacts.PNG](Contacts.PNG
"Image:Contacts.PNG")

## Adding new alarm

If you want to add a new alarm in eBAM you have to use the Alarm Wizard
you can find in eBAM Designer in the menu Ebam --\> Alarm Definition

![Image:InsertNewAlarm.PNG](InsertNewAlarm.PNG
"Image:InsertNewAlarm.PNG")

In the wizard, after created the new alarm, you have to associate the
value of the threshold that generates the alarm,

![Image:AssociateThresholdToAlarm.PNG](AssociateThresholdToAlarm.PNG
"Image:AssociateThresholdToAlarm.PNG")

the event whose the alarm is a consequence

![Image:AssociateEventToAlarm.PNG](AssociateEventToAlarm.PNG
"Image:AssociateEventToAlarm.PNG")

and optionally if the alarm has a mail to send ,you can associate here
contacts to whom the mail has to be sent by the system when this allarm
happens

![Image:AssociateContactToAlarm.PNG](AssociateContactToAlarm.PNG
"Image:AssociateContactToAlarm.PNG")