Ebam has designed to have different engines that analyse messages to
extract complex events. At this moment Ebam provide one base engine that
can execute two main rules

  - count of messages that has a defined pattern, and when the number of
    these events reaches a predefined threshold, if configured, an alarm
    will be generated.
  - identification of a pattern in a message, and possibility of
    associate an event and an alarm

For the CEP Engine (soon released),it will be an osgi bundle and we have
to put the bundle inside the runtime, so to use in the eBAM runtime you
have to put the plugin of the engine inside the subfolder /plugins and
insert the name of the jar containing the cep engine in the file
eBAM-0.7RC-runtime\\configuration\\org.eclipse.equinox.simpleconfigurator\\bundles.info
in this way

`NAME_OF_ENGINE,1.0.0,plugins/NAME_OF_ENGINE_1.0.0.jar,4,true`