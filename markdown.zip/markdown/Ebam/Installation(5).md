## DataBase Creation

If you don't use the default DBMS (H2),you have to create a database
called owned by a user called ebam, which password is ebam.You can find
the database scripts that build the database for H2 and MySQL unzipping
the eBAM-0.7RC DataBase
Scripts[1](http://www.eclipse.org/ebam/download_ebam.php). Moreover you
have to change the persistence file of eBAM Runtime and Designer,
following the instructions exposed in the specific chapter.

If you use the default DBMS H2 you can create the DB using as JDBC url
<u>jdbc:h2:tcp://localhost/\~/ebam</u> and username and password
ebam/ebam. Using the Database script you can create and fill the
database.Then shut down the DB and install the runtime. eBAM runtime
will automatically open the DB and link on it.

A faster way to use eBAM with the default DBMS is to unzip the H2
DataBase Files[2](http://www.eclipse.org/ebam/download_ebam.php) in the
home folder of your computer.In this way you the database is created,
and you can proceed to the installation of the runtime.

## Runtime Installation

After configuring the database, unzip the eBAM-0.7RC
Runtime[3](http://www.eclipse.org/ebam/download_ebam.php) and then click
on the <u>runtime.bat</u> file. Two command windows will open and the
second you can find the log of the eclipse runtime running. The runtime
will start opening automatically the H2 DataBase and parsing the log
files, if present, configured in the adapter manager configuration file.

\--[Wiedenbeckkai.googlemail.com](User:Wiedenbeckkai.googlemail.com "wikilink")
([talk](User_talk:Wiedenbeckkai.googlemail.com "wikilink")) 21:11, 9
December 2014 (EST)\[\[\[Link title\]\[

-----

<http://www.example.com> link title\]\]\]== Designer Installation ==

Unzip the eBAM-0.7RC
Designer[4](http://www.eclipse.org/ebam/download_ebam.php), then click
on <u>\\eBAM-0.7RC-designer\\eclipse\\eclipse.exe</u>. The eclipse IDE
will start with the eBAM Designer in the Eclipse Menu, and if is used
the default configuration of the DBMS (H2) the designer can
automatically link to the database.