## Introduction

The eBAM (extended Business Activity Monitoring) project aims to realize
an advanced platform for the monitoring of the heterogeneous services
and applications (infrastructures, processes, components) and the
historical analysis of data. eBAM allows users to set the governance
rules of their own monitoring systems, by defining the events and
services threshold included in the BAM systems, so that users can view
the most relevant events on their own system at runtime.

## Components

The distribution of eBAM is composed by a runtime and a designer
component, the runtime is composed by OSGI plugins that implement the
specific runtime features of the platform, for example:

1.  Adapter Management
2.  Rules and Events engines Management
3.  Alarm Management

So, the componets of the runtime are responsible of the management of
the eBAM information flow. The runtime is released as a server built
over Equinox, that can be automatically started by the
<u>runtime.bat</u> file. The eBAM designer is composed by eclipse
plugins that run inside eclipse and activate a new Menu Item to use the
wizards to configure eBAM. An Eclipse Helios distribution with eBAM
designer is released. Both the runtime and the design interact with the
metamodel which contains all the informations managed by ebam. In the
release, the DBMS H2 is used to interact with the metamodel, through
eclipse link, however is easy to modify the DBMS, as explained in the
[related
chapter](http://wiki.eclipse.org/Ebam/Configuration#Modifying_Database)

## Installation

<h3>

DataBase Creation

</h3>

If you don't use the default DBMS (H2),you have to create a database
called owned by a user called ebam, which password is ebam.You can find
the database scripts that build the database for H2 and MySQL unzipping
the eBAM-0.7RC DataBase
Scripts[1](http://www.eclipse.org/ebam/download_ebam.php). Moreover you
have to change the persistence file of eBAM Runtime and Designer,
following the instructions exposed in the specific chapter.

If you use the default DBMS H2 you can create the DB using as JDBC url
<u>jdbc:h2:tcp://localhost/\~/ebam</u> and username and password
ebam/ebam. Using the Database script you can create and fill the
database.Then shut down the DB and install the runtime. eBAM runtime
will automatically open the DB and link on it.

A faster way to use eBAM with the default DBMS is to unzip the H2
DataBase Files[2](http://www.eclipse.org/ebam/download_ebam.php) in the
home folder of your computer.In this way you the database is created,
and you can proceed to the installation of the runtime.

<h3>

Runtime Installation

</h3>

After configuring the database, unzip the eBAM-0.7RC
Runtime[3](http://www.eclipse.org/ebam/download_ebam.php) and then click
on the <u>runtime.bat</u> file. Two command windows will open and the
second you can find the log of the eclipse runtime running. The runtime
will start opening automatically the H2 DataBase and parsing the log
files, if present, configured in the adapter manager configuration file.

<h3>

Designer Installation

</h3>

Unzip the eBAM-0.7RC
Designer[4](http://www.eclipse.org/ebam/download_ebam.php), then click
on <u>\\eBAM-0.7RC-designer\\eclipse\\eclipse.exe</u>. The eclipse IDE
will start with the eBAM Designer in the Eclipse Menu, and if is used
the default configuration of the DBMS (H2) the designer can
automatically link to the database.

eBAM is composed by a series of adapters that can retrieve messages from
different sources and pass them to the Adapter Manager.

## Source Adapters

<h3>

Log File Adapter

</h3>

The log file Adapter is provived inside ebam and can parse an xml file,
retrieving messages from it, and send them to the Adapter Manager. The
log adapter optionally is able to restart reading the log from the
message in which it previously stopped to read. To configured this
adapter, take the eBAM runtime and go to subfolder <b>plugins</b>. With
a tool that manage .jar archive, open the plugin
<b>org.eclipse.ebam.adapter_1.0.0.jar</b>. Open the file
<u>/conf/configuration.xml</u>. In this file you can configure the
behaviour of the Log Adapter. Here there is a part of the text of the
configuration.xml which shows the configuration of the log Adapter:

<code> <adapter id="TEST_SERVICE">

` `<property name="factory" value="org.eclipse.ebam.adapters.log.LogAdapter"/>
` `<property name="source" value="C:/temp/logAllarme.log"/>
` `<property name="key" value="FALSE"/>
` `<property name="append" value="FALSE"/>
` `<property name="modality" value="RECOVERY"/>

</adapter> </code>

  - The property "factory" has the name of the class that implement the
    Adapter.
  - The property "source" has the path in which the adapter searchs for
    lof files. In this example, the adapter will search in C:/temp/ all
    the .log files that begin with logAllarme.
  - The property "key" if set to true, make the log adapter serach for a
    standard key value, that is a sequence of numbers in this way:
    `KEY=XXXXXXXX;`
    and memorize it. It is useful in tha case that the adapter has to be
    stopped withouth reading all the messages that are on the log files,
    in fact it makes the adapter start for the messages it didn't read
    yet before it stopped.
  - The property append if set to true, makes the adapter ignore
    messages already present in logs when it starts, and parses the
    first message that arrives after its starting.
  - The property modality if present, makes the adapter able to restart
    reading the log from the message in which it previously stopped to
    read.

## Engines

Ebam has designed to have different engines that analyse messages to
extract complex events. At this moment Ebam provide one base engine that
can execute two main rules

  - count of messages that has a defined pattern, and when the number of
    these events reaches a predefined threshold, if configured, an alarm
    will be generated.
  - identification of a pattern in a message, and possibility of
    associate an event and an alarm

For the CEP Engine (soon released),it will be an osgi bundle and we have
to put the bundle inside the runtime, so to use in the eBAM runtime you
have to put the plugin of the engine inside the subfolder /plugins and
insert the name of the jar containing the cep engine in the file
eBAM-0.7RC-runtime\\configuration\\org.eclipse.equinox.simpleconfigurator\\bundles.info
in this way

`NAME_OF_ENGINE,1.0.0,plugins/NAME_OF_ENGINE_1.0.0.jar,4,true`