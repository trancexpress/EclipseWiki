'''The main activities of 2011 will be '''

  - Integration of CEP Esper / Drools
  - Internal Cache
  - Configuration data Import/Export
  - Transformation of XST messages
  - New Adapters: JDBC, JMS
  - Integration of CBE, used as the standard for message definition.