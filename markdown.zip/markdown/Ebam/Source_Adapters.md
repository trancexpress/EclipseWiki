eBAM is composed by a series of adapters that can retrieve messages from
different sources and pass them to the Adapter Manager.

## Log File Adapter

The log file Adapter is provived inside ebam and can parse an xml file,
retrieving messages from it, and send them to the Adapter Manager. The
log adapter optionally is able to restart reading the log from the
message in which it previously stopped to read. To configured this
adapter, take the eBAM runtime and go to subfolder <b>plugins</b>. With
a tool that manage .jar archive, open the plugin
<b>org.eclipse.ebam.adapter_1.0.0.jar</b>. Open the file
<u>/conf/configuration.xml</u>. In this file you can configure the
behaviour of the Log Adapter. Here there is a part of the text of the
configuration.xml which shows the configuration of the log Adapter:

<code> <adapter id="TEST_SERVICE">

` `<property name="factory" value="org.eclipse.ebam.adapters.log.LogAdapter"/>
` `<property name="source" value="C:/temp/logAllarme.log"/>
` `<property name="key" value="FALSE"/>
` `<property name="append" value="FALSE"/>
` `<property name="modality" value="RECOVERY"/>

</adapter> </code>

  - The property "factory" has the name of the class that implement the
    Adapter.
  - The property "source" has the path in which the adapter searchs for
    lof files. In this example, the adapter will search in C:/temp/ all
    the .log files that begin with logAllarme.
  - The property "key" if set to true, make the log adapter serach for a
    standard key value, that is a sequence of numbers in this way:
    `KEY=XXXXXXXX;`
    and memorize it. It is useful in tha case that the adapter has to be
    stopped withouth reading all the messages that are on the log files,
    in fact it makes the adapter start for the messages it didn't read
    yet before it stopped.
  - The property append if set to true, makes the adapter ignore
    messages already present in logs when it starts, and parses the
    first message that arrives after its starting.
  - The property modality if present, makes the adapter able to restart
    reading the log from the message in which it previously stopped to
    read.