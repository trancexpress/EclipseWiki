The released files contain a simple TEST CASE.
You can find a simple file with some message
in :eBAM-0.8-runtime\\testFiles\\TEST_SERVICE_20101210_085426.log
The Knowledge Base contains these information:
Service:

  - TEST_SERVICE

Messages:

  - START_SERVICE
  - STOP_SERVICE
  - ALERT_SERVICE

These messages are linked to TEST_SERVICE.

If you want to test this simple use case you have to:

1\) download all eBAM components.
2\) install eBAM following the instruction in this wiki
3\) configure the Adapter, in particular the SOURCE property:


<adapter id="TEST_SERVICE">
`               `<property name="factory" value="org.eclipse.ebam.adapters.log.LogAdapter"/>
`       `<property name="source" value="D:/eBAM/rilascio 0.8/eBAM-0.8-runtime/testFiles/TEST_SERVICE.log"/>
`                `<property name="key" value="TRUE"/>
`       `<property name="modality" value="RECOVERY"/>
</adapter>


4\) activate the runtime component
5\) check if the messages are been inserted in the metamodel using the
reports included in the eBAM design