Welcome to the EclipseCon 2012 volunteers page\!

## About EclipseCon 2012

We're excited about the changes to EclipseCon this year. We are in the
new location on the East Coast, and are including two co-located
conferences: the brand-new Agile ALM Connect, and OSGi DevCon 2012. The
Hyatt Reston is a beautiful facility, and the entire venue is ours. And
just a few minutes away is Washington, D.C. -- one of the best tourism
areas in the world.

## What will you be doing?

Our volunteers this year will be helping our tutorial presenters; each
presenter will decide what his or her helper will do. We have 16
tutorials on Monday, in two sessions: 9am to noon, and 1pm to 4pm.

Your work assignment will start at 8am on Monday and be over about 5pm.
Lunch is served to all attendees from noon to 1pm. After the afternoon
sessions are over, you are done\! You'll be free to enjoy the rest of
the conference, with our thanks.

After we assign your tutorials, we will put you in touch with the
presenters so you can find out more about what you'll be doing for each
session.

## Which tutorial?

If you have signed up early for this, good for you\! You'll have first
choice on which tutorials you'll help with. Here's you to request the
tutorials you want. We will try to give everyone at least one of their
top choices, but naturally we aren't able to guarantee that.

1.  Review the scheduled tutorials on [the tutorial schedule
    page](http://www.eclipsecon.org/2012/program/session-schedule/tutorials).
2.  Send email to [Anne Jacko](mailto:anne.jacko@eclipse.org) with your
    top three choices for the morning, and your top three choices for
    the afternoon.
3.  Wait patiently to find out the results.

## What's next?

On Monday, please come to the Reston Suites A room at the Hyatt at 8am.
[Wayne Beaton](http://wbeaton.blogspot.com/) from the Eclipse Foundation
will be our volunteer wrangler, and will be meeting with you then. Plan
to start work at 8am on Monday and be done before 5pm. **Be sure you
have already registered and picked up your badge before 8am on Monday.**
Registration hours on Sunday are 4-8pm. Monday registration opens at
7:30am. If you don't register on Sunday, please be at registration
promptly at 7:30am so you are on time for orientation.

## Room share and ride share

Please use this page to communicate with one another if you like,
especially to make plans to share hotel rooms or rides. If you plan on
staying at the Hyatt, be sure to reserve your room early; we expect the
hotel to sell out and staying there is the best way to get the full
conference experience.

### Room shares

Add your contact info here if you'd like to share a room.

### Ride shares

Add your contact info here if you'd like to share a ride. (If you are
flying into Dulles International Airport, the Hyatt has a free shuttle
from the airport to the hotel.)

## Questions?

If you have any questions or concerns before you arrive in Reston,
please [email Anne](mailto:anne.jacko@eclipse.org).

## Thanks\!

We appreciate your help and hope you will find the conference
interesting, productive, and fun\!

Anne Jacko
Eclipse Foundation
EclipseCon Operations Chair