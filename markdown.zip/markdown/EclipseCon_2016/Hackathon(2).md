Where: EclipseCon 2016

When: Tuesday and Wednesday, March 8-9.

![ECNA2016_Hackathon_logo_final_coloredit1.png](ECNA2016_Hackathon_logo_final_coloredit1.png
"ECNA2016_Hackathon_logo_final_coloredit1.png")

The Hackathon area will be open from Tuesday immediately after lunch
until the end of the day on Wednesday. It is available for committers
and contributors to come and collaborate together as needed. We are
hosting "office hours" in which specific individuals will be available
to work on specific subject areas.

There's more information
[here](https://www.eclipsecon.org/na2016/hackathon).

# Hackathon

[What is a Hackathon?](https://en.wikipedia.org/wiki/Hackathon)

In this event you can meet with other interested developers to improve
Eclipse projects. No previous Eclipse development knowledge is required
but of course it is helpful if you know already about Eclipse
development.

In this event we basically sit together can you can ask questions, see
how other people work on Eclipse Projects and find areas where you may
want to contribute to your favorite framework or IDE feature.

While much of the work typically done at Eclipse Hackathons is focused
around the IDE, participation by and contributions to all Eclipse,
LocationTech, and PolarSys Projects is welcome.

This is what we typically do:

  - Work on the source code (i.e. contribute patches);
  - Test new features; and
  - Validate or open new Eclipse bug reports

If you are an Eclipse user, contributor or committer, we hope this event
will be a lot of fun for you. Attendees can hack away with the help of
experienceed Eclipse developers and can help to improve the Eclipse
platform and other open source projects.

So, bring your laptop and be ready to hack some code\!

# Code Contribution

Perhaps the most obvious sort of contribution is a patch containing code
that addresses an issue raised against a project. Naturally, you should
feel free to work on issues that you find interesting. If you're not
sure what to work on, we've listed a couple of sources of inspiration.

First, here's some groups of "help wanted" bugs:

  - Open issues against [common "IDE"
    components](https://bugs.eclipse.org/bugs/buglist.cgi?bug_status=NEW&bug_status=REOPENED&f1=tag&f2=OP&f3=product&f4=keywords&j_top=OR&known_name=Hackathon%20bugs&list_id=13405870&o1=anywords&o3=anywordssubstr&o4=allwordssubstr&query_based_on=Hackathon%20bugs&query_format=advanced&v1=hackathon&v3=Platform%2C%20JDT%2C%20Recommenders%2C%20EGit%2C%20m2e%2C%20WTP%2C%20Data%20Tools&v4=bugday%2C%20helpwanted);

Other kinds of contribution:

  - Bug reports;
  - Babel translations;
  - Write test cases;
  - Test the installer;
  - User experience (UX) feedback; and
  - More\! (be creative)

# Office Hours

We have recruited several Eclipse Project committers and others to
assist with office hours.

Eclipse Foundation staff are also on hand to assist with signing CLAs,
understanding the development and IP process, and answer other questions
regarding the Eclipse Foundation.

Consider attending [Contributing to an Eclipse Project: You Can Do
It\!](https://www.eclipsecon.org/na2016/session/contributing-eclipse-project-you-can-do-it)
to learn more about contributing patches to Eclipse.

### Tuesday

| Time        | Mentor(s)                      | Eclipse Foundation Staffer |
| ----------- | ------------------------------ | -------------------------- |
| 13:30-14:05 | Brian de Alwis (Platform UI)   | Wayne Beaton               |
| 14:15-14:50 |                                |                            |
| 15:00-15:35 | Olivier Prouvost (Platform UI) |                            |
| 16:15-16:50 |                                |                            |
| 17:00-18:00 |                                |                            |

### Wednedsday

| Time        | Mentor(s)                                                                                                    | Eclipse Foundation Staffer |
| ----------- | ------------------------------------------------------------------------------------------------------------ | -------------------------- |
| 10:30-11:05 | Brian de Alwis (Platform UI)                                                                                 | Wayne Beaton               |
| 11:15-11:50 | [Eike Stepper](http://thegordian.blogspot.de) ([Oomph](Eclipse_Installer "wikilink"), [CDO](CDO "wikilink")) |                            |
| 13:30-14:05 |                                                                                                              |                            |
| 14:15-14:50 |                                                                                                              |                            |
| 15:00-15:35 |                                                                                                              |                            |
| 16:15-16:50 | Olivier Prouvost (Platform UI)                                                                               |                            |
| 17:00-17:35 |                                                                                                              |                            |

[Category:Hackathons](Category:Hackathons "wikilink")
[Category:EclipseCon](Category:EclipseCon "wikilink")