![Image:eclipsecon_excercise.jpg](eclipsecon_excercise.jpg
"Image:eclipsecon_excercise.jpg")

Continuing in the tradition that Darin Swanson started at earlier
EclipseCons, there will be organized runs at the 2011 edition.

**Why run at EclipseCon?**

  - You have the opportunity to meet members of the community and get to
    know them better
  - You'll be wide awake and ready to focus on the outstanding talks
    EclipseCon has to offer
  - Burn off some calories from late nights in the Hyatt bar
  - Get out of the building and breathe in some nice crisp clean air
  - For those of us from a cold climate, no running in the snow for a
    week.  Can't beat that\!

We will be meeting in the lobby of the Hyatt Regency at 7am every
morning for an early morning run. Here's a
[map](http://www.usatf.org/routes/view.asp?rID=191702) for a possible
run.

**Organizers**
If you are interested in helping organize EclipseCon exercise,  please
add yourself to the list :-)

  - Elias Volanakis (503 929 5537)

**Participants**
Please sign up here for the days you are interested participating. If
you have any trouble with the wiki, just send an
[email](mailto:elias@eclipsesource.com?subject=EclipseCon_Exercise_2011).
Thanks\!

1.  Elias Volanakis, Mon - Thu
2.  Michael Pellaton, Mon - Thu
3.  Dave Orme, Mon - Thu
4.  Tonny Madsen, all days
5.  Anthony Dahanne, Mon - Thu
6.  Kai Tödter, Mon - Thu
7.  Chris Malin, Mon - Thu
8.  Bryan Obright, Mon - Thu
9.  Jesper Eskilson, Mon - Thu
10. Rick Schultz, Mon - Thu - couple days
11. Gilles Iachelini, all days
12. Dariusz Luksza, all days
13. David Hart, Mon - Thu
14. Bernhard Merkle, Mon - Thu - will try my best

We like to have prize categories to add a bit of interest; feel free to
add your suggestions here\!

  - Runner farthest away from home
  - Oldest running or conference shirt worn during EclipseCon Exercise
    ie. JavaOne 2005 shirt
  - Most colorful running outfit
  - Jazziest shoes
  - Most flexible
  - Most unlikely to run that day (given last night)