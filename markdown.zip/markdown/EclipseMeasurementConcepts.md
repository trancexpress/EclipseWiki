Measurement concepts define how [quality
attributes](EclipseQualityModel "wikilink") are measured. They provide
an intermediate level of abstraction to adapt the
[metrics](EclipseMetrics "wikilink") to various situations (programming
language used, accessibility of data sources, etc.) without modifying
the structure of the quality model. Note that measurement concepts have
been renamed to **questions** in the end of 2014 to better match user
concepts.

The complete list of questions is auto-generated. Please refer to the
dashboard documentation page:
<http://dashboard.castalia.camp/documentation/questions.html>

A concept has the following fields:

  - name (e.g. code size)
  - mnemo (e.g. CODE_SIZE)
  - description (e.g. The overall size of the code.)
  - composition (e.g. SLOC)
  - optionnally a question (e.g. how big is the software product?)

[Category:MaturityAssessment](Category:MaturityAssessment "wikilink")