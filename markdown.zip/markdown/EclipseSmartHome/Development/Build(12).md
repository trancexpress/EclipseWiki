Building Eclipse SmartHome

## Prerequisites

The build infrastructure is based on Maven in order to make it as easy
as possible to get up to speed. If you know Maven already then there
won't be any surprises for you. If you have not worked with Maven yet,
just follow the instructions and everything will miraculously work ;-)

What you need before you start: - Maven3 from
<http://maven.apache.org/download.html>

Make sure that the "mvn" command is available on your path

## Checkout

Checkout the source code from GitHub, e.g. by running

`git clone `<https://github.com/eclipse/smarthome.git>

## Building with Maven

To build Eclipse SmartHome from the sources, Maven takes care of
everything:

  - change into the smarthome directory ("cd smarthome“)
  - set MAVEN_OPTS to "-Xms512m -Xmx1024m -XX:PermSize=256m
    -XX:MaxPermSize=512m"" in order to avoid memory problems during the
    build process.
  - run "mvn clean install" to compile and package all sources

The build result will be available in the folder
smarthome/distribution/target. Both the repository as well as the
designer zips are placed in there.

## The repository as a build result

As Eclipse SmartHome is a framework, i.e. a set of OSGi bundles, the
main build artifact is a p2 repository which contains all these bundles
with their meta-information. You will find the repository packaged as a
zip as eclipsesmarthome-incubation-0.x.0-SNAPSHOT-repo.zip

There is currently no launchable binary of a runtime available. If you
want to launch the framework on Equinox as an OSGi container and Jetty
as an HTTP server, you can do so from within the [development
environment](https://github.com/eclipse/smarthome/blob/master/docs/sources/development/ide.md)
by running the provided launch configuration. If you are looking for an
example of how a solution can be built using the Eclipse SmartHome
framework, you might want to have a look at [this
project](https://github.com/openhab/openhab2#openhab-1-vs-openhab-2).

## Starting the designer

  - unzip the file
    eclipsesmarthome-incubation-0.x.0-SNAPSHOT-designer-<platform>.zip
    to a local folder
  - run the executable „Eclipse-SmartHome-Designer.exe"

## Eclipse Hudson instance

<http://hudson.eclipse.org/smarthome/job/SmartHomeDistribution/>