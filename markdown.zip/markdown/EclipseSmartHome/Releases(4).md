## 0.7.0 Release Notes

The Eclipse SmartHome 0.7.0 is the very first release after the project
creation. It brings a cleaned up code base, many bug fixes and new APIs
for bindings that support discovery and metadata descriptions.

Furthermore it includes two example bindings for YahooWeather and
Philips Hue that can be used as a code reference.

Find more details on the [project release
information](https://projects.eclipse.org/projects/iot.smarthome/releases/0.7.0/plan).

## 0.8.0 Release Notes

The 0.8.0 release introduces a JAX-RS-based REST API, which provides
endpoints for a wide range of functionality. Besides operational aspects
(like items and sitemaps), which already existed in version 0.7.0,
administration endpoints were added, which allow CRUD operations on all
entities as well as actively manage setup and configuration aspects. To
support server push functionality, SSE has been introduced as a
complement to the REST API.

The REST API has been polished and stabilised through many iterations,
while implementing clients that make use of the REST API.

Furthermore, the Thing and discovery APIs have been enhanced through
incorporating feedback from the community and can now be regarded as
stable.

As a new part of the project, the reference implementation of the OSGi
EnOcean base driver has been added.

Additionally, many bugs have been fixed. See a [list of issues
implemented in 0.8.0 in
Bugzilla](https://bugs.eclipse.org/bugs/buglist.cgi?product=SmartHome&query_format=advanced&resolution=FIXED&version=0.8.0).

## 0.9.0 Release Notes

This release includes improvements and new features on many levels,
ranging from new framework features to more mature APIs for extensions
and a long list of new available extensions.

The binding APIs are pretty stable and in wide use by now and also the
new rule engine has matured and can be used productively.

Code wise, the release now uses Java 8 langauge features and hence
dropped support for Java 7.

Major work went into the Paper UI as the reference administration user
interface. It supports GUI driven system configuration of the majority
of features.

With respect to configuration, a fully new approach is now in place for
textual configuration: The RCP-based "Eclipse SmartHome Designer" has
been deprecated and is no longer a project deliverable in favor for the
new Language Server Protocol (LSP) support that this built into the
runtime and which enables external editors to provide similar features
as it has been done by the Designer.

With this release, the project switched to EPLv2.

A full list of all changes is available on Github at
<https://github.com/eclipse/smarthome/milestone/4?closed=1>.

## 0.10.0 Release Notes

With this release Eclipse SmartHome provides under the hood improvements
along with new bindings and protocol extensions.

The new Units of Measurement API provides a way for bindings to pass
measurement values with a unit attached. The framework is able to
automatically convert between compatible units on a locale based default
or user defined units and offers full scripting support for unit based
calculations and comparison.

With an OAuth2 client and a highly customizable HTTP
authentication/authorization module the framework now supports a wide
range of security aspects. Basic HTTP authentication is delivered with
the release.

The new MQTT features are split into separate modules: There is basic
protocol support, an embedded MQTT broker, system & user specific MQTT
broker connections and along generic topic-to-item mappings an automated
discovery of Homie 3.x and Home Assistant compliant topics.

Semantic meaning is a key for future smart home applications. This
release offers an predefined ontology which can be attached to items
using tags. Built-in synonyms can be extended by instance specific
custom synonyms.

For this release a few new bindings are available: Bose SoundTouch,
OneWire, Homematic and Bluetooth LE support. The Bluetooth LE support
provides a generic binding along with vendor specific extensions:
BlueGiga and blueZ expose USB bluetooth dongles to the framework and
Blukii connects to SmartBeacons providing environmental data.