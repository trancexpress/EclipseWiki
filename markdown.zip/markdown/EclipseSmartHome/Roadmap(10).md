This page describes the current plan for the upcoming features of the
Eclipse SmartHome project. Please note that this plan is a moving target
- depending on priorities and community contribution and commitments,
the plan can change any time, so do not take it for granted, but see it
as a guidance of direction.

## Release 0.7.0

This is the very first release of Eclipse SmartHome and has been
released on October 9, 2014. It includes the following features:

  - Upgrade of all dependencies (such as Equinox, Jetty, EMF, Xtext
    etc.) to Luna release train
    ([bug 433990](https://bugs.eclipse.org/bugs/show_bug.cgi?id=433990))
  - Modularize the smarthome.cfg file
    ([bug 434003](https://bugs.eclipse.org/bugs/show_bug.cgi?id=434003))
  - Introduction of a configuration meta-data description service
    ([bug 433993](https://bugs.eclipse.org/bugs/show_bug.cgi?id=433993))
  - Introduction of the "Thing Concept" as a new way to implement
    bindings by providing thing and configuration meta-data
    ([bug 433994](https://bugs.eclipse.org/bugs/show_bug.cgi?id=433994))

See all details in the [official 0.7.0 release
plan](https://projects.eclipse.org/projects/iot.smarthome/releases/0.7.0/plan)

## Release 0.8.0

Following features are planned for the upcoming 0.8.0 release (planned
for March 2015):

  - REST-API for administration of items and things
    ([bug 423546](https://bugs.eclipse.org/bugs/show_bug.cgi?id=423546))
  - Updated set of types and items
    ([bug 423550](https://bugs.eclipse.org/bugs/show_bug.cgi?id=423550))
  - Provide a server-push mechanism for events (item status updates and
    other UI-relevant events)
    ([bug 423552](https://bugs.eclipse.org/bugs/show_bug.cgi?id=423552))

See a list of all already [implemented features and fixed
bugs](https://bugs.eclipse.org/bugs/buglist.cgi?bug_status=RESOLVED&component=Core&list_id=10984421&product=SmartHome&query_format=advanced&resolution=FIXED&version=0.8.0).

## Other topics to be prioritized and scheduled

  - Mechanism for marking invalid thing configuration settings with
    hooks to run setup logic / wizards with UI support
  - Role-based security concept to allow conditional access to items and
    sitemaps
    ([bug 423548](https://bugs.eclipse.org/bugs/show_bug.cgi?id=423548))
  - REST-API for time series for persisted data
    ([bug 423547](https://bugs.eclipse.org/bugs/show_bug.cgi?id=423547))
  - Introduce an optional unit in Number item
    ([bug 434006](https://bugs.eclipse.org/bugs/show_bug.cgi?id=434006))
  - Merge Registry and ManagedProvider concepts into one service while
    importing the entities from other providers
  - Implement export of MapDB entries in human readable form - or
    directly change serialization format for certain entities
  - Introduce new generation of sitemaps as JSON structure that can be
    managed through REST API
  - Add further meta-data to thing descriptions like images and
    documentation
  - Introduce a "default" ThingHandler for non-specific functionality,
    if no specific handler is registered
  - Improve DiscoveryService interface to allow deletion of entries (or
    TTL information)
  - Add "Trigger" channels to things to allow bindings sending commands