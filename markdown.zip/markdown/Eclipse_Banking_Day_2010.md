Moved to new page: [Eclipse Banking Day Copenhagen
\>\>](Eclipse_Banking_Day_Copenhagen "wikilink")