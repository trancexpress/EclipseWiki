![Image:Eclipse.JPG](Eclipse.JPG "Image:Eclipse.JPG")

Eclipse Day at the Googleplex is a full day event for developers to
learn about different Eclipse projects and related technologies. You are
invited to attend and listen as experts from the Eclipse projects and
Google share their experiences of using Eclipse. It's also a great
opportunity for you to meet and network with other Eclipse enthusiasts.
There is no cost to attend, but
[pre-registration](http://wiki.eclipse.org/Eclipse_Day_At_Googleplex_2010#Attendee_Registration)
is required. Note that registration is now closed, as of July 26.

This year we are adding an Eclipse Ignite session. For those new to the
Ignite format, presenters are given 5 minutes, 20 slides that will
automatically change every 15 seconds, on a topic of their choice. If
you are interested in presenting at the Ignite session, please send your
topic to
[googleplex2010@eclipse.org](mailto:googleplex2010@eclipse.org?subject=Eclipse%20Ignite%20Topic)


**Thursday, August 26, 2010**
9:00am - 5:00pm
Googleplex
1600 Amphitheatre Parkway
Mountain View, CA
Enter via the lobby of building 43. Parking is available. [See
Map](http://maps.google.com/maps?f=q&source=s_q&hl=en&geocode=&q=Google+near+Mountain+View,+CA&sll=37.0625,-95.677068&sspn=44.339735,77.34375&ie=UTF8&hq=Google&hnear=Mountain+View,+Santa+Clara,+California&ll=37.422696,-122.08791&spn=0.010906,0.018883&z=16)
Thanks very much to the [Google Open Source
office](http://code.google.com/opensource/) for hosting this event.

## Presentation Slides

  - Android Tools for Eclipse - Xavier Ducrohet (Google):
    [Slides](http://wiki.eclipse.org/images/3/32/Android_Tools_Eclipse_082010.pdf)
  - Next Generation Maven Development Stack - Jason van Zyl (Sonatype):
    [Slides](http://wiki.eclipse.org/images/9/9a/NextGenMaven.pdf)
  - What's New in Helios - Wayne Beaton (Eclipse Foundation): [Slides in
    PDF](Media:Helios-Long-v0.2.pdf "wikilink"), [Slides in
    ODP](Media:Helios-Long-v0.2.zip "wikilink")
  - Instantiations Eclipse Tools - Eric Clayberg
    (Instantiations/Google):
    [Slides](http://wiki.eclipse.org/images/c/cb/Eclipse-day-instantiations.pdf)
  - Eclipse Sequoyah for Android App Developers - Eric Cloninger
    (Motorola Mobility):
    [Slides](http://download.eclipse.org/sequoyah/presentations/Eclipse_Day_at_Google_2010-Cloninger-Sequoyah.pdf)
  - Eclipse Mylyn: from Stack Trace to Scrum - Mik Kersten (Tasktop):
    [Slides](http://wiki.eclipse.org/images/6/61/2010EclipseGoogleDay-Mylyn.pdf)
  - Tools for Mobile Web - Paul Beusterien (Symbian Foundation):
    [Slides](http://wiki.eclipse.org/images/f/f3/EclipseDay2010_Tools_for_Mobile_Web.pdf)
  - Eclipse Linux Tools Project - Andrew Overholt (Red Hat):
    [Slides](http://wiki.eclipse.org/images/6/68/EclipseDayAtGooglePlexLinuxTools.pdf)
  - EMF for GWT - Ed Merks (Cloudsmith):
    [Slides](http://wiki.eclipse.org/images/8/81/EMF4GWT.pdf)
  - Git and Eclipse - Chris Aniszczyk (Red Hat) & Shawn Pearce (Google):
    [Slides](http://wiki.eclipse.org/images/f/f7/EclipseDayGoogleplex_EGit.pdf)
  - Interactive Reporting with Eclipse BIRT - Abhisek Sinha (Actuate):
    [Slides](http://wiki.eclipse.org/images/4/47/InteractiveReportingBIRT.pdf)

## Eclipse Ignite Sessions

1.  Social Networking and Events at Eclipse - Donald Smith, Eclipse
    Foundation:
    [Slides](http://wiki.eclipse.org/images/6/6a/EclipseCon_Ignite.pdf)
2.  Java EE 6 Tooling Session with Eclipse - Arun Gupta (Oracle):
    [Slides](http://wiki.eclipse.org/images/6/6c/Javaee6-eclipseday-googleplex-2010.pdf)
3.  ConnectSpan Platform - Ashvin Radiya (ConnectSpan & Eclipse
    University):
    [Slides](http://wiki.eclipse.org/images/b/b6/ConnectSpan_Eclipse_Foundation_GooglePlex.pdf)
4.  ReplayDIRECTOR - Jeff Daudel (Replay Solutions):
    [Slides](http://wiki.eclipse.org/images/a/a0/EclipseDay-ReplaySolutions.pdf)
5.  The Distributed Testing Framework - Luis Alves (Yahoo):
    [Slides](http://wiki.eclipse.org/images/5/5e/Dtf_eclipse.pdf)
6.  How Cell Biosciences uses Eclipse - Ken Swartz & Daniel Coupal (Cell
    Biosicenes):
    [Slides](http://wiki.eclipse.org/images/9/93/CellbioEclipseDay.pdf)
7.  Building Data Applications with SQL-MapReduce and Aster Developer
    Express - Peter Pawlowski (Aster Data):
    [Slides](http://wiki.eclipse.org/images/f/f8/Aster_Eclipse_Slides.pdf)
8.  What's New in SWT for Eclipse 3.7 - Scott Kovatch (IBM):
    [Slides](http://wiki.eclipse.org/images/3/3b/Eclipse_Ignite_SWT.pdf)

## Agenda

| Time        | Track 1 - Tunis Room                                                                                                                                                                        | Track 2 - Seville Room                                                                                                                                                    |
| ----------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 9:00-9:30   | Registration                                                                                                                                                                                |                                                                                                                                                                           |
| 9:30-10:00  | Introduction - Ian Skerrett (Eclipse Foundation)                                                                                                                                            |                                                                                                                                                                           |
| 10:00-11:00 | [Android Tools for Eclipse](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Android_Tools_for_Eclipse "wikilink") - Xavier Ducrohet (Google)                                               | [Next Generation Maven Development Stack](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Next_Generation_Maven_Development_Stack "wikilink") - Jason van Zyl (Sonatype) |
| 11:00-12:00 | [What's New in Helios](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#What's_New_in_Helios "wikilink") - Wayne Beaton (Eclipse Foundation)                                                | [Instantiations Eclipse Tools](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Instantiations_Eclipse_Tools "wikilink") - Eric Clayberg (Instantiations/Google)          |
| 12:00-1:30  | Lunch and Unconference                                                                                                                                                                      |                                                                                                                                                                           |
| 1:30-2:00   | [Eclipse Sequoyah for Android App Developers](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Eclipse_Sequoyah_for_Android_App_Developers "wikilink") - Eric Cloninger (Motorola Mobility) | [Eclipse Mylyn: from Stack Trace to Scrum](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Eclipse_Mylyn:_from_Stack_Trace_to_Scrum "wikilink") - Mik Kersten (Tasktop)  |
| 2:00-2:30   | [Tools for Mobile Web](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Tools_for_Mobile_Web "wikilink") - Paul Beusterien (Symbian Foundation)                                             | [Eclipse Linux Tools Project](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Eclipse_Linux_Tools_Project "wikilink") - Andrew Overholt (Red Hat)                        |
|             |                                                                                                                                                                                             |                                                                                                                                                                           |
| 2:30-3:00   | [EMF for GWT](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#EMF_for_GWT "wikilink") - Ed Merks (Cloudsmith)                                                                              | [Eclipse 4.0](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Eclipse_4.0 "wikilink") - Chris Aniszczyk (Red Hat) & Wayne Beaton (Eclipse Foundation)                    |
| 3:00-3:30   | Break                                                                                                                                                                                       |                                                                                                                                                                           |
| 3:30-4:00   | [Git and Eclipse](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Git_and_Eclipse "wikilink") - Chris Aniszczyk (Red Hat) & Shawn Pearce (Google)                                          | [Interactive Reporting with Eclipse BIRT](Eclipse_Day_At_Googleplex_2010/Session_Abstracts#Interactive_Reporting_with_Eclipse_BIRT "wikilink") - Abhisek Sinha (Actuate)  |
| 4:00-5:00   | Eclipse Ignite                                                                                                                                                                              |                                                                                                                                                                           |
| 5:00-6:00   | Reception                                                                                                                                                                                   |                                                                                                                                                                           |

[All Session
Abstracts](Eclipse_Day_At_Googleplex_2010/Session_Abstracts "wikilink")

## Attendee Registration

Registration and the waiting list closed on July 26. For questions,
contact
[googleplex2010@eclipse.org](mailto:googleplex2010@eclipse.org?subject=Eclipse%20Day%20at%20the%20Googleplex).

Name, Company:

1.  Robert Konigsberg, Google
2.  Ian Skerrett, Eclipse Foundation
3.  [Chris Aniszczyk](http://aniszczyk.org), Red Hat
4.  Shawn Pearce, Google
5.  Andrew Overholt, Red Hat
6.  Wayne Beaton, Eclipse Foundation
7.  Ed Merks, Cloudsmith
8.  Paul Beusterien, Symbian Foundation
9.  Vitor Rodrigues, Google
10. Eric Cloninger, Motorola Mobility
11. Abhisek Sinha, Actuate
12. Lori Fraleigh, Motorola
13. Brian Choate, Nimblefish Technologies
14. Vassili Bykov, Google
15. Elias Volanakis, EclipseSource
16. Max Spring, Cisco
17. Joshua Levine, Cadence Design Systems
18. Jay Zelitzky, Synopsys
19. John Panelli, Intuit
20. Michael Gower, Ariba
21. Mark Feber, MulgaSoft.com
22. Chengdong Li, Tradescape
23. Olaf Schneider, Synopsys
24. Colin Ho, Research In Motion
25. Kevin Sawicki, Perforce Software
26. Adam Taylor, IBM
27. Scott Kovatch, IBM
28. Richard Kuo, AT\&T Services
29. Stephen Moon, Perforce Software
30. Liz Lam, Perforce Software
31. Felipe Leme, Oracle
32. Gary Struthers, UC Berkeley
33. Richard Katz, UC Berkeley
34. Ivan Sabinin, The Fanfare Group
35. Hien Tran, SJSU
36. Mik Kersten, Tasktop
37. Justin Early, eBay
38. Peter Pawlowski, Aster Data
39. Rafael Alvarez-Horine, Student at San Jose State University
40. Brian Payton, IBM
41. Eric Clayberg, Google
42. Dan Rubel, Google
43. Eugene Ostroukhov, Symbian
44. Rob Clevenger, Google
45. Steve Jin, VMware
46. David Fung, Symian Development
47. Maggie Zhang, VMware
48. Giampiero Caprino, VMware
49. Dongjun Lee, VMware
50. Michael Healy, ZZQ
51. Perry Chow, PCHDesigns
52. Jason van Zyl, Sonatype
53. Linda Hartwig
54. Claire Lee, Cavium
55. Wen-yao Li, ESRI
56. Yufen Kuo, MontaVista
57. Arun Gupta, Oracle
58. Xavier Ducrohet, Google
59. Yung-Nien Yang, NexTag
60. Manish Kumar, Ericsson
61. Jijoe Vurghese, NexTag
62. Tom Chavez, ACCESS
63. Michel Trudeau, Oracle
64. Alexander Smirnoff, Comcast
65. Roman Baumgaertner, T-Mobile
66. Rama Krishna, BMC Software
67. Dave Dodd, eBay
68. Satadal Bhattacharjee, LSI
69. Alexander Pochaev, Aravo Solutions
70. Lou Ceci, T-Mobile
71. Yulian Novosyolov, eBay
72. Andrew Marki, Software Engineer
73. Randy Ballew, UC Berkeley
74. Bob Stillerman, RS International
75. Kenny Lee, Contactual
76. Zoe Li, Contactual
77. Ashvin Radiya, ConnectSpan & Eclipse University
78. Vibha Dixit, AvantSoft & Eclipse University
79. Wonkyoung Kim, Giftizen
80. Badari Kakumani, Cisco Systems
81. Venugopal Dharmapuri, Cisco Systems
82. Swapnil Sapar, Infosys
83. Joep Rottinghuis, Ebay
84. Donald Smith, Eclipse Foundation
85. Francisco Carriedo, ZoomSystems
86. Aniruddha Shevade, SoftwareAG
87. Kandy Nachimuthu, iSanga
88. Alvin RichardsSalim Shaikh, [Replay
    Solutions](http://www.replaysolutions.com)
89. Jeff Daudel, [Replay Solutions](http://www.replaysolutions.com)
90. Vijay Bashyam, Monster.com
91. Alexander Konkin, eBay
92. Dave Hodson
93. Swati Sapar, [TigerLogic](http://www.tigerlogic.com)
94. Bo Meng, [TigerLogic](http://www.tigerlogic.com)
95. Apurv Jawle, SAP Labs
96. Satyajit Chakraborty, SAP
97. Chiaming Yang, Huawei
98. Anoop Balakrishnan, Excelfore Corporation
99. Shude Zheng, Excelfore Corporation
100. John Fu
101. Sateesh Kumar Kapu, BMC Software
102. Sureshbabu Mohan, BMC Software
103. Conrad Roche, CA Technologies
104. Laurence Gonsalves
105. [Paul E Davis](http://linkedin.com/in/pauledavis),
     [Rhapsody](http://rhapsody.com)
106. Lothar Werzinger, Tradescape
107. Pandu Rudraraju, Independent
108. Kevin Jungmeisteris, [Amazon.com](http://www.amazon.com)
109. Sergey Chemishkian, [Ricoh
     Innovations](http://ricohinnovations.com)
110. Atul Wagle, St. Jude Medical
111. Daniel Coupal, Universia
112. Ken Swartz, Cell Biosciences
113. Gene Leybzon [1](http://www.leybzon.com)
114. David Bohlin, Cloudshield Technologies
115. [Michael Latulippe](http://www.linkedin.com/in/michaellatulippe),
     [Become Noticed](http://www.becomenoticed.com)
116. Peter Zen, Cumunet
117. Charles Spencer, Creative Consulting Solutions
118. Oswald Campesato, iQuarkt
119. Romona Czichos, Independent
120. Peter Tsai, Stanford
121. Chris Cinelli, Stanford
122. Kaamel Kermaani, iTech4SBiz
123. Bill Slagle, Huawei
124. Murali Yalamanchi, Linq Labs
125. Bill Linker, ZipRealty
126. Nikolay Botev, Fujitsu
127. Ritesh Trivedi, Citrix Systems
128. Tsz-Wo Nicholas Sze, Yahoo\!
129. Gursel Mutlu, AirTies
130. Louis Meadows, MobiFoundry
131. Henry Villca-Valle, Student at Foothill College
132. Sachin Anand, Sony Ericsson
133. Michelle Mooi, Software/Android Developer
134. Benjamin Lau
135. Roy Yokoyama, Motorola
136. Hirak Chatterjee, TCS
137. Edward Leung, Android SIG
138. Rohit Surve, Masters Student at San Jose State University
139. Jeslie Chermak, JCC
140. Frank Maker, UC Davis
141. Georgi Dagnall, [Geogad, Inc.](http://www.geogad.com)
142. Karl Pohl, Independent Consultant
143. Ola Abraham, Singularity University
144. Bess Ho, Mobile Developer
145. Alec Dara-Abrams, Kinnexxus
146. Beth Mezias, Stanford
147. Chandra Chintanippu, PayPal
148. Srinivasa Mannava, PayPal
149. Luis Alves, Yahoo
150. Salima Fassil, Consultant
151. Chuck Huie, Avon Technology
152. [Michael Galpin](http://fupeg.blogspot.com), eBay

**REGISTRATION FULL**

## Waiting List

Registration and the waiting list closed on July 26. For questions,
contact
[googleplex2010@eclipse.org](mailto:googleplex2010@eclipse.org?subject=Eclipse%20Day%20at%20the%20Googleplex).

Name, Company:

1.  Lourdes Chiong
2.  Anbu Anbalagapandian, PayPal
3.  Vandan Parikh, Zinio
4.  Gordon Hamachi, PayPal
5.  Mark Fields, Fair Isaac
6.  Parag Raval, AvantSoft
7.  Paul Han, eBay
8.  Win Myo Htet, Aunndroid
9.  Aarthi Mohan, eBay
10. Johnpaul Williams, AfMob
11. Eric Chen, Deutsche Telekom
12. Pol F., Faze 1
13. Dan Bourque, Cisco
14. Deepti Bhardwaj, IBM
15. Amit Sarkar, Circar Consulting
16. Oleg Matcovschi, HP
17. Greg Stachnick, Oracle
18. Julian Ong, NexTag
19. Brian Hall, Mark/Space
20. Steve Robenalt, Web Circuit
21. Kayvan Kazeminejad
22. Kali Gaddam, VMware
23. Ken Swartz, Cell Biosciences
24. Anshul Dawra, IBM
25. Ruben Arce, Independent
26. Katharina Probst, Google
27. Ivan Gum
28. Gilles de Bordeaux, Taos
29. Vladimir Bacvanski, InferData
30. Kevin Nilson
31. [Kaniska
    Mandal](http://musings-on-technology.blogspot.com/search/label/Eclipse),
    [Imaginea](http://www.imaginea.com)
32. Steven Punte, Test Lens
33. Tao Lin, Telopea
34. George Estebe, Oracle
35. Justin Early, eBay
36. Lily Chang, VMware

## Carpooling Possibilities?

Please list your name/origin below if you need or can provide
carpooling.

1.  Scott K., Pleasanton, CA (SF East Bay, can provide up to 3
    additional)