**Date:** Saturday, August 29, 2015
**Location:** Bangalore, India
More details at:[Eclipse Day India 2015
Bangalore](http://eclipsedayindia.mybluemix.net)