![Image:DemoCamp.png](DemoCamp.png "Image:DemoCamp.png") [What is an
Eclipse DemoCamp?](Eclipse_DemoCamps_Neon_2016 "wikilink")

### Location

This time the DemoCamp will take place at the Dockland Hamburg. We'll be
hosted by the [NORDAKADEMIE Graduate
School](http://www.nordakademie-gs.de) again with a stunning view of the
river Elbe.

NORDAKADEMIE Graduate School
Van-der-Smissen-Strasse 9, 22767 Hamburg
LatLong: 53.54331, 9.9373
Follow this link for directions: <http://goo.gl/maps/Sp73I>

**Pro tip: take U3, S1 or S3 to Landungsbrücken, then change for ferry
line 62. The ferry will leave at 18:00, 18:15, 18:30,...**

![<File:Hamburg_Dockland.png>](Hamburg_Dockland.png
"File:Hamburg_Dockland.png")

### Date and Time

December 11, 2017

Get together starting at 06:45pm

### Organizer

[Lars Vogel](http://www.vogella.com/people/larsvogel.html), [vogella
GmbH](http://www.vogella.com)

[Martin Lippert](http://www.martinlippert.org),
[Pivotal](http://www.pivotal.io/)

[Jennifer Nerlich](http://www.vogella.com/people/jennifernerlich.html)
[vogella GmbH](http://www.vogella.com)

[Stefan Reichert](http://www.xing.com/profile/Stefan_Reichert5), [Zühlke
Engineering](http://www.zuehlke.com/)

### Sponsors

Following the principles of openness and transparency, we are open to
everybody to sponsor this demo camp. Feel free to contact the organizers
or simply add yourself to this wiki page as a sponsor.

***One additional note:** We will donate 20% of the sponsored
food/drinks to an organization that supports homeless people in Hamburg.
So 20% of the ordered drinks/food will not be delivered to our demo
camp, but directly to that organization at the same time. We did that
once in the past when we ordered more stuff that we could eat and we
thought we should do this again, but this time by purpose.*


![Itemis_pos-2.JPG](Itemis_pos-2.JPG "Itemis_pos-2.JPG")
[itemis](http://www.itemis.de) is general sponsor with EUR 500,-


![Image:Pivotal.png](Pivotal.png "Image:Pivotal.png")
[Pivotal](http://www.pivotal.io) is general sponsor with EUR 500,-

![Image:Zuehlke Logo rgb 100 2.png](Zuehlke_Logo_rgb_100_2.png
"Image:Zuehlke Logo rgb 100 2.png") [Zühlke
Engineering](http://www.zuehlke.com) is general sponsor with EUR 500,-

### Agenda

  - 18.45: Get together
  - 19.15: Opening/Welcome
  - 19.20: **Martin Lippert** (Pivotal) - **Spring Tools 4 - for Eclipse
    and beyond**
  - 19:40 **Karsten Thoms** (itemis) - **What's coming with Eclipse
    Photon?** -

In this demo I will give a sneak preview on Eclipse Photon. Let me show
you features already available with milestone 3, and things yet to come.
We will have a look at general IDE features, Git and Java tooling.

  - 20:00 **Simon Scholz** (vogella) - **Being Reactive in Eclipse RCP
    Applications - RxJava and RxSWT**
  - 20:20 - 20:30 Break
  - 20:30 **Patrik Suzzi** (itemis) - **Rapid Prototyping of Eclipse RCP
    Applications** (see also [EclipseCon
    Slides](https://www.slideshare.net/psuzzi/rapid-prototyping-of-eclipse-rcp-applications-eclipsecon-europe-2017))
  - 20:50 **Philip Wenig** (Lablicate GmbH) - **Eclipse Charting -
    Extended** -
    <https://www.eclipsecon.org/europe2017/sites/default/files/slides/Eclipse-Charting.pdf>
  - 21:10-21:30 **Olivier Prouvost** (opcoach) - '''Create easily your
    own E4 spy to help you to develop your application '''

### Who Is Attending

If you plan on attending please add your name and company to the list
below. You need to have an Eclipse Bugzilla account to do so. Signing up
is really easy and not only gives you the chance to attend Eclipse
DemoCamps, but also gives you the sweet fuzzy feeling of being able to
file Eclipse bugs\! Come on, give it a try - [we know you can do
it](https://bugs.eclipse.org/bugs/)\!

1.  [Martin Lippert](http://www.martinlippert.de), Pivotal
2.  [Stefan Reichert](http://www.xing.com/profile/Stefan_Reichert5),
    [Zühlke Engineering](http://www.zuehlke.com/)
3.  Patrik Suzzi, [itemis](http://www.itemis.com)
4.  [Karsten Thoms](http://www.xing.com/profile/Karsten_Thoms),
    [itemis](http://www.itemis.com)
5.  [Simon Scholz](http://www.vogella.com/people/simonscholz.html),
    [vogella](http://www.vogella.com)
6.  Olivier Prouvost, [OPCoach](http://www.opcoach.com)
7.  [Conrad Groth](http://www.xing.com/profile/Conrad_Groth)
8.  [Ataul Ahmad](http://www.xing.com/profile/AtaulWadood_Ahmad)
9.  [Philip Wenig](https://www.xing.com/profile/Philip_Wenig)
10. [Lars Vogel](http://www.vogella.com/people/larsvogel.html),
    [vogella](http://www.vogella.com)
11. [Fabian Pfaff](http://www.vogella.com/people/fabianpfaff.html),
    [vogella](http://www.vogella.com)
12. Shengyao Chen, [Kühne + Nagel](http://www.kuehne-nagel.com)
13. [Matthias
    Mailänder](https://www.xing.com/profile/Matthias_Mailaender), [LADR
    Lebensmittelanalytik](http://ladr-lebensmittel.de)
14. Erland Müller, [DESY](http://flash.desy.de/)
15. [evodion Information Technologies GmbH](https://www.evodion.de/),
    rri
16. [Gunther Bachmann](https://www.xing.com/profile/Gunther_Bachmann),
    [itemis](https://www.itemis.com)
17. [Stefan Schleyer](https://www.xing.com/profile/Stefan_Schleyer)
18. Sven Böckelmann, [benelog GmbH & Co. KG](http://www.benelog.com)
19. Massimo Bevilacqua, [benelog GmbH & Co. KG](http://www.benelog.com)
20. Mathias Bietz, [SUZLON Energy Ltd.](https://www.suzlon.com)
21. Daniel Raap, [subshell GmbH](http://www.subshell.com/)
22. Mario Torre, [Red Hat, Inc.](https://www.redhat.com)
23. Tommy Redel, [subshell GmbH](http://www.subshell.com/)
24. Torsten Witte, [subshell GmbH](http://www.subshell.com/)
25. Carsten Reckord, [Yatta](http://www.yatta.de/profiles/)
26. Martin Horn, [Uni Konstanz](https://www.bison.uni-konstanz.de/),
    [KNIME](https://www.knime.com/)
27. Alexander Kerner, [Lablicate GmbH](http://www.lablicate.com/)