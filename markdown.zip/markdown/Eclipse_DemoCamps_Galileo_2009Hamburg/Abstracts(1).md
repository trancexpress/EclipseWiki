**Combining graphics and text in model editors**

<div>

Textual and graphical representations of models both have their pros and
cons. While text allows to describe many details in a concise fashion,
higher-level views focussing on relations between objects can better be
shown in a diagram. With the Eclipse Modeling Framework (EMF), Xtext and
the Graphical Modeling Framework (GMF) it is possible to unite the
advantages of both representations in the same tool. In this talk, I
will present the challenges and solutions for designing modern modeling
tools on the Eclipse platform and give a demo.

</div>

-----

<div>

</div>

**redview - dynamische Views für Businessanwendungen**

<div>

Live Demo (Helios): mehrere Riena RCP Applikationen gestartet, der
Businessdesigner ändert das Model mit dem redView WYSIWYG Editor per
Drag'n'Drop, Outline oder Properties. Diese Änderungen werden by-magic
in die laufenden RCP Apps gepushed - hier kommt CDO zum Einsatz. Der
Unterschied zu anderen UI - Lösungen: alle Änderungen können im WYSIWYG
- SWT Editor erfolgen und werden dynamisch ausgewertet. Boilerplate Code
wird vermieden.

</div>

<div>

redView basiert auf EMF Modellen und erleichtert die Entwicklung und
Pflege von RCP Applikationen, kann aber auch für Prototyping genutzt
werden. redView bietet ausserdem Xpand/Xtend Templates zur Integration
in MDSD Architekturen. open-erp-ware als Referenzanwendung von redView
ergänzt das Konzept um Businesskomponenten: Lokalisierung (Label, Enums,
...), Lookup, Search, Navigation mit Riena UI und mehr. redView und
open-erp-ware werden unter EPL lizenziert.

</div>

<div>

</div>

<div>

weitere infos: [ekkes-corner](http://ekkes-corner.org/) oder
[redview](http://redview.wordpress.com/).

</div>

<div>

</div>

-----

**E4 - A short overview**

<div>

E4 is the the code name for the next generation of Eclipse-Application
framework for IDE and RCP Applications. E4 is a new Application
framework designed from scratch from the ground up using state of the
art technologies like EMF for the underlying application model,
dependency injection to name some of them. On the UI-Front E4 address
many needs of modern Application Frameworks starting from Declarative
Styling support (similar to CSS on the web) to Modeled and/or
Declarative UI development.

</div>

-----