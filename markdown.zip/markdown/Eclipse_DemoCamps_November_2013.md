![Image:Eclipse DemoCamp New.jpg](Eclipse_DemoCamp_New.jpg
"Image:Eclipse DemoCamp New.jpg")

From November 1-30, we are inviting individuals to organize and attend
Eclipse DemoCamps around the world. The Eclipse DemoCamps are an
opportunity to showcase all of the cool technology being built by the
Eclipse community.

<b>Eclipse Events Interactive Map</b>
Click the image below to see whole globe and [all
events](http://events.eclipse.org).

![EclipseEvents500.png](EclipseEvents500.png "EclipseEvents500.png")

<h2>

Demo Camps

</h2>

are an opportunity to showcase all of the cool and interesting
technology being built by the Eclipse community. They are also an
opportunity for you to meet Eclipse enthusiasts in your city. The format
of a DemoCamp is informal. A group of Eclipse enthusiasts meets up and
demos what they are doing with Eclipse. The demos can be from research
projects, Eclipse open source projects, applications based on Eclipse,
commercial products using Eclipse or whatever may be of interest to the
attendees.

<h2>

Hackathons

</h2>

are a chance for developers to gather and hack away on bugs and feature
requests, and come up with a reasonable patch by the end of the
Hackathon. They are also informal – a group of Eclipse hackers meets up
and hacks away on bugs and feature requests for a particular Eclipse
project. Attendees usually break out into groups of two or three and get
hands-on support from a project veteran to help ensure that a patch can
be completed. Here's an example of a [Hackathon from
November 2012](http://wiki.eclipse.org/Eclipse_DemoCamps_November_2012/Vancouver).

The only stipulation about these events is that they must be Eclipse
related. Take a look at the list of projects on
[eclipse.org](http://projects.eclipse.org/list-of-projects) or on
[Wikipedia](http://en.wikipedia.org/wiki/List_of_Eclipse_projects), and
the [Wikipedia list of Eclipse-based
software](http://en.wikipedia.org/wiki/List_of_Eclipse-based_software).

## Organizing

If you have not organized a Camp or Hackathon in the past, please read
this page on [organizing a
DemoCamp](http://www.eclipse.org/community/democamp/organizedemocamp.php),
and then send email to <democamps@eclipse.org> so we can add you to our
list of organizers.

When signing up to organize a DemoCamp or a Hackathon, **please be sure
to give us your contact information.** Either include your individual
email address on your event page, or send an email to
<democamps@eclipse.org> to provide your contact information.

When organizing a Camp or Hackathon, add your event to the list below,
then create a separate wiki page for your event. To help you create the
wiki page, we have a
[template](http://wiki.eclipse.org/Eclipse_DemoCamps_page_template). To
use the template, open it for editing and copy the contents of the edit
window to your clipboard, and then select "Cancel" at the bottom of the
page to cancel the editing session. Open up your new event page for
editing, copy the contents of your clipboard into the editing window,
and make your updates. **Please do not edit the template.**

Click on a city below to find out details and to let the organizers know
you plan on attending. Some cities have not finalized a date or location
but we still encourage you to let the organizer know you would like to
attend.

### Demo Sources

Please consider sharing presented demo sources or hacked solutions at
<https://github.com/Eclipse-DemoCamps>

## November 2013 DemoCamps

### Past DemoCamps

  - [Beijing
    Thursday](Eclipse_DemoCamps_November_2013/Beijing_Thursday "wikilink"),
    China - November 14th at [Funshion Online](http://www.funshion.com)
    Beijing office
  - [Prague](Eclipse_DemoCamps_November_2013/Prague "wikilink"), Czech
    Rep - 14.11., CVUT campus, Prague
  - [Bonn](Eclipse_DemoCamps_November_2013/Bonn "wikilink"), Germany -
    November 18h at [Collegium Leoninum
    Bonn](http://www.leoninum-bonn.de/index_en.html)
  - [Darmstadt](Eclipse_DemoCamps_November_2013/Darmstadt "wikilink"),
    Germany - November 19th, Deutsche Telekom AG
  - [Nantes](Eclipse_DemoCamps_November_2013/Nantes "wikilink"), France
    - November 19th, Epitech Nantes
    <span style="color:#ff0000">CANCELLED</span>
  - [Karlsruhe](Eclipse_DemoCamps_November_2013/Karlsruhe "wikilink"),
    Germany - November 20th, FZI Forschungszentrum Informatik, Karlsruhe
  - [Nieuwegein](Eclipse_DemoCamps_November_2013/Nieuwegein "wikilink"),
    Netherlands - November 20th, Industrial TSI
  - [Paris](Eclipse_DemoCamps_November_2013/Paris "wikilink"), France -
    November 20th, Epitech Paris
  - [Vienna](Eclipse_DemoCamps_November_2013/Vienna "wikilink"), Austria
    - November 22th, [Conference Center NINETEEN](http://nineteen.at/),
    Vienna
  - [Grenoble](Eclipse_DemoCamps_November_2013/Grenoble "wikilink"),
    France - November 25th
  - [Hamburg](Eclipse_DemoCamps_November_2013/Hamburg "wikilink"),
    Hamburg, Germany - November 26th, [NORDAKADEMIE Graduate
    School](http://www.nordakademie-gs.de)
  - [Toronto](Eclipse_DemoCamps_November_2013/Toronto "wikilink"),
    Canada - November 26th, [Red Hat
    Toronto](http://maps.google.com/maps?q=90+eglinton+avenue+east,+toronto)
  - [Hanover](Eclipse_DemoCamps_November_2013/Hanover "wikilink"),
    Hanover, Germany - November 27th, Zühlke Offices
    <span style="color:#ff0000">CANCELLED</span>
  - [Toulouse](Eclipse_DemoCamps_November_2013/Toulouse "wikilink"),
    France - November 28th
  - [Kassel](Eclipse_DemoCamps_November_2013/Kassel "wikilink"), Germany
    - November 28th, at [Circus Rambazotti](http://www.rambazotti.de) -
    by [Yatta Solutions](http://www.yatta.de/)
  - [Jakarta](Eclipse_DemoCamps_November_2013/Jakarta "wikilink"),
    Indonesia - 14 December, at Meruvian Camp Jakarta - by [Frans
    Thamura/Meruvian/JUG Indonesia|](mailto:frans@meruvian.org)
  - [Changsha](Eclipse_DemoCamps_November_2013/Changsha "wikilink"),
    China - November 30th, 长沙市天心区劳动西路308号凯华大厦B栋1202室
  - [Berlin](Eclipse_DemoCamps_November_2013/Berlin "wikilink"), Germany
    - December 2nd, 2013 at [Fraunhofer
    FOKUS](http://www.fokus.fraunhofer.de/de/fokus/index.html), Berlin
  - [Dresden](Eclipse_DemoCamps_November_2013/Dresden "wikilink"),
    Germany - December 3rd, [CoFab c/o ObjectFab
    GmbH](http://www.cofab.de), Pohlandstrasse 19, 01309 Dresden
    <span style="color:#ff0000">CANCELLED</span>
  - [Munich](Eclipse_DemoCamps_November_2013/Munich "wikilink"), Germany
    - 05.12.2013, EclipseSource München
  - [Stuttgart](Eclipse_DemoCamps_November_2013/Stuttgart "wikilink"),
    Germany - 06.12.2013, Leinfelden-Echterdingen
  - [Frankfurt](Eclipse_DemoCamps_November_2013/Frankfurt "wikilink"),
    Germany - 12.12.2013, by [Yatta Solutions](http://www.yatta.de/)
  - [Shared Remote
    Sessions](Eclipse_DemoCamps_November_2013/Shared_Remote_Sessions "wikilink")
    - December 14th, Video over Internet
    <span style="color:#ff0000">CANCELLED</span>
  - [Beijing](Eclipse_DemoCamps_November_2013/Beijing "wikilink"), China
    - December 14th, near Tech Temple 北京市东城区东四北大街107号天海商务大厦B座107
  - [Wuhan](Eclipse_DemoCamps_November_2013/Wuhan "wikilink"), China -
    December 14th, 中国湖北省武汉市东湖新技术开发区光谷大道金融港A3栋
    [北京风行在线技术有限公司](http://www.funshion.com)
    <span style="color:#ff0000">CANCELLED</span>
  - [Guangzhou](Eclipse_DemoCamps_November_2013/Guangzhou "wikilink"),
    China - December 14th, 广州市天河北路906号高科大厦A座22层
    [北京数字天堂信息科技有限责任公司广州分公司](http://www.d-heaven.com)
    <span style="color:#ff0000">CANCELLED</span>

## November 2013 Hackathons

### Scheduled

  - [Hamburg](http://wiki.eclipse.org/Hackathon_Hamburg_2013), Germany -
    November 22nd, [Chaos Computer Club
    Hamburg](http://www.hamburg.ccc.de/wegbeschreibung)
    <span style="color:#ff0000">CANCELLED</span>

## Past DemoCamps

  - [Eclipse DemoCamps November
    2013](Eclipse_DemoCamps_November_2013 "wikilink")
  - [Eclipse DemoCamps Kepler
    2013](Eclipse_DemoCamps_Kepler_2013 "wikilink")
  - [Eclipse DemoCamps November
    2012](Eclipse_DemoCamps_November_2012 "wikilink")
  - [Eclipse DemoCamps Juno
    2012](Eclipse_DemoCamps_Juno_2012 "wikilink")
  - [Eclipse DemoCamps November
    2011](Eclipse_DemoCamps_November_2011 "wikilink")
  - [Eclipse DemoCamps Indigo
    2011](Eclipse_DemoCamps_Indigo_2011 "wikilink")
  - [Eclipse DemoCamps November
    2010](Eclipse_DemoCamps_November_2010 "wikilink")
  - [Eclipse DemoCamps Helios
    2010](Eclipse_DemoCamps_Helios_2010 "wikilink")
  - [Eclipse DemoCamps November
    2009](Eclipse_DemoCamps_November_2009 "wikilink")
  - [Eclipse DemoCamps Galileo
    2009](Eclipse_DemoCamps_Galileo_2009 "wikilink")
  - [Eclipse DemoCamps November
    2008](Eclipse_DemoCamps_November_2008 "wikilink")
  - [Eclipse DemoCamps 2008 - Ganymede
    Edition](Eclipse_DemoCamps_2008_-_Ganymede_Edition "wikilink")
  - [Eclipse DemoCamp 2007](Eclipse_DemoCamp_2007 "wikilink")

[Category:DemoCamps](Category:DemoCamps "wikilink")