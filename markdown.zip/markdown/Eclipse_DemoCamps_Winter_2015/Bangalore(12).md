![Image:Eclipse_DemoCamp_New.jpg](Eclipse_DemoCamp_New.jpg
"Image:Eclipse_DemoCamp_New.jpg")
[](Eclipse_DemoCamps_Winter_2015 "wikilink")


![<File:EDCB2015.jpg>](EDCB2015.jpg "File:EDCB2015.jpg")

### Location

Cerner Healthcare Solutions Private Ltd. Level 7, Block C2, Manyata
Embassy Business Park Nagawara Bangalore - 560 045 India

### Date and Time

22nd January 2015. 3 PM to 7 PM

### Sponsors

This Eclipse DemoCamp will be sponsored by Cerner Healthcare Solutions
Private Ltd. [1](https://www.cerner.com/include/img/logo-cerner.gif)

If your company is willing to co-sponsor this event, please contact
eclipsedemocampblr@gmail.com

### Organizer

Cerner Healthcare Solutions Pvt Limited, Bangalore.
<http://www.cerner.com>

### Agenda


![<File:Eclipse_Demo_Camp_Bangalore_2015_Agenda_1.png>](Eclipse_Demo_Camp_Bangalore_2015_Agenda_1.png
"File:Eclipse_Demo_Camp_Bangalore_2015_Agenda_1.png")

### Presenters

If you would like to present at this event, please register by clicking
here: <http://goo.gl/forms/1PgtHuj3OQ>

### Who Is Attending

  - Registration is mandatory for attendees too. Please register by
    clicking here: <http://goo.gl/forms/1PgtHuj3OQ>
  - In case of any queries please drop an email to
    eclipsedemocampblr@gmail.com

## Slides and other resources

  - Java 8 tooling in Eclipse :
    <http://www.slideshare.net/NoopurGupta6/eclipse-demo-camp-bangalore-january-2015>
  - Eclipse 4 OSGi services :
    <https://drive.google.com/file/d/0B3BFv1k9kuecS1lyeHhQSUhlcTg/view?usp=sharing>
  - POJO ECORE and Social programming : <https://github.com/ancit>
    (contact p.karthykeyan@gmail.com for queries)