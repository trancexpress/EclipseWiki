<skin>strapping</skin> <css>

body { font-family: 'Open Sans', sans-serif; font-size: 14px;
font-weight: 300; color: \#676767; }

a{ color: \#f7941e; }

a:hover { color: \#292929; }

section\#content a.external, section\#content a.external\[href
^='<https://>'\], a{ background-image: none; padding-right: 0; }

.mw-content-ltr { border-top: 1px solid \#eee; margin-top: 20px; }

.span12 \#p-logo img{ width: 220px; margin-top: 25px; }

.span10 { width: 1170px; margin: 0 auto; }

.offset1 { margin-left: 30px; }

ul.navigation { margin-top: -53px; }

.nav li a:hover, .nav li a:focus {

` background-color: transparent;`

}

p.logo_ecdn { text-align: center; margin-top: -30px; }

.logo_ecdn img{ width: 730px; }

1.  toctitle, .tocnumber, .nolayout .firstHeading{

display: none; }

1.  toc ul {

margin: 0 auto; margin-top: 30px; margin-bottom: 50px; display: table; }

h3 { clear: both; }

1.  toc ul li {

float: left; list-style-type: none; margin-right: 20px; }

1.  toc ul li a{

color: \#f7941e; font-size: 18px; }

h3 span.mw-headline { color: \#2c2255; } </css>

![Image:Logo_EDCN_1line.png](Logo_EDCN_1line.png
"Image:Logo_EDCN_1line.png")

__TOC__ Cet évènement gratuit sera l'occasion de rencontrer
quelques-uns des contributeurs Eclipse, de découvrir les dernières
nouveautés et d'échanger avec d'autres utilisateurs.

La soirée débutera par une présentation de l'écosystème Eclipse et de
ses dernières actualités par Gaël Blondelle, représentant français de la
fondation. Ensuite, plusieurs intervenants aborderont quelques un des
sujets chauds du moment : Cloud, IoT, Arduino, développement web et
déploiement en entreprise.

### Date

5 février 2015, de 18h00 à 21h30

### Organisateur

[Goulwen Le Fur](https://twitter.com/glefur_),
[Obeo](http://www.obeo.fr)

### Agenda

<table class="table table-striped">

<tr>

<th>

</th>

<th width="20%">

Thème

</th>

<th>

Intervenants

</th>

<th>

Slides

</th>

</tr>

<tr>

<td>

<b>18h00 - 18h30</b>

</td>

<td>

[Ecosystème
Eclipse](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes_Agenda#Eclipse.2C_au_del.C3.A0_de_l.E2.80.99IDE.21)

</td>

<td>

<b>Gaël Blondelle</b> (Fondation Eclipse)

</td>

<td>

slides: soon

</td>

</tr>

<tr>

<td>

<b>18h30 - 19h00</b>

</td>

<td>

Déploiement en entreprise

</td>

<td>

<b>Laurent Broudoux</b> (MMA) & <b> Yann Guillerm </b>(MMA)

</td>

<td>

slides: soon

</td>

</tr>

<tr>

<td>

<b>19h00 - 19h30</b>

</td>

<td>

[Développement
web](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes_Agenda#Modern_Web_Application_Development_Workflow)

</td>

<td>

<b>Stéphane Bégaudeau</b> (Obeo)

</td>

<td>

slides: soon

</td>

</tr>

<tr>

<td>

<b>19h30 - 19h50</b>

</td>

<td>

Pause

</td>

<td>

</td>

<td>

</td>

</tr>

<tr>

<td>

<b>19h50 - 20h10</b>

</td>

<td>

[Migration vers le
Cloud](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes_Agenda#Migration_d.27Applications_vers_le_Cloud_en_Utilisant_Eclipse_Retour_d.27Exp.C3.A9rience_du_Projet_ARTIST)

</td>

<td>

<b>Hugo Brunelière</b> (Atlanmod)

</td>

<td>

[slides](http://www.slideshare.net/HugoBruneliere/migrating-applications-to-the-cloud-with-eclipse-technologies-feedback-from-the-artist-project)

</td>

</tr>

<tr>

<td>

<b>20h10 - 20h40</b>

</td>

<td>

[Développement dans le
Cloud](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes_Agenda#Introduction_.C3.A0_Eclipse_Che)

</td>

<td>

<b>Stévan Le Meur</b> (Codenvy)

</td>

<td>

slides: soon

</td>

</tr>

<tr>

<td>

<b>20h40 - 21h00</b>

</td>

<td>

[Arduino](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes_Agenda#Turning_Eclipse_into_an_Arduino_programming_platform)

</td>

<td>

<b>Maxime Porhel</b> (Obeo)

</td>

<td>

slides: soon

</td>

</tr>

<tr>

<td>

<b>21h00 - 21h30</b>

</td>

<td>

Internet of Things

</td>

<td>

<b>Fred Rivard</b> (IS2T)

</td>

<td>

slides: soon

</td>

</tr>

<tr>

<td>

<b>21h30 - 22h00</b>

</td>

<td>

Cocktail

</td>

<td>

</td>

<td>

</td>

</tr>

</table>

### Inscription

[Formulaire
d'inscription](https://docs.google.com/forms/d/1Q7t2QEAK5FCt6UbPaiZcRMO1V6HJhvXIm1d5G5vk2Jw/viewform)

### Lieu

[Hub Créatic,
Nantes](http://www.nantes-amenagement.fr/hub-creatic/contact-acces/)

![Hub-creatic_building.png](Hub-creatic_building.png
"Hub-creatic_building.png")

![Hub-creatic_map.png](Hub-creatic_map.png "Hub-creatic_map.png")

### Partenaires

Nous remercions chaleureusement nos partenaires pour leur soutien :

|                                                                    |                                                                 |                                                                 |
| ------------------------------------------------------------------ | --------------------------------------------------------------- | --------------------------------------------------------------- |
| ![Logo_Developpez.png](Logo_Developpez.png "Logo_Developpez.png") | ![Logo_GDGNantes.png](Logo_GDGNantes.png "Logo_GDGNantes.png") | ![Logo_JUGNantes.png](Logo_JUGNantes.png "Logo_JUGNantes.png") |