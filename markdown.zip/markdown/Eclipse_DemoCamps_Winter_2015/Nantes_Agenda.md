<skin>strapping</skin> <css>

body { font-family: 'Open Sans', sans-serif; font-size: 14px;
font-weight: 300; color: \#676767; }

a{ color: \#f7941e; }

a:hover { color: \#292929; }

section\#content a.external, section\#content a.external\[href
^='<https://>'\], a{ background-image: none; padding-right: 0; }

.mw-content-ltr { border-top: 1px solid \#eee; margin-top: 20px; }

.span12 \#p-logo img{ width: 220px; margin-top: 25px; }

.span10 { width: 1170px; margin: 0 auto; }

.offset1 { margin-left: 30px; }

ul.navigation { margin-top: -53px; }

.nav li a:hover, .nav li a:focus {

` background-color: transparent;`

}

p.logo_ecdn { text-align: center; margin-top: -30px; }

.logo_ecdn img{ width: 730px; }

1.  toctitle, .tocnumber, .nolayout .firstHeading{

display: none; }

1.  toc ul {

margin: 0 auto; margin-top: 30px; margin-bottom: 50px; display: table; }

h3 { clear: both; }

1.  toc ul li {

float: left; list-style-type: none; margin-right: 20px; }

1.  toc ul li a{

color: \#f7941e; font-size: 18px; }

h3 span.mw-headline { color: \#2c2255; }

.bioheader { font-size: 14px; color: \#2c2255; font-weight: bold;
line-height: -1.428571429; letter-spacing: 0.08em; margin-top: -3px;
margin-bottom: 15px; text-transform: uppercase; }

.biocontent { font-size: 12px; color: \#aaa; }

.divrule { height: 1px; width: 45px; background: \#AAA; } </css>

![Image:Logo_EDCN_1line.png](Logo_EDCN_1line.png
"Image:Logo_EDCN_1line.png")

### Eclipse, au delà de l’IDE\!

[Eclipse DemoCamp
Nantes](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes)

The Eclipse project was born in 2001, and the Eclipse Foundation turned
10. In the digital era, it looks old, but instead of resting on one's
laurels, the Eclipse ecosystem innovates in new domains like IoT,
Location aware technologies, Embedded Systems and more. This talk will
present projects and initiatives you would not expect to find inside the
Eclipse community if you still identify Eclipse mainly with the Java
IDE.

Open you eyes and your ears, and be ready to learn more about open
innovation "à la" Eclipse.

<div class="row">

<div class="span2">

![Gblondelle.jpg](Gblondelle.jpg "Gblondelle.jpg")

</div>

<div class="span9">

<span class="bioheader">Gaël Blondelle</span>, Eclipse Foundation

Depuis 2003, Gaël Blondelle a une solide expérience dans le domaine de
l'Open Source, et plus particulièrement dans les communautés OW2 et
Eclipse. Gaël a rejoint la fondation Eclipse en 2013 et est en charge du
développement de l'écosystème Eclipse, plus particulièrement en Europe.
Précédemment, il était Business Developer en charge de l'offre Open
Source chez Obeo, et responsable du projet européen ITEA2 OPEES dont un
résultat notable a été la création de PolarSys, un groupe de travail
autour des outils de développement Open Source pour les systèmes
embarqués. Depuis 1996, il a travaillé chez Alcatel, Valtech, et France
Telecom avant de co-fonder en 2004 PetalsLink, la société éditrice de
l'ESB Open Source Petals.

</div>

</div>

### Modern Web Application Development Workflow

[Eclipse DemoCamp
Nantes](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes)

People often consider that creating a web application is done by
creating a bunch of HTML, Javascript and CSS files in a text editor,
putting them in a folder and uploading them on the web.

Well, things have changed and in this presentation, you will see how the
workflow used to deliver web applications has evolved over the past few
years and where the Eclipse Foundation's tools stand in this new world\!

In this talk, we will start by having a look at all the new development
tools that have appeared with the arrival of Node.js and how they are
used by the web development community.

With tools like Bower used to manage the dependencies of a project,
Grunt and Gulp used for the continuous integration and Yeoman used to
kickstart web applications, web developers have dramatically increased
their productivity.

After that, we will see what tools like the Eclipse IDE and Orion can
offer to web developers in order to build and maintain their
applications and finally how they could be improved to provide the
features needed by web developers.

<div class="row">

<div class="span2">

![Sbegaudeau.png](Sbegaudeau.png "Sbegaudeau.png")

</div>

<div class="span9">

<span class="bioheader">Stéphane Bégaudeau</span>, Obeo

Stephane Begaudeau graduated from the Nantes University of Sciences and
Technology and is currently working as a web developer and Eclipse
Modeling consultant at Obeo in France.

</div>

</div>

### Migration d'Applications vers le Cloud en Utilisant Eclipse Retour d'Expérience du Projet ARTIST

[Eclipse DemoCamp
Nantes](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes)

Le projet collaboratif ARTIST, impliquant industriels et chercheurs
reconnus issus de plusieurs pays européens, a pour objectif de fournir
une méthodologie générale ainsi qu'un outillage correspondant dédiés à
la migration d'applications existantes vers le Cloud. De manière
intéressante, son "Open Source Package" est fortement basé sur Eclipse
et sur les technologies Eclipse Modeling. Cette présentation va donner
un bon aperçu du travail déjà réalisé et en cours au sein d'ARTIST en
insistant notamment sur 1) l'utilisation qui est faite de différents
projets et outils Eclipse dans ce contexte de migration vers le Cloud
ainsi que 2) les retours collectés jusqu'à présent auprès de nos
partenaires industriels fournissant les cas d'utilisation concrets: ATOS
(Espagne), Spikes (Belgique), Engineering (Italie) et ATC (Grèce).

<div class="row">

<div class="span2">

![Hbruneliere.jpg](Hbruneliere.jpg "Hbruneliere.jpg")

</div>

<div class="span9">

<span class="bioheader">Hugo Brunelière</span>, Atlanmod - INRIA

Hugo Brunelière est un ingénieur de recherche au sein de l'équipe
AtlanMod (Inria, Mines Nantes & LINA). Il travaille principalement sur
le thème de l'Ingénierie Dirigée pas les Modèles (IDM, ou MDE en
anglais) et de ses différentes applications concrètes, dans le domaine
du génie logiciel notamment. Via son implication dans divers projets
nationaux et internationaux ainsi que dans la communauté Eclipse, il
collabore quotidiennement avec des entreprises et labos pour le
développement, la dissémination et/ou l'industrialisation des résultats
de recherche et des prototypes correspondants. Il écrit régulièrement
des publications scientifiques et présente fréquemment lors des
évènements de la fondation Eclipse.

</div>

</div>

### Introduction à Eclipse Che

[Eclipse DemoCamp
Nantes](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes)

Eclipse Che est un IDE cloud ainsi qu'un SDK pour y créer des
extensions. Che est disponible avec plus de 55 extensions pour Java,
JavaScript, AngularJS, Git et Docker.

Le projet Che fourni la structure pour construire la partie serveur et
cliente des extensions qui sont écrites en Java mais générées en
JavaScript, un ensemble d'APIs REST, un grand nombre d'outils (Java,
Git, Datasources, Refactoring, etc...) ainsi qu'un IDE cloud par défaut
gérant la scalabilité.

Durant cette session, nous vous montrerons comment créer des
applications Java avec Eclipse Che, nous introduirons son architecture
puis nous construirons une extension directement depuis Che.

<div class="row">

<div class="span2">

![Slemeur.jpeg](Slemeur.jpeg "Slemeur.jpeg")

</div>

<div class="span9">

<span class="bioheader">Stévan Le Meur</span>, Codenvy

Stévan Le Meur est Product Manager à Codenvy. Avec un background de
dévelopeur, il est convaincu que de bonnes applications ne peuvent être
construites qu'avec de bons outils. Il porte cette passion dans Codenvy
IDE afin de créer et simplifier l'expérience du dévelopeur dans son
propre environnement de travail.

</div>

</div>

### Turning Eclipse into an Arduino programming platform

[Eclipse DemoCamp
Nantes](https://wiki.eclipse.org/Eclipse_DemoCamps_Winter_2015/Nantes)

"Daddy, daddy, how does a computer work?"

We're used to say that curiosity is a bad habit but it is nonetheless
one of the greatest strenghts of kids: they are eager to learn. Learn
how a computer works, how one can build an application for a phone or a
tablet, how one can create a video game. The best answer is probably to
give them the tools to discover by themselves the answer to those
questions.

Eclipse is used by hundreds of thousands of adults for programming
activies, so why not by kids? How to turn Eclipse into a programming
environment for kids?

This talk will present our approach and thoughts to simplify the Eclipse
user interface for usage by kids. We will show how we created, thanks to
Sirius, an easy-to-use and natural graphical tool to let kids discover
programming.

A demonstration will present a prototype of a development environment
that allows to program an Arduino using a simple and graphical
block-based language.

<div class="row">

<div class="span2">

![Mporhel.jpg](Mporhel.jpg "Mporhel.jpg")

</div>

<div class="span9">

<span class="bioheader">Maxime Porhel</span>, Obeo

Maxime Porhel is currently working as an Eclipse Modeling consultant at
Obeo in France.

</div>

</div>

### Final

La soirée s'achèvera autour de quelques sandwiches et d'un pot avec les
différents intervenant de la soirée. Ce moment convivial permettra
d'échanger à propos d'Eclipse avec toute la communauté Nantaise.