## Closing the Agile ALM loop with task-focused collaboration

**Benjamin Muskalla, Tasktop Technologies**
The rapid adoption of Mylyn as a collaboration technology by developers,
and as an ALM integration layer by Agile tool vendors, is making the
transformational role of task-focused collaboration clear. In order to
get the full benefits of Agile, the planning loop must be connected to
development activities across the application lifecycle. This talk will
examine how re-aligning collaboration around a unified notion of tasks
not only accelerates developer’s adoption of Agile project management
tools, but also yields a measurable productivity benefit when deployed
across the organization. Attendees will learn how tool-based integration
between development activities and Agile planning and collaboration can
provide a transformational productivity benefit across the software
production process. The showcase will provide attendees with enough
background to get their projects started on task-focused collaboration.
A review of the productivity and knowledge tracking mechanisms that the
task-focused interface enables will provide a background on tracking the
success of Agile tool rollouts by using productivity and usage metrics.
For tasks, Mylyn already streamlines workflow by providing first-class
task integration with the IDE. The recent Mylyn project restructuring
will soon enable the same integrated workflows for code reviews, builds
and version control systems like Git. For example, a developer can use
the Mylyn Task List to track requirements while EGit automatically
manages change sets. Committing and pushing to EGit can automatically
create a code review in Gerrit and trigger a Hudson build to execute
tests. Meanwhile, the Mylyn Reviews project enables a team member to
complete a code review and provide feedback to the developer, all
without leaving the IDE. In this talk we will show how the tools
available in the Mylyn project work together to seamlessly integrate
development artifacts in Eclipse all the way from tracking the
requirement to the final merge into the production branch.

## Requirements Engineering & Management with Eclipse

**Ömer Gürsoy, itemis**
The OMG (Object Management Group) is currently in the process of
adopting the first release of the ReqIF (Requirements Interchange
Format) standard. ReqIF provides various new ways to deal with
requirements. The talk will show how to manage requirements so formal as
possible with ReqIF in Eclipse including the tracing of these
requirements throughout the complete development chain.

## Using Eclipse as a Plattform for Functional Safety Management

**Hans-Jürgen Kugler, KUGLER MAAG CIE**

The recently founded Eclipse Automotive Industry Working Group intends
to build an Eclipse-based development platform. One of the key
considerations is to facilitate support for functional safety lifecycle
management. This presentation will outline some ideas of what will be
required.

## Tool Integration using the AUTOSAR tool platform (Artop)

**Mark Brörkens, OpenSynergy; Michael Rudorfer, BMW Car IT**
Many different tools need to be integrated within the automotive
software development. This presentation gives a brief overview over the
AUTOSAR development methodology and describes the AUTOSAR Tool Platform
(Artop). As an example we will describe the commercial product COQOS and
how Artop helped reducing development effort and increased tool
interoperability. Within a demo we will show ARText, a textual language
for AUTOSAR that was built on top of Artop.

## Model-based Test Automation - Fokus\!MBT

**Marc-Florian Wendland, Fraunhofer FOKUS**
Fokus\!MBT is a flexible and extensible tool chain, which facilitates
the development of model-based testing scenarios for heterogeneous
application domains. It is based on a service-oriented communication
infrastructure of loosely coupled services, interoperating with each
other in a distributed environment. Fokus\!MBT defines a proprietary
testing meta model – called TestingMM. The TestingMM represents an
integrated data model used for data and information exchange among the
services of the Fokus\!MBT tool chain. Fokus\!MBT is a set of compound
tools which support the model-based paradigm for testing purposes. It
establishes a tooling landscape for the specification, development and
documentation of tailored model-based testing scenarios.

## The TOPCASED status: components view and industrial usage

**Raphael Faudou, Atos Origin**
After now 3 years in production in some industrial projects the TOPCASED
platform has proved to be an efficient solution. In this session we give
the current status of the main TOPCASED components and explain what are
the major benefits for their industrial users. Next we present future
directions of each component and of the platform itselfand how to insure
their durability and maintenance.

## Papyrus: standard modeling, but also domain specific modeling\!

**Sebastien Gerard, CEA**
tba