![Oomph_Project_Logo.png](Oomph_Project_Logo.png
"Oomph_Project_Logo.png") <span style="font-size:90%;">[Powered by
Oomph](Oomph "wikilink")</span>

The Eclipse Installer automates the installation of Eclipse development
environments:

  - [Windows 64
    Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/eclipse-inst-win64.exe)
    (self-extracting exe)

<!-- end list -->

  - [Mac OS 64
    Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/eclipse-inst-mac64.dmg)
    (dmg) / [Mac OS 64
    Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/eclipse-inst-mac64.tar.gz)
    (tar.gz)

<!-- end list -->

  - [Linux 64
    Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/eclipse-inst-linux64.tar.gz)
    (tar.gz)

The Eclipse Installers are also available with an embedded JRE:

  - [Windows 64
    Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/eclipse-inst-jre-win64.exe)
    (self-extracting exe)

<!-- end list -->

  - [Mac OS 64
    Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/eclipse-inst-jre-mac64.dmg)
    (dmg) / [Mac OS 64
    Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/eclipse-inst-jre-mac64.tar.gz)
    (tar.gz)

<!-- end list -->

  - [Linux 64
    Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/eclipse-inst-jre-linux64.tar.gz)
    (tar.gz)

To download the latest nightly build of the installer, pick one of
[Windows 64
Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/latest/eclipse-inst-win64.exe),
[Mac OS 64 Bit
(dmg)](http://www.eclipse.org/downloads/download.php?file=/oomph/products/latest/eclipse-inst-mac64.dmg),
[Mac OS 64 Bit
(tar.gz)](http://www.eclipse.org/downloads/download.php?file=/oomph/products/latest/eclipse-inst-mac64.tar.gz),
[Linux 64
Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/latest/eclipse-inst-linux64.tar.gz).

To download the latest nightly build of the installer with an embedded
JRE, pick one of [Windows 64
Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/latest/eclipse-inst-jre-win64.exe),
[Mac OS 64 Bit
(dmg)](http://www.eclipse.org/downloads/download.php?file=/oomph/products/latest/eclipse-inst-jre-mac64.dmg),
[Mac OS 64 Bit
(tar.gz)](http://www.eclipse.org/downloads/download.php?file=/oomph/products/latest/eclipse-inst-jre-mac64.tar.gz),
[Linux 64
Bit](http://www.eclipse.org/downloads/download.php?file=/oomph/products/latest/eclipse-inst-jre-linux64.tar.gz).

You can also install the Oomph runtime into an existing IDE from the
latest [update site](http://download.eclipse.org/oomph/updates/latest)
or [site
archive](http://www.eclipse.org/downloads/download.php?file=/oomph/updates/latest/org.eclipse.oomph.site.zip).
See [update sites](#Update_Sites "wikilink") for more...

Our [help center](http://download.eclipse.org/oomph/help) is still work
in progress but you may already find answers to your questions there.

The installer is provided by the [Oomph](http://www.eclipse.org/oomph)
project.

![Image:OomphSimpleInstaller2.png](OomphSimpleInstaller2.png
"Image:OomphSimpleInstaller2.png")

See the [Authoring Guide](Eclipse_Oomph_Authoring "wikilink") for
details about how to customize the installer to create installations and
provision workspaces for your specialized needs.