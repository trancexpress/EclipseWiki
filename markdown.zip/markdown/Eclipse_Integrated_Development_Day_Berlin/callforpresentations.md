![Image:Logo eclipseday berlin new.png](Logo_eclipseday_berlin_new.png
"Image:Logo eclipseday berlin new.png")

You are invited to submit a talk, demo, experience report or case study
in the area of Integrated Development based on Eclipse technology.
Presentations that include demos or are based on real-life projects are
especially welcome.

**Presentation may address the following or additional topics:**

  - Tool integration frameworks (e.g. Repositories, Interfaces,
    Adapters, Transport layer)
  - Distributed tool chains
  - Management of tool chains
  - Granularity of access
  - Security and Access Control of models and tools
  - Adaptation between meta modeling frameworks (e.g. MOF 1.4 , CMOF,
    EMF, EMOF)
  - Model and model element identification
  - Model Driven Enterprise Service Bus
  - Model Driven Process Integration
  - Model Based System Management
  - Distributed Modeling Technologies (e.g. model querying)
  - Problem scenarios, User requirements, Practice reports & Success
    stories

Please submit your proposal by **September 3rd** to
[EclipseDay@fokus.fraunhofer.de](mailto:EclipseDay@fokus.fraunhofer.de?subject=Proposal%20Presentation%20Eclipse%20Day%20Berlin)


**Be sure to include:**
Presentation title and a 100 - 200 word abstract - Name, affiliation, a
100 - 200 word bio and contact information

**Presentation:**
Presentations will be approx. 30 minutes long, including time for
questions. There will be a computer projector to support your
presentation. Presentation slides can be posted to the Eclipse
Integrated Development Day 2010 wiki and, if you'd like to share a short
paper on your topic, we would also be glad to post a pdf-file on the
site.

**Language:**
English

'''Important dates: '''
Proposal submission deadline: September 3rd, 2010
Notification of presenters: September 10th, 2010
Eclipse Day date: October 12th, 2010