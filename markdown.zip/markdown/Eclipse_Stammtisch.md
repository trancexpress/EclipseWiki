![<File:Beispiel.jpg>](Beispiel.jpg "File:Beispiel.jpg")

### Registration

The ticket registration on
[Eventbrite](https://eclipsedemocamp-h.eventbrite.com) is now open.

### Location

Bredex GmbH
Mauernstr. 33
38100 Hannover
Germany

### Date and Time

March 14th - 7pm | 19:00 Uhr

### Organizers

Jonathan Beddig, [BREDEX GmbH](http://www.bredex.de)

### Sponsors

![Image:Bredex.png](Bredex.png "Image:Bredex.png")[BREDEX
GmbH](http://www.bredex.de)

### Agenda

19:00 - get together

19:20 - Begrüßung durch Jonathan Beddig (Head of Marketing @ Bredex
GmbH)

19:30 - Sebastian Struckmann talks about the new client API in Jubula,
that lets you write Jubula UI tests in Java code

\- Networking & open end -

After the talk, we will move on to a nearby restaurant [Lord
Helmchen](http://http://www.lordhelmchen.eu/aktionen-spezial/) (on
Tuesdays it's Schnitzel day\!).