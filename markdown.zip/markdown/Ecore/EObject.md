All [EMF](EMF "wikilink") generated models implement the
[EObject](http://download.eclipse.org/modeling/emf/emf/javadoc/2.6.0/org/eclipse/emf/ecore/EObject.html)
and
[InternalEObject](http://download.eclipse.org/modeling/emf/emf/javadoc/2.6.0/org/eclipse/emf/ecore/InternalEObject.html)
interfaces, and directly or indirectly extend the
[BasicEObjectImpl](http://download.eclipse.org/modeling/emf/emf/javadoc/2.6.0/org/eclipse/emf/ecore/impl/BasicEObjectImpl.html)
superclass.

## Documentation

  - [org.eclipse.emf.ecore Package Javadoc
    API](http://download.eclipse.org/modeling/emf/emf/javadoc/2.6.0/org/eclipse/emf/ecore/package-summary.html)

## FAQ

### How to obtain EPackage that contains an EObject's class?

``` java
eObject.eClass().getEPackage()
```