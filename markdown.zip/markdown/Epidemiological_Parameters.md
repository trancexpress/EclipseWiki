![STEM_TOP_BAR.gif](STEM_TOP_BAR.gif "STEM_TOP_BAR.gif")

| __TOC__ |
| ----------- |

**About Epidemiological Parameters**

### Common Variables and their Units

Using an SEIR model as an example, let's discuss some common
epidemiological parameters and what they mean. The figure shows the
compartments for S=Susceptible, E=Exposed (but not yet infectious),
I=Infectious (Shedding Virus), R=Recovered. The arrows show the
*transitions* or people moving between the compartments in a specified
time interval. Please also see the page [Introduction to Compartment
Models](Introduction_to_Compartment_Models "wikilink") for more
information (but please read this page first).

![SEIRnewDiseaseInput.png](SEIRnewDiseaseInput.png
"SEIRnewDiseaseInput.png") ![EpiParams.png](EpiParams.png
"EpiParams.png")

### What they mean

The table below shows the epidemiological parameters for the SEIR model
shown above. Note that the UNITS or all or the parameters are *inverse
time.* ![EpiParamsTable.png](EpiParamsTable.png "EpiParamsTable.png")
Figure 1: SEIR Compartment Model

Each of the parameters are *rate constants*. The transmission rate β has
a special role in that it appears inside the *mass action term.* This
interaction term includes the product SI.

`If the compartments are all normalize so that the total population S+E+I+R = 1`
`then Susceptible individuals become exposed at a rate, β`**`SI`**
`For S+E+I+R = P, the rate of exposure (or the `*`incidence`*`) becomes β`**`SI/P`**

### Common Questions

All of the parameters defined above (and as used in STEM) are *rate
constants* so their values depend on the user specified time period.

#### Mortality Rate

`The mortality rate μ represents the rate at which individuals die even with no disease.`
`For a constant population the mortality rate = the birth rate (or μ=μ*).`
`For humans, if the average life span is 50 years, and if the time period is 1 day, then`
`μ = (1/50 years) * (1 year/365.25 days) = (1/18262.5 days)`
`or`
`μ = 5.476 x 10`<sup>`-5`</sup>`[days`<sup>`-1`</sup>`].`




#### Infectious Mortality Rate (approximation)

The infectious mortality rate **δ** represents the rate at which
infected people die. It is *not* to be confused with the net **case
fatality rate** (**CFR**) which is the fraction of disease deaths PER
case (not per day or unit time). CFR defines fraction of deaths over the
entire period of infection

`If the case fatality rate is very small (CFR << 1), and we defining the inverse of the period of infection as the `**`recovery``
 ``rate`**` (γ)`
`then we can simply `*`approximate`*` the infectious mortality rate as:`
`δ ~ `**`CFR`**` * γ`
`leaving other parameters the same.`

`For example, suppose the case fatality rate for a new disease is 1% (so CFR = 0.01 [per case]). This means that 1% of people who get the new disease will die sometime during their illness.`
`Suppose also that that the period of infection is 10 days (or the `**`recovery``
 ``rate`**`  γ = 0.1 days`<sup>`-1`</sup>` ).`
`Then the  infectious mortality rate for this new disease is:`
`δ ~ 0.01 * 0.1 = 0.001 per day.`

#### Infectious Mortality Rate (more generally)

In general, for large mortality rates, one must also consider how the
mortality rate affects the net period of infection. To understand the
general solution, the figures below show the *flow* of individuals into
and out of the infectious compartment as a "pipe model". For simplicity
consider a steady state case where we always have a constant I ≡ 1.
There is always then equal flow in and out of the compartment. In the
figure below individuals in the I compartment leave by only one path
(e.g., into an R compartment not shown). In this simple case the inverse
of the period of infection is literally the "recovery rate". The flow
out (and the flow in) is γ *for* I ≡ 1

![STEM_flow1.png](STEM_flow1.png "STEM_flow1.png")

`Now let's look at a case where individuals may leave the Infectious compartment by two different paths (the flow is into two pipes).`
`They may recover (flow γ*) or they may die from the disease (flow δ). If, for example, the rate of infectious mortality δ is`
`not very small compared to γ, then clearly we need to make a correction to the recovery rate &gamma*. The steady state figure makes this clear.`
`By definition we always have:  `**`γ``   ``≡``   ``1/(Period``
 ``of``   ``Infection)`**

![STEM_flow3.png](STEM_flow3.png "STEM_flow3.png")

`so if we don't want the period of infection to change (i.e., if the flow out is still to add up to γ), then we need to adjust the  recovery rate γ*`
`A little algebra shows:`

`γ* = (1-CFR)γ`

`and the infectious mortality rate is:`

`δ = CFR γ`

`This satisfies the condition γ = δ + γ*`




#### The Difference between the Basic Reproductive Number and the Transmission Rate

A common question or confusion concerns the difference between the Basic
Reproductive Number R<sub>o</sub> and the Transmission Rate β. As
discussed above, the transmission rate β, is the rate at which
infectious cases cause secondary or new cases in a population, P, with S
susceptible individuals. It is a rate constant and has units of inverse
time (e.g., \[days<sup>-1</sup>\]).

The *basic reproduction number* , R<sub>o</sub>, (sometimes called basic
reproductive ratio) of an infection can be thought of as the number of
cases one single case generates on average *over the course of its
infectious period*, in a totaly susceptible (or otherwise uninfected)
population. R<sub>o</sub> is a dimensionless or unit-less parameter, and
it is *'not a rate*.

Epidemiologists want to compute or estimate R<sub>o</sub> because;

`when`
`R`<sub>`o`</sub>` < 1`
`the infection will die out in the long run. But if`
`and when`
`R`<sub>`o`</sub>` > 1`
`the infection will spread in a population and can cause an epidemic.`

The transmission rate β is an important control variable in an
epidemiological model. The Basic Reproductive Number R<sub>o</sub> can
easily be calculated but it *is a function of several epidemiological
parameters*. Conceptually (and by dimensional analysis) R<sub>o</sub> is
simply the ratio of the transmission rate (e.g. per day) divided by the
recovery rate (e.g., per day).

In general R<sub>o</sub> is the ratio of the *transmission rate* to the
*total rate at which individuals leave the infectious (I) compartment*.
So, if there is zero mortality,

`R`<sub>`o`</sub>` = β/γ`

with a non-zero mortality rate μ

`R`<sub>`o`</sub>` = β/[γ + μ]`

and with a net disease death rate δ

`R`<sub>`o`</sub>` = β/[γ + μ + δ]      <equation 1>`

etc. Notice that in all three cases above the numerator and denominator
have the same *units* so R<sub>o</sub> is dimensionless. Obviously γ , μ
, δ and β must all be provided or specified using the same time units
(e.g., \[days<sup>-1</sup>\].

`As an example let's consider an outbreak of variola major smallpox. Suppose we had the following values for the epidemiological parameters.`

  - Period of infection = 20 days.
      - This means γ = 0.05
  - CFR = 1%. Then δ = 0.01\*0.05 = 0.0005
  - natural death rate (all other causes) μ = 1/50 years = 5.5x10-5 per
    day
  - Transmission rate β = 0.3 per day

`Then our denominator in equation 1 is`
`γ + μ + δ = .05+.0005+.000055 = .050555`
`and we find`
`R`<sub>`o`</sub>` = β/[γ + μ + δ] = 0.3/.050555 = 5.9`

`of course given R`<sub>`o`</sub>` (instead of β) one could instead compute transmission rate β per day by inverting equation 1.`