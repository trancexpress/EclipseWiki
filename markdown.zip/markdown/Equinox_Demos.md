## Application Model

The [Equinox Application Model
Demo](Equinox_Application_Model_Demo "wikilink") shows how to create and
run multiple OSGi MEG applications.

## API Tooling

The [API Comparison demo](API_Comparison_demo "wikilink") uses
comparison of Eclipse SDK 3.1 and 3.2 to show how to generate reports
on:

  - breaking API changes
  - binary backward-compatible changes
  - version number checks

## Launcher Demos

Demos related to the new launcher work.

## [Phone Demos](Equinox_Phone_Demos "wikilink")

Click [here](Equinox_Phone_Demos "wikilink") to check out some of the
demos that the Equinox team has done for some cool phones.

  - Setting up the [Nokia 9300
    Communicator](Equinox_Phone_Demos#Nokia_9300_Communicator "wikilink").
  - Using the [SavaJe](Equinox_Phone_Demos#SavaJe "wikilink") phone.

## Provisioning Demos

Demos related to the new provisioning story can be found here.

## Resource Monitoring Demos

Check out the [Equinox
Incubator](http://www.eclipse.org/equinox/incubator/monitoring/index.php)
for more information on our Resource Monitoring code. Here is a link to
our [EclipseCon 2007 demo
script](Equinox_Resource_Monitoring_Demo "wikilink").

## Server-Side OSGi

  - JSPs - there are some demos that come with Tomcat and Struts
  - Embedded in app server
  - show the dev scenario - easy to use

[Demos](Category:Equinox "wikilink")