## May 15, 2007

### PermGen

  - fragment for ui ide
  - should it be on the workbench?
  - should be it a stand-alone bundle?
  - do we really need preference pages?
  - almost done - prefs work left
  - for RC1? still need to create fragment project, etc.

### Launcher

  - trying to ID a sun vm
      - patch only works on windows
      - added launcher permgen arg that it sends to the vm if applicable
  - trailing slash bug fix will be released

### Source Bundles

  - some changes left in PDE/Build
  - need to integrate with Orbit build

### RC1

  - launcher changes go in
  - permgen dialog delayed to 3.3.1
  - update the ini with the splash arg
  - bug w.r.t. help setting a system property