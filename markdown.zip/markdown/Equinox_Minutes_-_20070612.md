## June 12, 2007

### Bugs

  - launcher bug
      - launcher not displaying dialog
      - exit messages not getting displayed on windows
      - talk to Mike but probably will be for 3.3.1

<!-- end list -->

  - pde/build export
      - bogus folder being created and ini file put in wrong place
      - investigate for 3.3 but prob for 3.3.1
      - might be able to give a work-around
      - only when exporting from windows to the mac and you want your
        own product.ini file

<!-- end list -->

  - pde/build template update for packaging.properties
      - fix for 3.3

### 3.4

  - make lists
  - start thinking about things we believe are critical for 3.4
  - take some time to look at the things we have put off - if they are
    important then put them on the list

### Equinox Summit

  - around the last week in September
  - 2 days in Ottawa
  - in conjunction with the CDT Summit
  - some potential general topics
      - conventional osgi
      - provisioning
      - server-side
      - tooling
  - what should the format be?
  - need lots of time for discussion
  - max people is 50
  - model it after the CDT Summit as they've had success in the past