  - Bugs triaging
      - Some progress have been done, still some triaging to be done.
        Don't be afraid to close or change from bugs to enhancements.
      - Webstart bugs to be handled Andrew and Tom.

<!-- end list -->

  - Support to open a file in eclipse clicking on the launcher -
      - **We will do something if the community helps**.
      - Andrew owns the problem.

<!-- end list -->

  - Security
      - The equinox team would like to know more about what is going on
        in the security incubator.
      - Oleg to talk to Eric and Matt to give the team a presentation
        early january.

<!-- end list -->

  - Console refactoring
      - Simon to review what has happened in the bu reports and talk to
        Patrick (from Band XI) about the status.

<!-- end list -->

  - Launcher and memory limit
      - On windows, the eclipse.exe is not able to allocate as much
        memory as java.exe.
      - This is because the graphic library is loaded in the middle of
        the memory and then preventing the VM to allocate the memory
        requested. This can be worked around by rewriting the handling
        of graphics.

<!-- end list -->

  - Helpers for Executable extension
      - Late in M4 we had decided to add a helper to know if a bundle
        was active given an configuration element (poor phrasing).
        However additional requirements came in asking for support to
        know whether the creation of an executable extension would cause
        the activation of the plugin.

Given that we are not hot about adding such support, Tom and Oleg will
revisit the whole support and decide if we provide any helper.

  - API tools
      - Tracking memory leak in API search engine.
      - Working on improving the error message in case of binary
        incompatibility and how to handle quick fixes.
      - Ideas to show API differences in a compare editor.

<!-- end list -->

  - Review / graduation
      - The eclipse process will requires that API tooling and p2 go
        through a graduation review.