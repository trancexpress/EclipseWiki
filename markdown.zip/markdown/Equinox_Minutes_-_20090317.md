## Attendees

  - Tom
  - John
  - Simon
  - Pascal
  - Andrew
  - DJ
  - Matt

## Agenda

  - org.eclipse.equinox.concurrent is in the SDK. This is unintentional
    because of an optional dependency by ECF. It is too late to fix for
    M6. What do we do for M7? Leave it or take steps to remove?
      - use a greed flag in the bundle
      - should greed flag be false by default? This way we do not
        automatically install optional stuff.
          - Is this too much change? Would it require more UI to ask
            user to install optional stuff?
          - Bundle dependencies not greedy, feature dependencies should
            be greedy?
          - using p2.inf is more safe to disable greedy on per bundle
            dependency.
          - Publisher needs to understand p2.inf overrides from source.
          - Need ECF to produce meta-data with new publisher.
          - May be to much change to realistically get this fixed by ECF
            meta-data.
  - OBR and p2. New RFP created. How should we be involved?