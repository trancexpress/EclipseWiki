## Attendees

  - Jeff McAffer
  - Tom Watson

## Minutes

Meeting adjourned for lack of attendees