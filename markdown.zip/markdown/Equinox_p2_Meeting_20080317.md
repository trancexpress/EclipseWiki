## Agenda

  - Things to sort out for M6
      - Story for forcing a plugin. Can Susan's new stuff help with
        this?
      - Eclipse SDK Root files (license, etc)
      - Support for bundles with no manifest (in JAR or directory
        format)
      - Investigate any remaining test failures

<!-- end list -->

  - Installer

## Attendees

  - DJ Houghton
  - John Arthorne
  - Susan McCourt
  - Tim Mok

## Minutes

  - Installer currently can't install two different copies of the SDK,
    because it claims the profile already exists. Need to create a
    separate profile per install location.

<!-- end list -->

  - Can we find a short term solution to the forcing a plugin problem?
    Could invoke the Engine directly even though the planner is not
    satisfied. This would be slightly cleaner than telling users to edit
    bundles.info directly. However, there is no clear way to integrate
    this kind of functionality, and it would distract us from pursuing
    the real solution.

<!-- end list -->

  - Need to prioritize after M6 and focus on getting feature work done
    rather than addressing minor bugs.