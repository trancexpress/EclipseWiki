## Agenda

  - Nothing on agenda

## Attendees

  - Andrew Overholt
  - Dave Stevenson
  - Jeff McAffer
  - John Arthorne
  - Simon Kaegi
  - Susan McCourt

## Minutes

  - Working on 3.4.1 bugs
      - A new shared install bug was discovered and fixed last week
        (\[<http://bugs.eclipse.org/242632>)
      - Several performance enhancements added in 3.4.1
  - Need to self-host on 3.4.1 builds to get better testing
  - Publisher integration
      - Lives alongside and independently of the generator
      - Replaces the generator functionality
      - The publisher is a more modular implementation of the generator
      - Broken down into publish actions, with publishing advice as
        input
      - Actions can be aggregated into more complex actions
  - easyMock approved for use in Equinox, and looking at using it in
    publisher tests
  - Andrew working on shipping Fedora, looking into shared install bugs
  - p2 UI
      - 3.4.1 mostly done
      - Cancelation more responsive
      - Doing async viewer work in a branch