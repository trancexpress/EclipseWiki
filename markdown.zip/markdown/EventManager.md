Topic: An Efficient, Scalable Event Manager for EMF Notifications

Presenter: Dr. Axel Uhl has been with SAP AG since June 2004, crafting
the architecture of SAP's Modeling Infrastructure (MOIN) and is
currently Chief Development Architect in SAP's Office of the CTO. In
this role he works on the architecture of SAP's tools, repositories and
programming models.

Before Axel joined SAP, he worked at Interactive Objects Software GmbH,
as architect of their ArcStyler Model-Driven Architecture product, a
product that puts emphasis on the design, implementation, maintenance
and re-use of model transformations. Axel has authored several
publications on model-driven software development and has co-authored
"MDA Distilled".

Company: SAP AG

Type: Short presentation

Description: EMF offers various ways for dealing with change
notifications. Among them are adapters such as EContentAdapter that
assist in subscribing to notifications on entire composition trees, such
as a ResourceSet. The current paradigm of adding adapters to objects and
containment hierarchies is, however, not without flaws. When many
subscribers register for many different types of events, either many
adapters need to be registered and notified, or a single adapter
registered on the ResourceSet's containment hierarchy needs to funnel
and dispatch the notifications. We've implemented an event manager
plug-in that allows subscribers to provide an event filter and an
adapter. Event filters can be complex boolean expression trees over
basic filters such as for specific attributes, references or type of
notifier/new/old value. The adapter won't be registered on each element
in the ResourceSet. Instead, notifications are funneled through one
EContentAdapter and then dispatched efficiently by the event manager.
This session will describe the capabilities and scalability properties
of the event manager component which is already freely available as a
plug-in from
<https://www.hpi.uni-potsdam.de/giese/gforge/svn/bp2009/sources/trunk/de.hpi.sam.bp2009.solution.eventManager>
(get an account at <https://www.hpi.uni-potsdam.de/giese/gforge/>).

Project URL:
<https://www.hpi.uni-potsdam.de/giese/gforge/svn/bp2009/sources/trunk/de.hpi.sam.bp2009.solution.eventManager>