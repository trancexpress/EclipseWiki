This example is [Bugzilla
ID 193590](https://bugs.eclipse.org/bugs/show_bug.cgi?id=193590). If you
would like to contribute an example see the example contribution
guidelines.
\== Introduction == This illustrates linking a report parameter to a
sort condition on a table.

## BIRT Version Compatibility

This example was built and tested with BIRT 2.2 RC3.

## Example Files

[Example Report
Zipped](https://bugs.eclipse.org/bugs/attachment.cgi?id=71939)

## Description

BIRT provides sorting at many levels. This simple example sorts a table
based on a parameter. First the sample database is used to get the
following query:

`Select * from customers`

Next a parameter is added to the report named srt, which is a static
combo box with possible values of

`firstcol`
`secondcol`
`thirdcol`

These represent which column in the table will be used as the sort key.
Next drag the query to the report canvas, which will create the table
element. Select the properties for the table and choose the sorting tab.
Add a sort key with the following expression for the key.

`if( params["srt"].value == "firstcol" ){`
`    row["CUSTOMERNUMBER"];`
`} else if( params["srt"].value == "secondcol"){`
`    row["CUSTOMERNAME"];`
`} else if( params["srt"].value == "thirdcol"){`
`    row["CONTACTLASTNAME"];`
`}`

Now when executed, selecting the proper column will sort the table based
on the chosen value.

Additional this example has a script that is commented out in the
beforeFactory eventhandler for report. This script is shown below:

` importPackage(Packages.org.eclipse.birt.report.model.api);`
` importPackage(Packages.org.eclipse.birt.report.model.api.elements);`

` delm = reportContext.getReportRunnable().designHandle.getDesignHandle().findElement("mytable");`
` sc = StructureFactory.createSortKey();`
` sc.setKey("row[\"CONTACTLASTNAME\"]");`
` sc.setDirection("asc");`

` ph = delm.getPropertyHandle(TableHandle.SORT_PROP);`
` ph.addItem(sc);`

This script will add a sort condition to a named table at runtime using
the DE API.

I tried above example and it works successfully. I am having a problem
in excel format. I excel when I sort any column it opens a new excel
file with sorted data. Can it be done within same excel file?? Pls. help
me in this regard. I would be very much thankful.