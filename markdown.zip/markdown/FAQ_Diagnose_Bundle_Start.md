Here is how to diagnose problems with a bundle (aka. plug-in) that
doesn't want to start:

  - Start Eclipse with the command line option "`-console`" (this opens
    an OSGi console)
  - In this console, type ` install  `<file:///C:/path_to_your_bundle>
  - The OSGi console should answer with "`Bundle id is 123`", where
    "123" is a number assigned to your bundle
  - Now type: `diag 123`

This should give you a list of missing dependencies, that prevent the
bundle from being started.

[Category:FAQ](Category:FAQ "wikilink")