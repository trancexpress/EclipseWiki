In June 2004, books on Eclipse, other than this one, included the
following:

  - Frank Budinsky et al., *Eclipse Modeling Framework*, Addison-Wesley,
    2004 (http://www.aw.com)

<!-- end list -->

  - Berthold Daum, *Eclipse 2 for Java Developers*, Wiley, 2003
    (http://www.wileyeurope.com)

<!-- end list -->

  - Berthold Daum, *Java-Entwicklung mit Eclipse 2* (German), DPunkt,
    2003 (http://www.dpunkt.de)

<!-- end list -->

  - Berthold Daum, Stefan Franke, and Marcel Tilly, *Web-Entwicklung mit
    Eclipse 3* (German), DPunkt, 2004 (http://www.dpunkt.de)

<!-- end list -->

  - Eric Clayberg and Dan Rubel, *Eclipse: Building Commercial-Quality
    Plug-Ins*, Addison-Wesley, 2004 (http://www.qualityeclipse.com)

<!-- end list -->

  - Bill Dudney, *Eclipse Live*, SourceBeat, 2003
    (http://www.sourcebeat.com)

<!-- end list -->

  - David Gallardo, Ed Burnette, and Robert McGovern, *Eclipse in
    Action: A Guide for the Java Developer*, Manning, 2003
    (http://www.manning.com)

<!-- end list -->

  - Erich Gamma and Kent Beck, *Contributing to Eclipse*,
    Addison-Wesley, 2003 (http://www.aw.com)

<!-- end list -->

  - Wonjin Heo and Jiwon Jun, *Total Eclipse (Korean)*, Youngjin
    Publishing, 2003 (http://www.youngjin.com)

<!-- end list -->

  - Steven Holzner, *Eclipse: A Java Developers Guide*, OReilly, 2004
    (http://www.oreilly.com)

<!-- end list -->

  - Junya Ishikawa et al., *The Complete Eclipse Guidebook: From
    Installation to Plug-In Development* (Japanese), ASCII, 2003
    (http://www.ascii.co.jp)

<!-- end list -->

  - Shinji Miyamoto, Shinichi IIda, and Yu Aoki, *Java Developers Guide
    to Adopting Eclipse* (Japanese), SoftBank Publishing, 2003
    (http://www.sbpnet.jp)

<!-- end list -->

  - William Moore et al., *Eclipse Development using the Graphical
    Editing Framework and the Eclipse Modeling Framework*, IBM RedBooks,
    2003 (http://www.redbooks.ibm.com)

<!-- end list -->

  - Stanford Ng, Stephen Holder, and Matt Scarpino, *JFace/SWT in
    Action*, Manning, 2003 (http://www.manning.com)

<!-- end list -->

  - Steve Northover and Mike Wilson, *SWT: The Standard Widget Toolkit*,
    Addison-Wesley, 2004 (http://www.aw.com)

<!-- end list -->

  - Joe Pluta, *Eclipse: Step by Step*, MC Press, 2003
    (http://www.mc-store.com)

<!-- end list -->

  - Sherry Shavor et al., *The Java Developers Guide to Eclipse*,
    Addison-Wesley, 2003 (http://www.aw.com)

<!-- end list -->

  - Carlos Valcarcel, *Eclipse Kick Start*, Sams Publishing, 2004
    (http://www.samspublishing.com)

<!-- end list -->

  - Rob Warner and Robert Harris, *The Definitive Guide to SWT and
    JFace*, Apress, 2004 (http://www.apress.com)

<!-- end list -->

  - Seongjun Yun, Sang-Min Cho, and Jeong Il Song, *Eclipse: Reinforcing
    the Java world* (Korean), Hybird, 2003 (http://hybird.net)