## How to stop Connection from moving when Nodes are moved?

for this to take place we need to understand the concept of
fixedconnectionAnchor. Try to extend the class AbstractConnectionAnchor
and override the mehods getLocation() and the getOwner() method to suit
to your needs.

Then go to the editpart you wish the connection to stick to and just
write the following code -

`public ConnectionAnchor getTargetConnectionAnchor(ConnectionEditPart connEditPart) {`
`  if (fixedAnchor == null) {`
`    fixedAnchor = new FixedConnectionAnchor(getNodeFigure());`
`    getNodeFigure().addAncestorListener(fixedAnchor);`
`  }`
` return fixedAnchor;`
`}`

`public ConnectionAnchor getTargetConnectionAnchor(Request request) {`
`  if (fixedAnchor == null) {`
`      fixedAnchor = new FixedConnectionAnchor(getNodeFigure());`
`      getNodeFigure().addAncestorListener(fixedAnchor);`
`     }`
` return fixedAnchor;`
`}`

\--[arpit.the.star@gmail.com](User:Akhandelwal6.csc.com "wikilink")
00:53, 7 September 2007 (EDT)