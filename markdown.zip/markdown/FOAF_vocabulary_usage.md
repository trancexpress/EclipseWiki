{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}} The
[Persona vocabulary](Persona_vocabulary "wikilink") imports
[FOAF](http://xmlns.com/foaf/0.1) and uses some of the classes and
attributes it defines.

## UML Overview

Classes and attributes from FOAF:

![Foaf_2.0.120.png](Foaf_2.0.120.png "Foaf_2.0.120.png")

## Classes

Used:

  - Document
  - PersonalProfileDocument
  - Image

Not used:

  - OnlineAccount
  - OnlineEcommerceAccount
  - OnlineGamingAccount
  - OnlineChatAccount

## Attributes Used

  - status
  - myersBriggs
  - geekcode
  - aimChatID
  - skypeId
  - icqChatID
  - img
  - yahooID
  - msnChatID
  - made
  - maker
  - depicts
  - depiction
  - knows
  - page
  - homepage
  - weblog
  - openid
  - thumbnail
  - tipjar
  - schoolHomepage
  - workplaceHomepage
  - workInfoHomepage

## Attributes Not Used

  - account
  - accountName
  - accountServiceHomepage
  - age - use fp:age (as a presentation value computed from vcard:bday
    raw data)
  - birthday - use p:birthday
  - gender - use p:gender
  - mbox - use vcard:email
  - mbox_sha1
  - phone - use vcard:tel
  - holdsAccount - archaic: use (foaf:) account

## Links

  - [Persona Data Model 2.0](Persona_Data_Model_2.0 "wikilink")