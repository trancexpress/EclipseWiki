back to [slang DSL](slang_DSL "wikilink")

## Flow

A flow is the basic executable unit of slang. It represents a process
that can be described in a number of ways and that can perform a job
relevant to the end user. Each flow consists of a workflow describing
the exact tasks (one or more) that are performed during the execution a
flow. A flow can be used by other flows as a single task.

| Property | Required | Default              | Description                                                      |
| -------- | -------- | -------------------- | ---------------------------------------------------------------- |
| name     | V        | N\\A                 | The name of the flow                                             |
| inputs   |          |                      | List of inputs (see [Inputs](Inputs "wikilink"))                 |
| workflow | V        |                      | Describes the flow tasks and navigation                          |
| results  |          | \- SUCCESS - FAILURE | Possible results of the flow (see [Results](Results "wikilink")) |
| outputs  |          |                      | List of outputs (see [Outputs](Outputs "wikilink"))              |


<code> sample:

` namespace: slang.sample.flows`
` imports:`
` - ops: slang.ops.operations`
` flow:`
`   name: SimpleFlow`
`   inputs:`
`   - input_1`
`   - input_2`
`   - input_3`
`   workflow:`
`     CheckWeather:`
`       do:`
`         ops.check_Weather:`
`           city: input_1`
`       publish:`
`         weather`
`     PrintWeather:`
`       operation:`
`         ops.print:`
`             - text:  "'the weather in' + input_1 + ' is:' + weather"`

</code>

### Workflow

Describe the workflow of the flow, and contains the different tasks and
the navigations between them.

  - The first task in the workflow is the begin task of the flow.
  - on_failure is a reserved key.
  - A default go_to, overrides the following:
      - result of FAILURE goes to on_failure
      - result of SUCCESS goes to the next step
  - Every task can use: predefined operation, inline operation or sub
    flow, see [Task](Task "wikilink")

| Property    | Required | Default | Description                                        |
| ----------- | -------- | ------- | -------------------------------------------------- |
| on_failure |          |         | the default task FAILURE result should navigate to |

<code> sample:

` workflow:`
`   first_task:`
`     do:`
`       some_operation:`
`         - operation_input_1: flow_input_3`
`         - operation_input_2`
`         - operation_input_3`
`     publish:`
`       flow_var: some_op_output`
`     go_to:`
`     #how to handle operation that have non-default result`
`     #we'll use the default navigation as well: FAIL -> on_failure, SUCCESS -> next task (in our case second_task)`
`       NON_DEFAULT_RESULT:`
`         task_5:`
`           do:`
`             some_other_operation:`
`               - input_1: flow_input_1`
`               - input_2`
`         task_6:`
`           do:`
`             my_operation:`
`               - input_1: flow_input_1`
`               - input_2`
`           go_to: #override the default navigation, in case of success go to 'first task'`
`             SUCESS: first_task`
`   second_task:`
`     do:#sample of in-line operation`
`       inputs:`
`         - input_1`
`         - input_2`
`       action:`
`         python_file: script_file`
`       results:`
`         OOPS: statusCode == None`
`         SUCCESS: statusCode == 'created!'`
`         FAIL: statusCode == 'not going to happen ;('`
`       outputs:`
`         - some_output`
`     publish:`
`       flow_var_7: some_output`
`     go_to:`
`       OOPS: task_6`
`   on_failure:`
`     Send_Mail:`
`       do:`
`         ops.send_mail:`
`           from: score team`
`           subject: not nice`
`           body: fail no good`
`           username: smtp_user`
`           password: smtp_paswword`
`       go_to:`
`         SUCCESS: FAIL`

</code>