Eclipse developers and committers tend to say funny things sometimes...
this page is dedicated to those funny things:

"The reception was nice as well, though I found out a disturbing secret.
Mike Milinkovich is a closet Modeling Redneck. Apparently he believes,
and I quote, "Modeling is stupid" . Rich and I were going to bitch slap
him; actually mostly just me, but Rich probably would have helped
because he's ever so helpful. Instead I did the politically correct
thing and explained that the only thing more stupid than drawing a box
called X with a compartment called y, would be to write an interface
called X with getY and setY methods, a class classed XImpl, with a getY
and setY methods as well as a y field and method bodies to update y, a
factory to create an XImpl, some code to serialize X's y feature, and
finally some code to deserialize an X's y feature. Around this point he
started to glaze over so I'm sure I was highly convincing that not only
is not modeling stupid, but so is Ed. He's a very insightful person\!"

\--- [Ed
Merks](http://ed-merks.blogspot.com/2007/10/eclipse-summit-europe-day-two-big.html)

-----

<zx> s1m0ne: the best GUI builder imho for Eclipse is WindowBuilder

<zx> s1m0ne: free for open-source people, but costs $$$ for commercial

<zx> s1m0ne: not all things are free in life ;/ still waiting on free
beer

<s1m0ne> zx: cool thanks - I can't get funding for a wall calendar so
... I might check VE still - maybe I can get VE to do what we want for
SWT work - we are just looking into it, thanks \!

<zx> s1m0ne: sounds like you work at IBM

  - zx ducks :)

<s1m0ne> zx: (whistles)

-----

<toulmean> d_a_carver: dude, I'm French. That's why I'm so annoying.
And I can't see your stuff.

-----

<huebner> nickboldt: ping

  - huebner left the chat room.

<Kellindil> wouhou nick has found a way to kick people on pings :p