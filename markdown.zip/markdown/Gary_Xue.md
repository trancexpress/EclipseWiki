Gary Xue is currently working for Actuate Corporation to develop its
enterprise reporting platform. He is a committer and project lead for
the Eclipse BIRT project. Gary has 12 years of experience developing
Business Intelligence solutions. He holds a M.S. in Computer Science
from the University of Maryland.