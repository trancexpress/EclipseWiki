## [Eclipse Collections](https://www.eclipse.org/collections/)

Eclipse Collections is a collections framework for Java with optimized
data structures and a rich, functional and fluent API

**Relevant Issues:** ["Good first issues" to
contribute](https://github.com/eclipse/eclipse-collections/issues?q=is%3Aissue+is%3Aopen+label%3A%22good+first+issue%22)

**Skills required:** Java

**Possible Mentor:** TBD

## [Eclipse KUKSA.val](https://github.com/eclipse/kuksa.val)

KUKSA.val is a in-vehicle datserver that provides data about an Vehicle
to applications running in a vehicle. I implements standards jointly
developed by [Genivi](https://www.genivi.org/) and
[W3C](https://www.w3.org/auto/wg/).

KUKSA.val can be deployed by a manufacturer inside a vehicle computer as
well as used external (e.g. on a PI) connected to a vehicle's OBD Port
or CAN busses.

**Relevant Issues:** ["Help Wanted"
issues](https://github.com/eclipse/kuksa.val/issues?q=is%3Aissue+is%3Aopen+label%3A%22help+wanted%22)

**Demo video**: [KUKSA.val DBC
feeder](https://www.eclipse.org/kuksa/blog/2020/08/18/2020-08-18-dbc/)

**Skills required:** CPP

**Mentors:** [Sebastian
Schildt](https://accounts.eclipse.org/users/sschildt), [Wenwen
Chen](https://accounts.eclipse.org/users/wchenl8e)

### Topic: Support for the VISS2 messaging protocol.

The kuksa.val tree of in-vehicle data is provided via the W3C VISS
(Vehicle Information Service Specification) protocol based on
websockets. Currently version 1 of this protocol is supported
[1](https://www.w3.org/TR/vehicle-information-service/#message-structure).
We should upgrade the code support the upcoming VISS2 websocket standard
that can be found here
[2](https://github.com/w3c/automotive/tree/gh-pages/spec)

This task includes updating the code and add missing features to support
(a significant chunk) of the VISS2 messaging protocol. It does not
necessarily include the more generic architecture suggestions around
security deployment also given in the VISS spec

**Skills required:** CPP

**Possible Mentor:** [Sebastian
Schildt](https://accounts.eclipse.org/users/sschildt), [Wenwen
Chen](https://accounts.eclipse.org/users/wchenl8e)

## [Eclipse Lemminx](https://theia-ide.org/)

Eclipse Lemminx is an XML Language Server.

**Relevant Issues:** ["Good first issues" to
contribute](https://github.com/eclipse/lemminx/issues?q=is%3Aissue+is%3Aopen+label%3A%22good+first+issue%22)

**Skills required:** Java, XML

**Possible Mentor:** TBD

## [Eclipse SWTChart](http://eclipse.org/swtchart)

SWTChart is a powerful library to create charts and display data using
SWT. It can be easily used in Java desktop applications. Only a few
lines of code are necessary to create interactive and feature rich
charts:

``` java
public class MyChart extends MassSpectrumChart {

    public MyChart(Composite parent) {
        super(parent, SWT.NONE);
        initialize();
    }

    private void initialize() {

        IChartSettings chartSettings = getChartSettings();
        chartSettings.setCreateMenu(true);
        applySettings(chartSettings);
        //
        List<IBarSeriesData> barSeriesDataList = new ArrayList<IBarSeriesData>();
        IBarSeriesData barSeriesData = new BarSeriesData(SeriesConverter.getSeriesXY(SeriesConverter.BAR_SERIES_1));
        barSeriesDataList.add(barSeriesData);
        //
        addSeriesData(barSeriesDataList);
    }
}
```


The source code is located here and can easily be cloned:
<https://github.com/eclipse/swtchart/>
If you are interested in one of the topics you have to apply on the
[mailing list](https://dev.eclipse.org/mailman/listinfo/swtchart-dev).

### Topic: Support for Radar- and Spider Charts

SWTChart currently supports line-, scatter- and bar charts. Single and
multiLevel pie charts have been added as a Google Summer of Code project
in 2020. A nice enhancement would be to support also radar as well as
spider charts:

  - <https://en.wikipedia.org/wiki/Radar_chart>

**Skills required:** Java, SWT

**Possible Mentor:** [Philip
Wenig](https://accounts.eclipse.org/users/phwenig)

## [Eclipse Theia](https://theia-ide.org/)

Eclipse Theia is a cloud & desktop IDE framework implemented in
TypeScript.

**Relevant Issues:** ["Good first issues" to
contribute](https://github.com/eclipse-theia/theia/issues?q=is%3Aissue+is%3Aopen+label%3A%22good+first+issue%22)

**Skills required:** Node.js

**Possible Mentor:** TBD

## [Eclipse Dash License Tool](https://github.com/eclipse/dash-licenses)

The Eclipse Dash License Tool identifies the licenses of content.

Each individual bit of content is identified by its ClearlyDefined id.
This id uniquely defines, for example, a particular version of a JAR
file, or a particular version of an NPM module. This tool knows how to
read and convert Maven coordinates and NPM ids into ClearlyDefined ids.

### Project idea: Language and Tool support

This is very much a research topic. We need to extend the tool to
support other languages and build technologies, including Python.
Specifically, we need a means of extracting dependency information from
a Python build, converting into an acceptable form, so that we can feed
it to the command line tool.

Skills required: Entry level Python. Intermediate Java. Experience with
BASH.

Possible mentor: Wayne Beaton

### Project idea: License Tool server

The license tool has a feature by which is creates review requests for
content that is identified as requiring further investigation by the
Eclipse Foundation's intellectual property management team. These
requests are filed as issues against our GitLab instance.

The tool includes information with these requests, possibly including
the license of the corresponding content and a pointer to the source. We
need a process that pulls these open review requests using the GitLab
APIs, and--in the case where a request includes a pointer to
source--grabs that source, runs it through \[Scancode Toolkit
<https://github.com/nexB/scancode-toolkit>\], and posts the results on
the issue, and in cases where the licenses discovered by scancode match
our approved list, resolve the issue.

Our strong preference is that the process be authored in Java, but other
options are possible.

Skills required: Proficiency with Java, experience with GitLab or
similar (e.g. GitHub).

Possible mentor: Wayne Beaton

## Help Wanted

[Eclipse Bugzilla](https://bugs.eclipse.org/)

Any issue listed as *helpwanted* is a potential GSoC project idea.

  - 439299 \[Import/Export\] Expanded Export Wizard with sub-categories
    auto-collapses
  - 571070 "Generate equals/hashCode" dialog should default to use
    Objects.equals/hashCode
  - 570785 Extract method refactoring provide better default names
  - 570697 Projects imported from ZIP archive do not automatically add
    included JARs to classpath
  - 552710 Add External JARs selection ignored when creating a new
    project

A complete list is available
[here](https://bugs.eclipse.org/bugs/buglist.cgi?bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&columnlist=product%2Ccomponent%2Cassigned_to%2Cbug_status%2Cresolution%2Cshort_desc%2Cchangeddate&keywords=helpwanted%2C%20bugday%2C%20&keywords_type=allwords&list_id=19186819&order=changeddate%20DESC%2Cbug_id%20DESC&query_format=advanced).

[Eclipse CBI](CBI "wikilink")

The Eclipse Common Build Infrastructure (CBI) is an initiative combining
infrastructure, services, technologies and best practices for building,
testing and delivering software at the Eclipse Foundation.

  - ["Enhancement"
    issues](https://github.com/search?q=org%3Aeclipse-cbi+label%3Aenhancement+state%3Aopen&type=Issues&ref=advsearch&l=&l=)