{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}
![Higgins_logo_76Wx100H.jpg](Higgins_logo_76Wx100H.jpg
"Higgins_logo_76Wx100H.jpg") HBX supports a basic kind of automatic form
filling. If the Relying Party Agent (RPA) site's form follows a specific
set of conventions, and if a "form map" exists on the Higgins-based
server supporting HBX and if the schema of the Context associated with
the RPA site contains the properties mentioned in the form map, then HBX
will automatically fill in the fields of the form with the values from
the properties of the user's Digital Subject in the Context.

When the user points their browser/HBX at a page on the RPA site that
contains a web form, HBX asks ISS for the form map that corresponds to
this form. If the form map exists HBX uses it to copy the property
values from its cached copy of the user's Digital Subject into the
corresponding web form fields. A form map is an association between the
HTML field names and the Digital Subject's property names.

For example, if the web form asked for wall color, and the form map
existed then HBX could look up the schema attribute that corresponds to
wall color (say the URI "wall coloring"), lookup the value of the "wall
coloring" property, and automaticaly fill in the value into the form
field.

When HBX requests a form map from the Higgins server it identifies the
form map by concatenating:

  -
    host+name+id

where:

  - host is the host site
  - name is the name attribute of the form
  - id = "rpformfilling"

## RPA Site HTML Coding

The

<form>

MUST have an *id* attribute whose value MUST be "rpformfilling" to the
entire form. The

<form>

MUST have a *name* attribute, its value is arbitrary.

For example:

<form name="edit_form" method="post" id="rpformfilling"
                enctype="multipart/form-data"
                class="enableUnloadProtection"
                action="http://beta.idmashup.net/profiles/Maxim/base_edit">

Every individual element within the form MUST have a **unique** *id*
attribute.

See also [HBX Screen Scrape](HBX_Screen_Scrape "wikilink")

[Category:Higgins Obsolete
Pages](Category:Higgins_Obsolete_Pages "wikilink")