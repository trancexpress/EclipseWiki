{{\#eclipseproject:technology.higgins}}
![Higgins_logo_76Wx100H.jpg](Higgins_logo_76Wx100H.jpg
"Higgins_logo_76Wx100H.jpg")

## Version 1.1.105

  - This page describes changes made from version [HOWL Update
    1.1.104](HOWL_Update_1.1.104 "wikilink")

## Changes

1.  Changed selfInstanceSubject to a simple boolean attribute on the
    policy. If true this policy applies to the current IdAS consumer.
2.  Added four "self" operations that all specialize a new attribute
    called "selfOperation" that is a sub-attribute of "operation".
      - higgins:selfOperation: Abstract operation on all attributes of
        entity S(elf) (or the set of attributes of S indicated by the
        onAttribute predicates of this Policy), where S is an instance
        of the class indicated by the range AND S is a representation of
        the current IdAS consumer. Sub-attribute of higgins:operation.
      - selfAdd (sub-attribute of selfOperation): Must be used in
        conjunction with one or more onAttributes. These selected
        attributes of the "self" Entity may be added.
      - selfDelete (sub-attribute of selfOperation): Selected attributes
        (as specified by onAttribute predicates) else all attributes of
        "self" Entity may be deleted.
      - selfModify (sub-attribute of selfOperation): Selected attributes
        (as specified by onAttribute predicates) else all attributes of
        "self" Entity may be modified.
      - selfDelete (sub-attribute of selfOperation): Selected attributes
        (as specified by onAttribute predicates) else all attributes of
        "self" Entity may be read.

## RDF/XML Snapshot

` `<rdf:RDF>
`   xmlns:rdf="`<http://www.w3.org/1999/02/22-rdf-syntax-ns#>`"`
`   xmlns:xsd="`<http://www.w3.org/2001/XMLSchema#>`"`
`   xmlns:rdfs="`<http://www.w3.org/2000/01/rdf-schema#>`"`
`   xmlns:owl="`<http://www.w3.org/2002/07/owl#>`"`
`   xmlns:skos="`<http://www.w3.org/2004/02/skos/core#>`"`
`   xmlns:owl11="`<http://www.w3.org/2006/12/owl11#>`"`
`   xmlns:higgins="`<http://www.eclipse.org/higgins/ontologies/2008/6/higgins#>`"`
` xml:base="`<http://www.eclipse.org/higgins/ontologies/2008/6/higgins>`">`
` `<owl:Ontology rdf:about="">
`   `<owl:versionInfo>`1.1.105`</owl:versionInfo>
`   `<rdfs:label>`Higgins Ontology`</rdfs:label>
`   `<rdfs:comment>`Higgins Context Provider developers must commit to this ontology. They can either use it as their only ontology, or create their own ontology that imports this one.`</rdfs:comment>
` `</owl:Ontology>
` `<owl:Class rdf:ID="TimeSpan">
`   `<rdfs:label xml:lang="en">`Time span`</rdfs:label>
`   `<rdfs:subClassOf>
`     `<owl:Restriction>
`       `<owl:onProperty>
`         `<owl:DatatypeProperty rdf:ID="validTo"/>
`       `</owl:onProperty>
`       `<owl:maxCardinality>`1`</owl:maxCardinality>
`     `</owl:Restriction>
`   `</rdfs:subClassOf>
`   `<rdfs:subClassOf>
`     `<owl:Restriction>
`       `<owl:onProperty>
`         `<owl:DatatypeProperty rdf:ID="validFrom"/>
`       `</owl:onProperty>
`       `<owl:maxCardinality>`1`</owl:maxCardinality>
`     `</owl:Restriction>
`   `</rdfs:subClassOf>
`   `<rdfs:comment xml:lang="en">`A duration of time`</rdfs:comment>
` `</owl:Class>
` `<owl:Class rdf:ID="Entity">
`   `<rdfs:subClassOf>
`     `<owl:Restriction>
`       `<owl:maxCardinality rdf:datatype="http://www.w3.org/2001/XMLSchema#int"
        >`1`</owl:maxCardinality>
`       `<owl:onProperty>
`         `<owl:DatatypeProperty rdf:ID="entityId"/>
`       `</owl:onProperty>
`     `</owl:Restriction>
`   `</rdfs:subClassOf>
`   `<rdfs:subClassOf rdf:resource="http://www.w3.org/2002/07/owl#Thing"/>
`   `<rdfs:label xml:lang="en">`Higgins Entity`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`Object within a Context`</rdfs:comment>
` `</owl:Class>
` `<owl:Class rdf:ID="Context">
`   `<rdfs:label xml:lang="en">`Context`</rdfs:label>
`   `<rdfs:subClassOf>
`     `<owl:Restriction>
`       `<owl:cardinality rdf:datatype="http://www.w3.org/2001/XMLSchema#int"
        >`1`</owl:cardinality>
`       `<owl:onProperty>
`         `<owl:DatatypeProperty rdf:ID="contextId"/>
`       `</owl:onProperty>
`     `</owl:Restriction>
`   `</rdfs:subClassOf>
`   `<rdfs:subClassOf rdf:resource="http://www.w3.org/2002/07/owl#Thing"/>
`   `<rdfs:comment xml:lang="en">`A singleton object that is part of the set of data objects contained within a context, and represents the containing Context itself.`</rdfs:comment>
` `</owl:Class>
` `<owl:Class rdf:about="http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement"/>
` `<owl:Class rdf:ID="AccessControl">
`   `<rdfs:subClassOf>
`     `<owl:Class rdf:ID="Policy"/>
`   `</rdfs:subClassOf>
`   `<rdfs:label xml:lang="en">`Access control`</rdfs:label>
`   `<rdfs:comment rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`Policy related to Access Control and data sharing`</rdfs:comment>
` `</owl:Class>
` `<owl:Class rdf:ID="Agent">
`   `<rdfs:subClassOf rdf:resource="#Entity"/>
`   `<rdfs:comment xml:lang="en">`An agent (eg. person, group, software or physical artifact).`</rdfs:comment>
`   `<rdfs:label xml:lang="en">`Agent`</rdfs:label>
` `</owl:Class>
` `<owl:Class rdf:ID="Person">
`   `<rdfs:subClassOf rdf:resource="#Agent"/>
`   `<rdfs:comment xml:lang="en">`A contextualized aspect of a person.`</rdfs:comment>
`   `<rdfs:label xml:lang="en">`Person`</rdfs:label>
` `</owl:Class>
` `<owl:Class rdf:ID="Group">
`   `<rdfs:subClassOf rdf:resource="#Agent"/>
`   `<rdfs:comment xml:lang="en">`A class of Agents.`</rdfs:comment>
`   `<rdfs:label xml:lang="en">`Group`</rdfs:label>
` `</owl:Class>
` `<owl:Class rdf:ID="Organization">
`   `<rdfs:subClassOf rdf:resource="#Agent"/>
`   `<rdfs:comment xml:lang="en">`An organization.`</rdfs:comment>
`   `<rdfs:label xml:lang="en">`Organization`</rdfs:label>
` `</owl:Class>
` `<owl:Class rdf:ID="Statement">
`   `<rdfs:label xml:lang="en">`Higgins Statement`</rdfs:label>
`   `<rdfs:subClassOf>
`     `<owl:Restriction>
`       `<owl:maxCardinality rdf:datatype="http://www.w3.org/2001/XMLSchema#int"
        >`1`</owl:maxCardinality>
`       `<owl:onProperty>
`         `<owl:DatatypeProperty rdf:ID="authority"/>
`       `</owl:onProperty>
`     `</owl:Restriction>
`   `</rdfs:subClassOf>
`   `<rdfs:subClassOf>
`     `<owl:Restriction>
`       `<owl:onProperty>
`         `<owl:DatatypeProperty rdf:ID="lastVerifiedFromSource"/>
`       `</owl:onProperty>
`       `<owl:maxCardinality>`1`</owl:maxCardinality>
`     `</owl:Restriction>
`   `</rdfs:subClassOf>
`   `<rdfs:subClassOf>
`     `<owl:Restriction>
`       `<owl:onProperty>
`         `<owl:DatatypeProperty rdf:ID="lastModified"/>
`       `</owl:onProperty>
`       `<owl:maxCardinality>`1`</owl:maxCardinality>
`     `</owl:Restriction>
`   `</rdfs:subClassOf>
`   `<rdfs:subClassOf>
`     `<owl:Restriction>
`       `<owl:onProperty>
`         `<owl:DatatypeProperty rdf:ID="lastVerifyAttempt"/>
`       `</owl:onProperty>
`       `<owl:maxCardinality>`1`</owl:maxCardinality>
`     `</owl:Restriction>
`   `</rdfs:subClassOf>
`   `<rdfs:comment xml:lang="en">`A reification of an Entity-attribute-value triple`</rdfs:comment>
` `</owl:Class>
` `<owl:Class rdf:about="#Policy">
`   `<rdfs:label rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`Access Control Policy`</rdfs:label>
`   `<rdfs:subClassOf rdf:resource="#Entity"/>
` `</owl:Class>
` `<owl:ObjectProperty rdf:ID="groupSubject">
`   `<rdfs:comment rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`Relation indicates what Agents are the subject of the Policy by specifying a Group or super-Group, iteratively, the Agents are a member of. {@en|`</rdfs:comment>
`   `<rdfs:subPropertyOf>
`     `<owl:ObjectProperty rdf:ID="subject"/>
`   `</rdfs:subPropertyOf>
`   `<rdfs:label rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`group subject`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="entityRelation">
`   `<rdfs:domain rdf:resource="#Entity"/>
`   `<rdfs:label xml:lang="en">`Entity Relation`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`A directed relation of an unspecified nature between two Entities.`</rdfs:comment>
`   `<rdfs:range rdf:resource="#Entity"/>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="timeSpan">
`   `<rdfs:domain rdf:resource="#Entity"/>
`   `<rdfs:range rdf:resource="#TimeSpan"/>
`   `<rdfs:label xml:lang="en">`time span`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="memberOf">
`   `<rdfs:subPropertyOf>
`     `<owl:ObjectProperty rdf:ID="partOf"/>
`   `</rdfs:subPropertyOf>
`   `<rdfs:label xml:lang="en">`member of`</rdfs:label>
`   `<rdfs:range rdf:resource="#Group"/>
`   `<rdfs:domain rdf:resource="#Agent"/>
`   `<rdfs:comment xml:lang="en">`The Group or Organization of which this Agent is a member.`</rdfs:comment>
`   `<rdfs:range rdf:resource="#Organization"/>
`   `<owl:inverseOf>
`     `<owl:ObjectProperty rdf:ID="member"/>
`   `</owl:inverseOf>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="contextCorrelation">
`   `<rdfs:label xml:lang="en">`context correlation`</rdfs:label>
`   `<rdfs:domain rdf:resource="#Context"/>
`   `<rdfs:range rdf:resource="#Context"/>
`   `<rdfs:comment rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`A directed relation between two Contexts asserted to be representing the same underlying organization or group. (@en}`</rdfs:comment>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="selfDelete">
`   `<rdfs:comment xml:lang="en">`Selected attributes (as specified by onAttribute predicates) else all attributes of "self" Entity may be deleted.`</rdfs:comment>
`   `<rdfs:subPropertyOf>
`     `<owl:AnnotationProperty rdf:ID="selfOperation">
`       `<rdfs:comment xml:lang="en">`Abstract operation on all attributes of entity S(elf) (or the set of attributes of S indicated by the onAttribute predicates of this Policy), where S is an instance of the class indicated by the range AND S is a representation of the current IdAS consumer.`</rdfs:comment>
`       `<rdfs:subPropertyOf>
`         `<owl:AnnotationProperty rdf:ID="operation">
`           `<rdfs:comment xml:lang="en">`Abstract operation allowed on an Entity or a class of Entities. Range is an Entity instance or a class of Entities that define the scope of resource for this Access Control Policy. The scope may be further restricted by the addition of onAttribute properties to only specified Attributes of this Entity or class of Entities.`</rdfs:comment>
`           `<rdfs:label xml:lang="en">`operation`</rdfs:label>
`           `<rdfs:subPropertyOf>
`             `<owl:AnnotationProperty rdf:ID="accessControl">
`               `<rdfs:comment xml:lang="en">`Abstract super-property`</rdfs:comment>
`               `<rdfs:label rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
                >`access control`</rdfs:label>
`               `<rdfs:domain rdf:resource="#AccessControl"/>
`             `</owl:AnnotationProperty>
`           `</rdfs:subPropertyOf>
`           `<rdfs:domain rdf:resource="#AccessControl"/>
`         `</owl:AnnotationProperty>
`       `</rdfs:subPropertyOf>
`       `<rdfs:range rdf:resource="http://www.w3.org/2002/07/owl#Class"/>
`       `<rdfs:label rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
        >`self operation`</rdfs:label>
`     `</owl:AnnotationProperty>
`   `</rdfs:subPropertyOf>
`   `<rdfs:label rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`self delete`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="part">
`   `<rdfs:comment xml:lang="en">`A relationship between an aggregated whole (the domain) and a part of that whole (the range)`</rdfs:comment>
`   `<rdfs:subPropertyOf rdf:resource="#entityRelation"/>
`   `<rdfs:label xml:lang="en">`part`</rdfs:label>
`   `<owl:inverseOf>
`     `<owl:ObjectProperty rdf:about="#partOf"/>
`   `</owl:inverseOf>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="modify">
`   `<rdfs:label xml:lang="en">`Self Instance Modify`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`If not further restricted by onAttribute properties, then instances of the class of Entity indicated by the range may be arbitrarily modified. If restricted, then some or all of the values of the kind(s) of properties/attribute(s) specified by onAttribute properties may be modified.`</rdfs:comment>
`   `<rdfs:subPropertyOf rdf:resource="#operation"/>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="contextRelation">
`   `<rdfs:comment xml:lang="en">`A directed relation between two Contexts`</rdfs:comment>
`   `<rdfs:domain rdf:resource="#Context"/>
`   `<rdfs:range rdf:resource="#Context"/>
`   `<rdfs:label xml:lang="en">`context relation`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="delete">
`   `<rdfs:subPropertyOf rdf:resource="#operation"/>
`   `<rdfs:label xml:lang="en">`Delete`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`If not further restricted by onAttribute properties, then instances of the class of Entity indicted by the range may be deleted from the Context. If restricted, then some or all of the values of the kind(s) of properties/attribute(s) specified by onAttribute properties may be deleted.`</rdfs:comment>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:about="#subject">
`   `<rdfs:label xml:lang="en">`subject`</rdfs:label>
`   `<rdfs:domain rdf:resource="#AccessControl"/>
`   `<rdfs:subPropertyOf rdf:resource="#accessControl"/>
`   `<rdfs:comment xml:lang="en">`If present on an Access Control Policy the policy is restricted to apply only to this Attribute. {@en}`</rdfs:comment>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="add">
`   `<rdfs:comment xml:lang="en">`If not further restricted by onAttribute properties, then new instances of the class of Entity indicated by the range may be added to the Context. If restricted, then a new instance of the kinds of properties/attribute(s) specified by onAttribute may be added or new values added.`</rdfs:comment>
`   `<rdfs:label xml:lang="en">`Add`</rdfs:label>
`   `<rdfs:subPropertyOf rdf:resource="#operation"/>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="read">
`   `<rdfs:subPropertyOf rdf:resource="#operation"/>
`   `<rdfs:label xml:lang="en">`Read`</rdfs:label>
`   `<rdfs:comment>`If not further restricted by onAttribute properties, then instances of the class of Entity indicted by the range may be read. If restricted, then some or all of the values of the kind(s) of properties/attribute(s) specified by onAttribute properties may be read. {@en`</rdfs:comment>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:about="#partOf">
`   `<rdfs:comment xml:lang="en">`A relationship between a part (the domain) and an agregated whole (the range)`</rdfs:comment>
`   `<rdfs:subPropertyOf rdf:resource="#entityRelation"/>
`   `<rdfs:label xml:lang="en">`part`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:about="#member">
`   `<rdfs:domain rdf:resource="#Organization"/>
`   `<rdfs:subPropertyOf rdf:resource="#part"/>
`   `<rdfs:label xml:lang="en">`member`</rdfs:label>
`   `<rdfs:domain rdf:resource="#Group"/>
`   `<rdfs:range rdf:resource="#Agent"/>
`   `<rdfs:comment xml:lang="en">`A relationship between a Group or Organization and its member Agent (the range)`</rdfs:comment>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="selfAdd">
`   `<rdfs:comment xml:lang="en">`Must be used in conjunction with one or more onAttributes. These selected attributes of the "self" Entity may be added.`</rdfs:comment>
`   `<rdfs:subPropertyOf rdf:resource="#selfOperation"/>
`   `<rdfs:label rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`self add`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="selfModify">
`   `<rdfs:comment xml:lang="en">`Selected attributes (as specified by onAttribute predicates) else all attributes of "self" Entity may be modified.`</rdfs:comment>
`   `<rdfs:subPropertyOf rdf:resource="#selfOperation"/>
`   `<rdfs:label xml:lang="en">`Modify`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="entityCorrelation">
`   `<rdfs:comment xml:lang="en">`A directed relation between two Entities that are asserted to be representing the same person, group, object or concept`</rdfs:comment>
`   `<rdfs:range rdf:resource="#Entity"/>
`   `<rdfs:domain rdf:resource="#Entity"/>
`   `<rdfs:label xml:lang="en">`entity correlation`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="selfRead">
`   `<rdfs:comment xml:lang="en">`Selected attributes (as specified by onAttribute predicates) else all attributes of "self" Entity may be read.`</rdfs:comment>
`   `<rdfs:subPropertyOf rdf:resource="#selfOperation"/>
`   `<rdfs:label rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`self read`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:ObjectProperty rdf:ID="agentSubject">
`   `<rdfs:comment xml:lang="en">`Relation indicates what Agent or class of Agents is the subject of the Policy.`</rdfs:comment>
`   `<rdfs:subPropertyOf rdf:resource="#subject"/>
`   `<rdfs:range rdf:resource="#Agent"/>
`   `<rdfs:label rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`agent subject`</rdfs:label>
` `</owl:ObjectProperty>
` `<owl:DatatypeProperty rdf:about="#contextId">
`   `<rdfs:comment xml:lang="en">`Context Id. A required attribute of all Context objects. Value is a Context UDI string.`</rdfs:comment>
`   `<rdfs:domain rdf:resource="#Context"/>
`   `<rdfs:range>
`     `<owl:DataRange rdf:ID="ContextUDI">
`       `<rdfs:comment xml:lang="en">`Context UDI`</rdfs:comment>
`       `<rdfs:label xml:lang="en">`context UDI`</rdfs:label>
`       `<owl11:onDataRange rdf:resource="http://www.w3.org/2001/XMLSchema#string"/>
`     `</owl:DataRange>
`   `</rdfs:range>
`   `<rdfs:label xml:lang="en">`context id`</rdfs:label>
` `</owl:DatatypeProperty>
` `<owl:DatatypeProperty rdf:about="#lastVerifiedFromSource">
`   `<rdfs:range rdf:resource="http://www.w3.org/2001/XMLSchema#date"/>
`   `<rdfs:domain rdf:resource="#Statement"/>
`   `<rdfs:label xml:lang="en">`last verified from source`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`The timestamp of the most recent time that this Statement was verified from data from its associated higgins:source.`</rdfs:comment>
` `</owl:DatatypeProperty>
` `<owl:DatatypeProperty rdf:about="#lastModified">
`   `<rdfs:label xml:lang="en">`last modified`</rdfs:label>
`   `<rdfs:domain rdf:resource="#Statement"/>
`   `<rdfs:range rdf:resource="http://www.w3.org/2001/XMLSchema#dateTime"/>
`   `<rdfs:comment xml:lang="en">`The most recent modification date-time.`</rdfs:comment>
` `</owl:DatatypeProperty>
` `<owl:DatatypeProperty rdf:about="#authority">
`   `<rdfs:comment xml:lang="en">`The Agent that is the authority for this Statement.`</rdfs:comment>
`   `<rdfs:domain rdf:resource="#Statement"/>
`   `<rdfs:label xml:lang="en">`authority`</rdfs:label>
`   `<rdfs:range rdf:resource="#Agent"/>
` `</owl:DatatypeProperty>
` `<owl:DatatypeProperty rdf:ID="creator">
`   `<rdfs:range rdf:resource="#Agent"/>
`   `<rdfs:domain rdf:resource="#Statement"/>
`   `<rdfs:label xml:lang="en">`creator`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`Agent that made this statement.`</rdfs:comment>
` `</owl:DatatypeProperty>
` `<owl:DatatypeProperty rdf:about="#validTo">
`   `<rdfs:range rdf:resource="http://www.w3.org/2001/XMLSchema#date"/>
`   `<rdfs:domain rdf:resource="#TimeSpan"/>
`   `<rdfs:label xml:lang="en">`to`</rdfs:label>
` `</owl:DatatypeProperty>
` `<owl:DatatypeProperty rdf:about="#lastVerifyAttempt">
`   `<rdfs:domain rdf:resource="#Statement"/>
`   `<rdfs:range rdf:resource="http://www.w3.org/2001/XMLSchema#date"/>
`   `<rdfs:label xml:lang="en">`last verify attempt`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`The timestamp of the most recent unsuccessful attempt to verify this Statement against data in its source.`</rdfs:comment>
` `</owl:DatatypeProperty>
` `<owl:DatatypeProperty rdf:about="#validFrom">
`   `<rdfs:domain rdf:resource="#TimeSpan"/>
`   `<rdfs:range rdf:resource="http://www.w3.org/2001/XMLSchema#date"/>
`   `<rdfs:label xml:lang="en">`from`</rdfs:label>
` `</owl:DatatypeProperty>
` `<owl:DatatypeProperty rdf:about="#entityId">
`   `<rdfs:domain rdf:resource="#Entity"/>
`   `<rdfs:label xml:lang="en">`entity id`</rdfs:label>
`   `<rdfs:comment rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`Uniquely identifies this Entity within its containing Context. The identifier may be an Entity UDI or a string.`</rdfs:comment>
`   `<rdfs:range>
`     `<owl:DataRange rdf:ID="RelativeEntityUDI">
`       `<owl11:onDataRange rdf:resource="http://www.w3.org/2001/XMLSchema#string"/>
`       `<rdfs:comment xml:lang="en">`Relative Entity UDI`</rdfs:comment>
`       `<rdfs:label xml:lang="en">`relative entity UDI`</rdfs:label>
`     `</owl:DataRange>
`   `</rdfs:range>
` `</owl:DatatypeProperty>
` `<owl:DataRange rdf:ID="AbsoluteEntityUDI">
`   `<owl11:onDataRange rdf:resource="http://www.w3.org/2001/XMLSchema#string"/>
`   `<rdfs:label xml:lang="en">`absolute entity UDI`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`Absolute Entity UDI`</rdfs:comment>
` `</owl:DataRange>
` `<owl:AnnotationProperty rdf:ID="selfSubject">
`   `<rdfs:comment xml:lang="en">`If true, this policy's subject is implicitly defined as the current Idas consumer.`</rdfs:comment>
`   `<rdfs:subPropertyOf rdf:resource="#accessControl"/>
`   `<rdfs:range rdf:resource="http://www.w3.org/2001/XMLSchema#boolean"/>
`   `<rdfs:label rdf:datatype="http://www.w3.org/2001/XMLSchema#string"
    >`self subject`</rdfs:label>
` `</owl:AnnotationProperty>
` `<owl:AnnotationProperty rdf:ID="onAttribute">
`   `<rdfs:label xml:lang="en">`on attribute`</rdfs:label>
`   `<rdfs:subPropertyOf rdf:resource="#accessControl"/>
`   `<rdfs:comment xml:lang="en">`If present on an Access Control Policy the policy is restricted to apply only to the type of property indicated by the range of this relation within the Entity or set of Entities indiated by this Policy's operation relation.`</rdfs:comment>
` `</owl:AnnotationProperty>
` `<owl:AnnotationProperty rdf:ID="category">
`   `<rdfs:range rdf:resource="http://www.w3.org/2004/02/skos/core#Concept"/>
`   `<rdfs:label xml:lang="en">`category`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`Indicates the skos:Concept category to which this Attribute belongs.`</rdfs:comment>
`   `<rdf:type rdf:resource="http://www.w3.org/1999/02/22-rdf-syntax-ns#Property"/>
` `</owl:AnnotationProperty>
` `<rdfs:Property rdf:ID="displayOrder">
`   `<rdfs:range rdf:resource="http://www.w3.org/2001/XMLSchema#positiveInteger"/>
`   `<rdfs:label xml:lang="en">`display order`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`Used to aid in creating intuitive user interfaces. The UI displays sets of Attributes in an order determined by the relative order of the displayOrder of each individual Attribute.`</rdfs:comment>
`   `<rdf:type rdf:resource="http://www.w3.org/2002/07/owl#AnnotationProperty"/>
` `</rdfs:Property>
` `<owl:DataRange rdf:ID="RelativeAttributeUDI">
`   `<owl11:onDataRange rdf:resource="http://www.w3.org/2001/XMLSchema#string"/>
`   `<rdfs:label xml:lang="en">`relative attribute UDI`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`Relative attribute UDI`</rdfs:comment>
` `</owl:DataRange>
` `<owl:DataRange rdf:ID="AbsoluteAttributeUDI">
`   `<rdfs:label xml:lang="en">`absolute attribute UDI`</rdfs:label>
`   `<rdfs:comment xml:lang="en">`Absolute Attribute UDI`</rdfs:comment>
`   `<owl11:onDataRange rdf:resource="http://www.w3.org/2001/XMLSchema#string"/>
` `</owl:DataRange>
` `</rdf:RDF>

## See Also

  - [HOWL Update 1.1.106](HOWL_Update_1.1.106 "wikilink")
  - [HOWL Update 1.1.104](HOWL_Update_1.1.104 "wikilink")