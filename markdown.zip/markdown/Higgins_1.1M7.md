{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}

## 1.1M7 (Stable) - Build completed on 25-Aug-09

  - [All 1.1M7
    items](https://bugs.eclipse.org/bugs/buglist.cgi?bug_file_loc=;bug_file_loc_type=allwordssubstr;bug_id=;bugidtype=include;chfieldfrom=;chfieldto=Now;chfieldvalue=;email1=;email2=;emailtype1=substring;emailtype2=substring;field-1-0-0=product;field-1-1-0=target_milestone;field0-0-0=noop;keywords=;keywords_type=allwords;long_desc=;long_desc_type=allwordssubstr;product=Higgins;query_format=advanced;remaction=;short_desc=;short_desc_type=allwordssubstr;status_whiteboard=;status_whiteboard_type=allwordssubstr;target_milestone=1.1M7;type-1-0-0=anyexact;type-1-1-0=anyexact;type0-0-0=noop;value-1-0-0=Higgins;value-1-1-0=1.1M7;value0-0-0=;votes=;query_based_on=)
    For more information about **some** of these, see below.

### Website

  - [273328](https://bugs.eclipse.org/bugs/show_bug.cgi?id=273328)
    Create new downloads page (1832) - **DONE** .
      - We have the completed page deployed
        [here](http://eclipse.org/higgins/downloads.php) on the Higgins
        page.
      - For M7 we are going to focus on fully defining the Windows GTK
        version.
  - [284462](https://bugs.eclipse.org/bugs/show_bug.cgi?id=284462)
    convert mockup to new downloads page - **DONE**
  - [282699](https://bugs.eclipse.org/bugs/show_bug.cgi?id=282699) PHP
    Components pages - deferred to M8
  - Propose we just make static updates to this new download page
    [here](http://eclipse.org/higgins/solutions/my_downloads.php) and
    integrate this page to the website. There will be some solutions
    that may not be ready by M7 to support this (e.g. AIR selector) and
    we will just gray out those rows on the table.

### iPhone Selector

  - [282702](https://bugs.eclipse.org/bugs/show_bug.cgi?id=282702) Move
    projects from Nursery and list components on [Components
    1.1](Components_1.1 "wikilink")

### GTK Selector 1.1-Win

Done:

  - [282693](https://bugs.eclipse.org/bugs/show_bug.cgi?id=282693) Use
    standard Higgins
    [HBX](http://wiki.eclipse.org/Higgins_Browser_Extension) (1980) -
    DONE
  - [273315](https://bugs.eclipse.org/bugs/show_bug.cgi?id=273315) Build
    [Higgins Selector Switch](Higgins_Selector_Switch "wikilink")
    connector for GTK selector (1889) - DONE
  - [273316](https://bugs.eclipse.org/bugs/show_bug.cgi?id=273316) Merge
    all [Higgins Selector Switch](Higgins_Selector_Switch "wikilink")
    connectors (AIR, Cardspace, GTK) into
    [HSS](http://wiki.eclipse.org/Components_1.1#Higgins_Selector_Switch_.28HSS.29)
    (1890) - DONE
  - [282529](https://bugs.eclipse.org/bugs/show_bug.cgi?id=282529)
    Implement support for [CardSync Web
    App](CardSync_Web_App "wikilink") within [I-Card
    Service](I-Card_Service "wikilink") per
    [1](http://wiki.eclipse.org/Selector_Architecture_Harmonization#Server)
    - DONE
  - [282528](https://bugs.eclipse.org/bugs/show_bug.cgi?id=282528)
    Implement [CardSync Web App](CardSync_Web_App "wikilink") RESTful
    binding on Higgins Server per
    [2](http://wiki.eclipse.org/Selector_Architecture_Harmonization#Server)
    - DONE
      - The code for this is completed, but have not checked into
        Higgins yet due to jersey and jaxb libs aren't approved by
        eclipse. Using Azigo developers landing site to hold the
        download for this code.
  - [273321](https://bugs.eclipse.org/bugs/show_bug.cgi?id=273321) For
    future variants: Port HSS to OSX and Linux. (1765) - DONE
  - [282517](https://bugs.eclipse.org/bugs/show_bug.cgi?id=282517) Split
    the shared tcpserver project into multiple projects (1772) - DONE -
    working on merging code to check into Higgins.
  - [282720](https://bugs.eclipse.org/bugs/show_bug.cgi?id=282720)
    Update GTK Selector 1.1-Win wiki page -DONE
  - [282525](https://bugs.eclipse.org/bugs/show_bug.cgi?id=282525) Adapt
    [Local I-Card Service](Local_I-Card_Service "wikilink") (LICS) to
    use [CardSync Web App](CardSync_Web_App "wikilink") per
    [3](http://wiki.eclipse.org/Selector_Architecture_Harmonization#Local_I-Card_Service)
    (2004, 2007, 2008) - DONE

### STS Client

  - [244073](https://bugs.eclipse.org/bugs/show_bug.cgi?id=244073) Add
    WS-Trust 1.3 support - DONE - working on getting checked into
    Higgins
  - [227044](https://bugs.eclipse.org/bugs/show_bug.cgi?id=227044) Add
    SOAP 1.2 support - DONE - working on getting checked into Higgins
      - This work is done - but ran into issue with WS Security spec
        message mode. WS IT framework does not support the protocol as
        extension for WS Security. We will need to create a seperate
        ticket for this for M8. Reference this OSIS test
        [spec](http://osis.idcommons.net/wiki/I5:FeatureTest-Selector_Support_for_WS-Trust_1.3_and_WS-SecurityPolicy_1.2)
      - Would also need to create tickets for STS sever upgrade for SOAP
        1.2 and WSTrust 1.3. This should be done for M8

## See Also

  - [Higgins 1.1M6](Higgins_1.1M6 "wikilink")
  - [Higgins 1.1M8](Higgins_1.1M8 "wikilink")
  - [Higgins 1.1 Plan](Higgins_1.1_Plan "wikilink")

[Category:Higgins Project
Plan](Category:Higgins_Project_Plan "wikilink")