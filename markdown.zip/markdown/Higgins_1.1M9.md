{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}

[All 1.1M9 tasks in
Bugzilla](https://bugs.eclipse.org/bugs/buglist.cgi?bug_file_loc=&bug_file_loc_type=allwordssubstr&bug_id=&bugidtype=include&chfieldfrom=&chfieldto=Now&chfieldvalue=&columnlist=bug_status%2Cshort_desc%2Cassigned_to%2Cstatus_whiteboard%2Ctarget_milestone%2Cbug_severity%2Cpriority&email1=&email2=&emailtype1=substring&emailtype2=substring&field0-0-0=noop&keywords=&keywords_type=allwords&long_desc=&long_desc_type=allwordssubstr&product=Higgins&query_format=advanced&short_desc=&short_desc_type=allwordssubstr&status_whiteboard=&status_whiteboard_type=allwordssubstr&target_milestone=1.1M9&type0-0-0=noop&value0-0-0=&votes=&order=bug_status%2Cbug_id&query_based_on=)

Milestone includes these solutions:

Higgins Selector

  - [AIR Selector 1.1](AIR_Selector_1.1 "wikilink")
  - [IPhone Selector 1.1](IPhone_Selector_1.1 "wikilink")
  - [Android Selector 1.1](Android_Selector_1.1 "wikilink")

Selector Supporting Services

  - [Cloud Selector 1.1](Cloud_Selector_1.1 "wikilink")
  - [I-Card Service 1.1](I-Card_Service_1.1 "wikilink")
  - [CardSync Service 1.1](CardSync_Service_1.1 "wikilink")
    (Experimental)
      - Need to add deployment documentation

Identity Services

  - [STS IdP](STS_IdP "wikilink")
  - [SAML2 IdP](SAML2_IdP "wikilink")
  - [Extensible Protocol RP Website
    1.1](Extensible_Protocol_RP_Website_1.1 "wikilink")

Building Blocks

  - [XDI4j 1.1](XDI4j_1.1 "wikilink")
  - Data models Used by H1.0 and H1.1:
      - [Higgins Data Model 1.0](Higgins_Data_Model_1.0 "wikilink")
      - [Context Data Model 1.0](Context_Data_Model_1.0 "wikilink")
  - [IdAS 1.1](IdAS_1.1 "wikilink")
      - Remove IHasAttributes on IAttributes

Misc

  - All components exist in [Components](Components "wikilink") pages
    (1.0, 1.1 and 1.x)?

## See Also

  - [Higgins 1.1M7](Higgins_1.1M7 "wikilink")
  - [Higgins 1.1M9](Higgins_1.1M9 "wikilink")
  - [Higgins 1.1](Higgins_1.1 "wikilink")
  - [Higgins 1.1 Wishlist](Higgins_1.1_Wishlist "wikilink")