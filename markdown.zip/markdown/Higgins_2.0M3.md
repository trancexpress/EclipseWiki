{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}

[2.0 Milestone 3 Issues
List](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=Technology&product=Higgins&target_milestone=2.0M3&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

Highlights:

  - Person-site data sharing
    [355585](https://bugs.eclipse.org/bugs/show_bug.cgi?id=355585)

## Links

[Higgins 2.0M2](Higgins_2.0M2 "wikilink")