### Prerequisite

  - Install **Visual Studio 2005** and it will also install the*' .Net
    framework*'
  - Install **Required SDK** for different platform
      - Install **Windows Mobile 6 Professional SDK Refresh.msi** for*'
        WM 5 & WM6*'
      - Install **Windows Mobile 6 Standard SDK Refresh.msi** for **WM
        STD 6**
      - Install **dxsdk_jun2007.exe** for **Win32**
      - Install **Windows CE 5.0 STANDARD SDK.msi** for **WinCE 5.0**
  - Install **Java SDK**, such as IBM 1.4.2 or Sun 1.5
  - Checkout **org.eclipse.ercp.swt.core.win
    org.eclipse.ercp.swt.expanded.win org.eclipse.ercp.swt.mobile.win**
    from **dev.eclipse.org**
  - Checkout **required build project** from **dev.eclipse.org**
      - **org.eclipse.ercp.swt.wm6pro** for*' WM 5 & WM6*'
      - **org.eclipse.ercp.swt.sp2005** for **WM STD 6**
      - **org.eclipse.ercp.swt.win32** for **Win32**
      - **org.eclipse.ercp.swt.wince5** for **WinCE 5.0**
  - Developer should download*' jniport.h*' and **jni.h** to your PC

### Steps of How to Resovle the Errors in org.eclipse.ercp.swt.core(expanded|mobile).win

  - Right click **org.eclipse.ercp.swt.core.win** in your IDE
  - Click **Propertis**
  - Click **Java Build Path**
  - Click **Libraries**
  - **Remove all default jar/lib path**
  - **Add Library**
  - Choose **JRE System Library**
  - Click **Next** and Point to the*' Device JRE*'
  - Then we should resolve the errors in the project
  - Do the same steps for expanded.win and mobile.win to resolve the
    errors

### Steps of How to build eswt-converge.dll

  - Go to
    **\~\\workspace\\org.eclipse.ercp.swt.{platform}\\converged_dll**

![Image:converged_dll folder.JPG](converged_dll_folder.JPG
"Image:converged_dll folder.JPG")

  - Double click **eswt-converged.sln**
  - **Visual Studio** will bring up
  - Right click **ugl_wince_port** in **right** panel

![Image:ugl_wince_port_properties.JPG](ugl_wince_port_properties.JPG
"Image:ugl_wince_port_properties.JPG")

  - Click **Properties**, it will bring up the property page

![Image:ugl_wince_port_propertiespage.JPG](ugl_wince_port_propertiespage.JPG
"Image:ugl_wince_port_propertiespage.JPG")

  - Expand **C/C++**
  - Click **General**
  - Click the **scroll-down button** of the **Additional Include
    Diectories**, it will bring up the **Additional Include Directories
    page**

![Image:Additional_Include_Directories_Page.JPG](Additional_Include_Directories_Page.JPG
"Image:Additional_Include_Directories_Page.JPG")

  - Click **New Line**, it will **generate a new entry**
  - Click the **scroll-down button** on the*' right hand side*' again
  - **Point to the folder** which **jniport.h** and **jni.h** resides

![Image:Additional_Include_Directories_Page_NewEntry.JPG](Additional_Include_Directories_Page_NewEntry.JPG
"Image:Additional_Include_Directories_Page_NewEntry.JPG")

  - Click **OK** and **save** this configuration
  - Choose the **corresponding platform SDK** on **top-center
    scroll-down menu**
  - Choose **Release** mode of **top-left-center scroll-down menu**

![Image:Release_SDK.JPG](Release_SDK.JPG "Image:Release_SDK.JPG")

  - Click **Build**--\>**Builds Solution**

![Image:Build.JPG](Build.JPG "Image:Build.JPG")

  - Then you can build **eswt-converge.dll** successfully which resides
    in **\~\\workspace\\org.eclipse.ercp.swt.wm6pro\\os\\win32\\arm**

### Steps of How to build eswt-converge.jar

  - This **required Java SDK** to build and here I install this SDK as
    following C:\\Program Files\\IBM\\Java142\\
  - Modify the **env.ini** under
    **\~\\workspace\\org.eclipse.ercp.swt.{platform}\\converged_jar**
    folder
      - JAVA_COMPILER=C:\\Program Files\\IBM\\Java142\\bin\\javac.exe
      - JAVA_ARCHIVE=C:\\Program Files\\IBM\\Java142\\bin\\jar.exe
  - Double click **main.bat**
  - Then you can build **eswt-converge.jar** successfully which resides
    in **\~\\workspace\\org.eclipse.ercp.swt.wm6pro\\ws\\win32\\**