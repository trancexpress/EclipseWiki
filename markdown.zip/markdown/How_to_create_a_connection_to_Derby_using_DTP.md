## Creating a Database Connection to Apache Derby using WTP 2.0

WTP 2.0 uses [Eclipse Data Tools Platform](http://www.eclipse.org/dtp)
for database and SQL language support. In order to use DTP for database
development, you will need to create a connection to a database using
its tools. This simple tutorial outlines how you can do that for [Apache
Derby](http://derby.apache.prg), a 100% Java database. We will assume
that Apache Derby is installed and that it will be started in the server
(networked) mode.

  - Step 1 - Switch to Database Development Perspective. Go to
    Window\>Open Perspective and choose Database Development.

![Image:DatabaseDevelopmentPerspective.png](DatabaseDevelopmentPerspective.png
"Image:DatabaseDevelopmentPerspective.png")

  - Step 2 - In the Data Source Explorer select Databases, choose New
    from the menu to create a New Connection Profile and choose 'SQL
    Model-JDBC Connection' from the list. Click Next to enter a name for
    the connection profile, name it 'HelloWorld Derby Connection'.

![Image:NewConnectionProfile.png](NewConnectionProfile.png
"Image:NewConnectionProfile.png")

  - Step 3 - Next Page will let us specify a driver and connection
    details for Derby. In the Select a driver from the drop-down, click
    on the ... button to add a new driver definition. Choose Generic
    JDBC Driver (Do not choose Derby Client Driver - At the time of
    writing this tutorial there was a bug with DTP that prevented using
    this definition). Click Add.

![Image:AddDerbyDriverDefinition.png](AddDerbyDriverDefinition.png
"Image:AddDerbyDriverDefinition.png")

  - Step 4 - In the list that comes up, choose the Generic JDBC Driver
    and give it a name, and click OK.

<!-- end list -->

  - Step 5 - In the next page, add the derby.client.jar that you will
    find inside the Apache Derby installation folder to Driver Files
    list. Complete the driver definition details as the following and
    click OK:

![Image:DTPDriverDetailsForDerby.png](DTPDriverDetailsForDerby.png
"Image:DTPDriverDetailsForDerby.png")

  - Step 6 - Choose the driver definition you have just created and fill
    the connection profile settings such as username and password. Click
    test Connection to test the profile and click Finish to create the
    database connection.

![Image:DTPDatabasePerspective.png](DTPDatabasePerspective.png
"Image:DTPDatabasePerspective.png")

  - Step 7 - Your new connection will be liste dunder the Databases. You
    can use it browse and edit the database.