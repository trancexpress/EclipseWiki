{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}
![Higgins_logo_76Wx100H.jpg](Higgins_logo_76Wx100H.jpg
"Higgins_logo_76Wx100H.jpg")![Image:Iss-v1.1.119.png](Iss-v1.1.119.png
"Image:Iss-v1.1.119.png")

  - STS client uses many other STS projects (not STS Server howerver) as
    part of the packaging for above noted STS client block.

[Category:Higgins_Packages](Category:Higgins_Packages "wikilink")