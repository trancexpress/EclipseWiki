## Summary:

<table border=0>

<tr>

<td>

Normal Defects:

</td>

<td>

6

</td>

</tr>

<tr>

<td>

Major Defects:

</td>

<td>

1

</td>

</tr>

<tr>

<td>

Enhancement:

</td>

<td>

3

</td>

</tr>

<tr>

<td>

**Total**:

</td>

<td>

**10**

</td>

</tr>

</table>

## Changes to Tigerstripe in Iteration 46:

**Support annotation-based exclusion for Facets (Bugzilla
[366987](https://bugs.eclipse.org/bugs/show_bug.cgi?id=366987))**
Similar to stereotype-based exclusion, users can now specify
annotation-based exclusion/inclusion in Tigerstripe Facets. This means
users can exclude/include certain artifacts based on their
annotation(s).

To leverage this feature, create a Facet \> switch to 'Scope' tab \>
Look under 'Annotation Scope Details'.

![Image:annotation_based_exclusion.png](annotation_based_exclusion.png
"Image:annotation_based_exclusion.png")

**Issues with adding artifact attributes (Bugzilla
[368719](https://bugs.eclipse.org/bugs/show_bug.cgi?id=368719))**
This was a regression where attributes could not be properly added and
renamed for an artifact. Adding multiple attributes and selecting one to
rename it would automatically change user's selection.

**Return value of stereotype is not displayed in editor (Bugzilla
[320105](https://bugs.eclipse.org/bugs/show_bug.cgi?id=320105))**
This enhancement outlined a number of usability improvements to artifact
editors that had already been implemented.

**Do not support addition of stereotypes in referenced TS modules
(Bugzilla
[366988](https://bugs.eclipse.org/bugs/show_bug.cgi?id=366988))**
Since referenced Tigerstripe modules are read-only, user should not be
allowed to add stereotypes to its artifacts. This action was disabled
from Annotation Property view.

![Image:stereotype_disabled123.png](stereotype_disabled123.png
"Image:stereotype_disabled123.png")

**Moving attributes will not move its corresponding annotations
(Bugzilla
[367567](https://bugs.eclipse.org/bugs/show_bug.cgi?id=367567))**
Attributes that are moved from one artifact to another would not move
their corresponding annotations. With this fix, the annotations are
moved as well.

**Entity in referenced project is not updated (Bugzilla
[367568](https://bugs.eclipse.org/bugs/show_bug.cgi?id=367568))**
If Tigerstripe project A is referencing project B in the same workspace
and user makes modifications to artifacts contained in project B, the
references were not updated under project A. This defect resolves the
issue and now properly updates the referenced artifacts.

**Issue with finding source folder for a File Copy Rule (Bugzilla
[365546](https://bugs.eclipse.org/bugs/show_bug.cgi?id=365546))**
There were some issues with certain paths specified for a Copy Rule,
which are now resolved.

![Image:copy_rule.png](copy_rule.png "Image:copy_rule.png")

**CopyRule should only issue a warning if Source Dir does not exist
(Bugzilla
[367979](https://bugs.eclipse.org/bugs/show_bug.cgi?id=367979))**
This was a request by one of our users to issue a warning instead of an
error when source folder did not exist for a Copy Rule. The idea is that
Copy Rule should apply to certain projects and not to others.

**Defect(s) marked as Invalid:**
Bugzilla [367272](https://bugs.eclipse.org/bugs/show_bug.cgi?id=367272)
- Opened editors are closed when I convert Association Class

**Defect(s) marked as Won't Fix:**
Bugzilla [251850](https://bugs.eclipse.org/bugs/show_bug.cgi?id=251850)
- Need to be able to specify annotation patterns