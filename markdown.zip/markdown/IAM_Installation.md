# IAM Installation

The project still has to go through some paperwork to be able to make
official releases at the Eclipse Foundation.

In the meantime the previous project Q4E is providing builds for your
convenience, so you can enjoy the features and bugfixes already
developed.

Check the [installation
instructions](http://code.google.com/p/q4e/wiki/Installation)

[Category:IAM](Category:IAM "wikilink")