[January 2016 Status
Meetings](ICE_January_2016_Status_Meetings "wikilink")

[February 2016 Status
Meetings](ICE_February_2016_Status_Meetings "wikilink")

[March 2016 Status Meetings](March_2016_Status_Meetings "wikilink")

[April 2016 Status Meetings](April_2016_Status_Meetings "wikilink")

[May 2016 Status Meetings](ICE_May_2016_Status_Meetings "wikilink")

[June 2016 Status Meetings](ICE_June_2016_Status_Meetings "wikilink")

[July 2016 Status Meetings](ICE_July_2016_Status_Meetings "wikilink")

[August 2016 Status
Meetings](ICE_August_2016_Status_Meetings "wikilink")

[September 2016 Status
Meetings](ICE_September_2016_Status_Meetings "wikilink")

[October 2016 Status
Meetings](ICE_October_2016_Status_Meetings "wikilink")

[November 2016 Status
Meetings](ICE_November_2016_Status_Meetings "wikilink")

[December 2016 Status
Meetings](ICE_December_2016_Status_Meetings "wikilink")