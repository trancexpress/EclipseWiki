### 20150202

Jay - Porting the reflectivity code.
Alex - Updating EMF tree loading. Added infrastructure for JAXB class
registration.
Anna - Getting new contributor started on the wiki, getting the updated
ResourceComponent working.
Jordan - Finishing up Connections Table. Trying to get Paraview working
a vis service.
Taylor - Checking out the Nek5000 tools in ICE and writing tutorials for
the study.

### 20150203

Jordan - Working on integrating Paraview demo into IVizService
architecture.
Anna - Working on bug related to ResourceComponent as a subclass of
ListComponent.
Taylor - Working on getting Nek5000 installed in the cloud.
Hari - Fixed multi-threading bug in branch, sent to Jordan for review.

### 20150204

Jay - Working on the reflectivity code.
Jordan - Working on Paraview VizService.
Anna - Working on ResourceComponent XML persistence.
Taylor - Getting ICE to work with Nek5000 install on server.
Andrew - Working on getting screenshots for caebat release doc.
Implementing IReader find functionality for key-value generation.

### 20150206

Jay - Working on the reflectivity code.
Alex - Merging the updates to the XMLPersistenceProvider.
Taylor - Tracking issues with using ICE and Amazon cloud.
Jordan - Working on Paraview VizService, getting it connecting from
Windows client. Working on FileEntry rendering in JFace table viewer.
Anna - Working on MooseModel updating ResourceComponent whenever the
mesh file entry is changed.
Andrew - Testing changes for Caebat general case architecture.
Hari - Updated VisIt server port configuration.

### 20150209

Jordan - Working on VisIt default connections working properly. Merging
post-processing branch.
Anna - Debugging JobLauncher resource component integration,
specifically downloaded files being added to the ResourceComponent.
Taylor - Installing and testing VisIt ICE functionality through amazon
cloud server.
Andrew - Working on Windows Eclipse configuration, meeting with CAEBAT
team to get requirements for continuing general input cases.

### 20150210

Anna - Fixing bug in CSV Plot Service.
Jordan - Working on VisIt default connections working properly. Merging
post-processing branch.
Taylor - Drafting solicitation to recruit experiment participants.
Hari - Working through NEAMS budget. Continuing update VisIt server port
configuration.

### 20150211

Jay - Meeting with John on Reflectivity, continuing to port Visual Basic
code.
Jordan - Working on getting Moose Model Builder to pull the input file
mesh from the ResourceComponent.
Anna - Fixing widget disposed error that occurs when showing the CSV
plot view.
Taylor - Finishing drafts of solicitation materials. Working on
evaluation questionnaire.

### 20150216

Jay - Working on some new plotting tools.
Jordan - Working on getting the VisIt viz service to work smoothly,
updating UI for MOOSE work related to File entry, fixing a few bugs.
Taylor - Working on tutorial documents for HCI experiments.
Andrew - Working on tutorial documents for CAEBAT.

### 20150217

Anna - Working on the ICEResourcePage and plotting for MOOSE/BISON.
Taylor - Working on participant instruction and tutorial documents for
HCI experiments.
Andrew - Testing new release of VM for CAEBAT.
Jordan - Working on getting the VisIt viz service to work smoothly,
updating UI for MOOSE work related to File entry, fixing a few bugs.

### 20150218

Jay - Interviewing Anara.
Anara - Being interviewed. Gave a talk.
Alex - Interviewing Anara.
Taylor - Working on participant instruction documents.
Jordan - Fixing bugs in VisIt service, working with Anna on ResourcePage
related to IVizServices.
Anna - Working on exception throwing for IPlot when given invalid
data.

### 20150220

Andrew - Working out VM problems, finding and fixing bugs in CAEBAT VM
and ICE.
Anna - Fixing bug with MOOSE Launcher and persisted VizResources.
Updating test if possible to catch this bug.
Hari - Updating forked ICE to support new functionality in VisIt 2.9.
Jordan - Working on updating ICEResourcePage to deal with exceptions
from IVizService and IPlots. Looking at CSVPlot loader exceptions with
Anna.
Taylor - Working on EclipseCon NA 2015 poster.

### 20150223

Jay - Fixing/Finishing Reflectivity calculator.
Jordan - Fixing ResourceView bugs, merging post process branch into
visit viz service branch. Working on paraview viz service.
Anna - Fixing exception throwing in CSVPlot.
Taylor - Working on the EclipseCon poster and presentation, also
participant instructions for HCI experiment.
Andrew - Demonstrating working CAEBAT plugins to the team.

### 20150224

Jordan - Working on the Paraview plugins and a couple of bugs in the UI
of the post processing branch.
Anna - Working on comment attribute for Entry, updating tests, and
integrating it into Moose stuff.
Taylor - Working on the EclipseCon poster and presentation, also
participant instructions for HCI experiment.
Andrew - Working on adding templates for the components in the port.
Hari - Updating NEAMS work package. Updating VisIt password
functionality and creating pull request.

### 20150225

Jay - Porting the tile generation and convolution routines.
Taylor - Continuing the EclipseCon poster work and slides.

### 20150227

Jay - Working on administrative paper work.
Jordan - Working on the Paraview Viz Service.
Anna - Working on getting \*.i files to render in ICEResourcePage.
Taylor - Working on EclipseCon presentation and poster.
Andrew - Testing out the VIBE VM, cleaning up the VIBE plugins.