### 20160502

Greg - Working ICE for TITAN.
Robert - Continuing JAXB support for Mesh Editor.
Andrew - Testing the translation from EMF to ICE objects.

### 20160503

Greg - Working on ICE for TITAN.
Robert - Continuing JAXB support for Mesh Editor.
Andrew - Fixing bugs in translation process for the parser generator.

### 20160504

Robert - Fixing bugs in Mesh Editor persistence.

### 20160506

Robert - Finishing Mesh Editor persistence.

### 20160507

Jay - Fixing build errors in ICE/EAVP, finishing reflectivity branch.
Greg - Improving repo layout.
Andrew - Trying to fix parsergenerator branch build issue.
Robert - Fixing Mesh Editor bugs related to persistence.

### 20160508

Jay - Starting January data structures refactor and refactoring workflow
engine.
Greg - Getting ptp to work on Titan.
Andrew - Learning how to use XText's grammar access.
Robert - Started work on persistence for Geometry Editor.

### 20160509

Alex - Removed Bison files from ICETests and updated tests to use MOOSE
files.
Greg - Getting ptp to work on Titan.
Robert - Moving Transformation from IView to IMesh. WOrking on
persistence for Geometry Editor.

### 20160511

Robert - Trying to get maven to build EAVP with the source code included
in a way that it can be automatically detected by Eclipse when added to
the target.

### 20160516

Greg - Getting PTP working on Titan using TCF.
Andrew - Fixing bug and improving options for project generation.
Robert - Working on getting on the EAVP build to include source code.
Working on JAXB for goemetry editor.

### 20160517

Greg - Getting PTP working on Titan using TCF.
Andrew - Working on improvements for project generator.
Robert - Finishing up Geometry Editor JAXB persistence.

### 20160518

Robert - Resolving tycho-maven-plugin build issue. Working on problems
with built executables not having up to date JAXB support.

### 20160520

Jay - Working on slides for OLCF day zero training.
Robert - Working on getting a build of EAVP with source code and working
on the mesh editor data structures.

### 20160523

Jay - Conducting OLCF training and working on ldrd.
Alex - Conducting OLCF training.
Greg - Conducting OLCF training and TITAN support.
Andrew - Working on parser generator's writer.
Robert - Working on ParaView's remote connection support.
Kasper - Trying out Netgen. Working on geometry data structure design.

### 20160524

Jay - General administrative activities.
Greg - General administrative activities.
Andrew - Setting up VM to do build testing and more work on grammar
access component of parser generator.
Robert - Working on ParaView remote support and optimizations for
geometry data structures. Responding to user requests for EAVP.
Kasper - Compiling Netgen and researching other mesh generators.

### 20160525

Greg - Helping John Eblen with using ICE for Gromacs.
Robert - Working on remote ParaView support.
Kasper - Looking into mesh generators (NetGen and GMsh).

### 20160527

Robert - Working on ParaView remote support.
Kasper - Writing FENICS wiki article and compiling MeshKit.

### 20160531

Jay - Working on geometry editor data model. Meeting with users. Putting
together bugs for Robert and Kasper.
Greg - PTP target management and putting together release reviews and
working on Titan support.
Alex - Odd jobs.
Andrew - Finishing testing for project generator improvements.
Streamlining adding a new ICE item project.
Robert - Finishing ParaView remote support.
Kasper - Finishing FENICS documentation and investigating geometry file
formats (starting with CUBIT).