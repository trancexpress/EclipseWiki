## ICE OSGi Configuration

ICE is built using Equinox, the reference implementation of the OSGi.
ICE has four OSGi bundles:

  - gov.ornl.ice.icecore
  - gov.ornl.ice.iceclient
  - gov.ornl.ice.icedatastructures
  - gov.ornl.ice.iceitem

The gov.ornl.ice.iceclient bundle is also an Eclipse RCP application.

ICE also has several separate bundles and fragment bundles that are used
for testing.

These components were created using the Eclipse Plug-in Development
Environment in IBM Rational Software Architect v. 8.0 following the
procedures outlined in "OSGi and Equinox" by Jeff McAffer et. al.

## Using OSGi bundles in Eclipse RCP applications

### Getting the OSGi bundles from the repository

The OSGi bundles are available in the [ICE
Repository](http://sourceforge.net/p/niceproject/docs/NiCE_Repository)
in the trunk/src/ and trunk/tests directories. The bundles are
configured as Eclipse projects and may be checked out as an Eclipse PDT
project using the Subversive plugin.

The bundles may also be checked out using a standard SVN client.

### Exporting the OSGi bundles from Eclipse

#### Support for Apache Felix

The gov.ornl.nice.nicecore and gov.ornl.nice.nicedatastructures bundles
are supported on Apache Felix. To date (9-7-2011), gov.nice.niceclient
is not compatible with Apache Felix because it is an Eclipse RCP
application.

#### NiCE OSGi Bundles on Android

The ICE OSGi bundles work on Google Android using Apache Felix. Perform
the following steps to get the ICE OSGi bundles to run on the Android
OS:

1\. Download the Android SDK and make sure $ANDROID_PATH/tools and
$ANDROID_PATH/platform-tools are in your $PATH

2\. Download osgi-apache.zip from Apache:
<http://felix.apache.org/site/documentation.data/osgi-android%20-%20felix%201.4,%20android%20SDK%201.0.zip>

3\. Create *.dex archives* for *all* the .jar bundles in the project and
add them to that corresponding jar file:

<code>dx --dex --output=classes.dex JAR_File.jar

aapt add JAR_File.jar classes.dex</code>

4\. Make sure you have an Android emulator created:

a.) check for target IDS:

`android list targets`

b.) create a new one with the corresponding target and an avd name

`android create avd -n myAVD2.2 -t 2`

5\. start the emulator:

`emulator -avd myAVD2.2 &`

6\. Push the project bundles and the felix.sh file to the emulator

`find * -type f -exec adb push {} /data/felix/{} \;`

7\. Launch Felix

<code>adb shell

cd /data/felix

sh felix.sh</code>

8\. Install and start desired bundles in the Felix console

` start  `<file:bundle/JAR_File.jar>

ICE assumes the following directory structure on Android:

    ICEFelixTest/

        bin/felix.jar

        bundle/*jars

        felix.sh

    cd bundle

    dx --dex --output=classes.dex gov.ornl.nice.nicecore.jar

    aapt add gov.ornl.nice.nicecore.jar classes.dex

    dx --dex --output=classes.dex gov.ornl.nice.nicedatastructures.jar

    aapt add gov.ornl.nice.nicedatastructures.jar classes.dex

    cd ..

    emulator -avd myAVD2.2 &

    find * -type f -exec adb push {} /data/felix/{} \;

    adb shell

    cd /data/felix

    sh felix.sh</code>

    In felix framework:

    <code>start file:bundle/gov.ornl.nice.nicecore.jar

    start file:bundle/gov.ornl.nice.nicedatastructures.jar

![<File:FelixShell.png>](FelixShell.png "File:FelixShell.png")

## NiCE OSGi Bundles Embedded in an Android Application

The following outlines the steps needed to get Felix and the ICE OSGi
bundles running in an Android application.

### Bundles needed

  - org.apache.felix.shell-1.4.2.jar
  - org.apache.felix.log-1.0.1.jar
  - org.apache.felix.configadmin-1.2.8.jar
  - org.apache.felix.bundlerepository-1.6.6.jar
  - org.apache.felix.scr-1.6.1.jar (must compile from source, detailed
    next)
  - gov.ornl.nice.nicedatastructures.jar
  - gov.ornl.nice.nicecore.jar
  - gov.ornl.nice.servicetester.jar

All of these bundles must be dex'ed according the procedure outlined
above in NiCE OSGi Bundles on Android. All Felix bundles except the SCR
can be downloaded from <http://felix.apache.org/site/downloads.cgi> .
You will also need the Felix 3.3.2 jar (not dex'ed) from that site as
well.

#### SCR Declarative Services

There is a bug in the currently available version of Apache Felix SCR
(1.6.0) that causes the android application to crash because of an
incorrect text format. To fix this bug, we must checkout the Felix SVN
repository and build the bundle from scratch using Maven 2 (yum install
maven2). Here are the steps:

<code>svn co -r 1097847 http://svn.apache.org/repos/asf/felix/trunk
Felix

cd Felix/

mvn -Dpackaging=plugins install cd scr/

mvn -Dpackaging=bundle install

cd target/</code>

The resultant org.apache.felix.scr-1.6.1-SNAPSHOT.jar in the target/
directory is the correct bundle to use.

#### Embedding in Android

Create a new Android project and add the downloaded Felix 3.3.2 jar to
the build path of the project. This should give you an android Activity
class and the required resources from the res/ directory. Add a new
class to the project that implements the OSGi BundleActivator interface.
In this class we will need to populate the start() method to create the
downloaded bundles and start them in the Felix framework. Create the
needed private attributes on the Activity class:

``` java
private StringMap configMap;
private Felix felix;

//configMap holds all the required Felix configurations. Here's the pertinent configuration options needed to get Felix up and running on and Android phone:

configMap.put(FelixConstants.FRAMEWORK_SYSTEMPACKAGES, SystemPackages);
configMap.put(FelixConstants.FRAMEWORK_SYSTEMPACKAGES_EXTRA, "org.xml.sax,org.xml.sax.helpers,javax.xml.parsers");
configMap.put(FelixConstants.LOG_LEVEL_PROP, "4");
configMap.put(FelixConstants.FRAMEWORK_DEFAULT_STARTLEVEL, "1");
configMap.put("felix.startlevel.bundle", "1");
configMap.put("felix.service.urlhandlers", "false");
configMap.put("org.osgi.service.http.port", "8080");
configMap.put("org.shell.telnet", "on");
configMap.put(FelixConstants.FRAMEWORK_STORAGE, cacheDir.getAbsolutePath());
// Set the BundleActivator List
NiCEBundleActivator activator = new NiCEBundleActivator(this.getResources(), rootPath + File.separator+ "felix");
List<BundleActivator> activatorList = new ArrayList<BundleActivator>();
activatorList.add(activator);
configMap.put(FelixConstants.SYSTEMBUNDLE_ACTIVATORS_PROP, activatorList);

//The ICEBundleActivator is used to start up the required Felix and ICE bundles. Its start() method uses Android's built in Resources mechanism to read in the bundles using java.io.InputStream. This InputStream is then used, along with the BundleActivator's BundleContext to install the bundles to the running Felix framework. Once installed, ICEBundleActivator calls start() on all the installed bundles.

InputStream is = res.getAssets().open("shell_1.4.2.jar");
shell = context.installBundle(file+"/bundle/shell.jar", is);
InputStream logstream = res.getAssets().open("log_1.0.1.jar");
log = context.installBundle(file+"/bundle/log.jar", logstream);
InputStream configStream = res.getAssets().open("configadmin_1.2.8.jar");
configadmin = context.installBundle(file+"/bundle/configadmin.jar", configStream);
InputStream repoStream = res.getAssets().open("bundlerepository_1.6.6.jar");
bundlerepo = context.installBundle(file+"/bundle/bundlerepository.jar", repoStream);
InputStream scrStream = res.getAssets().open("scr_1.6.1.jar");
scr = context.installBundle(file+"/bundle/scr.jar", scrStream);
InputStream dataStream = res.getAssets().open("nicedatastructures.jar");
data = context.installBundle(file+"/bundle/data.jar", dataStream);
InputStream coreStream = res.getAssets().open("nicecore.jar");
core = context.installBundle(file+"/bundle/core.jar", coreStream);
InputStream serviceStream = res.getAssets().open("servicetester.jar");
servicetester = context.installBundle(file+"/bundle/servicetester.jar", serviceStream);
shell.start();
log.start();
configadmin.start();
bundlerepo.start();
scr.start();
data.start();
core.start();
servicetester.start();
felix = new Felix(configMap);
felix.start();
```