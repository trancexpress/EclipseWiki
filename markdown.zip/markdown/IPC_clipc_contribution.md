## CLIPC Contribution to the ECF Project

This page was created to help with the process of contributing the
"com.lts.ipc" (CLIPC) source code to the Eclipse Communications
Framework (ECF) project.

## Introduction

CLIPC is a library of Java and C code that facilitates the following
Inter-Process Communications (IPC) primitives:

  - Semaphores
  - FIFOs (aka Named Pipes)
  - Shared Memory

CLIPC facilitates the use of these primitives in two ways:

  - It provides primitives that do not exist in Java via native
    implementations (Semaphores and FIFOs).
  - It provides an easier to use primitive for those that do exist
    (Shared Memory).

CLIPC consists of two modules/subprojects:

  - The platform independent Java portion: clipc-java
  - The platform dependent C portion: clipc-native

clipc-java defines the native interfaces to the FIFO and Semaphore
primitives.  clipc-native provides the implementation for those
interfaces.

## Eclipse Legal Process

This section contains some answers to the questions posited in [Eclipse
Legal Process
Poster](http://www.eclipse.org/legal/EclipseLegalProcessPoster.pdf)

### Quick Answers

  - CLIPC was written 100% by the contributor (non-committer) Clark N.
    Hobbie from scratch.
    \*CLIPC contains no cryptography code.
      - CLIPC was written from scratch.
      - CLIPC is 100% EPL Code.
  - CLIPC comes from Bugzilla, ID:
    [286744](https://bugs.eclipse.org/bugs/show_bug.cgi?id=286744)
  - CLIPC is <B>more</B> than 250 lines of code
  - CLIPC does not contain a contribution questionnaire ([see
    below](#questionnaire "wikilink"))
  - The source code is attached to the IPBug

Here are some answers to the questions that the [Eclipse Legal Process
Poster](http://www.eclipse.org/legal/EclipseLegalProcessPoster.pdf)
indicated would be in the Contribution Questionnaire:

  - [Is the use: binary or Source?](#binary_vs_source "wikilink") Source
  - [Is the use: in modified or unmodified
    form](#modified_vs_unmodified "wikilink")? Unmodified
  - [Is this a standard binary distribution or are you sub setting? See
    below.](#sub_setting "wikilink")
  - [List all the licenses that apply to the code:
    EPL](#author_license "wikilink")
  - [Is there one author or many authors: One author (the
    contributor).](#author_license "wikilink")
  - [Is there a clear mechanism by which contributors to the project
    agreed to submit their code to the project under the license
    provided? N/A (one author).](#author_license "wikilink")
  - [If there was a change in license ...:
    N/A](#author_license "wikilink")
  - If this code has been previously reviewed...: This is the first
    submission of CLIPC to the Eclipse Foundation.

### Notes and Details

<div id="questionnaire">

#### Contribution Questionnaire

</div>

I could not find this page. Doing a search on eclipse.org for
"Contribution Questionnaire" came up with [this
link,](http://www.eclipse.org/legal/ContributionQuestionnairePart1-v1.0.php)
which in turn, redirects you to [the
portal](http://portal.eclipse.org/). That location does not seem to have
the link and when searching for the questionnaire, it comes up with the
first link again.

<div id="source_code">

#### Source Code

</div>

The source code is attached to the IPBug in the form of two ZIP files.

clipc-java.zip contains an Eclipse project with the platform independent
Java code, while clipc-native.zip contains the platform dependent C
code.

<div id="binary_vs_source">

#### Is the Use Binary or Source?

</div>

I'm assuming that the question was is the contribution in the form of
source code or binary files. CLIPC is in the form of source code.

<div id="modified_vs_unmodified">

#### Is the Use: in Modified or Unmodified Form

</div>

I'm assuming that the question was is the contribution modified from
it's original form. Since I wrote CLIPC, any modifications can be
considered the "original form" so I specified "unmodified".

<div id="sub_setting">

#### Is this a Standard Binary Distribution or Are You Sub Setting?

</div>

I'm not real clear on what the question is here. If it is asking whether
the project uses different settings for different platforms, the answer
is yes. Since CLIPC uses C code, JNI and the like in order to provide
the required primitives, it has different settings depending on the
platform.

<div id="author_license">

#### Author and License Related Questions

</div>

I am submitting CLIPC under the terms of the EPL. I am CLIPC's sole
author. CLIPC was written from scratch.

CLIPC was originally made available from SourceForge at
<http://clipc.sourceforge.net>. It uses the LGLP license, but I am
assuming that given the above conditions I can contribute the library
using EPL.

Please let me know if you want me to change the license on SourceForge
to EPL.

LGPL, but I'm assuming that since I'm the only author, I can change the
license to whatever I want.