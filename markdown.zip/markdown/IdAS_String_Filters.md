## Problem

While the current IFilter, IFilterAssertion (and sub-interfaces) are
adequate to perform complex searches across an IdAS context, it is
cumbersome to code to them. Furthermore, there is currently no way to
represent a filter using a string such that it could be passed easily
across a wire protocol

## Proposals

### ABNF

The following ABNF could be used to represent filters as strings. Note
that I simply looked at the way today's IFilter is and extrapolated an
ABNF.

    filter       = LP filteritem RP
    filteritem   = assertion / and / or / not
    assertion    = attrpresent /
                   attreq /
                   attrge /
                   attrle /
                   attrsub /
                   eideq /
                   etypeeq
    and          = AMP 1*filter
    or           = BAR 1*filter
    not          = EXC filter
    attrpresent  = "a:" resource ; matches when an entity has an attribute (named by resource) present
    attreq       = "a=:" resource SP value ; matches when an entity has an attribute (named by resource) with a value equal to value
    attrge       = "a>=:" resource SP value ; matches when an entity has an attribute (named by resource) with a value greater or equal to value
    attrle       = "a<=:" resource SP value ; matches when an entity has an attribute (named by resource) with a value less or equal to value
    attrsub      = "a*:" resource SP value ; matches when an entity has an attribute (named by resource) with a value containing a substring of value
    attrext      = "a(" matchrule ")" resource SP value ; matches when an entity has an attribute (named by resource) with a value matching value using the specified matchrule
    eideq        = "eid=:" SP entityid ; matches when an entity has the id specified in entityid
    etypeeq      = "etype=:" SP resource ; matches when an entity's type matches that specified in resource
    resource     = URI ; typically specifies an attribute ID or entity type
    value        = ; TODO: occurrences of RP must be escaped in values
                   ; TODO: how are complex attr's represented?
                   ; TODO: how are attr's on values represented?
    matchrule    = URI ; specifies a matching rule
    LP           = %x28 ; left paren ("(")
    RP           = %x29 ; right paren (")")
    SP           = %x20 ; space (" ")
    AMP          = %x26 ; ampersand ("&")
    BAR          = %x7C ; vertical bar or pipe ("|")
    EXC          = %x21 ; exclamation mark ("!")

#### Examples

Match for any entity with a telephone number of 888-555-1212 or
888-123-4567

    (&(a=:http://example.org/attrs/phonenumber 888-555-1212)(a=:http://example.org/attrs/phonenumber 888-123-4567))

Match entities who's first name is Robert, Bob, or Bobby

    (a(http://example.org/matchrules/nicknames):http://example.org/attributes/givenname Robert)

### XML