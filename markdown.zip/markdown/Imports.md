back to [slang DSL](slang_DSL "wikilink")

## Imports

Written at the beginning of the file, after the namespace, used to
specify the dependencies the file is using and the name it will be
referenced within the file.
<code> sample:

`  imports:`
`     - ops: user.ops.OpenstackOperations`
`     - order_vm_flow: user.flows.OrderVmFlow`
`     - script_file: some_script_file.py`

</code>