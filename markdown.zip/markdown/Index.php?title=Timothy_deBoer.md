Tim deBoer is an architect at the IBM Toronto Lab. He's the project lead
for the Web Tools Platform's Server Tools project, and a member of the
WTP Project Management Committee.