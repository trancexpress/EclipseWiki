<table>
<colgroup>
<col style="width: 90%" />
<col style="width: 9%" />
</colgroup>
<tbody>
<tr class="odd">
<td><h2 id="overview">Overview</h2>
<p>(Insert text here)</p>
<h2 id="other_topic">Other Topic</h2>
<p>(Insert text here)</p></td>
<td><table>
<thead>
<tr class="header">
<th><p>OAW Navigation   </p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td><p><a href="OAW" title="wikilink">Main Page</a></p></td>
</tr>
</tbody>
</table></td>
</tr>
</tbody>
</table>