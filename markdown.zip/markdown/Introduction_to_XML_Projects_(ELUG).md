![Image:Elug draft icon.png](Elug_draft_icon.png
"Image:Elug draft icon.png") '''For the latest EclipseLink
documentation, please see
<http://www.eclipse.org/eclipselink/documentation/> '''

-----

<div style="float:right;border:1px solid #000000;padding:5px">

__TOC__ [Related
Topics](Special:Whatlinkshere/Introduction_to_XML_Projects_\(ELUG\) "wikilink")

</div>

This section provides an overview of XML projects and their components.

For information on project concepts and features common to more than one
type of EclipseLink projects, see [Introduction to
Projects](Introduction%20to%20Projects_\(ELUG\) "wikilink").

## XML Project Concepts

Use an XML project for nontransactional, nonpersistent (in-memory)
conversions between Java objects and XML documents using JAXB (see
[EclipseLink Support for Java Architecture for XML Binding
(JAXB)](#EclipseLink_Support_for_Java_Architecture_for_XML_Binding_\(JAXB\) "wikilink")
and [JAXB Validation](#JAXB_Validation "wikilink")). The Workbench
provides complete support for creating XML projects.

The EclipseLink runtime performs XML data conversion based on one or
more XML schemas. In an XML project, Workbench directly references
schemas in the deployment XML, and exports mappings configured with
respect to the schemas you specify. For information on how to use
Workbench with XML schemas, see [Using XML
Schemas](Using%20Workbench%20\(ELUG\)#Using_XML_Schemas "wikilink"). For
information on how EclipseLink supports XML namespaces, see [XML
Namespaces
Overview](Introduction%20to%20Projects_\(ELUG\)#XML_Namespaces_Overview "wikilink").

<span id="Table 52-1"></span> **'' XML Project Components**''

| **Component** | **Supported Types**                                                                                                               |
| :------------ | :-------------------------------------------------------------------------------------------------------------------------------- |
| Data Source   | None                                                                                                                              |
| Descriptors   | For more information, see [Descriptor Concepts](Introduction%20to%20XML%20Descriptors%20\(ELUG\)#Descriptor_Concepts "wikilink"). |
| Mappings      | For more information, see [XML Mappings](XML_Mappings_\(ELUG\) "wikilink").                                                       |

In an XML project, you do not use EclipseLink queries and expressions.

### EclipseLink Support for Java Architecture for XML Binding (JAXB)

JAXB defines annotations to control the mapping of Java objects to XML,
but it also defines a default set of mappings. Using the defaults,
EclipseLink can marshall a set of objects into XML, and unmarshall an
XML documennt into objects. JAXB provides a standard Java object-to-XML
API. For more information, see
[`http://java.sun.com/xml/jaxb/index|l`](http://java.sun.com/xml/jaxb/index%7Cl).

EclipseLink provides an extra layer of functions on top of JAXB. It
allows for the creation and subsequent manipulation of mappings (in the
form of a Workbench project) from an existing object model, without
requiring the recompilation of the JAXB object model.

An essential component of this function is the EclipseLink JAXB
compiler. Using the EclipseLink JAXB compiler, you can generate both an
EclipseLink XML project and JAXB-compliant object model classes from
your XML schema.

The EclipseLink JAXB compiler simplifies JAXB application development
with EclipseLink by automatically generating (see [Creating an XML
Project from an XML
Schema](Creating%20an%20XML%20Project%20\(ELUG\) "wikilink")) the
required JAXB files (see [Working with JAXB-Specific Generated
Files](#Working_with_JAXB-Specific_Generated_Files "wikilink")) from
your XML schema (XSD) document.

For more information on using the JAXB and EclipseLink-specific run-time
classes, see [Using EclipseLink JAXB Compiler-Generated Files at Run
Time](#Using_EclipseLink_JAXB_Compiler-Generated_Files_at_Run_Time "wikilink").

#### Generating EclipseLink Project and XML Schema Using JAXB Annotations

The EclipseLink JAXB compiler generates a EclipseLink project and an XML
schema using the following JAXB annotations:

  - `XmlRootElement` - Indicates that a class should be mapped to a
    root-level element in a schema.
    The element name and namespace are specified in this annotation.
    This is a class-level annotation.
  - `XmlElement` - Indicates that a particular attribute on a Java class
    should be mapped to an XML element in the schema.
    The name and namespace can be specified by this annotation.
    This is a field-level annotation.
  - `XmlElementRef` - Indicates that a particular attribute on a Java
    class should be mapped in the schema to an XML element derived from
    the attribute's type.
    The name and namespace can be specified by this annotation.
    This is a field-level annotation.
    For more information, see [Substitution
    Groups](Introduction%20to%20XML%20Mappings%20\(ELUG\)#Substitution_Groups "wikilink").
  - `XmlElementRefs` - Contains a collection of `XmlElementRef`
    annotations.
    This is a field-level annotation.
    For more information, see [Substitution
    Groups](Introduction%20to%20XML%20Mappings%20\(ELUG\)#Substitution_Groups "wikilink").
  - `XmlAttribute` - Indicates that the Java attribute should map to an
    XML attribute in the schema.
    Name and namespace should be provided.
    This is a field-level annotation.
  - `XmlElementWrapper` - Specifies a wrapper element around another
    element or attribute.
    You can use this annotation to create a grouping element around a
    collection.
    This is a field-level annotation.
  - `XmlList` - Indicates that a collection property should map to a
    space-separated list in XML.
    This is a field-level annotation.
  - `XmlType` - Defines the complex-type for a class.
    Using this annotation’s `propOrder` property, you can specify the
    order in which to map elements. The `propOrder` property also
    determines if the schema should contain a `sequence` or an `all`.
    Depending on the structure of the class, it will either map to a
    `ComplexType`, a `SimpleType`, or a `ComplexType` with
    `SimpleContent`.
    This is a class-level annotation.
  - `XmlTransient` - Indicates that a mapping should not be generated
    for a particular field.
    This is a marker annotation.
    This is a field-level annotation.
  - `XmlSchema` - Specifies the target namespace for a schema.
    You can also use this annotation to configure namespace prefix
    mappings with the `XmlNs` annotation.
    This is a package-level annotation.
  - `XmlNs` - Appears only in an `XmlSchema` annotation to specify
    namespace-prefix mappings.
    This is a package-level annotation.
  - `XmlValue` - Maps an attribute to a text node under the parent class
    (for example, an Xpath of "text( )").
    Also indicates that the owning class should map to either a
    `SimpleType` or a `ComplexType` with `SimpleContent`.
    This is a field-level annotation.
  - `XmlEnum` - Indicates that a JDK 1.5 `Enum` type should map to a
    simple type with enumeration facets in the schema.
    The base schema type is specified on this annotation.
    This is a field-level annotation.
  - `XmlEnumValue` - Lets you specify the enumeration facets to be used
    in the schema, if they are to be different from the string values of
    the `Enum` constants specified in Java.
    This is a field-level annotation.
  - `XmlAccessorType` - Specifies how the classes’ attributes should be
    processed.
    This is a package- or class-level annotation.
    The following are valid values:
      - `FIELD` – Process all the public and/or private fields of the
        class.
      - `PROPERTY` – Process all the public or private get and set
        method pairs on the class.
      - `PUBLIC_MEMBER` – Process all the public fields and public get
        and set method pairs on the class.
      - `NONE` – Only process members that are annotated with JAXB
        annotations.
  - `XmlAccessorOrder` - Specifies the order in which properties are to
    be processed.
    This is a package- or class-level annotation.
    The following are valid values:
      - `DEFAULT`
      - `ALPHABETICAL`.
  - `XmlSchemaType` - If specified at a property level, indicates the
    schema type that should be used in schema generation.
    If used as part of an `XmlSchemaTypes` annotation, overrides default
    schema types at a package level.
    This is a property- or a package-level annotation.
  - `XmlSchemaTypes` - Contains a collection of `XmlSchemaType`
    annotations. Each one specifies a Java class and a XML schema type
    pair that should be used as a default for this package.
    This is a package-level annotation.
  - `XmlAnyAttribute` - Specifies that a Map property should be mapped
    to an `xs:any` attribute in the schema. For more information, see
    [XML Any Attribute
    Mapping](Introduction%20to%20XML%20Mappings%20\(ELUG\)#XML_Any_Attribute_Mapping "wikilink").
    This is a filed-level annotation.

For more information, see Chapter 8 of JAXB Specification at
<http://jcp.org/aboutJava/communityprocess/pfd/jsr222/index.html>

<table>
<tbody>
<tr class="odd">
<td style="text-align: left;"><p><strong>Note:</strong> The EclipseLink project is generated from a collection of annotated Java classes with support for relationships, collection-style mappings, and JDK 1.5 enumerations.</p>
<p>The schema is generated from a set of annotated Java classes with support for relationships.</p></td>
</tr>
</tbody>
</table>

#### Working with JAXB-Specific Generated Files

The EclipseLink JAXB compiler generates the following JAXB-specific
files from your XSD:

  - [Implementation Classes](#Implementation_Classes "wikilink")

The JAXB runtime uses these files as specified by the JAXB
specification.

All JAXB-specific files are generated in the output directory you
define, and in the subdirectories implied by the target package name you
define. For more information about EclipseLink JAXB binding compiler
options, see [Creating an XML Project from an XML SchemaCreating an XML
Project from an XML
Schema](Creating%20an%20XML%20Project%20\(ELUG\)#Creating_an_XML_Project_from_an_XML_SchemaCreating_an_XML_Project_from_an_XML_Schema "wikilink").

Before you compile your generated classes, be sure to configure your IDE
classpath to include `<`*`ECLIPSELINK_HOME`*`>\lib\xml.jar`. For an
example, see [Using an Integrated Development
Environment](Using%20an%20Integrated%20Development%20Environment%20\(ELUG\) "wikilink").

##### Implementation Classes

All implementation classes are named according to the content, element,
or implementation `name` attribute defined in the XSD.

The generated implementation classes are simple domain classes, with
private attributes for each JAXB property, and public `get` and `set`
methods that return or set attribute values.

#### Using EclipseLink JAXB Compiler-Generated Files at Run Time

At run time, you can access the EclipseLink JAXB compiler-generated
files by doing the following:

  - Using EclipseLink `XMLContext` (see [How to Use EclipseLink
    XMLContext](#How_to_Use_EclipseLink_XMLContext "wikilink"))
  - Using EclipseLink `XMLBinder` (see [How to Use EclipseLink
    XMLBinder](#How_to_Use_EclipseLink_XMLBinder "wikilink"))
  - Using EclipseLink `JAXBContext` (see [How to Use
    JAXBContext](#How_to_Use_JAXBContext "wikilink"))

##### How to Use EclipseLink XMLContext

EclipseLink provides an `org.eclipse.persistence.ox.XMLContext` class
with which you can create instances of EclipseLink `XMLMarshaller`,
`XMLUnmarshaller`, `XMLBinder` (see [How to Use EclipseLink
XMLBinder](#How_to_Use_EclipseLink_XMLBinder "wikilink")), and
`XMLValidator`.

The `XMLContext` is thread-safe. For example, if multiple threads
accessing the same `XMLContext` object request an `XMLMarshaller`, each
will receive their own instance of `XMLMarshaller`, so any state that
the `XMLMarshaller` maintains will be unique to that process. By using
the `XMLContext`, you can use EclipseLink XML in multithreaded
architectures, such as the binding layer for Web services. Create the
`XMLContext` using its constructor method and by passing in the session
name defined in the `sessions.xml` file, as the following example shows:

`XMLContext context = new XMLContext("mysession");`

You can also create the `XMLContext` from multiple sessions using a
colon separated list of session names, as the following example shows:

`XMLContext context = new XMLContext("session1:session2:session3");`

Use the `XMLContext` to create an EclipseLink `XMLMarshaller`,
`XMLUnmarshaller`, `XMLBinder`, and `XMLValidator`, as follows:

`XMLMarshaller marshaller = context.createMarshaller();`
`marshaller.marshal(myObject, outputStream);`
`marshaller.setFormattedOutput(true);`

`XMLUnmarshaller unmarshaller = context.createUnmarshaller();`
`Employee emp = (Employee)unmarshaller.unmarshal(new File("employee.xml"));`

`XMLBinder binder = context.createBinder();`
`Address add = (Address)binder.unmarshal(myElement);`

`XMLValidator validator = context.createValidator();`
`boolean isValid = validator.validate(emp);`

Using the `XMLContext` `getDocumentPreservationPolicy` method, you can
retrieve this context's document preservation policy in a form of the
`DocumentPreservationPolicy` object. This object's API lets you specify
the position of newly added to the node elements, as well as disable the
addition of new elements.

##### How to Use Marshal and Unmarshal Events

You can provide EclipseLink `XMLMarshaller` and `XMLUnmarshaller` with
additional functionality at run time by registering them with a listener
to handle specific event callbacks. This allows for extra processing on
a business object either immediately before, or immediately after an
object is written to or read from XML.

There are two types of event callbacks that you can handle in two
different ways:

1.  To handle listener-based callbacks, set an event handler on an
    instance of `XMLMarshaller` or `XMLUnmarshaller` that implements a
    required interface, such as `XMLMarshalListener` or
    `XMLUnmarshalListener`. The events are triggered on the marshaller
    or unmarshaller's listener for any classes being marshalled or
    unmarshalled.
2.  To handle class-specific callbacks, you need to provide the required
    callback methods on your business objects.

|                                                                                                                                                    |
| :------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Note:** If you specify both the listener and the business object callbacks, the class-specific method will be invoked before the listener event. |

This example shows how to create your custom event listeners.

<span id="Example 52-33"></span> **'' Implementing the EclipseLink
XMLMarhsalListener and XMLUnmarhsalListener Interfaces**''

`public class EmployeeMarshalListener implements XMLMarshalListener {`

`   public void beforeMarshal(Object target) {`
`       // do something`
`   }`

`   public void afterMarshal(Object target) {`
`       // do something`
`   }`
`)`

`public class EmployeeUnmarshalListener implements XMLUnmarshalListener {`

`   public void beforeUnmarshal(Object target, Object parent) {`
`       // do something`
`   }`

`   public void afterUnmarshal(Object target, Object parent) {`
`       // do something`
`   }`
`}`

The following examples show how to use the listeners in your
application.

<span id="Example 52-34"></span> **'' Using the Marshal Listener**''

`...`
`XMLMarshaller marshaller = context.createMarshaller();`
`marshaller.setMarshalListener(new EmployeeMarshalListener());`
`marshaller.marshal(myObject, System.out);`
`...`

<span id="Example 52-35"></span> **'' Using the Unmarshal Listener**''

`...`
`XMLUnmarshaller unmarshaller = context.createUnmarshaller();`
`unmarshaller.setUnmarshalListener(new EmployeeUnmarshalListener());`
`Object myObject = unmarshaller.unmarshal(myFile);`
`...`

##### How to Use EclipseLink XMLBinder

`XMLBinder` is a run-time class that allows you to preserve a document
that you have unmarshalled, as well as to resynchronize that document
with the unmarshalled objects at any time.

|                                                                                                                                                                          |
| :----------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Note:** This functionality is based on the JAXB binder API (`javax.xml.bind.Binder`<XmlNode>). This is an addition to the design-time method of document preservation. |

When the `XMLBinder` unmarshalls XML nodes into mapping objects, and
then performs an update operation, it preserves not only the order of
elements, but also the comments from an original XML document using the
cached value. This way, both the returned node and the cached node are
identical and reflect the preserved document. When adding new elements,
EclipseLink `XMLBinder` places them at the correct location (relative to
other mapped content) in the node.

When unmarshalling a document that contains only unmapped content,
setting some values and then marshalling, the `XMLBinder` adds new
elements before existing unmapped data, such as comments and processing
instructions.

This example demonstrates how you can unmarshall a document using an
instance of an `XMLBinder`.

<span id="Example 52-2"></span> **'' Unmarshalling a Document Using
XMLBinder**''

`XMLContext conext = new XMLContext(myProject);`
`XMLBinder binder = context.createBinder();`
`Employee emp = (Employee) binder.unmarshal(myDocument);`

In the preceding example, `emp` is the root object that was unmarshalled
from the provided document. The binder maintains references to the
original XML document as well as objects generated during the unmarshall
operation.

The following example demonstrates how you can make changes to the
object (`Employee`) and update the XML document using an instance of an
`XMLBinder`.

<span id="''Example 52-3"></span> *' Making Changes to an Object and to
Updating XML Using XMLBinder*'''

`...`
`emp.setPhoneNumber("123-4567");`
`binder.updateXML(emp);`

In the preceding example, the `updateXML` method will update the cached
node in the binder. Note that the cached node preserves the document,
including comments, as the following example shows:

<employee>

`      `<name>`John Smith `</name>
`      `<phone-number>`123-4567`</phone-number>
`   `
</employee>

The following example demonstrates how you can obtain an associated node
for a subobject (`Address`) of the `Employee` using an instance of an
`XMLBinder`.

<span id="Example 52-4"></span> **'' Obtaining an Associated Node Using
XMLBinder**''

`...`
`Address addr = emp.getAddress();`
`Node addressNode = binder.getXMLNode(addr);`

In the preceding example, the returned node (`addressNode`) is the XML
node in the original XML document that was used to build this employee's
`Address` object.

This example demonstrates how you can make changes to an XML node and
update objects (`Address`) of the `Employee` using an instance of an
`XMLBinder`.

<span id="Example 52-5"></span> **'' Making Changes to an XML Node and
Updating Objects Using XMLBinder**''

`...`
`addressNode.setAttribute("apt-no", "1527");`
`Address updatedAddressNode = binder.updateObject(addressNode);`

In the preceding example, the address returned from the binder operation
is the original Address object created during the unmarshall operation,
but now it contains the updated apartment number information from the
XML document.

##### How to Use JAXBContext

You can create an instance of `JAXBContext` from a collection of classes
that are to be bound to XML. This will generate a EclipseLink project
from the classes dynamically at run time.

Using the instance of `JAXBContext` you can obtain `Marshaller` and
`Unmarshaller` instances to operate on those classes, as the [Creating
and Using JAXBContext](#Example_52-6 "wikilink") example shows. Note
that this example assumes that you configure your application classpath
to include your domain object class files.

<span id="Example 52-6"></span> **'' Creating and Using JAXBContext**''

`Class[] classes = {Employee.class, Address.class, Department.class};`
`JAXBContext jaxbContext = JAXBContext.newInstance(classes);`
`Marshaller marshaller = jaxbContext.createMarshaller();`
`marshaller.marshal(myEmployee, myOutput);`

|                                                    |
| :------------------------------------------------- |
| **Note:** The `JAXBContext` object is thread-safe. |

##### How to Use JAXBElement

EclipseLink lets you marshal to and unmarshal from `JAXBElement` types.
The `javax.xml.bind.JAXBElement` class provides access to the following
basic properties of an XML element:

  - its qualified name, which is composed of `{target namespace}` and
    `{name}`
  - its value, which is an instance of the Java class binding of its
    `{type definition}`
  - whether or not the element's content is `{nillable}`

EclipseLink supports the following JAXB element marshal API defined in
the `Marshaller`:

  - `marshal(java.lang.Object jaxbElement, java.io.Writer writer)`
  - `marshal(java.lang.Object jaxbElement, java.io.OutputStream os)`
  - `marshal(java.lang.Object jaxbElement, org.xml.sax.ContentHandler)`
  - `marshal(java.lang.Object jaxbElement, javax.xml.transform.Result)`
  - `marshal(java.lang.Object jaxbElement, org.w3c.dom.Node)`
  - `marshal(java.lang.Object jaxbElement,
    javax.xml.stream.XMLStreamWriter writer)`

|                                                                                                                                                                                   |
| :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Note:** If the first parameter is not a `JAXBElement` instance, the marshal operation will throw an `org.eclipse.persistence.exceptions.XMLMarshalException.MARSHAL_EXCEPTION`. |

EclipseLink provides implementation of the following JAXB element
unmarshal API defined in the `Unarshaller`:

  - <T>`  JAXBElement `<T>`  unmarshal(org.w3c.dom.Node node,
    Class `<T>`  declaredType) `
  - <T>`  JAXBElement `<T>`  unmarshal(javax.xml.transform.Source
    source, Class `<T>`  declaredType) `
  - <T>`  JAXBElement `<T>`  unmarshal(javax.xml.stream.XMLStreamReader
    streamReader, Class `<T>`  declaredType) `
  - <T>`  JAXBElement `<T>`  unmarshal(javax.xml.stream.XMLEventReader
    eventReader, Class `<T>`  declaredType) `

### JAXB Validation

EclipseLink can validate both complete object trees and subtrees against
the XML schema that was used to generate the implementation classes. In
addition, EclipseLink will validate both root objects (objects that
correspond to the root element of the XML document) and nonroot objects
against the schema used to generate the object's implementation class.

When validating an object tree, EclipseLink performs the following
checks (in order):

1.  Check that element appears in the document at the specified
    location.
2.  If **maxOccurs** or **minOccurs** is specified, check number of
    elements.
3.  If **type** is specified, check that element value satisfies the
    type constraints.
4.  If a **fixed value** is specified, check that the element value
    matches it.
5.  If **restrictions** (length, patterns, enumerations, and so on) are
    specified, check that the element value satisfies it.
6.  If an **ID** type is specified during a `validateRoot` operation,
    check that the ID value is unique in the document.
7.  If an **IDREF** type is specified during a `validateRoot` operation,
    check that the ID referenced exists in the document.

If validation errors are encountered, EclipseLink stops validating the
object tree and creates a `ValidationEvent` object, according to the
JAXB specification. If an error occurs in a subobject, EclipseLink will
not validate further down that object's subtree.

For more information on using EclipseLink XML to perform validation, see
[Using EclipseLink JAXB Compiler-Generated Files at Run
Time](#Using_EclipseLink_JAXB_Compiler-Generated_Files_at_Run_Time "wikilink").

For additional information on JAXB and validation, refer to the JAXB
specification at <http://java.sun.com/xml/jaxb/>.

-----

*[Copyright
Statement](EclipseLink_User's_Guide_Copyright_Statement "wikilink")*

[Category: EclipseLink User's
Guide](Category:_EclipseLink_User's_Guide "wikilink") [Category: Release
1](Category:_Release_1 "wikilink") [Category:
Concept](Category:_Concept "wikilink") [Category:
XML](Category:_XML "wikilink")