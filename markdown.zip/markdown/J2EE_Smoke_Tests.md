## J2EE 1.4

### Setup

  - Install a J2EE 1.4-compatible server, such as JOnAS, JBoss or
    WebSphere
  - Add the server in Window -\> Preferences -\> Server -\> Runtime
    Environments
  - Install the XDoclet support (1.2.1, 1.2.2 or 1.2.3)
  - Add the XDoclet support in Window -\> Preferences -\> Java EE -\>
    XDoclet
  - Expand the XDoclet node and configure the ejbdoclet and webdoclet
    support for your installed server(s).

### Create resources

#### Create a Web 2.4 project

  - Target it at the installed J2EE server
  - Choose "Dynamic Web Project with XDoclet" from Configurations
  - Create a servlet inside the project
      - enter "test" for Java package
      - specify a name
      - select the "Generate a XDoclet annotated class" checkbox
      - give "test" for servlet's name (second page)
      - leave only the "doGet" checkbox checked (third page - inherited
        abstract methods)
      - add the following code in the doGet() method of the servlet
        class

`response.getOutputStream().println("This is a test servlet. ");`

  - Create a JSP inside the project
      - file name: index.jsp
      - add the following text inside the
        <body>
        tag

`This is the Smoke Test.`

  - Ensure the project builds and is targeted to the server correctly

#### Create an EAR 1.4 project

  - Target it at the installed J2EE server
  - Select the Web 2.4 project as J2EE module (second page)

#### Create an EJB 2.1 project

  - Target it at the installed J2EE server
  - Choose "EJB Project with XDoclet" from Configurations
  - Choose "Add project to an EAR" and choose the previously created EAR
    project
  - Create a new XDoclet Enterprise JavaBean
      - choose Session Bean as a type
      - enter "test" for Java package

### Verify Project Explorer content

#### Verify the Web project

  - verify that the servlet class exists in the project file structure
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 2.4
  - verify that the servlet class is listed under the "Servlets" node
  - verify that the "/test -\>" url mapping is listed under the "Servlet
    Mappings" node

#### Verify the EJB project

  - verify that an EJB client project is created together with the EJB
    project
  - verify that there is an ejb-client-jar tag in the ejb-jar.xml
    deployment descriptor
  - verify that session bean classes exist in the project file structure
      - EJB interfaces should be in the EJB client project instead in
        the EJB project
  - verify there is a node for the deployment descriptor
  - the deployment descriptor node should specify version 2.1
  - verify that the there is a node for the bean under the "Session
    Beans" node
      - verify that under this node all bean classes and interfaces are
        listed

#### Verify the EAR project

  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 1.4
  - expand the deployment descriptor node
      - verify there are "Modules" and "Utility JARs" nodes
  - expand the Modules node
      - verify there are references to the Web and EJB modules

### Export the projects

#### Export the Web project

  - verify that the deployment descriptor XML, Servlet classes, JSP
    files and libraries are included in the WAR

#### Export the EJB project

  - verify that all of the classes and the deployment descriptor XML are
    included in the EJB JAR

#### Export the EAR project

  - verify that deployment descriptor XML and the WARs and EJB JARs of
    the referenced J2EE modules are included

### Deploy and Run the application

  - Run the test servlet
      - Right click on the servlet node in the deployment descriptor
        tree and choose Run As -\> Run on Server
      - Select the targeted J2EE server
      - The internal browser should request the test servlet and show
        the result page
  - Run the index.jsp
      - Right click on the index.jsp and choose Run As -\> Run on Server
      - Select the targeted J2EE server
      - The internal browser should request the index.jsp and show the
        result page

## Java EE 5

### Setup

  - Install a Java EE 5-compatible server, such as Glassfish or JBoss
  - Add the server in Window -\> Preferences -\> Server -\> Runtime
    Environments

### Create resources

#### Create a Web 2.5 project

  - Target it at the installed Java EE server
  - Create a servlet inside the project
      - enter "test" for Java package
      - specify a name
      - give "test" for servlet's name (second page)
      - leave only the "doGet" checkbox checked (third page - inherited
        abstract methods)
      - add the following code in the doGet() method of the servlet
        class

`response.getOutputStream().println("This is a test servlet. ");`

  - Create a JSP inside the project
      - file name: index.jsp
      - add the following text inside the
        <body>
        tag

`This is the Smoke Test.`

  - Ensure the project builds and is targeted to the server correctly

#### Create an EAR 5 project

  - Target it at the installed Java EE server
  - Select the Web 2.5 project as J2EE module (second page)

#### Create an EJB 3.0 project

  - Target it at the installed Java EE server
  - Choose "Add project to an EAR" and choose the previously created EAR
    5 project
  - Create a new Session Bean
      - enter "test" for Java package
      - enter "TestBean" for Class name
      - leave "Create Business Interface \> Local" checked

### Verify Project Explorer content

#### Verify the Web project

  - verify that the servlet class exists in the project file structure
  - verify there is a web.xml file under the WEB-INF folder
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 2.5
  - verify that the servlet class is listed under the "Servlets" node
  - verify that the "/test -\>" url mapping is listed under the "Servlet
    Mappings" node

#### Verify the EJB project

  - verify that an EJB client project is created together with the EJB
    project
  - verify that session bean classes exist in the project file structure
      - EJB interfaces should be generated in the EJB client project
        instead of in the EJB project
  - verify there is an ejb-jar.xml file under the /ejbModule/META-INF
    directory
      - there should be an ejb-client-jar tag pointing to the EJB client
        project
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 3.0
  - verify that the there is a node for the bean under the "Session
    Beans" node
      - verify that under this node all bean classes and interfaces are
        listed

#### Verify the EAR project

  - verify there is no application.xml file under the
    /EarContent/META-INF directory
      - verify that /META-INF directory is not generated under
        /EarContent
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 5.0
  - expand the deployment descriptor node
      - verify there are "Bundled Libraries" and "Modules" nodes
  - expand the Bundled Libraries node
      - verify there is reference to the EJB Client JAR
  - expand the Modules node
      - verify there are references to the Web and EJB modules

### Export the projects

#### Export the Web project

  - verify that the deployment descriptor XML, Servlet classes, JSP
    files and libraries are included in the WAR

#### Export the EJB project

  - verify that all of the classes and the deployment descriptor XML are
    included in the EJB JAR

#### Export the EAR project

  - verify that the WARs and EJB JARs of the referenced J2EE modules are
    included
  - verify there is no deployment descriptor XML

### Deploy and Run the application

  - Run the test servlet
      - Right click on the servlet node in the deployment descriptor
        tree and choose Run As -\> Run on Server
      - Select the targeted Java EE server
      - The internal browser should request the test servlet and show
        the result page
  - Run the index.jsp
      - Right click on the index.jsp and choose Run As -\> Run on Server
      - Select the targeted Java EE server
      - The internal browser should request the index.jsp and show the
        result page

## Java EE 6

### Setup

  - Install a Java EE 6-compatible server, such as GlassFish v3
  - Add the server in Window -\> Preferences -\> Server -\> Runtime
    Environments

### Create resources

#### Create a Web 3.0 project

  - Target it at the installed Java EE server
  - Create a servlet inside the project
      - enter "test" for Java package
      - specify a name
      - give "test" for servlet's name (second page)
      - leave only the "doGet" checkbox checked (third page - inherited
        abstract methods)
      - add the following code in the doGet() method of the servlet
        class

`response.getOutputStream().println("This is a test servlet. ");`

  - Create a JSP inside the project
      - file name: index.jsp (Note: If you are using the GlassFish v3
        server and server adapter, the wizard for creating the Web 3.0
        project had already created an index.jsp file, so you would have
        to choose some other name)
      - add the following text inside the
        <body>
        tag

`This is the Smoke Test.`

  - Ensure the project builds and is targeted to the server correctly

#### Create an EAR 6 project

  - Target it at the installed Java EE server
  - Select the Web 3.0 project as J2EE module (second page)

#### Create an EJB 3.1 project

  - Target it at the installed Java EE server
  - Choose "Add project to an EAR" and choose the previously created EAR
    6 project
  - Create a new Session Bean
      - enter "test" for Java package
      - enter "TestBean" for Class name
      - choose the "Create Business Interface \> Local" option (since by
        default a No-interface client view is specified) and uncheck the
        No-interface View box

### Verify Project Explorer content

#### Verify the Web project

  - verify that the servlet class exists in the project file structure
  - verify there is no web.xml file under the WEB-INF folder
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 3.0
  - verify that the servlet class is listed under the "Servlets" node
  - verify that the "/test -\>" url mapping is listed under the "Servlet
    Mappings" node

#### Verify the EJB project

  - verify that an EJB client project is created together with the EJB
    project
  - verify that session bean classes exist in the project file structure
      - EJB interfaces should be generated in the EJB client project
        instead of in the EJB project
  - verify there is an ejb-jar.xml file under the /ejbModule/META-INF
    directory
      - there should be an ejb-client-jar tag pointing to the EJB client
        project
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 3.1
  - verify that the there is a node for the bean under the "Session
    Beans" node
      - verify that under this node all bean classes and interfaces are
        listed

#### Verify the EAR project

  - verify there is no application.xml file under the
    /EarContent/META-INF directory
      - verify that /META-INF directory is not generated under
        /EarContent
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 6.0
  - expand the deployment descriptor node
      - verify there are "Bundled Libraries" and "Modules" nodes
  - expand the Bundled Libraries node
      - verify there is reference to the EJB Client JAR
  - expand the Modules node
      - verify there are references to the Web and EJB modules

### Export the projects

#### Export the Web project

  - verify that the Servlet classes, JSP files and libraries are
    included in the WAR (there should be no deployment descriptor XML)

#### Export the EJB project

  - verify that all of the classes and the deployment descriptor XML are
    included in the EJB JAR

#### Export the EAR project

  - verify that the WARs and EJB JARs of the referenced J2EE modules are
    included
  - verify there is no deployment descriptor XML

### Deploy and Run the application

  - Run the test servlet
      - Right click on the servlet node in the deployment descriptor
        tree and choose Run As -\> Run on Server
      - Select the targeted Java EE server
      - The internal browser should request the test servlet and show
        the result page
  - Run the index.jsp
      - Right click on the index.jsp and choose Run As -\> Run on Server
      - Select the targeted Java EE server
      - The internal browser should request the index.jsp and show the
        result page

## Java EE 7

### Setup

  - Install a Java EE 7-compatible server, such as GlassFish v4
  - Add the server in Window -\> Preferences -\> Server -\> Runtime
    Environments

### Create resources

#### Create a Web 3.1 project

  - Target it at the installed Java EE server
  - Create a servlet inside the project
      - enter "test" for Java package
      - specify a name
      - give "test" for servlet's name (second page)
      - leave only the "doGet" checkbox checked (third page - inherited
        abstract methods)
      - add the following code in the doGet() method of the servlet
        class

`response.getOutputStream().println("This is a test servlet. ");`

  - Create a JSP inside the project
      - file name: index.jsp (Note: If you are using the GlassFish v4
        server and server adapter, the wizard for creating the Web 3.1
        project had already created an index.jsp file, so you would have
        to choose some other name)
      - add the following text inside the
        <body>
        tag

`This is the Smoke Test.`

  - Ensure the project builds and is targeted to the server correctly

#### Create an EAR 7 project

  - Target it at the installed Java EE server
  - Select the Web 3.1 project as J2EE module (second page)

#### Create an EJB 3.2 project

  - Target it at the installed Java EE server
  - Choose "Add project to an EAR" and choose the previously created EAR
    7 project
  - Create a new Session Bean
      - enter "test" for Java package
      - enter "TestBean" for Class name
      - choose the "Create Business Interface \> Local" option (since by
        default a No-interface client view is specified) and uncheck the
        No-interface View box

### Verify Project Explorer content

#### Verify the Web project

  - verify that the servlet class exists in the project file structure
  - verify there is no web.xml file under the WEB-INF folder
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 3.1
  - verify that the servlet class is listed under the "Servlets" node
  - verify that the "/test -\>" url mapping is listed under the "Servlet
    Mappings" node

#### Verify the EJB project

  - verify that an EJB client project is created together with the EJB
    project
  - verify that session bean classes exist in the project file structure
      - EJB interfaces should be generated in the EJB client project
        instead of in the EJB project
  - verify there is an ejb-jar.xml file under the /ejbModule/META-INF
    directory
      - there should be an ejb-client-jar tag pointing to the EJB client
        project
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 3.2
  - verify that the there is a node for the bean under the "Session
    Beans" node
      - verify that under this node all bean classes and interfaces are
        listed

#### Verify the EAR project

  - verify there is no application.xml file under the
    /EarContent/META-INF directory
      - verify that /META-INF directory is not generated under
        /EarContent
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 7.0
  - expand the deployment descriptor node
      - verify there are "Bundled Libraries" and "Modules" nodes
  - expand the Bundled Libraries node
      - verify there is reference to the EJB Client JAR
  - expand the Modules node
      - verify there are references to the Web and EJB modules

### Export the projects

#### Export the Web project

  - verify that the Servlet classes, JSP files and libraries are
    included in the WAR (there should be no deployment descriptor XML)

#### Export the EJB project

  - verify that all of the classes and the deployment descriptor XML are
    included in the EJB JAR

#### Export the EAR project

  - verify that the WARs and EJB JARs of the referenced J2EE modules are
    included
  - verify there is no deployment descriptor XML

### Deploy and Run the application

  - Run the test servlet
      - Right click on the servlet node in the deployment descriptor
        tree and choose Run As -\> Run on Server
      - Select the targeted Java EE server
      - The internal browser should request the test servlet and show
        the result page
  - Run the index.jsp
      - Right click on the index.jsp and choose Run As -\> Run on Server
      - Select the targeted Java EE server
      - The internal browser should request the index.jsp and show the
        result page

## Java EE 8

### Setup

  - Install a Java EE 8-compatible server, such as GlassFish v5
  - Add the server in Window -\> Preferences -\> Server -\> Runtime
    Environments (Note: there are not yet any Java EE 8-compatible
    servers with an appropriate WTP Server adapter)

### Create resources

#### Create a Web 4.0 project

  - Target it at the installed Java EE server
  - Create a servlet inside the project
      - enter "test" for Java package
      - specify a name
      - give "test" for servlet's name (second page)
      - leave only the "doGet" checkbox checked (third page - inherited
        abstract methods)
      - add the following code in the doGet() method of the servlet
        class

`response.getOutputStream().println("This is a test servlet. ");`

  - Create a JSP inside the project
      - file name: index.jsp (Note: If you are using the GlassFish v5
        server and server adapter, the wizard for creating the Web 4.0
        project had already created an index.jsp file, so you would have
        to choose some other name)
      - add the following text inside the
        <body>
        tag

`This is the Smoke Test.`

  - Ensure the project builds and is targeted to the server correctly

#### Create an EAR 8 project

  - Target it at the installed Java EE server
  - Select the Web 4.0 project as J2EE module (second page)

#### Create an EJB 3.2 project

  - Target it at the installed Java EE server
  - Choose "Add project to an EAR" and choose the previously created EAR
    8 project
  - Create a new Session Bean
      - enter "test" for Java package
      - enter "TestBean" for Class name
      - choose the "Create Business Interface \> Local" option (since by
        default a No-interface client view is specified) and uncheck the
        No-interface View box

### Verify Project Explorer content

#### Verify the Web project

  - verify that the servlet class exists in the project file structure
  - verify there is no web.xml file under the WEB-INF folder
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 4.0
  - verify that the servlet class is listed under the "Servlets" node
  - verify that the "/test -\>" url mapping is listed under the "Servlet
    Mappings" node

#### Verify the EJB project

  - verify that an EJB client project is created together with the EJB
    project
  - verify that session bean classes exist in the project file structure
      - EJB interfaces should be generated in the EJB client project
        instead of in the EJB project
  - verify there is an ejb-jar.xml file under the /ejbModule/META-INF
    directory
      - there should be an ejb-client-jar tag pointing to the EJB client
        project
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 3.2
  - verify that the there is a node for the bean under the "Session
    Beans" node
      - verify that under this node all bean classes and interfaces are
        listed

#### Verify the EAR project

  - verify there is no application.xml file under the
    /EarContent/META-INF directory
      - verify that /META-INF directory is not generated under
        /EarContent
  - verify there is a node for the deployment descriptor
      - the deployment descriptor node should specify version 8.0
  - expand the deployment descriptor node
      - verify there are "Bundled Libraries" and "Modules" nodes
  - expand the Bundled Libraries node
      - verify there is reference to the EJB Client JAR
  - expand the Modules node
      - verify there are references to the Web and EJB modules

### Export the projects

#### Export the Web project

  - verify that the Servlet classes, JSP files and libraries are
    included in the WAR (there should be no deployment descriptor XML)

#### Export the EJB project

  - verify that all of the classes and the deployment descriptor XML are
    included in the EJB JAR

#### Export the EAR project

  - verify that the WARs and EJB JARs of the referenced J2EE modules are
    included
  - verify there is no deployment descriptor XML

### Deploy and Run the application

(Note: there are not yet any Java EE 8-compatible servers with an
appropriate WTP Server adapter, so this step cannot be completed)

  - Run the test servlet
      - Right click on the servlet node in the deployment descriptor
        tree and choose Run As -\> Run on Server
      - Select the targeted Java EE server
      - The internal browser should request the test servlet and show
        the result page
  - Run the index.jsp
      - Right click on the index.jsp and choose Run As -\> Run on Server
      - Select the targeted Java EE server
      - The internal browser should request the index.jsp and show the
        result page

## See also

[Category:Eclipse Web Tools Platform
Project](Category:Eclipse_Web_Tools_Platform_Project "wikilink")
[WTP_Testing_Related](Category:WTP_Testing_Related "wikilink")