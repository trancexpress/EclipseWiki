## Logistics

Meetings are held on Thursday's, [11 AM to 12 Noon Eastern
Time](http://www.timeanddate.com/worldclock/fixedtime.html?hour=11&min=0&sec=0&p1=179).
Meeting will be skipped if there is no preliminary agenda.

Dial-in numbers:
Toll Free: 888-426-6840
Toll (USA): 215-861-6239
Participant Passcode: 32557235
[Full list of global access
numbers](https://www.teleconference.att.com/servlet/glbAccess?process=1&accessCode=6460142&accessNumber=2158616239)

## Meeting Agenda

Next meeting: [2013-04-24](JEE_Status_Meetings/2013-04-24 "wikilink") at
10 am EDT

## Topics

Juno Planning continued

  - Maven integration
  - Java EE 6 spec enhancements?
  - Java 7 enhancements?
  - "Web" project / facet consolidation?

### Past topics

### On focus

  - WTP 3.4 planning.
      - Themes: **Ease of Use** and **Java EE 6**
      - [Java EE Tools
        planning](http://www.eclipse.org/projects/project-plan.php?projectid=webtools.jeetools)
      - [EJB Tools
        planning](http://www.eclipse.org/projects/project-plan.php?projectid=webtools.ejbtools)
      - [Planning
        chart](https://bugs.eclipse.org/bugs/report.cgi?bug_file_loc=&bug_file_loc_type=allwordssubstr&bug_id=&bugidtype=include&chfieldfrom=&chfieldto=Now&chfieldvalue=&classification=WebTools&email1=&email2=&emailtype1=substring&emailtype2=substring&field0-0-0=noop&keywords=plan&keywords_type=allwords&long_desc=&long_desc_type=allwordssubstr&product=WTP%20Common%20Tools&product=WTP%20EJB%20Tools&product=WTP%20Java%20EE%20Tools&short_desc=&short_desc_type=allwordssubstr&status_whiteboard=&status_whiteboard_type=allwordssubstr&target_milestone=3.1&target_milestone=3.1%20M1&target_milestone=3.1%20M2&target_milestone=3.1%20M3&target_milestone=3.1%20M4&target_milestone=3.1%20M5&target_milestone=3.1%20M6&target_milestone=3.1%20M7&target_milestone=3.1%20RC1&target_milestone=3.1%20RC2&target_milestone=3.1%20RC3&target_milestone=3.1%20RC4&type0-0-0=noop&value0-0-0=&votes=&x_axis_field=target_milestone&y_axis_field=product&z_axis_field=&width=600&height=350&action=wrap&format=table)
      - [Unplanned
        enhancements](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=target_milestone&y_axis_field=product&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&product=WTP+Common+Tools&product=WTP+EJB+Tools&product=WTP+Java+EE+Tools&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=nowords&keywords=plan&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&bug_severity=enhancement&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

### Pending

  - Write mode for Java EE models
    [242722](https://bugs.eclipse.org/242722)
  - Review ProjectStructure enhancements

## Past Meeting Minutes

  - 2011
    October
    [2011-10-06](JEE_Status_Meetings/2011-10-06 "wikilink")

<!-- end list -->

  - 2010
    August
    [2010-08-26](JEE_Status_Meetings/2010-08-26 "wikilink")
    [2010-08-19](JEE_Status_Meetings/2010-08-19 "wikilink")
    [2010-08-12](JEE_Status_Meetings/2010-08-12 "wikilink")
    [2010-08-05](JEE_Status_Meetings/2010-08-05 "wikilink")

<!-- end list -->

  - May
    [2010-05-20](JEE_Status_Meetings/2010-05-20 "wikilink")
    [2010-05-13](JEE_Status_Meetings/2010-05-13 "wikilink")

<!-- end list -->

  - April
    [2010-04-29](JEE_Status_Meetings/2010-04-29 "wikilink")
    [2010-04-22](JEE_Status_Meetings/2010-04-22 "wikilink")
    [2010-04-15](JEE_Status_Meetings/2010-04-15 "wikilink")
    [2010-04-08](JEE_Status_Meetings/2010-04-08 "wikilink")

<!-- end list -->

  - March
    [2010-03-18](JEE_Status_Meetings/2010-03-18 "wikilink")
    [2010-03-11](JEE_Status_Meetings/2010-03-11 "wikilink")
    [2010-03-04](JEE_Status_Meetings/2010-03-04 "wikilink")

<!-- end list -->

  - February
    [2010-02-25](JEE_Status_Meetings/2010-02-25 "wikilink")
    [2010-02-04](JEE_Status_Meetings/2010-02-04 "wikilink")

<!-- end list -->

  - January
    [2010-01-28](JEE_Status_Meetings/2010-01-28 "wikilink")
    [2010-01-14](JEE_Status_Meetings/2010-01-14 "wikilink")
    [2010-01-07](JEE_Status_Meetings/2010-01-07 "wikilink")

<!-- end list -->

  - 2009
    December
    [2009-12-10](JEE_Status_Meetings/2009-12-10 "wikilink")
    [2009-12-03](JEE_Status_Meetings/2009-12-03 "wikilink")

<!-- end list -->

  - November
    [2009-11-19](JEE_Status_Meetings/2009-11-19 "wikilink")

<!-- end list -->

  - October
    [2009-10-15](JEE_Status_Meetings/2009-10-15 "wikilink")
    [2009-10-01](JEE_Status_Meetings/2009-10-01 "wikilink")

<!-- end list -->

  - September
    [2009-09-24](JEE_Status_Meetings/2009-09-24 "wikilink")
    [2009-09-17](JEE_Status_Meetings/2009-09-17 "wikilink")

<!-- end list -->

  - August
    [2009-08-27](JEE_Status_Meetings/2009-08-27 "wikilink")
    [2009-08-20](JEE_Status_Meetings/2009-08-20 "wikilink")
    [2009-08-06](JEE_Status_Meetings/2009-08-06 "wikilink")

<!-- end list -->

  - July
    [2009-07-30](JEE_Status_Meetings/2009-07-30 "wikilink")
    [2009-07-23](JEE_Status_Meetings/2009-07-23 "wikilink")
    [2009-07-16](JEE_Status_Meetings/2009-07-16 "wikilink")
    [2009-07-09](JEE_Status_Meetings/2009-07-09 "wikilink")
  - June
    [2009-06-25](JEE_Status_Meetings/2009-06-25 "wikilink")
    [2009-06-18](JEE_Status_Meetings/2009-06-18 "wikilink")
    [2009-06-11](JEE_Status_Meetings/2009-06-11 "wikilink")

<!-- end list -->

  - January
    [2009-01-29](JEE_Status_Meetings/2009-01-29 "wikilink")

<!-- end list -->

  - 2008
    [2008-12-11](JEE_Status_Meetings/2008-12-11 "wikilink")
    [2008-11-13](JEE_Status_Meetings/2008-11-13 "wikilink")
    [2008-11-06](JEE_Status_Meetings/2008-11-06 "wikilink")
    [2008-10-23](JEE_Status_Meetings/2008-10-23 "wikilink")
    [2008-10-02](JEE_Status_Meetings/2008-10-02 "wikilink")
    [2008-09-25](JEE_Status_Meetings/2008-09-25 "wikilink")
    [2008-09-11](JEE_Status_Meetings/2008-09-11 "wikilink")
    [2008-09-04](JEE_Status_Meetings/2008-09-04 "wikilink")
    [2008-08-28](JEE_Status_Meetings/2008-08-28 "wikilink")
    [2008-07-31](JEE_Status_Meetings/2008-07-31 "wikilink")
    [2008-07-24](JEE_Status_Meetings/2008-07-24 "wikilink")
    [2008-07-16](JEE_Status_Meetings/2008-07-16 "wikilink")

[Category:Eclipse Web Tools Platform
Project](Category:Eclipse_Web_Tools_Platform_Project "wikilink")