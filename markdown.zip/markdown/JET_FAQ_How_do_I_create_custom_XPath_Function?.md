## Question

JET provides tools for creating custom XPath functions. How does it work
?

## Answer

1\. Create a plug-in project

2\. In the Plug-in manifest editor, go to the Dependencies tab and add :
org.eclipse.jet, org.eclipse.core.runtime, org.eclipse.core.resources

3\. In the Plug-in manifest editor, go to the Extensions tab, and add
org.eclipse.jet.xpathfunctions.

4\. Add a xpathFunction entry under this. Set the name, and the min/max
arguments as you wish.

5\. Click the Implementation link, and specify a Class to implement the
function.

6\. Code the class.

The following example is an XPathFunction which name is
"resourceExists", and min/max attributes are set to 1.

    package org.eclipse.jet.example.customfunction;

    import java.util.List;
    import org.eclipse.core.resources.IResource;
    import org.eclipse.core.resources.ResourcesPlugin;
    import org.eclipse.jet.xpath.XPathFunction;
    import org.eclipse.jet.xpath.XPathUtil;

    public class ResourceExistsFunction implements XPathFunction {

      public Object evaluate(List args) {
        String path = XPathUtil.xpathString(args.get(0));
        IResource resource = ResourcesPlugin.getWorkspace().getRoot().findMember(path);
        return Boolean.valueOf(resource != null && resource.exists());
      }
    }

In your template, usage would then be:

    <c:if test="resourceExists('someproject/somefolder/somefile.c')">
        .. do this if file exists
    </c:if>

## See Also

  - [JET FAQ How do I create custom
    tag?](JET_FAQ_How_do_I_create_custom_tag? "wikilink")

Back to the [M2T-JET-FAQ](M2T-JET-FAQ "wikilink")

[Category:Modeling](Category:Modeling "wikilink")
[Category:M2T](Category:M2T "wikilink")