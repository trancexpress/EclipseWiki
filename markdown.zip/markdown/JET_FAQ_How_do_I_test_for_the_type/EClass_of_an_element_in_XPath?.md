To test for a subclass, use the *self::Subclass* test. See the sceanrio
below. The following Ecore relationships exits

  - SuperClass \<- SubClass1
  - SuperClass \<- SubClass2
  - SuperClass \<- Banana

bananas are caught in the *otherwise* clause.

```

<c:iterate select="$container/referenceOfTypeSuperClass" var="superClassInstance">

<c:choose>

<c:when test="$superClassInstance/self::SubClass1">
This is an instance of type SubClass1!
</c:when>

<c:when test="$superClassInstance/self::SubClass2">
This is an instance of type SubClass2!
</c:when>

<c:otherwise>
This is an instance of SuperClass, or any other Subclass of it!
</c:otherwise>

</c:choose>

</c:iterate>
```