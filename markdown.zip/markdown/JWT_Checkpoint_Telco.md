# Partners

  - An EU project wants to use JWT for managing their BP (see Florian)
  - A french research project is interested in the JoNES project (which
    predates the friend project SCOrWare) ; Ask for a summary for JWT
    (ask Marc)

# Roadmap

Agilpro version next week \!

  - Time to get some buzz out (tss, stp, ml, blogs)

From that point on we still need to do many changes to generate xpdl
code.

  - Right now only architecture, metamodel are done

Florian will meet Gunther, who is doing things that are in line with the
WAM

  - what level of contribution ? API level would be win-win, see with
    him

Ask etienne or emo about eclipse code review delays.

# Community

  - We should be open and write to the community (wiki, mailing lists)
    rather than keep it only for a subset of the mailing lists
  - What about JWT blog(s) ? Push that idea to the community for
    feedback.

# Next checkpoint telco

15/05 4 pm