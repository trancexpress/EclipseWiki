  - [Extension Requirements and Use
    Cases](JWT_Metamodel_Extension_Specifications/Requirements "wikilink")
  - [Specification Alternatives
    Study](JWT_Metamodel_Extension_Specifications/Alternatives_Study "wikilink")
  - [Metamodel Extension
    Prototype](JWT_Metamodel_Extension_Specifications/Prototype "wikilink")
    - working samples (added 20080527)
  - [Metamodel extensions and JWT WE (added
    20080527)](JWT_Metamodel_Extension_Specifications/WE "wikilink")
  - [Metamodel extensions and JWT
    Transformations](JWT_Metamodel_Extension_Specifications/Transformations "wikilink")
    - TODO
  - [Metamodel extensions and JWT
    Runtimes](JWT_Metamodel_Extension_Specifications/Runtime "wikilink")
    - TODO
  - [Technical specifications
    v1](JWT_Metamodel_Extension_Specifications/Technical_Specifications_v1 "wikilink")
    (obsolete)
  - [Technical specifications
    v2](JWT_Metamodel_Extension_Specifications/Technical_Specifications_v2 "wikilink")
    - See bugzilla
    <https://bugs.eclipse.org/bugs/show_bug.cgi?id=241567> .
  - Aspects metamodel extension feature development - See bugzilla
    <https://bugs.eclipse.org/bugs/show_bug.cgi?id=241567>
  - Aspects metamodel extension documentation - See [JWT Metamodel
    Extension](JWT_Metamodel_Extension "wikilink").