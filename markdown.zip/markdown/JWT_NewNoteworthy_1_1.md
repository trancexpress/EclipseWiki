  - [delete & queries in WAM
    API](https://bugs.eclipse.org/bugs/show_bug.cgi?id=329362)
  - [custom properties available in
    transformations](https://bugs.eclipse.org/bugs/show_bug.cgi?id=327474)