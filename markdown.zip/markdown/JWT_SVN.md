This site contains information about the dependencies of JWT's
components, as well as a description on how to download the latest
versions from the Eclipse SVN and the layout of the JWT SVN
repositories.

## Access the JWT Source Code

### Browsing it online

You can browse the SVN repository online at
[1](http://dev.eclipse.org/svnroot/soa/org.eclipse.jwt/).

TODO <http://git.eclipse.org/c/jwt/org.eclipse.soa.jwt.git/tree/>

### Donwload it

To download the latest source code of the various components of JWT,
please connect your SVN client (typically Eclipse's SVN Browsing
perspective) with:

  - **URL:** <http://dev.eclipse.org/svnroot/soa/org.eclipse.jwt/>
  - **User:** anonymous
  - **Password:** (none)

If you have a committer account, please provide your committer data
(username and password) and select as connection type
svn+ssh://dev.eclipse.org/svnroot/soa/org.eclipse.jwt .

TODO git clone
<ssh://yourcommitteraccount@git.eclipse.org/gitroot/jwt/org.eclipse.soa.jwt.git>

### Overview

In this SVN repository, the source code of JWT is under the
"org.eclipse.jwt" directory, which you can retrieve by doing a SVN
checkout. It is laid out as follows:

Essential stuff:

  - org.eclipse.jwt/metamodel : **Meta Model**, the JWT meta model
  - org.eclipse.jwt/we : **Workflow Editor**, i.e. design time tools

Optional stuff:

  - org.eclipse.jwt/we-plugins : **Workflow Editor Plugins**, e.g..
    additional views
  - org.eclipse.jwt/transformations : **Transformations**, e.g. to/from
    BPMN, XPDL, ...
  - org.eclipse.jwt/examples : **Examples**, demonstrate how to extend
    JWT

Releng stuff:

  - org.eclipse.jwt/releng : **Release engineering**, required for
    building the JWT feature

Additional components:

  - org.eclipse.jwt/wam : **Workflow Audit And Monitoring**, i.e.
    runtime time tools and framework
  - org.eclipse.jwt/desktop : **Simulator** and other standalone BPM
    tools

For a more detailed layout please refer to [Detailed Layout of the
SVN](JWT_SVN#Detailed_Layout_of_the_SVN "wikilink").

## Requirements

### Dependencies (for SVN TRUNK as of July 2015 / JWT 1.5.0)

Below is the easiest way to get an Eclipse environment with all
dependencies for this JWT version.

### Environment

Install *Eclipse 4.5 (Mars)* and a **Java Runtime Environment (JRE)** /
**Java Development Kit (JDK) 1.7** or higher.

### Plugins

Add the following plugins :

  - **EMF - Eclipse Modeling Framework SDK**
  - **Graphical Editing Framework Draw2d SDK** (GEF)
  - and its **Graphical Editing Framework Zest Visualization Toolkit
    SDK** extension
  - **ATL SDK - ATLAS Transformation Language SDK**
  - **GMF - Graphical Modeling Framework** (runtime, tooling & extension
    ?) which brings org.apache.batik.dom.svg required by the SVG Export
    feature.

Those plugins' SDKs are optional but may be useful for developers.

If you already have Eclipse installed, you can download those plugins
from from your "Software updates" menu.

### Orbit

Add the following [Orbit](Orbit "wikilink") dependencies :

  - **org.apache.xalan** 2.7.1 - tag (branch) : v2_7
  - **org.jdom** 1.0 - tag (branch) : v1_0

To work with them in your workspace, follow the steps described
[here](Orbit_Faq#How_do_I_work_with_a_bundle_in_Orbit.3F "wikilink"),
with additional in depth information
[here](Easy_Bake_Builds_with_Orbit_Bundles "wikilink").

In our case, simply check out in your workspace each module described
above from the Eclipse Tools CVS repository:

  - host: dev.eclipse.org
  - repository: /cvsroot/tools
  - (using pserver protocol and anonymous username is enough)
  - module: org.eclipse.orbit/org.jdom
  - Tag: use the appropriate tag corresponding to the version mentioned
    above. You may get the tag by browsing the CVS repository in
    Eclipse, doing a right-click \> "Configure Branches and Versions" on
    the dependency folder, selecting the right tag and finally clicking
    on "Add Checked Tags".

## Start working with the code

### Build the JWT Code

You need to retrieve the JWT source code by checking it out from SVN
after having installed its dependencies, as described above.

If you used an external SVN tool to check out the codebase, you need to
import the source code into Eclipse as projects (in the Java
Perspective, using right click \> import existing projects). Look below
to know which projects are required to be imported.

The build will start automatically once you've imported the projects
(thanks Eclipse \!). If you've got all required dependencies (see
above), once the build is finished, all projects should be built with no
remaining error (red tags), like in the following picture :

![Image:Jwt dev workspace.png](Jwt_dev_workspace.png
"Image:Jwt dev workspace.png")

If it says "missing API baseline", use the Quick Fix shortcut to [create
an API baseline for your
workspace](http://www.ibm.com/developerworks/library/os-eclipse-api-tools/),
for instance "Eclipse 4.3.2" if you're targeting to release along
Eclipse 4.4 and want to know which previous API your are breaking.

If you've got errors, they are usually about dependencies. Maybe you
haven't imported enough JWT projects, or maybe you've imported
"obsolete" parts of the SVN codebase. Again, look below to know which
projects are required or obsolete in the codebase.

### Run the JWT Plugins from Code

Right click on the *jwt-we* project and choose *Run as* \> *Eclipse
application*. This will launch JWT-WE with all plugins that are
available in the workspace. If Eclipse does not succeed to start or
JWT-WE is not active, please ensure that all necessary plug-ins are
configured to start with your projects. To do so, click on the arrow in
the *Run* item in toolbar, and choose *Run Configuration...*.

Select/Create a run configuration (*Eclipse Application*) for JWT-WE and
on the *Plug-ins* tab select all necessary plug-ins (in case you have
doubt, select *Add Required Plugins*). Workflow Editor plugins (e.g. the
*Documentation Generator* plugin) must also be enabled in order to be
available at run time.

You can now use the *Run* item in the toolbar to start your new
configuration.

### Debug JWT

There are two alternatives.

1\. (the most common) As a developer, you'll want to debug your code and
the JWT code you build on. To do so, do as above but using *Debug as* \>
*Eclipse Application* rather than *Run as*.

2.Sometimes, a JWT release (packaged in an Eclipse release, or a custom
RCP release) will have a different behaviour than when started from
workspace plugins as above. You can debug it using java remote
debugging. To do so,

  - add to the startup executable (ex. "C:\\eclipse\\eclipse.exe") of
    the Eclipse + JWT installation you want to debug the following
    command line arguments :

`-consolelog -clean -debug -vmargs -Xdebug -Xrunjdwp:transport=dt_socket,address=8000,server=y,suspend=n`

  - once started, connect your development Eclipse to it, by
    right-clicking on *Debug as*, creating a new, properly configured
    *Remote Java Application* if required and hitting "enter".

### Run the tests

Make sure you have already checked out the releng/jwt-test-plugin
project.

To run all the tests, Checkout the releng/jwt-test-plugin project,
right-click on it and choose "Run as..." \> "JUnit Plugin Test".

To run a given JUnit test, right-click on its class and also choose "Run
as..." \> "JUnit Plugin Test" (AND NOT "JUnit Test")

## Structure of SVN

  - All projects start with *jwt*.
  - Afterwards the main component is added *jwt-we*,
    *jwt-transformation* or *jwt-wam*.
  - If an example is visible in a specific area it is named
    *jwt-we-XY-example* (for an example using an extension point of the
    workflow editor).
  - The package structure is org.eclipse.jwt.*component* and for
    additional plugins
    org.eclipse.jwt.*component*.plugins.*nameexample*, e.g.
    org.eclipse.jwt.we.plugins.viewexample.
  - Versioning: It is always *x.y.z* where *x* and *y* are always
    consistent with the corresponding JWT version and *z* is reserved
    for the different versions of the plugin in one release, e.g. 0.4.1
    for JWT release 0.4 and first change of this additional plugin.
  - In SVN there will be a main directory for each component jwt-we,
    jwt-transformation, jwt-wam and jwt-we-plugins where all additional
    plugins can be found.

## Detailed Layout of the SVN

### metamodel

Contains everything related to the *JWT metamodel*

  - **jwt-converter** *JWT metamodel converter (helps version
    migration)* (REQUIRED)
  - **jwt-metamodel** *JWT EMF-based workflow metamodel* (REQUIRED)

### we

Contains everything related to the *Workflow Editor*

  - **jwt-we** *The Workflow Editor* (REQUIRED)

Aspect oriented metamodel extension : (RECOMMENDED)

  - **jwt-we-conf-model** *Aspect oriented metamodel extension framework
    (no dependency to JWT)*
  - **jwt-we-conf-model.edit** *its management and property sheet UI (no
    dependency to JWT)*
  - **jwt-we-conf-model.editor** *its model editor, with helper tools
    (draft)*
  - **jwt-we-conf-model.editor-tests**
  - **jwt-we-conf-model.we** *Integration of the Aspect oriented
    metamodel extension framework in JWT*
  - **jwt-we-conf-property-model** *All-purpose property-like metamodel
    extension*
  - **jwt-we-conf-property-model.edit** *its property sheet UI*

### we-plugins

Plugins :

  -   - **jwt-we-action-example** *An Example on how to add Menu/Toolbar
        Actions to the Workflow Editor*
      - **jwt-we-action-doc** *An Action for generating Documentations*
      - **jwt-we-view-example** *A Example on how to add Views to the
        Workflow Editor*
      - **jwt-we-view-uml** *A view that displays Processes as UML
        Activity Diagrams*
      - **jwt-we-helpers-application** *propertyDescriptors and
        changeListener to facilitate the modeling of an application*
      - **jwt-we-helpers-files** *propertyDescriptors and tools to
        replace TextArea by filesystem browser for files (icon,
        jarArchive)*
      - **jwt-we-sample-staticaspect(.edit)** *Sample showcasing static
        EMF metamodel extension*
      - **jwt-we-sample-registereddynamicaspect** *Sample showcasing
        dynamic EMF metamodel extension*
      - **jwt-we-sample-standalonedynamicaspect** *Sample showcasing
        dynamic EMF metamodel extension without a plugin*
      - **jwt-we-sample-aspectschildextender** *Sample showcasing EMF
        child extenders*
      - **jwt-we-sample-logging(.edit)** *Simple logging metamodel
        extension*

Others :

  - **jwt-view** **OBSOLETE** (not supported anymore) *A Program for
    Creating and Modifying Workflow Editor Views*
  - **jwt-we-feature** *JWT-WE Feature (to be published on Update Site)*
  - **jwt-we-update-site** *Contents for Update-Site*

-----

### transformations (RECOMMENDED)

  - **jwt-transformation-base** *The base plug-in for any
    transformation. Provides UI*
  - **jwt-transformation-stub** *A sample plug-in that is based on
    jwt-transformation-base*
  - **jwt-transformation-xslt-tools** *Helpers for using XSLT to
    implement JWT transformations*
  - **jwt-transformation-xpdl** *JWT to XPDL transformation*
  - **jwt-transformation-xpdl-test** *Tests for JWT to XPDL
    transformation*
  - **jwt-transformation-jpdl** *JWT to jPDL transformation
    (incubation)*
  - **jwt-transformation-jpdl-test** *Tests for JWT to jPDL
    transformation (incubation)*
  - **jwt-transformation-bpmn** *jwt to bpmn transformation*
  - **jwt-transformation-bpmn-tests** *Tests for the jwt to bpmn
    transformation*
  - **jwt-transformation-properties** *Extraction of JWT properties into
    a .properties file*
  - **jwt-transformation-stpim** *Bridge with SOA Tool Platform (STP)'s
    Intermediate Model*
  - **jwt-transformation-stpim-test**

-----

### wam

  - **jwt-webservices** *Tools to introspect WSDL*
  - **jwt-runtime-api** *A workflow client API that is also used by
    monitoring plug-in at runtime to get informations from a workflow
    engine*
  - **jwt-monitoring** *A plug-in that provides tools to display a
    workflow state from a workflow engine into JWT*
  - **jwt-monitoring-tests**

-----

### runtime

  - **task-engine-framework** *Runtime API and framework to help
    integrating JWT with any workflow server*

-----

### releng (for "release engineering")

JWT releases automated builds. See [JWT Automatic
Build](JWT_Automatic_Build "wikilink") for usage.

  - **builder** *The builder utility: contains ant files and scripts to
    build and publish JWT*
  - **tester** *The tester utility: works only and is necessary for
    builder. Contains a set of files for automated testing*
  - **cbi-builder** *An experimental builder, based on the [Common Build
    Infrastructure](Common_Build_Infrastructure "wikilink")*
  - **jwt-feature** *The JWT feature to release =\> contains the list of
    plugins to include into the release*
  - **jwt-feature-branding** *The branding plugin for JWT feature*
  - **jwt-tests-feature** *The JWT test feature. It is not intended to
    be shipped or distributed, since it is only used for automated
    testing. It contains the list of all tests plugins that we want to
    test at build time*
  - **jwt-tests-plugin** *The master test plugin. It contains a
    plugin.xml wheich ocntains the list of all test plugins we want to
    run, and also a AllTest class that is the automated testing entry
    point test suite. Any test suite that wishes to be run at build time
    must be added to this TestSuite*
  - **jwt-ui-capabilities**

# See also

  - [JWT Website](http://www.eclipse.org/jwt/)