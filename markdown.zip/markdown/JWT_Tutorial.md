On this page you can find information on how to use the applications of
the Java Workflow Tooling kit. In addition to several introductive
articles, also some of the more advanced topics like extending JWT's
meta-model are discussed.

# Introduction

This document shows the installation and usage of the JWT Workflow
Editor (WE) process modeling tool and how to extend and modify it to
suit your needs. In addition we show how to execute and how to actually
simulate or execute a process model.

We try to cover all aspects of JWT that are of interest for the user and
reader of these documents. If there is another topic that you are
interested in that is not covered in this description, please don’t
hesitate to contact us.

If you're looking for technical information on how to extend JWT using
the defined extension points, this can be found at [Extending
JWT](JWT_Extensions "wikilink").

This tutorial is currently adapted for JWT 0.6

# Tutorials

## Starting Tutorials

These tutorials are intended for users that are new to JWT:

  - [Installing JWT](JWT_Tutorial_Install "wikilink")
  - The [parts](JWT_Tutorial_Parts "wikilink") of the Workflow Editor
  - Learn how to model [your first
    process](JWT_Tutorial_FirstProcess "wikilink")
  - Adding [technical data](JWT_Tutorial_TechnicalData "wikilink") to
    the process
  - Structuring processes using
    [subprocesses](JWT_Tutorial_Subprocesses "wikilink")
  - Creating [datatypes and guards](JWT_Tutorial_Guards "wikilink")
  - Switching between [different
    views](JWT_Tutorial_ViewsSwitching "wikilink")
  - Exporting and Importing [workflow
    templates](JWT_Tutorial_Templates "wikilink")
  - Exporting and Importing from and to other standards using
    [Transformations](JWT_Tutorial_Transformations "wikilink") such as
    BPMN, STP-IM, XPDL, etc.
  - Setting the [preferences](JWT_Tutorial_Preferences "wikilink") of
    the JWT Workflow Editor
  - [Additional features](JWT_Tutorial_Additional "wikilink")

## Advanced Stuff

  - Add [additional
    actions](JWT_Extensions#Adding_Actions_to_Menu.2FToolbar "wikilink")
    to the toolbar
  - Provide your own [editor
    sheets](JWT_Extensions#Adding_Editor_sheets "wikilink")
  - Add your own [property sheet
    pages](JWT_Extensions#Adding_Property_Sheet_Pages "wikilink") to the
    property editor
  - Register your own factories using the
    [FactoryRegistry](FactoryRegistry "wikilink") mechanism
  - Reacting to [double
    clicks](JWT_Extensions#Adding_a_new_Double_click_handler "wikilink")
    on model elements
  - Putting your own [property
    editors](JWT_Extensions#Adding_Custom_PropertyDescriptor_.28and_editors.29_in_property_sheets "wikilink")
    in the properts sheet
  - [Listen to
    changes](JWT_Extensions#Adding_NotificationChangeListener_when_a_value_is_changed_in_EMF_Model "wikilink")
    of EMF model elements
  - Plug in additinal [transformations](JWT_Transformations "wikilink")

# Designing Views

  - Design [your own views](JWT_Tutorial_ViewsDesign "wikilink")
  - Using the view editor
  - Changing the visual representation of model elements
  - Register the view with the Workflow Editor

# Enriching the Meta-Model

  - What are aspects in JWT?
  - How to add aspects to the meta-model

## Integrators

  - [Simulate](JWT_Tutorial_AgilPro "wikilink") your processes with the
    AgilPro Simulator
  - [Execute](JWT_Tutorial_Scarbo "wikilink") processes with Scarbo
    (using the Nova Bonita process engine)