For convenience, parts of existing workflows can be exported into
template files from which they can be reimported to other workflows.

# Exporting templates

Once you have created your packages with applications, data and roles
you are able to export them to use them in future process models.
Therefore, click on the corresponding Import/Export toolbar icon. In the
following wizard you can choose between importing and exporting workflow
elemets.

![jwt_we_tut_tempwizard.gif](jwt_we_tut_tempwizard.gif
"jwt_we_tut_tempwizard.gif")

Select "Export Workflow Template" and press "Next". In the next dialog
you can select the packages that you want to export and the name of the
target template file:

![jwt_we_tut_tempexport.gif](jwt_we_tut_tempexport.gif
"jwt_we_tut_tempexport.gif")

Choose the filename where you want to export the packages and all their
content to and click on “Finish”. When you click on “Export comments”,
then all comments are exported into the template, too. Comments can be
created to each element in the outline view to store some additional
information that does not fit anywhere else. Use it if you find it
necessary and export the comments then, too. Otherwise simply ignore
this option. Elements that can be exported include: Data, Roles,
Applications, Datatypes, Comments and Activities (with their contents).

**Hint** If you select activities that contain references to elements
outside this activity, the export wizard will notify you of this issue
and include the required elements automatically.

# Importing templates

Templates can be imported at two points:

1\. When you create a new workflow, the creation wizard offers the
possibility to include some templates:

![jwt_we_tut_newworkflowimport.gif](jwt_we_tut_newworkflowimport.gif
"jwt_we_tut_newworkflowimport.gif")

2\. Through the Import/Export wizard in the toolbar templates can be
imported to existing workflows:

![jwt_we_tut_tempimport.gif](jwt_we_tut_tempimport.gif
"jwt_we_tut_tempimport.gif")

To import templates, browse for the .workflowtemplate file and add it to
the list of selected templates. By clicking on an entry in this list,
the contents of the corresponding package are shown in the field above.

# See also

  - [Tutorial Main Page](JWT_Tutorial "wikilink")
  - [Wiki Main Page](Java_Workflow_Tooling_Project "wikilink")
  - [JWT Website](http://www.eclipse.org/jwt/)