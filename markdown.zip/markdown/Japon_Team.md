## About the team...

\- Mathias FAURÉ (<mathias.faure.31@gmail.com>)

\- Mathieu SOUM (<mathieu.soum@gmail.com>)

## About the rover...

### Report

In the following report you'll find the following diagrams:

\- The Use case diagram

\- The requirements diagram

\- The global block definition diagram of the rover

\- The Rover intern block diagram

\- The Micro-controller intern block diagram

### Models

We have used [Papyrus](https://www.eclipse.org/papyrus/) (version
1.0.1v201409170932) to define the following models (downloadable files
or URL to download the files).

![<File:FAURE_SOUM_Rover.zip>](FAURE_SOUM_Rover.zip
"File:FAURE_SOUM_Rover.zip")

\--Japon Team 08:50, 16 January 2015 (EST)