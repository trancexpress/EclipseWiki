In project I would examine different APIs that can be used to read Java
code as a model like APT, Reflection, JDT IJavaModel, AST, JEM etc.
Usage of each API need some special integration (e.g. my example of
IJavaModel work only when runned in Eclipse) as well as libraries that
ease using this models. All APIs has they drawbacks. E.g. IJavaModel is
need handling and resolving type signature, JEM does not include Java 5
features, AST is complicated and slow etc. After discussion with mentor
one API would be choosen and integration for it would be provided.

To test the integration I propose creation of Java to UML transformation
with Xtend or some CRUD scaffolding with Xpand.

I have already created a PoC for using JDT IJavaModel to read Java,
handle signatures, resolve types and create UML from it.

I consider creation of POJO or EMF wrapper for one of those API to make
usage simple but only if necessary. Maybe extending JEM would be a good
idea.

Project would probably have to deal with issues that are described here:

<http://www.openarchitectureware.org/forum/viewtopic.php?forum=2&showtopic=6628&highlight=Missing%20required%20plugin%20\\\'org.eclipse.uml2.uml.resources\\\'%20in%20classpath>.

Some more info can be found in discussion:

<http://dev.eclipse.org/mhonarc/lists/soc-dev/msg00901.html>

# Ideas

  - use JEM - lack generics, annotations
  - use IJavaModel - need type resolving
  - use AST
  - use resolved AST and work with Bindings - time and memory consuming
  - wrap IJavaModel like JEM wraps reflection
  - use reflection
  - use APT
  - create Ecore Java Model and transform Annotations classes to Ecore
    models like XSD adapter transform XML Schema
  - use [MoDisco/JavaDiscoverer](MoDisco/JavaDiscoverer "wikilink")

[Category:Xtend](Category:Xtend "wikilink")