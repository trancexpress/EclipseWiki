I am a member of the research staff in the Computer Science Research
Group at the Oak Ridge National Laboratory in Oak Ridge, TN. I have the
privilege of leading the Scientific Software Initiative, which focuses
on the development of large-scale, next-generation modeling and
simulation technologies for the U.S. Department of Energy and other
sponsors. I am a founding member of the Eclipse Science Working group as
well as Oak Ridge National Laboratory’s representative on its steering
committee. I hold the M.S. in theoretical astrophysics from the
University of Tennessee and I am currently an Energy Science and
Engineering Ph.D. candidate in the University’s Bredesen Center for
Interdisciplinary Research and Graduate Education. I stopped counting
the number of scientific publications I have a few years ago when I
realized that I was writing way more code than papers\!

I lead [Eclipse ICE](http://www.eclipse.org/ice) and
[EAVP](http://www.eclipse.org/eavp). I am a mentor on
[Triquetrum](http://www.eclipse.org/triquetrum) and
[Apogy](http://www.eclipse.org/apogy). I was appointed to the Eclipse
Architecture Council in February 2016. I also won the Top Newcomer
Evangelist Award for 2016.

In my few hours of spare time each week, I enjoy spending time with my
wife, family and friends; singing and hacking just about anything I can
find.