Return to [buckminster.cspex](buckminster.cspex "wikilink").

    <?xml version="1.0" encoding="UTF-8"?>
    <cspecExtension
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xmlns:bc="http://www.eclipse.org/buckminster/Common-1.0"
        ns="http://www.eclipse.org/buckminster/CSpec-1.0">
        <dependencies>
            <dependency name="org.eclipse.platform" componentType="eclipse.feature"/>
            <dependency name="org.eclipse.equinox.concurrent" componentType="osgi.bundle"/>
            <dependency name="org.apache.commons.httpclient" componentType="osgi.bundle"/>
            <dependency name="org.apache.commons.logging" componentType="osgi.bundle"/>
            <dependency name="org.apache.commons.codec" componentType="osgi.bundle"/>
        </dependencies>
        <generators>
            <!-- Place your Generators here -->
        </generators>
        <artifacts>
            <!-- Place your Artifacts here -->
        </artifacts>
        <actions>
            <!-- Place your Actions here -->
        </actions>
        <groups>
            <!-- Place your Groups here -->
        </groups>
        <alterDependencies>
            <!-- Place your Dependencies alterations here -->
        </alterDependencies>
        <alterArtifacts>
            <!-- Place your Artifact alterations here -->
        </alterArtifacts>
        <alterActions>
            <!-- Place your Action alterations here -->
        </alterActions>
        <alterGroups>
            <!-- Place your Group alterations here -->
        </alterGroups>
    </cspecExtension>