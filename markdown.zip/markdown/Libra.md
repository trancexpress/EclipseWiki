![Image:Libra.png](Libra.png "Image:Libra.png")

The Libra project enables you to use tools that integrate the existing
WTP tooling and PDE tooling so that OSGi Enterprise applications can be
developed with both tooling at the same time. It also provides you with
tools for better experience in the [Server-Side
Equinox](http://www.eclipse.org/equinox/server//) scenario.

### Send us feedback

  - Mailing list: <https://dev.eclipse.org/mailman/listinfo/libra-dev>
  - Bugzilla:
    <https://bugs.eclipse.org/bugs/enter_bug.cgi?product=Libra>
  - Forum: <http://www.eclipse.org/forums/eclipse.libra>