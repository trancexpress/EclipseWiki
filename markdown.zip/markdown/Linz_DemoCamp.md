![Image:eclipse-camp.gif](eclipse-camp.gif "Image:eclipse-camp.gif")
[What is an Eclipse DemoCamp?](Eclipse_DemoCamp "wikilink")

### Location

Johannes Kepler University

TNF Building, Room - T111

Altenberger Strasse 69

A-4040 Linz, Austria, Europe

### Date and Time

Wednesday, **December 12th**, 17:30 to 20:30pm

### Organizer

Sylva Girtelschmid, JKU

Email: sgirtel@gup.jku.at

### Presenters

If you would like to present at a DemoCamp, please feel free to add your
name and topic to the list. Depending on the number of people interested
we may have to limit the number of presenters and time of each demo.

  - Holger Weissböck, dynaTrace Diagnostics® - a software solution for
    business critical applications
  - Thomas Köckerbauer, JKU -
    [g-Eclipse](http://www.eclipse.org/geclipse/)[1](http://www.geclipse.eu):
    access the power of the grid

### Who Is Attending

If you plan on attending please add your name to the list below. We'd
like to see as many people show up as possible.

  - Thomas Köckerbauer, g-Eclipse
  - Christof Klausecker, g-Eclipse
  - Sylva Girtelschmid, g-Eclipse
  - Holger Weissböck, dynaTrace
  - Christoph Spielmann,JKU
  - Johann Messner, JKU
  - Roland Landertshamer, JKU
  - Christian Glasner, JKU
  - Erich Hochmuth, dynaTrace
  - Roland Mungenast, dynaTrace