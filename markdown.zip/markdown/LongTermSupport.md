Long Term Support (LTS) is a suffix that e.g. applies to Ubuntu Linux
system releases and indicates that this release should see a much longer
life time as a supported version than many other released versions.