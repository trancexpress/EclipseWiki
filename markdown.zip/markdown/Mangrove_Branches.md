org.eclipse.soa.mangrove.branches - the Transformation Plug-ins: contain
the logic required to move and convert information between editors,
tools and the core metamodel instance.

[EasySOA Mangrove Branch](EasySOA_Mangrove_Branch "wikilink"):
integration with the Easy SOA / Nuxeo