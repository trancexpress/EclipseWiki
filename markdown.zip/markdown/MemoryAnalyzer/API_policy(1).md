# Memory Analyzer API Policy

This document provides the current API Policy for Memory Analyzer.

## Declared API

The declared APIs in Memory Analyzer are provided as public and
documented. The API compatibility between different versions of Memory
Analyzer should be reflected by the version numbers, following the
Eclipse [versioning policy](http://wiki.eclipse.org/Version_Numbering)
Changes to the API - addind new APIs or deprecating APIs should be
documented (e.g. in Bugzilla) and communicated to the community (e.g.
via the newsgroups).
Deprecated API should be available for at lease one major release.

## Provisional and internal API

Provisional APIs should be used while development is occurring. If
successfully adopted, they might become declared APIs. If not, they can
be removed. In any situation, the community should be notified.

[Category:Memory Analyzer](Category:Memory_Analyzer "wikilink")