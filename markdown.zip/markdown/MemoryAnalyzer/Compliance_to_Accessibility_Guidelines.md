Specialists at IBM have analyzed the MAT's compliance following these
[guidelines](http://www-03.ibm.com/able/guidelines/software/accesssoftware.html).

For a detailed list of fixed and open accessibility related issues in
MAT use the following [Bugzilla
query](https://bugs.eclipse.org/bugs/buglist.cgi?classification=Tools&keywords=accessibility&keywords_type=allwords&product=MAT&query_format=advanced).