## MAT Website

This page contains information about the MAT web site
<http://www.eclipse.org/mat/> - where the source is, how to make
updates, etc...

The MAT Website resides in Git.

## Setting up the Tools

### EGit

To work with Git in Eclipse, you'll need to install (if not available
already) the EGit tools from

`http://download.eclipse.org/egit/updates/`

A detailed EGit user guide is available here: [EGit/User
Guide](EGit/User_Guide "wikilink")

### SSH Key

For the ssh communication, you will need to setup a key. Follow the
guide [Git\#Setting up ssh keys](Git#Setting_up_ssh_keys "wikilink")

### Username/E-Mail

The following resources can be useful to properly configure your
environment:

  - Introduction
    [Git\#Committers_new_to_Git](Git#Committers_new_to_Git "wikilink")
  - Setup your user/e-mail [Platform-releng/Git Workflows\#Configure the
    workspace](Platform-releng/Git_Workflows#Configure_the_workspace "wikilink")

## Get the MAT Website Git Repository

MAT Website repository moved to GitHub:
<https://github.com/eclipse/mat-website>

Clone the repository <https://github.com/eclipse/mat-website> (see
[Cloning a
Repository](https://docs.github.com/en/repositories/creating-and-managing-repositories/cloning-a-repository)
if you need help).

The content of the master branch is displayed on the website. See
[Project
Websites](https://www.eclipse.org/projects/handbook/#resources-website)
for more details such as changes taking up to 5 minutes to be copied to
the live website.

## Import the project

There is one general project for the website content. Once you cloned
the repository you can import the project.

See [EGit/User Guide\#Importing
projects](EGit/User_Guide#Importing_projects "wikilink")

## Making changes

Well, there is nothing specific for MAT. Once you have cloned the
repository and imported the project in the IDE, you can make local
changes and commit them locally. Before committing, be sure the have
properly set the user/e-mail (see above).

Once you think the changes are ready to be put on the website, push your
changes. The new content will be visible on the website in a few
minutes.

See:

  - [EGit/User
    Guide\#Fetching_from_upstream](EGit/User_Guide#Fetching_from_upstream "wikilink")
  - [EGit/User Guide\#Committing
    Changes](EGit/User_Guide#Committing_Changes "wikilink")
  - [EGit/User Guide\#Pushing to
    upstream](EGit/User_Guide#Pushing_to_upstream "wikilink")

[Category:Memory Analyzer](Category:Memory_Analyzer "wikilink")