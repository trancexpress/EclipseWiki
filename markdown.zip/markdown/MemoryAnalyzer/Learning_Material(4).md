# Tutorials

[Eclipse Memory Analyzer
Tutorial](http://www.vogella.com/articles/EclipseMemoryAnalyser/article.html)
by Lars Vogel. July 6, 2016

[Automated Heap Dump Analysis: Finding Memory Leaks with One
Click](http://memoryanalyzer.blogspot.de/2008/05/automated-heap-dump-analysis-finding.html)
by Krum Tsvetkov, part of the Memory Analyzer
[blog](http://memoryanalyzer.blogspot.in/)

[10 Tips for using the Eclipse Memory
Analyzer](http://eclipsesource.com/blogs/2013/01/21/10-tips-for-using-the-eclipse-memory-analyzer/)
by Ian Bull. January 21, 2013

[Java memory analysis using Eclipse Memory
Analyzer](https://vimeo.com/21356498) by Chris Grindstaff

[Analyzing the Memory Consumption of
Eclipse](http://kohlerm.blogspot.de/2008/05/analyzing-memory-consumption-of-eclipse.html/)
by Markus Kohler.

[Detect duplicated/conflicting
libs/classes](http://community.bonitasoft.com/effective-way-fight-duplicated-libs-and-version-conflicting-classes-using-memory-analyzer-tool)
by Aurelien Pupier

[Analyzing Java Collections Usage with Memory
Analyzer](https://blogs.sap.com/2007/11/04/analyzing-java-collections-usage-with-memory-analyzer/)

The Memory Analyzer grew up at SAP. Back then, Krum blogged about
[Finding Memory Leaks with SAP Memory
Analyzer](https://blogs.sap.com/2007/07/02/finding-memory-leaks-with-sap-memory-analyzer/).
The content is still relevant.

[Debugging from dumps - Diagnose more than memory leaks with Memory
Analyzer](https://www.ibm.com/developerworks/library/j-memoryanalyzer/)
by Chris Bailey, Andrew Johnson, and Kevin Grigorenko. March 15, 2011

# Presentations

[Eclipse Memory Analyzer Tool
Video](https://www.youtube.com/watch?v=sLoifF_YA4w), San Diego Java User
Group, Kevin Grigorenko, June 2019

[The MAT
Tutorial](https://wiki.eclipse.org/images/0/0b/EDKRK2012_MAT.pdf) by
Szymon Ptaszkiewicz, Eclipse Day, Kraków, 13 September 2013.

[Eclipse Summit
Europe](http://www.slideshare.net/AJohnson1/extending-eclipse-memory-analyzer),
Ludwigsburg, 4 November '10

[TheServerSide Java Symposium -
Europe](http://www.slideshare.net/AJohnson1/practical-lessons-in-memory-analysis),
Prague, October '09

[TS-4118
JavaOne](https://www.slideshare.net/AJohnson1/ps-ts-41183041182301finv1),
San Francisco, June '09

[Eclipse Summit
Europe](http://www.slideshare.net/nayashkova/eclipse-memory-analyzer-presentation-763314)
Ludwigsburg, 20 November, '08

[Automated Heap Dump Analysis for Developers Testers and Technical
Support
Employees](https://www.oracle.com/technetwork/systems/ts-5729-159371.pdf),
TS-5729, JavaOne, San Francisco, May '08

[EclipseCon](https://www.eclipsecon.org/2008/sub/attachments/Memory_Analysis_Simplified_Automated_Heap_Dump_Analysis_for_Developers_Testers_and_Technical_Support_Employees.pdf),
March '08 (Slides)

[JavaOne](http://www.sdn.sap.com/irj/scn/go/portal/prtroot/docs/library/uuid/00ca7f0d-8ee6-2910-5d82-fc3e8dd25300)[TS-21935
JavaOne](https://docs.huihoo.com/javaone/2007/java-se/TS-21935.pdf), San
Francisco, May '07

[Category:Memory Analyzer](Category:Memory_Analyzer "wikilink")