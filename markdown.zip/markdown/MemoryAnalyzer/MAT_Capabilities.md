This document provides some sample
[capability](Eclipse/Capabilities "wikilink") definitions for the Memory
Analyzer (MAT). It describes:

1.  Where to find the existing Capabilities plug-in in SVN
2.  Or how to implement your own Capabilities for Memory Analyzer

### Existing Capabilities Plug-in

The plug-in org.eclipse.mat.ui.capabilities contains Capabilities
definition for Memory Analyzer

The plug-in can be found in MAT's SVN source repository:

`   * Host: dev.eclipse.org`
`   * Repository Path: /svnroot/tools/org.eclipse.mat`
`   * User: anonymous`
`   * Password: `<empty>
`   * Connection URL (http): `<http://dev.eclipse.org/svnroot/tools/org.eclipse.mat>
`   * Path (in trunk) /plugins/org.eclipse.mat.ui.capabilities`

### Capabilities Implementation

The code snippet below shows how to turn off Memory Analyzer
functionality in the workbench via Capabilities:

`  `
`   <extension point="org.eclipse.ui.activities">`
`    <activity`
`        id="org.eclipse.mat"`
`        name="%activity.name"`
`        description="%activity.description" />`
`  `
`    <activityPatternBinding`
`        activityId="org.eclipse.mat"`
`        pattern="org\.eclipse\.mat\..*"/>`
`   </extension>`
`   `

[Category:Memory Analyzer](Category:Memory_Analyzer "wikilink")