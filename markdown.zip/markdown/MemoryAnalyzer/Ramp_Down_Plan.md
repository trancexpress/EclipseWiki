## Ramp down plan

Typically the last week of a Milestone is for testing, and fixing only
regressions and P1 or blocking defects. For milestones, the component
lead (or delegate) is enough to review and approve a bug.

**For M3 \[*was M7 for Photon and before*\], we plan to be API and
feature complete**, so there will be no breaking API changes and no new
feature requests will be accepted.

**For RC1 \[*was RC1 and RC2 for Photon and before*\] only bug fixes to
Memory Analyzer** functionality should be done. The following describes
the types of bugs that would be appropriate:

  - A regression
  - A P1 or P2 bug, one that is blocking or critical
  - Minor documentation changes, including adding new and noteworthy

**For RC2 \[*was RC3 - RC4 for Photon and before*\]** only bug fixes
damaging the build/functionality of the simultaneous release should are
allowed

  - [Galileo Simultaneous
    Release](Galileo_Simultaneous_Release "wikilink")
  - [Helios Simultaneous
    Release](Helios_Simultaneous_Release "wikilink")
  - [Indigo Simultaneous
    Release](Indigo_Simultaneous_Release "wikilink")
  - [Juno/Simultaneous Release
    Plan](Juno/Simultaneous_Release_Plan "wikilink")
  - [Kepler/Simultaneous Release
    Plan](Kepler/Simultaneous_Release_Plan "wikilink")
  - [Luna/Simultaneous Release
    Plan](Luna/Simultaneous_Release_Plan "wikilink")
  - [Mars/Simultaneous Release
    Plan](Mars/Simultaneous_Release_Plan "wikilink")
  - [Neon/Simultaneous Release
    Plan](Neon/Simultaneous_Release_Plan "wikilink")
  - [Oxygen/Simultaneous Release
    Plan](Oxygen/Simultaneous_Release_Plan "wikilink")
  - [Photon/Simultaneous Release
    Plan](Photon/Simultaneous_Release_Plan "wikilink")
  - [Simultaneous Release](Simultaneous_Release "wikilink") subsequent
    releases on a 13-week cycle

[Category:Memory Analyzer](Category:Memory_Analyzer "wikilink")