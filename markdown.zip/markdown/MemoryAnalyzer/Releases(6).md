The releases information is available under the common Eclipse projects
information [page for
MAT](https://projects.eclipse.org/projects/tools.mat/governance)

[Category:Memory Analyzer](Category:Memory_Analyzer "wikilink")