This document provides the current retention policy for Memory Analyzer.

# Released Versions

For all officially released versions the following applies:

  - the two most recent releases from the latest major version will be
    available on <http://download.eclipse.org>
  - releases included in the Eclipse simultaneous release will be
    available on <http://download.eclipse.org>
  - older releases wull be archived on <http://archive.eclipse.org> and
    available there for unlimitted time

This applies both for RCPs and update sites.

# Milestones, Previews, Development Builds

Milestone builds, developer builds or previews may be fully removed from
the download sites or archived - the Memory Analyzer team should decide
this.

[Category:Memory Analyzer](Category:Memory_Analyzer "wikilink")