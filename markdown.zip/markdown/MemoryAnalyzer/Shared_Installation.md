# Eclipse Memory Analyzer and a shared installation

Sometimes it can be useful to install Eclipse Memory Analyzer in a
shared directory so that many people can use it, but ideally with their
own settings.

See [Eclipse multi-user
installs](https://help.eclipse.org/latest/index.jsp?topic=%2Forg.eclipse.platform.doc.isv%2Freference%2Fmisc%2Fruntime-options.html)

1.  Unpack Eclipse Memory Analyzer into a location which can be shared
2.  Option: Start MAT and set up preferences etc. as required which will
    be the default configuration
3.  Add the following to MemoryAnalyzer.ini. This stops a root user from
    running Memory Analyzer and overwriting key files in the shared
    directories.
    `-protect`
    `root`
4.  Add to configuration/config.ini a line such as
    `osgi.instance.area=@user.home/MemoryAnalyzer`
    This sets the workspace as the default would be under the Memory
    Analyzer install directory, so would not be writable. This means the
    user does not have to specify -data
5.  Make all the Memory Analyzer files and directories publicly
    readable, but not writable.
6.  The error logs will go to a location like
    \~/.eclipse/org.eclipse.mat_1.13.0_87691952_linux_gtk_x86_64/configuration/1651585377771.log
    The org.eclipse.mat and 1.13.0 come from .eclipseproduct, linux from
    the os, gtk from ws, x86_64 from arch.

[Category:Memory Analyzer](Category:Memory_Analyzer "wikilink")