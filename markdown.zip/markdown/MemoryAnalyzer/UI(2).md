## UI interface text

The Eclipse Memory Analyzer User Interface (UI)

### Views

### Editors

### UI/UX Guidelines

[Eclipse UI
Guidelines](https://eclipse-platform.github.io/ui-best-practices/)

#### 5.1.1. Views & Editors

Overview and Find Object by address are on the toolbar but not in a menu

Persist the state of each view between sessions (Guideline 7.20). May
not be possible to reopen heap dumps??

#### 5.1.2. Wizards & Dialogs

Acquire Heap dump and diagnostics start with a message

#### 5.1.3. Workbench & Preferences

Headline Capitalization

Sentence capitalization needs work

[Category:Memory Analyzer](Category:Memory_Analyzer "wikilink")