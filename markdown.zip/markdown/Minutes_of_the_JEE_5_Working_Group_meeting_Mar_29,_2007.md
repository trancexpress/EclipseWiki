## Teleconference on [JEE 5 Support](JEE_5_Support "wikilink") in WTP Mar 29, 2007

### Attendance

  - Naci Dai - Eteration
  - Kaloyan Raev - SAP
  - Chuck Bridgham - IBM
  - Paul Andersen - IBM
  - Neil Hauge - Oracle
  - Dave Gorton - BEA
  - Rob Frost - BEA
  - Shaun Smith - Oracle

### Agenda

  - Review JEE 5 Use Case []( "wikilink") and comment on feasibility of
    achieving these goals by WTP 2.0
  - Go over priorities
  - Bug Status

### Minutes

  - ND: JEE 5 use cases are published on the wiki. These are bare
    minimums that I think we should be able to support to call ourselves
    JEE5 compliant. None of these scenarios can run out of the box
    today. I would like to hear from our component leads if we can
    achieve them by WTP 2.0.

\- The use cases are: 1) Standalone Web App (2.5) run on Tomcat 6. 2)
Combined Scenario with Ear 5 containing Web2.5 with JSF 1.1 and EJB3
with JPA1 running on a JEE5 runtime.

  - CB: I think we can support these scenarios by WTp 2.0, I do not see
    important problems.
  - SS: We will need an additional scenario, with a single Web App with
    2.5 + JPA 1 . That is the default scenario explained at the Dali
    website.
  - ND: Our server runtime support has issues also. We cannot target a
    module to a server runtime if there are no deployment descriptors.
    We can add one manually but it would be nicer if the wizrda created
    one.
  - CB: JEE5 spec does not require a DD for module. For example it will
    figure the contents of an ear by traversing the modules in the ear
    file.
  - ND: We have to make sure that Server runtime have this capability.
    i.e. be able to handle modules with no DD.
  - CB: Our model JEE5 extensibility API are committed to WTP2.0 stream.
  - ND: Are these sufficient for SAP?
  - KR: We have tried these APIs at SAP and they meet our needs for 2.0.
  - CB: We added content types to JEE5 model support. DD validators
    behave well when they do not recognize the DD version. EMF models
    also behave well when new versions are loaded.
  - ND: Bugs reviewed on the call:

`  `<https://bugs.eclipse.org/bugs/show_bug.cgi?id=126090>
`  `<https://bugs.eclipse.org/bugs/show_bug.cgi?id=178073>
`  `<https://bugs.eclipse.org/bugs/show_bug.cgi?id=179932>
`  `<https://bugs.eclipse.org/bugs/show_bug.cgi?id=179972>