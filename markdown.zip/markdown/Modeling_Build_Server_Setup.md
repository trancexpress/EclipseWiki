This install log is for a SuSE. For an Ubuntu server, see [EMF Build
Server Setup](EMF_Build_Server_Setup "wikilink"). For Fedora/Xen, see
[EMFT Build Server Setup](EMFT_Build_Server_Setup "wikilink"). *The old
version of this document is
[here](Modeling_Build_Server_Setup_\(Archived\) "wikilink").*

# Modeling Build Server Setup

You will need to be root for most of these tasks.

## Installing and Updating Software

OOTB, YaST2 (/sbin/yast2) does not include [any
repos](http://en.opensuse.org/Package_Repositories) for updating your
server. This is lame. To fix this, [add the following
repos](http://en.opensuse.org/Add_Package_Repositories_to_YaST):

  - <http://install/sles10/sles10/CD1>
  - <ftp://www.mirrorservice.org/sites/ftp.suse.com/pub/suse/update/10.1/>
  - <http://download.opensuse.org/repositories/mozilla/openSUSE_10.3/>
  - <http://download.opensuse.org/repositories/Java:/packages/openSUSE_10.3/>
  - <http://download.opensuse.org/repositories/zypp:/Backport/openSUSE_10.3/>

<!-- end list -->

  - <http://packman.unixheads.com/suse/10.3/>
  - <ftp://ftp.pbone.net/mirror/ftp5.gwdg.de/pub/opensuse/repositories/devel:/updatestack/openSUSE_10.3/>

Then, you can [use
YaST2](http://sman.informatik.htw-dresden.de/doc/manual.10.3/sec.yast.ncurses_commands.html)
to find and install software, or you can install
[Zypper](http://en.opensuse.org/Using_zypper) and do it all via the
commandline.