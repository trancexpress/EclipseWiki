Time: 10:00 am Eastern (U.S.)

Toll Free Dial In Number: (888) 476-6128

Int'l Access/Caller Paid Dial In Number: (517) 267-1462

PARTICIPANT CODE: 888691

### Attendees

  - Ed Merks
  - Bjorn Freeman-Benson
  - Richard Gronback
  - Kenn Hussey
  - Jean Bezivin
  - Frederic Jouault

### Topics

  - EMFT as incubator (follow-up with Bjorn)
      - Bjorn agreed that it's good to keep EMFT for incubators, and
        that it should move to Modeling (no rush)
  - EclipseCon follow-up
      - All agreed the conference went well (good luck to Doug Gaff for
        next year).
  - Modeling icon for about dialog
    [options](https://bugs.eclipse.org/bugs/show_bug.cgi?id=154906#c55)
      - Top left icon from Gen seems to be favorite, though Nick will
        follow up on making background transparent to match new Eclipse
        icon from platform

### Actions

  -
    \[Rich\] to start non-API policy wiki (carry over)

[Category:Modeling_Meetings](Category:Modeling_Meetings "wikilink")