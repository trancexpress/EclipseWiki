Time: 10:00AM Eastern

Conference number: North America 1-866-245-5059, Global 800-4444-1010,
Toronto 416-343-2607 Passcode: 1972050

### Attendees

Richard Gronback, Ed Merks, Sven Efftinge, Paul Elder

### Topics

  - Streamlining Target Milestone lists after each release
      - Decided OK to do on per-project basis, although it presents a
        challenge for projects with discrete components that are at
        varied version numbers
  - GMT cleanup
      - Deadline from Foundation is before next PMC call, so resolution
        to be discussed then (Jean and Frederic could not make this
        week's call).
  - MDDi status
      - We agreed to send an archival notice to mailing list, as it
        appears there is no life left to this project
  - Release issues, planning plans
      - None noted
  - End game for next release... allow trivial items, in addition to
    high severity/priority?
      - Agreed we can change wording to allow trivial items in early RC
        phases along with PMC approval
  - Modeling package N\&N pages: per project, or unified for all of
    Modeling?
      - This release, send Rich your links to N\&N pages. Next release,
        we'll try to create a common modeling N\&N.

[Category:Modeling_Meetings](Category:Modeling_Meetings "wikilink")