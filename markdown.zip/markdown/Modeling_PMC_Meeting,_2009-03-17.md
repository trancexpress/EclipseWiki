Time: 10:00AM Eastern

Conference number: North America 1 866-842-3549, Global +800-4444-7070,
Ottawa 613-787-5018, Passcode: 1556241

  - International Toll-free number notes
      - Dialing from a cellular network may not work\!
      - Passcode is often not recognized. After the third failure, you
        will be transfered to an operator who will ask for the
        conference ID (1556241), sponsoring company (IBM) and meeting
        organizer (Paul Elder).
      - Pressing \*0 will bring you directly to an operator.

### Expected Attendees

  - Richard Gronback
  - Ed Merks
  - Sven Efftinge
  - Paul Elder
  - Jonathan Musset (for Cedric Brun)
  - Kenn Hussey
  - Frédéric Jouault

### Topics

  - Rebooting Query, Transaction, Validation, and OCL
      - We will try to uphold meritocratic principles by focusing on
        folks with demonstrated contributions.
          - For OCL this is easier because there is a long list of
            volunteers, but the other components haven't generated as
            much interest yet.
  - Rich's succession plan?
      - Yes, Rich has stepped down as lead.

[Category:Modeling_Meetings](Category:Modeling_Meetings "wikilink")