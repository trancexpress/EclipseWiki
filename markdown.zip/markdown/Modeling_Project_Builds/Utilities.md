This document describes utilities that simplify promotion of project
builds run on a [Hudson](Hudson "wikilink") CI server. All of the
utilities can be found on the build.eclipse.org server, in the
/shared/modeling/tools/promotion/ directory. See also [Milestone and
Release Builds](Milestone_and_Release_Builds "wikilink").

## download-artifacts.xml & download-artifacts.xsl

An ant script (complemented with an xsl stylesheet) to download
artifacts produced by a single Hudson build. The artifacts are
downloaded to a subdirectory of the current working directory; the name
of the subdirectory is based on the timestamp of the specified Hudson
build and (if available) on the build type:

> \[<build type>\]\<build timestamp in format "YYYYMMDDhhmm"\>

for instance - in case the build type ("S" in this example) was
available:

> S201012161737

or - in case the build type was not available - just:

> 201012161737

##### usage

>
>
>     <nowiki>/shared/common/apache-ant-1.7.1/bin/ant -f /shared/modeling/tools/promotion/download-artifacts.xml -Dbuild.url=<build URL> [ -Dartifact.prefix=<prefix> ]</nowiki>

where

>   - build URL : is a URL of the build that produced the artifacts to
>     be downloaded, for instance:
>     <https://hudson.eclipse.org/hudson/job/emf-cdo-integration/948>
>     prefix : is a prefix of artifacts (of their relative paths) which
>     should be included in the download; artifacts with relative paths
>     not starting with the specified prefix won't be included in the
>     download; the prefix will also be stripped off of the relative
>     paths of the artifacts before they are stored in the local
>     filesystem

##### example

    <nowiki>/shared/common/apache-ant-1.7.1/bin/ant -f /shared/modeling/tools/promotion/download-artifacts.xml -Dbuild.url=https://hudson.eclipse.org/hudson/job/emf-cdo-integration/948 -Dartifact.prefix=result/site.p2/</nowiki>

## unpack-iu.xml

An ant script to unpack (using the unpack200 tool) selected artifact
from a p2 repository and update the repository metadata accordingly. The
purpose of this tool is to be able to unpack artifacts known to cause
problems when being unpacked with an older version of the unpack200 tool
in advance with the newer version of the tool and thus avoid the
problems.

##### usage

>
>
>     <nowiki>cd <repository path>
>     ant -f /shared/modeling/tools/promotion/unpack-iu.xml -Dunpack.iu=<IU to unpack></nowiki>

where

>   - repository path : is a directory in which the p2 repository
>     containing the artifact to be unpacked resides
>     IU to unpack : is the p2 ID of the IU corresponding to the
>     artifact to be unpacked

##### example

    <nowiki>cd S201012140905/
    ant -f /shared/modeling/tools/promotion/unpack-iu.xml -Dunpack.iu=org.apache.derby</nowiki>

## manage-composite.xml

An ant script to simplify management of p2 composite repositories. It
can add and remove child repositories from a composite repository.

##### usage

>
>
>     <nowiki>cd <composite repository path>
>     ant -f /shared/modeling/tools/promotion/manage-composite.xml { add | remove } -Dchild.repository=<child repository URL> [ -Dcomposite.name=<composite repository name> ]</nowiki>

where

>   - composite repository path : is a directory containing the
>     composite repository (or a directory where the composite
>     repository is to be created)
>     child repository URL : is a URL of the child repository to be
>     added/removed from the composite; note that the URL can be (and
>     most often is) a relative URL
>     composite repository name : is a name of the composite repository;
>     this name is only used when a new composite repository is created,
>     it is ignored if the repository already exists

##### example

    <nowiki>cd /home/data/httpd/download.eclipse.org/modeling/emf/cdo/updates/4.0-milestones/
    ant -f /shared/modeling/tools/promotion/manage-composite.xml add -Dchild.repository=../4.0/S201012140905</nowiki>

## mirror-repository.xml

An ant script to mirror one repository into another. It adds all
artifacts (and associated metadata) found in one (source) repository
into the other (target) repository.

##### usage

>
>
>     <nowiki>cd <target repository path>
>     ant -f /shared/modeling/tools/promotion/mirror-repository.xml -Drepository=<source repository URL></nowiki>

where

>   - target repository path : is a directory in which the target p2
>     repository resides
>     source repository URL : is a URL of the repository to be mirrored
>     to the target repository

##### example

    <nowiki>ant -f /shared/modeling/tools/promotion/mirror-repository.xml -Drepository=/home/data/httpd/download.eclipse.org/modeling/emf/emf/updates/2.7milestones/base/S201012150917</nowiki>