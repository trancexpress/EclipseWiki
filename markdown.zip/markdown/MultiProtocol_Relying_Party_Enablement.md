{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}} The
relying party enablement code has been architected to support many
different authentication protocols and can be implemented on many
different application container platforms. The package
org.eclipse.higgins.rp.interface contains all the interfaces needed for
an API, SPI and other common utility functions.

Authentication protocols are implemented through Authentication Protocol
Handlers. There should be a new project for each authentication protocol
supported. Currently, the only supported authentication protocol handler
is the Information Card authentication protocol handler. The
authentication protocol handlers depend on a set of SPIs to handle the
platform specific implementation. There should be no platform dependent
code written into any of the authentication protocol handlers.

Relying Party applications can be configured to use one of the plaform
specific implementations and one authentication protocol handler. In the
future the code will support applications that want to give users a
choice of authentication protocols to gain access to the application.

## See Also

  - [Extensible Protocol RP Website
    1.0](Extensible_Protocol_RP_Website_1.0 "wikilink")

[Category:Higgins Components](Category:Higgins_Components "wikilink")