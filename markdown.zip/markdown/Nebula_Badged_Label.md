[\< Back to Nebula Main Page](Nebula "wikilink")

# Introduction

![<File:BadgeWidget.PNG>](BadgeWidget.PNG "File:BadgeWidget.PNG")

This widget displays a label with a badge (located on a corner of the
label).

__TOC__

# Usage

This is very simple :

  - you first instantiate a `BadgedLabel` object.
  - The location is set in the constructor (style)
      - The horizontal location is `SWT.LEFT` or `SWT.RIGHT`
      - The vertical location is `SWT.TOP` or `SWT.BOTTOM`
  - Like a label, you can set the text(**setText()**) or an image
    (**setImage()**).
  - You have to set the text displayed in the "badge" by calling the
    method **setBadgeValue()**
  - By default, the color of the badge is *blue*. You can change the
    colors of this badge :
      - Either by calling the method **setPredefinedColor**. Predefined
        colors are SWT.COLOR_BLUE, SWT.COLOR_GRAY, SWT.COLOR_GREEN,
        SWT.COLOR_RED,SWT.COLOR_YELLOW, SWT.COLOR_CYAN,
        SWT.COLOR_BLACK
      - Or by calling the methods setBadgeForeground() or
        setBadgeBackground()

`final BadgedLabel button1 = new BadgedLabel(shell, SWT.BORDER | SWT.TOP | SWT.LEFT);`
`button1.setText("Notification");`
`final GridData gd = new GridData(GridData.FILL, GridData.CENTER, false, false);`
`gd.widthHint = 200;`
`gd.heightHint = 100;`
`button1.setLayoutData(gd);`
`button1.setBadgeValue("1");`
`button1.setPredefinedColor(SWT.COLOR_GREEN);`
`button1.setBackground(label.getDisplay().getSystemColor(SWT.COLOR_WHITE));`

# Examples

An example called **BadgedLabelSnippet.java** is located in the plugin
**org.eclipse.nebula.widgets.badgedlabels.snippets**.

This example is also available here :
[BadgedLabelSnippet.java](https://github.com/eclipse/nebula/blob/master/widgets/badgedlabel/org.eclipse.nebula.widgets.badgedlabel.snippets/src/org/eclipse/nebula/widgets/badgedlabel/BadgedLabelSnippet.java)