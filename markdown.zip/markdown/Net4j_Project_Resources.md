**All of this information is obsolete since the Net4j project has been
integrated into the [CDO](CDO "wikilink") project.**

__TOC__
\==Downloads==

  - Read the [Release
    notes](http://www.eclipse.org/modeling/emf/news/relnotes.php?project=net4j&version=HEAD)
  - Download the
    [ZIPs](http://www.eclipse.org/modeling/emf/downloads/index.php?project=net4j&showAll=0&showMax=5)
  - Use the [EMF Update
    Manager](http://www.eclipse.org/modeling/emf/updates/)


\==Sources==

  - Use the [CVS Web
    Viewer](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.emf/org.eclipse.emf.net4j/?root=Modeling_Project)
  - Follow these [instructions](CDO_Source_Installation "wikilink") to
    install a complete workspace



## Documentation

  - Read the [JavaDocs for
    Net4j 1.0.0](http://download.eclipse.org/modeling/emf/net4j/javadoc/1.0.0/)
  - Work through the [Tutorials](Net4j#Tutorials "wikilink")


\==Support and Feedback==

  - Browse the [Open
    Bugs](http://bugs.eclipse.org/bugs/buglist.cgi?product=EMF&component=Net4j&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&order=bugs.bug_status,bugs.target_milestone,bugs.bug_id&query_format=advanced)
  - Submit a [New
    Bug](https://bugs.eclipse.org/bugs/enter_bug.cgi?product=EMF)
  - Ask Questions and write comments on the [EMF
    Newsgroup](http://www.eclipse.org/modeling/emf/newsgroup-mailing-list.php)


\==Miscellaneous==

  - View [Net4j 2.0 project
    plan](http://www.eclipse.org/projects/project-plan.php?planurl=http://www.eclipse.org/modeling/emf/net4j/project-info/plan.xml&component=Net4j)
  - View project statistics at
    [Ohloh](http://www.ohloh.net/projects/8907?p=Net4j)

-----

Wikis: [Net4j](Net4j "wikilink") | [CDO](CDO "wikilink") |
[Eclipse](Eclipse "wikilink") |
[OSGi](http://en.wikipedia.org/wiki/OSGi) |
[NIO](http://en.wikipedia.org/wiki/Nio) | [New
I/O](http://en.wikipedia.org/wiki/New_I/O)