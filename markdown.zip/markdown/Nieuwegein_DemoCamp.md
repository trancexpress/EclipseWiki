![Image:eclipse-camp.gif](eclipse-camp.gif "Image:eclipse-camp.gif")
[What is an Eclipse DemoCamp?](Eclipse_DemoCamp "wikilink")

### Location

Big Daddy's Roadhouse
Symfonielaan 3
3438EX Nieuwegein
<http://www.bigdaddys.nl/>

### Date and Time

November 28, 2007
6:30 pm - mingling starts
7:00 pm - demos start

### Organizer

Yuri Kok, Industrial TSI

### Presenters

If you would like to present at a DemoCamp, please feel free to add your
name and topic to the list. Depending on the number of people interested
we may have to limit the number of presenters and time of each demo.

  - Wim Jongman, Remain's TD/OMS plugin in Eclipse, BIRT integration
  - Martin Taal, EMFT Teneo Project
  - Maarten Meijer, Mylyn introduction
  - Erik Post, Model Driven Development with Eclipse (with FLEX preview)

### Who Is Attending

If you plan on attending please add your name to the list below. We'd
like to see as many people show up as possible.

  - Wim Jongman, Remain
  - Marco Kok, Industrial TSI
  - Yuri Kok, Industrial TSI
  - Wing Yu Chong, Remain
  - Martin Taal, elver.org
  - Jim van Dam, HiPeS [LinkedIn](http://www.linkedin.com/pub/0/865/b81)
  - Marco Theunissen, Livre & ICT Light
  - Casper Bodewitz, Rijksuniversiteit Groningen
  - Dennis van der Laan, Rijksuniversiteit Groningen
  - Eric Wout van der Steen, Rijksuniversiteit Groningen
  - Ivo van Bennekom, e-id
  - Erik Post, e-id
  - Henk-Peter Koster, Industrial TSI
  - Frank Cornelissen, T310 Software Development
    [LinkedIn](http://www.linkedin.com/in/t310sd)
  - Maarten Meijer, FOLD Systems and contributor to Eclipse/Mylyn
  - Peter de Winter, Brocacef
  - Paul Reitsema, Brocacef
  - Marco de Jong, Anytime Anyplace
  - Said Taaouati, Remain
  - Marc Evers, Piecemeal Growth
  - Jaap Reitsma, Telematica Instituut
  - Jarno de Wit, Pareto
    [LinkedIn](http://www.linkedin.com/in/jarnodewit)
  - Rick Lotman, IHC
  - Tim Rob, trdev.net [LinkedIn](http://www.linkedin.com/in/trdev)