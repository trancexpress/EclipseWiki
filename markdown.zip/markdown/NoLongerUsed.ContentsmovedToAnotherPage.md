<h1>

Running your own Repository Reports

</h1>

<h2>

Introduction

</h2>

This document gives a brief outline of how to run the "repo reports"
locally, against a repository on your local file system.

There are some tests, that look at jars specifically, that require the
jars to be on local file system and essentially use plain 'ol Java file
IO and regex-type checks on the contents.

Another class of tests, read the content.jar/xml meta-data and reports
on the data or relationships in that meta data.

Yet another, small class of tests, verify the jars are signed. These
tests are not really "Java" or "workspace" related, but use Java's
"exec" method to invoke "jarsigner -verify" on multiple threads, on a
directory of jars. (There is actually a faster heuristic in the code
that simply looks for the presence of the Eclipse signature file, but
that is a heuristic and might not always be accurate, so it not used by
default).

<h2>

Running the repo tests

</h2>

These instructions are focus for "running from your workspace", but
could also easily be done "from the command line" if you know how to run
Eclipse Applications from the command line.

<h3>

The Basics

</h3>

The Eclipse Application is named
'org.eclipse.cbi.p2repo.analyzers.repoReport'. It takes two "system
properties"; one to specify where you want the output to go, and another
to specify where the repository-to-analyze is on the file system. An
optional third parameter names a repository to use as reference for the
"version check" reports. For example:

  - \-DreportOutputDir=/home/shared/eclipse/repoReport
  - \-DreportRepoDir=/home/www/html/downloads/eclipse/updates/4.6-M-builds/M20161013-0730/
  - \-DreferenceRepo=/home/www/html/downloads/eclipse/updates/4.6/R-4.6.1-201609071200/

There is another parameter, *-DuseNewApi=true* which is not yet
documented () but runs the code in such a way that tests pass, fail, or
give a warning, and produces [compact, color coded table of
results](http://download.eclipse.org/eclipse/downloads/drops4/R-4.6.1-201609071200/buildlogs/errors-and-moderate_warnings.html),
to link to an experimental example.

<h3>

The Details

</h3>

The source project is named 'org.eclipse.cbi.p2repo.analyzers' and is
currently in Git in repository named
'cbi/org.eclipse.cbi.p2repo.analyzers.git'. See .

Once you load that project into your workspace, it will include one
"launch configuration" that can be used as a starting example, edited
and used to launch the application from your workspace.

On a large repository, it take 5 or 10 minutes to complete, and then you
just look at the results (usually) with a web browser starting with the
'index.html' at the location you specified in 'reportOutputDir'
property.

For one example of a bash script that takes advantage of a "product
build" to run the report application, see the example in the Eclipse
Platform Git repository named
[createReports.sh](http://git.eclipse.org/c/platform/eclipse.platform.releng.aggregator.git/plain/production/createReports.sh).

For an example of installing as a feature from a p2 repository see the
['installTestsFromRepo'
target](http://git.eclipse.org/c/simrel/org.eclipse.simrel.tools.git/tree/build.xml#n110)
in the SimRel build.xml file. And then, see the actual running of the
tests in the ['runReports'
target](http://git.eclipse.org/c/simrel/org.eclipse.simrel.tools.git/tree/runTests.xml#n97)
in the SimRel runTests.xml file.

<h2>

Getting help or making contributions

</h2>

You can ask questions on cross-project list if the tests do not work as
expected. Or, even better, you can make improvements/fixes directly on
this wiki, if the instructions can be better. Feel free to supply
patches on the cross-project component in bugzilla.