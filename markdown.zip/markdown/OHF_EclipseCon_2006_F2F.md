![banner132x38.gif](banner132x38.gif "banner132x38.gif") One of the
presentations (not written yet) is about OHF on Server. More information
will be posted in the Wiki in the following days.

  - [OHF bridge presentation](Media:OHF_on_Server_F2F.pdf "wikilink")