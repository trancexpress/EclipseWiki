[Back to the OHF Wiki](OHF "wikilink")

## Content

The OHF Wiki is intended for use by developers and advanced users that
are interested in the underlying architecture of OHF as well those
looking to contribute to OHF. Content that is designed for end-users
only (i.e. install documents, basic configuration documents) should be
placed on the component-specific pages of the main OHF Web site.

It is strongly recommended that content creators keep a strict
separation of content between the main Web site and Wiki for the sake of
consistency. Please consider the content that you are writing before
deciding whether it should go on the Wiki or Web site. A good rule of
thumb is balance long-term static content vs. content that will change
often. This often ties directly into the notion of public release versus
unstable release of code. For example, if you are writing an install
guide for a public release of your component, it is better suited to be
on the main Web page, as it is primarily intended for end users and will
not be modified often. On the other hand, if you are composing the
next-generation architecture of your component, it will likely be
modified repeatedly and fits more into a Wiki paradigm.

### Content Ownership

A wiki is intended to be a collaborative environment where people are
encouraged to contribute their expertise on a topic in an effort to help
share knowledge. The OHF Wiki follows this principal as well. In many
cases, the expert(s) on the topic will be the principal contributor for
a specific page and thus act as the de facto owner. However, we
encourage all users to contribute to the OHF Wiki and make changes where
needed. These changes from grammatical to factual fixes all the way to
adding new, useful content. It is recommended that you content the
primary author before making significant changes to a specific Wiki
page.

## Naming

The Eclipse OHF Wiki is co-located in the same namespace as all other
Eclipse project content. To ensure consistency, all OHF content pages
should be prefixed with the letters 'OHF'. For component-specific pages,
the component name should also be prefixed. For example, all pages
relating to the IHE components of OHF will be prefixed with 'OHF IHE'.
If you encounter a page belonging to OHF that does not follow this
naming convention, please use the MediaWiki **move** function to make it
conform and update the originating link.

There are exceptions to this policy for OHF-related Wiki pages that do
not specifically relate to OHF work. Pages like this should *not* be
prefixed with OHF.

## Linking and Navigation

### Backlinking

All Wiki pages should implement a back link to its logical predecessor.
For example, an OHF component page should always link back to the main
OHF Wiki page.