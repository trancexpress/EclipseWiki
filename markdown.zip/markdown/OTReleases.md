Releases of the Eclipse Object Teams Project:

  - **2.0** (graduation) Part of the Indigo Simultaneous Release
      - [download](http://www.eclipse.org/objectteams/download-prev.php#R20)
  - **2.1** Part of the Juno Simultaneous Release
      - Review tracking in bugzilla at
      - [Review docuware](OTReleases/JunoReview "wikilink")

Meanwhile all releases are documented via
<https://projects.eclipse.org/projects/tools.objectteams/documentation>

[Category:Object Teams](Category:Object_Teams "wikilink")
[Category:Object Teams
Development](Category:Object_Teams_Development "wikilink")