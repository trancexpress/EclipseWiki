### 20151002

Jay - Working on project support - refactoring persistence provider and
core.
Robert - Working on VIBE SWTBot tests. Reviewing Tony's contributions.
Hari - Adding support for expressions in the VisIt client and
session/window saves.
Taylor - Preparing for pilot participants. Working on the Nek Model
Builder SWTBot tests.

### 20151005

Jay - Working on project support and setting up the XML Persistence
Provider to use Extension Registry. Similarly for IReader/IWriter.
Alex - Working on ICE developer tooling, refactoring abstract handler
object hierarchy.
Robert - Working on getting SWTBot recorder to work, getting CI working
on Mac Mini, and working on Mac UI bugs.
Andrew - Fixing issues with python installer.

### 20151006

Alex - Working on dev support, merging into next. Looking into XML
Schema improvements.
Taylor - Working on configuration and testing for participant machines
in VOCC lab.
Robert - Setting up Mac OS X Jenkins install.
Andrew - Researching artificial intelligence stuff.

### 20151007

Jay - Working on common navigator framework extensions needed for
loading Items. Refitting the Core to use ICE Extension points.
Taylor - Working on configuration and testing for participant machines
in VOCC lab.
Robert - Working on VizService Tests.

### 20151009

Jay - Continuing work on project support - converting declarative
services to extension points, fixing bugs related to item development in
ICE.
Robert - Adding VizService tests, working through EMF tutorials,
starting reactor refactor in EMF prototype.
Taylor - Working on setup tasks from pilot, meeting to figure out
scheduling, planning for study at ORNL. Working on slides for ECE.
Pratul - Working on Tau use and integration in ICE. Testing out ICE Dev
Menu.
Hari - Working on java client - making it more robust.

### 20151012

Robert - Working on the EMF reactor data structures prototype.
Taylor - Working on planning and scheduling for the study on Oct.
21,22.
Andrew - Research/Lit review for machine learning.

### 20151013

Alex - Working on project support branch, cleaning up and fixing bugs
for merge with next.
Robert - Working on EMF prototype and getting the new JavaFX geometry
viz service working.
Andrew - Working on pulling features out of structured text.

### 20151014

Alex - Working on project support branch, cleaning up a few build
bugs.
Robert - Working on the EMF prototype, getting EList and EMap to work.
Taylor - Working on R scripts for usability study data analysis.
Ksenia - Working on Lab training, running through lab responsibilities
checklist.
Hari - Working on a bug in the visit java client related to updates in
the backend.

### 20151016

Ksenia - Working through ICE Wiki tutorials - testing each one in ICE
for potential bugs.
Taylor - Continuing with R stats work. Working on ECE talk.
Pratul - Working on Tau wiki docs.
Robert - Working on JavaFX EMF prototype. Fixing target issues on Linux
machine.
Hari - Working on remaining java client bug fixes. Working on visit
build version 10.

### 20151019

Jay - Finished project support in ICE. Working on ICE plugin
generation.
Alex - Working on import file as item functionality in new ICE project
support setup.
Robert - Tested project support branch on Windows. Testing on Tony's
JavaFX work. Working on getting ICE working on Linux machine.
Taylor - Working on ECE slides. Finalizing scheduling for HCI study.
Andrew - Working on writing up docs on AI.

### 20151020

Jay - Working on the ICE plugin project generation tool. Also working on
the parser generator.
Alex - Updated the Import File and Import File As Item Wizards to work
with new project support.
Robert - Installed E(fx)clipse on demo laptop. Working on getting the
Linux touchpoint p2 bug fix.
Taylor - Preparing for tomorrow's HCI study.
Andrew - Researching pattern classification and Eclipse class
generation.

### 20151021

Alex - Implemented ICE Item XML file renaming functionality.
Taylor - Running the HCI study.
Robert - Working on the Linux target bug, writing tests for EMF data
structures prototype.
Hari - Documenting changes in library and external wiki.

### 20151023

Jay - Merging projectSupport into next, attending various meetings.
Starting up the new web server.
Robert - Installing ICE on laptop, working on Tony's geom editor and
more EMF tests.
Ksenia - Installing ICE on Linux with the python script.
Hari - Working on documentation for java client widgets.

### 20151026

Jay - Fixing bugs in next to prepare for ICE 2.1.8 release.
Robert - Building the projectSupport branch on Linux and Windows to test
it. Writing more tests.
Ksenia - Continuing testing the MOOSE Item, researching MOOSE and Stork
repos. Installing and connecting to VisIt.
Taylor - Working on ECE talk preparations.
Andrew - Testing projectSupport branch.

### 20151027

Robert - Working with Modisco and Papyrus to get the Java-to-UML-to-Java
workflow working.
Taylor - Working on ECE talk preparations.

### 20151028

Jay- UI Refactor and bugfixing reflectivity code.
Robert - Working with Modisco and Papyrus to get the Java-to-UML-to-Java
workflow working.
Taylor - Working on ECE talk preparations.
Hari- Updating Java client documentation and merging into next.

### 20151030

Jay - Working on a vision document for work at the SNS. Starting on talk
slides for ECE.
Robert - Working on the Java to UML to Java workflow and Viz Service
tests.
Ksenia - Testing the ICE install python script.
Taylor - Finishing up ECE presentation, starting data analysis for HCI
study.