  - Call convened at [1000
    EST](http://timeanddate.com/worldclock/fixedtime.html?month=11&day=27&year=2007&hour=10&min=0&sec=0&p1=188)
  - Call-in: **613.287.8000** or **866.362.7064**, passcode **892048\#**
  - Previous Meeting: [Orbit Minutes
    071016](Orbit_Minutes_071016 "wikilink")

## Attendees

  - Joel Cayne
  - Christian Damus
  - David Williams
  - Pascal Rapicault
  - Kim Moir
  - DJ Houghton

## Discussion

### Bugs

We had a bunch of open bug reports about adding [new
bundles](http://wiki.eclipse.org/Orbit_Minutes_071016#New_Bundles) and
fixing a [few
bugs](http://wiki.eclipse.org/Orbit_Minutes_071016#Bug_Fixes). Did we
release all the changes yet?

  - batik 1.7 - still in beta so we will wait until 1.7 is officially
    released before we put it in Orbit
  - <font color="red">Action: DJ to ping people about open bug
    reports</font>

### Eclipse 3.4 M4

We are fast approaching the Eclipse 3.4 M4 release. We need to lock down
n-1.

  - promote I-build Friday, November 30
  - promote S-build Friday, December 7
  - <font color="red">Action: DJ to send note to mailing list with
    dates</font>

### Source Bundles

The Eclipse Platform is moving to a new format for source bundles. It
will allow them to be packaged individually, be JAR'd, and specify that
they are a source bundle in the manifest file rather than via the
extension registry. (plugin.xml)

  - still need to update wiki with new instructions
  - DJ will update all the source bundles initially
  - Don't fix before Ganymede milestone (Jan 11) to make things easier
    for a re-build if necessary

## Next Meeting

  - TBD

[Category:Orbit](Category:Orbit "wikilink")
[Category:Orbit/Meeting](Category:Orbit/Meeting "wikilink")
[Category:Meeting](Category:Meeting "wikilink")