{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}

  - I-Card instances instantiated and managed by this [I-Card
    Provider](I-Card_Provider "wikilink") implement the ICard and
    ITokenCard interfaces (see [I-Card
    Interfaces](I-Card_Interfaces "wikilink"))
  - Retreives signed security tokens from CardSpace-compatible IdP/STSes
    and acceptable by CardSpace-compatible RPs
  - Imports CardSpace-format managed card files

[Category:Higgins Components](Category:Higgins_Components "wikilink")