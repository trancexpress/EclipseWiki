{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}

  - I-Card instances instantiated and managed by this provider implement
    the ICard, ITokenCard, and IURICard interfaces (see [I-Card
    Interfaces](I-Card_Interface "wikilink"))
  - The provider impl uses IdAS to access attribute values.
  - Examples:
      - LDAP directory card: provides a view of the user's identity data
        stored on an enterprise HR directory

[Category:Higgins Components](Category:Higgins_Components "wikilink")