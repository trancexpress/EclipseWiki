{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}
![Higgins_logo_76Wx100H.jpg](Higgins_logo_76Wx100H.jpg
"Higgins_logo_76Wx100H.jpg") API of the [Identity Attribute
Service](Identity_Attribute_Service "wikilink"). The
[Org.eclipse.higgins.idas.api](Org.eclipse.higgins.idas.api "wikilink")
per se does not include the [IdAS Registry](IdAS_Registry "wikilink")
API, which is described separately.
[Org.eclipse.higgins.idas.api](Org.eclipse.higgins.idas.api "wikilink")
is part of the [IdAS Package](IdAS_Package "wikilink").

## See Also

  - [IdAS Package](IdAS_Package "wikilink")
  - [Components](Components "wikilink"): [IdAS
    Component](http://wiki.eclipse.org/index.php/Components#Identity_Attribute_Service_and_Context_Providers)
    --lists [IdAS](Identity_Attribute_Service "wikilink") Component
    sub-projects and as well as projects for available Context Providers

[Category:Higgins IdAS](Category:Higgins_IdAS "wikilink")
[Category:Higgins Components](Category:Higgins_Components "wikilink")