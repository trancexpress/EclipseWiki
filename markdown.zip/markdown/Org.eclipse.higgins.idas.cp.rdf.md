{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}
![Higgins_logo_76Wx100H.jpg](Higgins_logo_76Wx100H.jpg
"Higgins_logo_76Wx100H.jpg") The [RDF CP](RDF_CP "wikilink") is a very
simple, read-only [IdAS](IdAS "wikilink") [Context
Provider](Context_Provider "wikilink") that can retrieve an RDF document
from a URI and expose it as a Higgins [Context](Context "wikilink").

## Details

  - *Javadoc*:
    [Javadoc](http://download.eclipse.org/technology/higgins/downloads/idas.cp.rdf/lastNightlyBuild/javadoc/index.html)
  - *Status*: first code in Higgins B-1-1-M3
  - *Language*: Java
  - *Packaging*: OSGI bundle

## Configuration

The [RDF CP](RDF_CP "wikilink") expects a single configuration setting
in its [ContextId](ContextId "wikilink") via the [Configuration
API](Configuration_API "wikilink"): **uri**

Example configuration using an [XML configuration
file](Configuration_XML "wikilink"):

``` xml
<Configuration
    xmlns:xsd="http://www.w3.org/2001/XMLSchema"
    ns="http://higgins.eclipse.org/Configuration"
    xmlns:htf="http://higgins.eclipse.org/Configuration">
    xsd:schemaLocation="http://higgins.eclipse.org/Configuration Configuration.xsd ">

    <!--  The setting handlers are classes that consume Setting elements where the Type matches and generate an object of the Class -->
    <SettingHandlers>
        <SettingHandler Type="htf:map" Class="java.util.Map" Handler="org.eclipse.higgins.configuration.xml.MapHandler"/>
        <SettingHandler Type="htf:list" Class="java.util.List" Handler="org.eclipse.higgins.configuration.xml.ListHandler"/>
        <SettingHandler Type="xsd:string" Class="java.lang.String" Handler="org.eclipse.higgins.configuration.xml.StringHandler"/>
        <SettingHandler Type="htf:classinstance" Class="java.lang.Object" Handler="org.eclipse.higgins.configuration.xml.ClassInstanceHandler"/>
        <SettingHandler Type="htf:classsingleton" Class="java.lang.Object" Handler="org.eclipse.higgins.configuration.xml.ClassSingletonHandler"/>
        <SettingHandler Type="htf:uri" Class="java.net.URI" Handler="org.eclipse.higgins.configuration.xml.URIHandler"/>
    </SettingHandlers>

    <Setting Name="DeploymentConfiguration" Type="htf:map">

        <Setting Name="ComponentSettings" Type="htf:map">
            <Setting Name="RDFContextFactory" Type="htf:map" />
            <Setting Name="IdASRegistry" Type="htf:map">
                <Setting Name="ContextFactoryInstancesList" Type="htf:list">
                    <Setting Name="RDFContextFactory" Type="htf:map">
                        <Setting Name="Instance" Type="htf:string">RDFContextFactory</Setting>
                        <Setting Name="ContextTypes" Type="htf:list">
                            <Setting Name="ContextType1" Type="htf:string">$context$mime*application*rdf.xml</Setting>
                        </Setting>
                    </Setting>
                </Setting>

                <Setting Name="ContextIdsList" Type="htf:list">
                    <Setting Name="ContextId1" Type="htf:map">
                        <Setting Name="ContextId" Type="xsd:string">rdfTestContext</Setting>
                        <Setting Name="ContextTypes" Type="htf:list">
                            <Setting Name="HigginsContextType" Type="xsd:string">$context$mime*application*rdf.xml</Setting>
                        </Setting>
                        <Setting Name="uris" Type="htf:list">
                            <Setting Name="uri1" Type="htf:uri">http://myopenlink.net/dataspace/person/danieljohnlewis</Setting>
                        </Setting>
                    </Setting>
                </Setting>
            </Setting>
        </Setting>

        <!-- The name of the class that implements the RDF Context Provider -->
        <Setting Name="RDFContextFactory" Type="htf:classinstance">org.eclipse.higgins.idas.cp.rdf.RDFContextFactory</Setting>

        <!-- The name of the class that provides the factory for the class that implements the IdASRegistry -->
        <Setting Name="IdASRegistry" Type="htf:classsingleton">org.eclipse.higgins.idas.registry.IdASRegistry</Setting>

    </Setting>

</Configuration>
```

## Service

  - The RDF CP does not require authentication materials. It assumes
    that anyone can retrieve the URI with the RDF data.
  - The RDF CP sends an "Accept: application/rdf+xml" HTTP header when
    retrieving the RDF data.
  - The RDF CP is suitable for reading RDF data from [Hash and 303 Cool
    URIs](http://www.w3.org/TR/2007/WD-cooluris-20071217/).
  - The RDF CP is useful in conjunction with [IdAS UDI
    Resolution](IdAS_UDI_Resolution "wikilink"), since 303 and Hash Cool
    URIs are one type of [Entity UDI](Entity_UDI "wikilink").
  - The recommended [Context Type](Context_Type "wikilink") for contexts
    opened with the RDF CP is **$context$mime\*application\*rdf.xml**.

## See Also

  - [Identity Attribute Service](Identity_Attribute_Service "wikilink")
    --overview of IdAS
  - [Components](Components "wikilink"): [IdAS
    Component](http://wiki.eclipse.org/index.php/Components#Identity_Attribute_Service_and_Context_Providers)
    --lists [IdAS](Identity_Attribute_Service "wikilink") Component
    sub-projects and as well as projects for available Context Providers

[Category:Higgins Components](Category:Higgins_Components "wikilink")