{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}} This
mapper matches requests to handlers based on information in the request
and a set of configured mapping data.

[Category:Higgins Components](Category:Higgins_Components "wikilink")