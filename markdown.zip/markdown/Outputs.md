back to [slang DSL](slang_DSL "wikilink")

## Outputs

Outputs defines the possible parameters flow \\ operation expose to
further use.
<code> sample:

`       outputs:`
`       - output_from_return_value: processId`
`       - output_from_input_value: fromInputs ['input1']`

</code>