A personal [R-Card](R-Card "wikilink"). That is, a personal card with a
resource-udr claim.