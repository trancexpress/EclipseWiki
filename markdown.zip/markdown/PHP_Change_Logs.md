This page provides direct access to the different change logs of every
integration build.

  - [I20061113](http://download.eclipse.org/tools/php/downloads/drops/I20061113/changelog.html)

<!-- end list -->

  - [I20061012](http://download.eclipse.org/tools/php/downloads/drops/I20061012/changelog.html)

<!-- end list -->

  - [I20060926](http://download.eclipse.org/tools/php/downloads/drops/I20060926/changelog.html)

<!-- end list -->

  - [I20060911](http://download.eclipse.org/tools/php/downloads/drops/I20060911/changelog.html)

<!-- end list -->

  - [I20060820](http://download.eclipse.org/tools/php/downloads/drops/I20060820/changelog.html)

<!-- end list -->

  - [I20060725](http://download.eclipse.org/tools/php/downloads/drops/I20060725/changelog.html)

<!-- end list -->

  - [I20060706](http://download.eclipse.org/tools/php/downloads/drops/I20060706/changelog.html)

<!-- end list -->

  - [I20060703](http://download.eclipse.org/tools/php/downloads/drops/I20060703/changelog.html)

<!-- end list -->

  - [I20060629](http://download.eclipse.org/tools/php/downloads/drops/I20060629/changelog.html)

<!-- end list -->

  - [I20060625](http://download.eclipse.org/tools/php/downloads/drops/I20060625/changelog.html)