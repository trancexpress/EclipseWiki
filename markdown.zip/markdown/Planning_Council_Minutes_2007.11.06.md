These are the minutes from the [Eclipse Planning
Council](http://www.eclipse.org/org/foundation/council.php#planning)
face-to-face November 6th, 2007 at
[EclipseWorld](http://www.eclipseworld.net/) in Reston, VA.

The main purpose of this face-to-face was to be the kick-off meeting
[Ganymede](Ganymede "wikilink").

### Europa Fall and Winter Maintenance

We began with a discussion of the Europa maintenance releases. We
discussed various options for sign-offs, voting, etc. and in the end
decided that the Europa Fall Maintenance Release issues were a one-off
problem and were not likely to reoccur. Thus we settled on Nick's
suggested dates but chose not to implement the sign-off table. See
[Europa\#Coordinated_Maintenance](Europa#Coordinated_Maintenance "wikilink")
proposals. We did agree that if we send emails about Europa build
problems, cross-projects bugs, etc., we should use the "URGENT" label in
the title to get through certain people's almost infinite inboxes.

### Define the Ganymede Musts and Shoulds Rules

We discussed the defined the must-dos and should-dos. See [Ganymede
Simultaneous Release](Ganymede_Simultaneous_Release "wikilink").

The project leaders *mostly* agreed to fix usability and out-of-box
experience issues in the Ganymede time frame. However, the project
leaders were unwilling to make that a must-do requirement. There were
two main arguments: one was resources (people) and the other was that
usability is more holistic than just conforming to a checklist. A good
example of the latter was around the integration of documentation,
examples, wizards, and the main tool sets.

### Set Ganymede Milestone Dates

Discussed and set the dates. Added a +3 stage. Agreed to include the EPP
packages as part of the Ganymatic so that they are always available and
thus we do not need an extra step to create them. We chose not to
incorporate voting or sign-offs and instead continue to rely on
date-based builds. For details, see[Ganymede Simultaneous
Release](Ganymede_Simultaneous_Release "wikilink").

### Ganymatic

The Ganymede build system is running (see
[1](http://build.eclipse.org/ganymede/)). Further improvements are
planned, including running pack200, building the EPP packages (see
[2](http://www.eclipse.org/epp/download.php)), running junit tests,
testing as many of the "must do" rules as possible, etc.

An action item for Bjorn is to implement a report card of should dos and
must dos (probably a static report card).

### User Interface Guidelines

Bob Fraser of the [User Interface Best Practices Working
Group](User_Interface_Best_Practices_Working_Group "wikilink") said that
they will come up with a "developer UI checklist" of about 10 items that
is meant to be measurable and actionable but that the group will not to
be in the business of enforcement. The group also encouraged projects to
go through a UI work through with them. The UIBPWG has become a group
for people who are interested in UI issues around Eclipse.

### Packages

The Europa releases included four packages on the download page. This
proved to be quite successful and we're planning to do at least the same
thing for Ganymede. However one critique of the packages last year was
that there was inadequate cross-project testing within the packages. So
this year the projects that are incorporated into the packages need to
agree to do some cross-project testing. Specifically, they need to agree
to do their usual testing with the package rather than just with their
own project image.

We will create packages (I call them distros) when there is an owner for
package. For example, David Williams volunteered to have the WTP team
"own" the Web Tooling package. They will be responsible for what is
included in the package and for testing the package, etc. The package
owner will:

1.  Decide what goes into the package (in both the sense of conceptually
    evaluating proposed content, as well as soliciting other projects to
    participate if they should be included).
2.  Will ensure the package gets at least some minimum testing from
    committers, and will work to promote widespread testing from
    community.

The packages will still be assembled by the EPP project and distributed
by the Eclipse Foundation's main download site.

All of the projects agreed to move their custom "all-in-one" zips to be
real EPP packages.

There will still be a Ganymede update site with all the projects but,
based on the download stats from Europa, we expect most users to consume
the distros instead of the download site. Adopters will continue to
consume the update site.

The eclipse.org download page [3](http://www.eclipse.org/downloads/)
will have distros listed on it again this year. If we have more distros
owned by PMCs than slots on the download page, the EMO will choose four
or five for the main download page and then there will be a second page
listing all the distros.

### Internationalization

An updated on the Babel project's implementation of the Aptana
server-based contribution. There was discussion on how to submit and
consume the results. In the end, we agreed that:

1.  each project will specify which of their property files need to be
    translated. This will be done through an as-yet-defined either
    web-api or project meta-data item. Rich made the excellent
    suggestion that Babel should consume the map files if possible and
    then find all property files below that.
2.  Babel will generate (and place in its own download directory) one
    language pack for each language; the language pack will cover all
    Eclipse projects.