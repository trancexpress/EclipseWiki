  - Companies
      - [Nokia](http://www.nokia.com)
      - [Macrobug](http://www.macrobug.com/)
  - Participants from Macrobug
      - Adrian Taylor
  - Participants from Nokia
      - Ken Ryall
      - Don Podwall
  - Products tested and versions
      - Nokia Carbide.C++ 1.2 pre-beta
      - Macrobug Memory Leak Tracer 1.0.3 pre-alpha
  - How did the test go?
      - Problems with workarounds
  - What tests did you complete?
      - Installed Memory Leak Tracer 1.0.3 on a clean installation of
        Carbide 1.2 alpha on Adrian's laptop.
  - What problems did you find
      - Macrobug problem: Selecting a code item in the historical call
        stack did not go to the relevant code. This may not be related
        to the new version of Carbide as I (Adrian) have seen this
        before.
      - Nokia problem: when creating a new project it includes two
        versions of each file in the Project Explorer. This is
        apparently a known issue with this really early version of
        Carbide 1.2.
  - What resolutions did you find
      - n/a - everything worked well enough
  - Is there a screenshot?
      - Yes

![Picture of the products working together](Nokia_Macrobug_testing.png
"Picture of the products working together")