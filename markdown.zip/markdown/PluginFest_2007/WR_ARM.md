  - Testers
      - WR: Martin Oberhuber, Doug Gaff
      - ARM: Mikhail Khodjaiants, Chris Mead, Hobson Bullman, Anthony
        Berent
  - Products tested
      - WB 2.6, CDT + RealView ICE 3.1
  - Overall Result
      - Worked with some minor issues (expected platform limitations)
  - Tests
      - Used "Register Installation into Eclipse" from WB to install
        into RVIce.
      - Import WR projects into RVIce
      - Launched debug sessions for both WB and RVIce
      - Set and edit breakpoints
      - ARM assembler
      - WR Static Analysis
  - Problems
      - Know platform limitation: Debugger can only link to one C
        editor, and there are two C editors. This creates problems
        getting breakpoint properties for Workbench breakpoints.
        Stepping and instruction pointer indicators seem to work.
        Breakpoint properties from the breakpoints view wasn't bringing
        up the right BP properties page.
      - Minor ARM assembler bugs, but the assembler is in a very early
        form.
  - Screenshot

[image:wrwb_arm_small.gif](image:wrwb_arm_small.gif "wikilink")