  - Testers
      - WR: Martin Oberhuber, Doug Gaff
      - IBM: Stephen Rooks, Richard France
  - Products tested
      - WB 2.6, RSD 7.0, TestRT 7.0
  - Overall Result
      - Both WB+RSD and WB+TestRT worked with some workarounds
  - RSD Tests
      - Installed RSD into WB.
      - Tested RSD visualizer and xml code generator.
      - Installed WB into RSD.
      - Installed TestRT application and added TestRT plug-in to WB.
        Tested build.
  - WB/RSD Problems
      - Installation - RSD into WB
          - Need to enter the install path multiple times.
          - The personal configuration file is in the user's home
            directory and the IBM installer is looking for it in the
            eclipse directory. Installer should detect this by looking
            at the config.ini file in the configuration directory.
            Workaround was to take the configuration directory from the
            user's home directory and copy it into the eclipse
            directory.
          - Enhancement: would like to be able to specify the JVM. Why
            is this needed when installing into an existing Eclipse?
          - Enhancement: on Features page, listing the actual install
            path under the disk usage area.
          - We had to update jdt.core, osgi, swt, swt.win, update.core
            packages to the very latest version (maintenance builds) in
            WB. We used the update manager in WB to pull down the latest
            versions from the Eclipse update site. When we reran the
            installer, it reported that the latest osgi was not
            installed. So we had to restart WB before rerunning the
            installer in order for the eclipse configuration to be
            updated.
          - After updating, we were unable to rerun the installation
            manager that had been installed. We had to start over from
            disk.
      - Installation - WB into RSD
          - RSD has multiple installation locations. RSD is reporting
            that it's version 7 (in .eclipseproduct), so the WB install
            into function reports that it can't install.
          - We hacked the correct version number, but install into
            failed with errors. We will test further after pluginfest.
      - Usage
          - WR projects do not have a CDT nature yet, so the visualizer
            doesn't work from a WR project.
          - We were able to run code generation tools and get a CDT
            project created.
          - We hacked the .project file for a WR project and manually
            added the CDT project nature and build commands. This put
            both the WR and CDT builders in the project properties. The
            visualizer and code generator worked on the WR project after
            this.
  - Test RT Tests
      - Installation - TestRT into WB
          - TestRT uses a different installer than RSD. TestRT is a
            standalone application outside of Eclipse. From WB, we added
            a new extension location to pick up the TestRT plug-in.
          - TestRT expects that CDT (and several other plug-ins) are
            already installed into eclipse. Feature Request: the
            installer should check to see if the eclipse install has the
            required plugins and warn the user. Alternatively, TestRT
            could use the same installer as RSD. For this test, we had
            RSD and WB installed together, so we had the required
            plugins installed already. Otherwise, we would have had to
            add them manually.
          - TestRT menu only appears from the C/C++ projects view. The
            testrtcc command is automatically added to CDT managed make
            projects.
          - Modified the command in WR managed build to add "testrtcc"
            to add instrumentation to our code. Had some problems with
            the instrumented code compilation in linking. (Instrumented
            code is RTOS and compiler dependent.) We also had to exclude
            the Test RealTime directory from the managed project. There
            were some linking errors. Richard found a couple of
            configuration problems in TestRT Deployment Port. Issues
            seam to be related to using a Deployment Port designed for
            VxWorks 5.5 on a VxWorks 6.x project.
  - Screenshot


[image:Wrwb_rsd.gif](image:Wrwb_rsd.gif "wikilink")

[image:Wrwb_testrt.gif](image:Wrwb_testrt.gif "wikilink")