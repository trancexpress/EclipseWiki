  - Testers
      - WR: Martin Oberhuber, Doug Gaff
      - Klocwork: David Goldman, Sergey Bushkov
  - Products tested
      - WB 2.6
      - Klocwork 7.5
  - Overall Result
      - Everything worked
  - Tests
      - Installed Klocwork into WB
      - Ran Klocwork against a couple of source files. Klocwork found a
        bug in one of the files. Fixed and reran to verify success.
        Added include paths to pick up header files that Klocwork
        couldn't find.
      - Ran kwinject at command line to get the includes and defines.
        Tested running kwinject with Workbench managed build and
        flexible build.
  - Problems
      - Enhancement: Klocwork needs a way to get additional build
        settings (includes, defines) programmatically from projects in
        order to pass this information to the parsing engine. Klocwork
        needs a common API, though, preferably based on CDT. Wind River
        will need to support this API.
      - Enhancement: ability to change include path order in project's
        Klocwork properties.
      - Enhancement: Would be nice to allow navigation from the Klocwork
        Log Console. In the WB example, the parser didn't like a line in
        one of the header files where we were using a non-standard
        compiler extension, but we couldn't navigate to it from the
        Klocwork Log Console.
  - Screenshot

[image:Wrwb_klocwork2.gif](image:Wrwb_klocwork2.gif "wikilink")