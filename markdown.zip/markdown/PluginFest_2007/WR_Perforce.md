  - Testers
      - Perforce: Laurette Cisneros, Pascal Soccard, Robin Gardner
      - WR: Martin Oberhuber, Doug Gaff
  - Products tested
      - WB 2.6, Perforce 2006.2
  - Overall Result
      - Worked, with a few issues
  - Tests
      - Installed perforce server and client & WB 2.6
      - Added files from a project to the Depot
      - Tested check-in, check-out, diff.
      - Rename project
      - Rename file
  - Problems
      - Compare editor - save button doesn't check out automatically
      - Setting up the default workspace in perforce to see your Eclipse
        workspace is an important step that users need to get right
      - Line endings: perforce defaults to local, but Eclipse defaults
        to keep line endings as-is in the file. When you do a version
        diff, you might see every line changed. Tried changing perforce
        to "share", but this put the version in the Depot in Unix line
        style.
      - When you rename the project, the version control associations
        are lost
      - In Perforce Perspective, the Window - Show View menu doesn't
        show the shortcuts to the perforce views (they are listed in
        Other).
      - Submitted Changelist view - Depot view provides context
        selection, but editor does not.
      - Submit at the project level is broken. (Has been fixed in recent
        release.)
      - Feature request: CVS has a drop down to show previous comments
        on check-in. Would be nice for Perforce, too.
      - Had some problems creating branches.
  - Screenshot

[image:WRWB_Perforce.gif](image:WRWB_Perforce.gif "wikilink")