  - Testers
      - WR: Martin Oberhuber, Doug Gaff
      - Yura Zharkovsky, Doron Ben-Ari
  - Products tested
      - WB 2.6, Telelogic 7.0 Maintenance Release 2
  - Overall Result
      - Integration worked after some workarounds
  - Tests
      - Build dishwasher example.
      - Run as an RTP on VxSim and look at statechart and sequence
        diagram animation.
  - Problems
      - During install, we put the rhapsody plugins into an external
        location, since the install was trying to put them in the 2.4
        tree.
      - Had to change the rhapsody.ini file to specify the new path for
        WB 2.6. Directory structure changed from 2.4.
      - The Rhapsody project types need to be updated for WB 2.6. Some
        include paths for Rhapsody libraries are missing from the build
        spec. Also need to rebuild the libraries with the latest
        toolchains. We switched to Diab compiler and manually added the
        libraries. We then rebuilt the libraries for 2.6.
  - Screenshot

[image:Wrwb_rhapsody2_small.gif](image:Wrwb_rhapsody2_small.gif "wikilink")