## Portlet Example

This example shows how to deploy BIRT Report Engine in a portal. This is
a basic example and shows how to deploy a BIRT report in a simple Apache
Jetspeed-2 portlet. It is based on [Servlet
Example](Servlet_Example "wikilink") in BIRT Report Engine API Examples.

#### Web Application Setup

1\. Create a directory webreport/WEB-INF/lib.

2\. Copy all the jars in the birt-runtime-2_1_1/ReportEngine/lib
directory from the Report Engine download into webreport/WEB-INF/lib
directory.

3\. Create a directory named platform in the WEB-INF folder.

4\. Copy the birt-runtime-2_1_1/ReportEngine/plugins and
birt-runtime-2_1_1/ReportEngine/configuration directories to the
platform directory.

5\. Copy iText.jar to the platform/plugins/com.lowagie.itext/lib
directory. If the directory does not exist, create it.

6\. Create directories Images and Reports in webreport folder.

#### Report Application

1\. It consist of three files that are archived into webreport.jar. Copy
the following three files to a folder.

  - BirtConfig.properties - Configuration properties for the Engine.
  - BirtEngine.java - Class used to initialize the Report Engine.
  - WebReport.java - The portlet that handles report generation.

#### Source

**BirtConfig.properties**

`logDirectory=c:/temp`
`logLevel=FINEST`

**BirtEngine.java**

`import java.io.InputStream;`
`import java.io.IOException;`
`import java.util.Properties;`
`import java.util.logging.Level;`

`import org.eclipse.birt.report.engine.api.EngineConfig;`
`import org.eclipse.birt.report.engine.api.IReportEngine;`
`import javax.servlet.*;`
`import org.eclipse.birt.core.framework.PlatformServletContext;`
`import org.eclipse.birt.core.framework.IPlatformContext;`
`import  org.eclipse.birt.core.framework.Platform;`
`import org.eclipse.birt.core.exception.BirtException;`
`import org.eclipse.birt.report.engine.api.IReportEngineFactory;`

`public class BirtEngine {`

` private static IReportEngine birtEngine = null;`

` private static Properties configProps = new Properties();`

` private final static String configFile = "BirtConfig.properties";`

` public static synchronized void initBirtConfig() {`
`  loadEngineProps();`
` }`

` public static synchronized IReportEngine getBirtEngine(ServletContext sc) {`
`  if (birtEngine == null)`
`  {`
`   EngineConfig config = new EngineConfig();`
`   if( configProps != null){`
`    String logLevel = configProps.getProperty("logLevel");`
`    Level level = Level.OFF;`
`    if ("SEVERE".equalsIgnoreCase(logLevel))`
`    {`
`     level = Level.SEVERE;`
`    } else if ("WARNING".equalsIgnoreCase(logLevel))`
`    {`
`     level = Level.WARNING;`
`    } else if ("INFO".equalsIgnoreCase(logLevel))`
`    {`
`     level = Level.INFO;`
`    } else if ("CONFIG".equalsIgnoreCase(logLevel))`
`    {`
`     level = Level.CONFIG;`
`    } else if ("FINE".equalsIgnoreCase(logLevel))`
`    {`
`     level = Level.FINE;`
`    } else if ("FINER".equalsIgnoreCase(logLevel))`
`    {`
`     level = Level.FINER;`
`    } else if ("FINEST".equalsIgnoreCase(logLevel))`
`    {`
`     level = Level.FINEST;`
`    } else if ("OFF".equalsIgnoreCase(logLevel))`
`    {`
`     level = Level.OFF;`
`    }`

`    config.setLogConfig(configProps.getProperty("logDirectory"), level);`
` }`

` config.setEngineHome("");`
` IPlatformContext context = new PlatformServletContext( sc );`
` config.setPlatformContext( context );`

` try`
` {`
`  Platform.startup( config );`
` }`
` catch ( BirtException e )`
` {`
`  e.printStackTrace( );`
` }`

` IReportEngineFactory factory = (IReportEngineFactory) Platform`
` .createFactoryObject( IReportEngineFactory.EXTENSION_REPORT_ENGINE_FACTORY );`
` birtEngine = factory.createReportEngine( config );`

`}`
`return birtEngine;`
`}`

`public static synchronized void destroyBirtEngine() {`
`if (birtEngine == null) {`
` return;`
`}`
`birtEngine.shutdown();`
`Platform.shutdown();`
`birtEngine = null;`
`}`

`public Object clone() throws CloneNotSupportedException {`
` throw new CloneNotSupportedException();`
`}`

`private static void loadEngineProps() {`
`try {`
` //Config File must be in classpath`
` ClassLoader cl = Thread.currentThread ().getContextClassLoader();`
` InputStream in = null;`
` in = cl.getResourceAsStream (configFile);`
` configProps.load(in);`
` in.close();`

`} catch (IOException e) {`
` e.printStackTrace();`
`}`

`}`

`}`

**WebReport.java**

`import java.util.HashMap;`
`import java.util.logging.Level;`
`import java.util.logging.Logger;`

`import javax.servlet.ServletContext;`
`import org.apache.pluto.core.impl.PortletContextImpl;`

`import org.eclipse.birt.report.engine.api.EngineConstants;`
`import org.eclipse.birt.report.engine.api.HTMLRenderContext;`
`import org.eclipse.birt.report.engine.api.HTMLRenderOption;`
`import org.eclipse.birt.report.engine.api.IReportRunnable;`
`import org.eclipse.birt.report.engine.api.IRunAndRenderTask;`
`import org.eclipse.birt.report.engine.api.IReportEngine;`

`public class WebReport extends javax.portlet.GenericPortlet {`

`/**`
`*`
`*/`
`private static final long serialVersionUID = 1L;`

`/**`
`* Constructor of the object.`
`*/`
`private IReportEngine birtReportEngine = null;`
`protected static Logger logger = Logger.getLogger( "org.eclipse.birt" );`

`public WebReport() {`
` super();`
`}`

`/**`
`* Destruction of the portlet.`
`*/`
`public void destroy() {`
` super.destroy();`
` BirtEngine.destroyBirtEngine();`
`}`

`public void doView(javax.portlet.RenderRequest req, javax.portlet.RenderResponse resp)`
`               throws javax.portlet.PortletException, java.io.IOException {`
`  resp.setContentType("text/html");`

`   // Name of your report`
`   String reportName = "simple_report.rptdesign";`
`   ServletContext sc = ((PortletContextImpl)req.getPortletSession().getPortletContext()).getServletContext();`
`  this.birtReportEngine = BirtEngine.getBirtEngine(sc);`

`   //setup image directory`
`   HTMLRenderContext renderContext = new HTMLRenderContext();`
`   renderContext.setBaseImageURL(req.getContextPath()+"/images");`
`   renderContext.setImageDirectory(sc.getRealPath("/images"));`

`   logger.log( Level.FINE, "image directory " + sc.getRealPath("/images"));`
`   System.out.println("stdout image directory " + sc.getRealPath("/images"));`

`   HashMap contextMap = new HashMap();`
`   contextMap.put( EngineConstants.APPCONTEXT_HTML_RENDER_CONTEXT, renderContext );`

`   IReportRunnable design;`
`   try`
`   {`
`    //Open report design`
`    design = birtReportEngine.openReportDesign( sc.getRealPath("/Reports")+"/"+reportName );`
`    //create task to run and render report`
`    IRunAndRenderTask task = birtReportEngine.createRunAndRenderTask( design );`
`    task.setAppContext( contextMap );`

`    //set output options`
`    HTMLRenderOption options = new HTMLRenderOption();`
`    options.setOutputFormat(HTMLRenderOption.OUTPUT_FORMAT_HTML);`
`    options.setOutputStream(resp.getPortletOutputStream());`
`    task.setRenderOption(options);`

`    //run report`
`    task.run();`
`    task.close();`
`   }catch (Exception e){`

`    e.printStackTrace();`
`    throw new javax.portlet.PortletException( e );`
`   }`
`}`

`/**`
`* Initialization of the portlet.`
`*`
`* @throws PortletException if an error occure`
`*/`
`public void init() throws javax.portlet.PortletException {`
` BirtEngine.initBirtConfig();`
`}`

`}`

2\. Copy a report design file (e.g simple_report.rptdesign) to
webreport/Reports directory. This is the report which will be deployed
as a portlet. It can be an example report or any report designed
previously. Make sure any dependent jar files (e.g driver jars) required
by the report are copied to webreport/WEB-INF/lib. This report design
file is referred in WebReport.java in the following line:

String reportName = "simple_report.rptdesign";

If using a report file with different name, modify WebReport.java
accordingly.

3\. Build the java classes. To build, add the following to the build
path:

  - All jars from birt-runtime-2_1_1/ReportEngine/lib
  - portlet-api-1.0.jar and pluto-1.0.1.jar from
    $JETSPEED_HOME/shared/lib, where $JETSPEED_HOME is the directory
    where Jetspeed is installed.
  - servlet.jar from the Tomcat Eclipse plug-in

4\. Archive the .class files and BirtConfig.properties into
webreport.jar.

5\. Copy webreport.jar to webreport/WEB-INF/lib directory.

#### Deployment descriptors

1\. Create the file portlet.xml in webreport/WEB-INF directory.

<?xml version="1.0" encoding="UTF-8"?>

<portlet-app id="webreport" version="1.0">
` `<portlet id="WebReport">
`   `<portlet-name>`WebReport`</portlet-name>
`   `<display-name>`Simple portal displaying a BIRT report`</display-name>
`   `<portlet-class>`WebReport`</portlet-class>
`   `<supports>
`     `<mime-type>`text/html`</mime-type>
`     `<portlet-mode>`VIEW`</portlet-mode>
`   `</supports>
`   `<supported-locale>`en`</supported-locale>
`   `<portlet-info>
`     `

<title>

BIRT report

</title>

`     `<short-title>`BIRT report in a portal`</short-title>
`   `</portlet-info>
` `</portlet>
</portlet-app>

2\. Create the file web.xml in webreport/WEB-INF directory.

<?xml version="1.0" encoding="UTF-8"?>

`<!DOCTYPE web-app PUBLIC "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN" "`<http://java.sun.com/dtd/web-app_2_3.dtd>`">`
<web-app>
` `<display-name>`WebReport`</display-name>
` `<description>`BIRT report in a portal`</description>
</web-app>

#### Deployment

1\. Create the WAR file. From the directory WebReport combine the files
into a war file using the command: jar cvf ../webreport.war .

2\. Deploy the WAR file. Copy the war file to
$JETSPEED_HOME/webapps/jetspeed/WEB-INF/deploy. Jetspeed-2 will deploy
the webapp.

3\. Create a PSML file, webreport.psml, and copy it to the
$JETSPEED_HOME/webapps/jetspeed/WEB-INF/pages directory of your
Jetspeed Portal.

<?xml version="1.0" encoding="UTF-8"?>

<page>
` `<defaults
     skin="orange"
     layout-decorator="tigris"
     portlet-decorator="tigris"
  />
` `

<title>

The simplest portlet in the world

</title>

` `<metadata name="title" xml:lang="fr">`La plus simple portlet du monde`</metadata>

` `<fragment id="webreport" type="layout" name="jetspeed-layouts::VelocityTwoColumns">
`   `<fragment id="webreport-1" type="portlet" name="webreport::WebReport">
`     `<property layout="TwoColumns" name="row" value="0" />
`     `<property layout="TwoColumns" name="column" value="0" />
`   `</fragment>
` `</fragment>

` `<security-constraints>
`   `<security-constraints-ref>`public-view`</security-constraints-ref>
` `</security-constraints>
</page>

4\. Test the portlet using
<http://localhost:8080/jetspeed/portal/webreport.psml> in a browser.

## Comments

Please enter comments below by selecting the edit icon to the right. You
will need a Bugzilla account to add comments.

-----

[Category:BIRT](Category:BIRT "wikilink") [Category:BIRT
Example](Category:BIRT_Example "wikilink") [Category:BIRT Example
Integration](Category:BIRT_Example_Integration "wikilink")