## General CVS Information

|                  |                     |          |
| ---------------- | ------------------- | -------- |
| Connection Type  | Committers          | :extssh: |
| Anonymous access | :pserver:           |          |
| Host             | dev.eclipse.org     |          |
| Repository Path  | /cvsroot/technology |          |
|                  |                     |          |

## RSS-SSE RP Test Projects

Main RSS-SSE RP Test project is

|  |
|  |
|  |
|  |
|  |
|  |
|  |

## Build Instructions

  - **Building within Eclipse IDE:**
      - The normal project build method will compile the source
      - How to export a WAR<sup>1</sup> file from a Web project:
          - Right click on a Web project folder and select Export from
            the pop-up menu. Then select WAR file in the Export window
            and then select Next.
          - Specify the Web project you want to export (this field is
            primed if you used the pop-up menu to open the wizard), and
            specify a location for the new WAR file.
          - Optional: Optionally, supply WAR export Options, such as
            whether or not to include Java™ source files in the WAR, and
            whether to overwrite any existing resources during the
            export process. Source files are not usually included in a
            WAR file, because they are not necessary for the server to
            run the web application.
          - Click Finish.

<!-- end list -->

  - **Builds notes:**
      - <sup>1</sup> The Eclipse Web Tools Platform should be installed.
        [More about WTP](http://www.eclipse.org/webtools/main.php).

## See Also

  - [Higgins Home](http://www.eclipse.org/higgins)
  - [Components](Components "wikilink")