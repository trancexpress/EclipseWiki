![Image:eclipse-camp.gif](eclipse-camp.gif "Image:eclipse-camp.gif")
[What is an Eclipse DemoCamp?](Eclipse_DemoCamp "wikilink")

### Location

The Broad Street Cafe, 1116 Broad Street, Durham, NC 27705 A short 10
minute drive from RTP: <http://www.thebroadstreetcafe.com/>

Thank you all for making this a great DemoCamp. We had over 45 people
and 8 excellent demonstrations.

### Date and Time

December 4, 2007 6:00pm to 8:00pm EST

### Organizers

Ginny Ghezzo, IBM Corporation (Want to help? Contact me at: ginnyb at us
dot ibm dot com)

### Presenters

NOTE: We are no longer accepting additional presenters for the 2007 RTP
Eclipse DemoCamp. Presentations will be limited to 8 minutes and
questions\\follow-ups will be encouraged after the demonstrations.

  - Lee Surprenant and Randy Carroll, SODA/Stepstone (a subproject of
    Eclipse OHF)
  - Neil Hauge, Dali JPA Tools (a subproject of Eclipse WTP)
  - Simon Archer, Service Activator Toolkit (a small part of Eclipse
    OHF)
  - Brett Hackleman, Cyrano Sensor Fusion Platform (commercial project
    based on Eclipse, Equinox, SAT, OHF)
  - Ritchie Schacher and Kristen Balhoff, The Jazz Project: Team
    Collaboration Platform, <http://jazz.net/>
  - Larry Isaacs, SAS AppDev Studio Eclipse Plug-ins (commercial product
    based on Eclipse and WTP)
  - Paul VanderLei, Toast: Telematics-on-a-stick (a vehicle telematics
    example application for OSGi/Equinox)
  - Sarah Heckman and Stephen Thomas, AWARE Eclipse Plug-in (automated
    in-process ranking of static analysis alerts)

### Who Is Attending

If you plan on attending please add your name to the list below. We'd
like to see as many people show up as possible.

1.  Ginny Ghezzo, IBM Corporation
2.  David Williams, IBM, Eclipse WTP Project
3.  Lee Surprenant
4.  Randy Carroll
5.  Neil Hauge, Oracle, Eclipse WTP - JPA Tools
6.  Olivier Singla, Signal Innovations Group
7.  Pat Huff, IBM Corporation
8.  Eleni Binopolus Rundle, IBM Corporation
9.  Chris Church, Effician Inc.
10. Brett Hackleman, Band XI International
11. John Cunningham, Band XI International
12. Patrick Dempsey, Band XI International
13. Jim Mickelson, IBM
14. Kristen Balhoff, IBM
15. Larry Isaacs, SAS Institute Inc., Eclipse WTP - Server Tools
16. Simon Archer, Eclipse OHF Committer and OSGi enthusiast
17. Naren, GSK
18. Kristen James Eberlein, Systems Documentation, Inc.
19. Jonathan Rippy
20. Nitin Dahyabhai, IBM Rational, Eclipse WTP - Source Editors
21. Bhanu S Tanty
22. Dean Atchley, Duke
23. Jason Grosland, Duke
24. Scott Pumer, Duke
25. Jim Balhoff, National Evolutionary Synthesis Center
26. Brian Vosburgh, Oracle, Eclipse WTP - JPA Tools
27. Patrick Mueller, IBM WebSphere
28. Ed Savage
29. Samir Jain, Allscripts
30. Owen Astrachan, Duke
31. Paul VanderLei, IBM
32. Andy Smith, IBM
33. Paul Fullbright, Oracle, Eclipse WTP - JPA Tools
34. Stephen Thomas, NCSU
35. Sarah Heckman, NCSU and IBM
36. Ritchie Schacher, IBM Corporation, Rational
37. Dawn Smith, IBM
38. Betsy Plunket, IBM
39. Balaji Krish, IBM
40. Benson Chen, IBM
41. Doug Williams, IBM
42. Valerie Bennett, IBM
43. Stephen Hinton, IBM
44. Jeff Duska
45. Dirk Nicol, IBM
46. David Huff, Red Hat, Release Engineer
47. Peter Dimitrios, IBM
48. Jeanne Hiesel, AHR