Although Buckminster is still an *incubator* project that has yet to
reach its initial release, we intend to freeze our API's at RC0 and only
do bug-fixing from there on until the Europa release.

[Category:Archive Buckminster
Documentation](Category:Archive_Buckminster_Documentation "wikilink")