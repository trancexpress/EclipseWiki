### About

ICE uses jMonkeyEngine v. 3 (jME3) for displaying 3d geometry to the
screen. It is sometimes necessary to replace the binary distribution of
jME3 to get the latest updates or address bugs. Instructions for this
process are presented below. It is expected that the reader is using
Eclipse to replace the bundle and the instructions below reference
several things that only make sense from the Eclipse Workbench.

### Downloading the jME3 jars

  - Download the jME3 jars from the [jME3 community
    site](http://jmonkeyengine.org), preferably a nightly version. The
    nightly versions are available through the *Download* tab on their
    site. Do **not** download the executable SDK; the file that you
    download should be a .zip file.
  - Unzip the jME3 bundle to a directory. The directory should contain
    several folders, but only the lib folder is needed for ICE.

### Prepping ICE

  - Open the gov.ornl.nice.client.eclipse.widgets project and its
    MANIFEST.MF file in the META-INF directory.
  - Navigate to the *Runtime* tab in MANIFEST.mf, and remove all entries
    from the *Classpath* list except for ".". If "." does not exist, do
    not worry about adding it.
  - Create a folder in the gov.ornl.nice.client.eclipse.widgets package
    called deps if one does not already exist.

### Import jME3 libs

  - Import the contents the jME3 lib directory into the
    gov.ornl.nice.client.eclipse.widgets</big>
    </pre>
    project's deps directory using the *File \> Import \> General \>
    File System* mechanism in Eclipse.
  - In the *Classpath* list of the MANIFEST.MF file, click *Add* tab,
    navigate to the deps directory, and add all of the jME3 jars.

### Test, Build and Commit

ICE needs to be fully tested with the new jars. ICE can be launched
using the run configuration in the gov.ornl.nice.client.eclipse.rcp
project and built using the instructions on the [ICE Build
Instructions](ICE_Build_Instructions "wikilink") page.

### A note about updating to jME 3.1 and above

The jMonkeyEngine development team is pushing their native bullet
library, which will replace the jbullet.

If the most recent nightly does not include binary distributions of
their native bullet library, you will need to download the latest
version of jbullet used in jME. Currently, this can be found in the
latest 3.0 stable release.