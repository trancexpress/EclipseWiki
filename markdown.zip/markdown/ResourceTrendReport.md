## Requirement summary

To understand the requirements of this report consider the Java Pet
Store blueprint application. The Java Pet Store is a sample application
that uses J2EE technology to demonstrate . The following figure
illustrates one possible multi tiered network topology that can support
this application:

![Image:net_topology.gif](net_topology.gif "Image:net_topology.gif")

The topology is composed of the following nodes:

  - Client - network node that contains a web browser
  - Web Server - hosts presentation logic
  - Application Server - hosts application logic
  - Database - Relation Database Management Systems and hosts data logic

Consider the following use case. The Pet Shop Store application is
running on the enterprise system and the system administrator wants to
gauge the "health" of the system every morning. To determine the
"health" of the system the system administrator wants to determine the
network throughput for each node, memory utilization and cpu utilization
over time. This trend report will allow the system administrator to
determine the network traffic at certain time of the day. This report
will also determine whether the current system can handle the day to day
loads.

Now consider the case where a specific node in the network is showing
irregular memory utilization. In this case a more detailed report
showing the memory utilization of processes running in the node would
isolate the cause of the irregular memory utilization.

## Design summary

### Data model

The following shows a possible XML data structure that models the
information needed to generate a trend report for the system.

`   `<document>
`       `<node hostName="clientHost">
`           `<data name="throughput" unit="bytes/second">
`                 `<sample time="12939942432" value="2312"/>
`                 .....`
`           `</data>
`           `<data name="cpu utilization" unit="%">
`                 `<sample time="12939942432" value="12"/>
`                 .....`
`           `</data>
`            .....`
`      `</node>
`       .....`
`   `</document>

Similarly a data structure is needed to model monitoring information
from processes running on a particular network node.

`   `<document>
`       `<node hostName="webaserverHost">
`           `<process id="22" name="apache.exe">
`               `<data name="memory utilization " unit="%">
`                     `<sample time="12939942432" value="21"/>
`                     .....`
`               `</data>
`               `<data name="cpu utilization" unit="%">
`                     `<sample time="12939942432" value="12"/>
`                     .....`
`               `</data>
`               .....`
`          `</process>
`          .....`
`      `</node>
`   `</document>

After reviewing the above schema a generic element should model
resources. Instead of modeling <node> or <process> separatly a
<manageElement> element should represent nodes as follows:

`   `<manageElement type="node| process| disk drive"/>

An id attribute should also be associated with the resource to uniquely
identify the resource. Note: a naming convention is needed for the id
attribute. The identifers should be unambigious that can interoperate
with CMS. With these design consideration the schema would look as
follows:

`   `<document>
`       `<manageElement type="node" id="webaserverHost">
`           `<manageElement type="process" id="apache.exe_22">
`               `<data name="memory utilization " unit="%">
`                     `<sample time="12939942432" value="21"/>
`                     .....`
`               `</data>
`               `<data name="cpu utilization" unit="%">
`                     `<sample time="12939942432" value="12"/>
`                     .....`
`               `</data>
`               .....`
`          `</manageElement>
`          .....`
`      `</manageElement>
`   `</document>

### Report mockup

The following shows a report mockup of the trend report for the system.
Notice that the report composes of three charts that shows throughput,
memory usage and cpu usage. A detailed table follows.
![Image:trendsnap.gif](trendsnap.gif "Image:trendsnap.gif")

### Report files

The following zip contains the sample xml file and report template file
used to create this mockup.

  - [Media:TrendReport.zip](Media:TrendReport.zip "wikilink")

[back](CosmosDataReportingComponent "wikilink")