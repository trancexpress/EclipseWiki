This example is [Bugzilla
ID 182208](https://bugs.eclipse.org/bugs/show_bug.cgi?id=182208). If you
would like to contribute an example see the example contribution
guidelines.
\== Introduction == This example illustrates retrieving data from
session.

## BIRT Version Compatibility

Enter the version of BIRT that was used to build the example.

## Example Files

Add a URL to your bugzilla attachment. eg. [Example Report
Zipped](https://bugs.eclipse.org/bugs/attachment.cgi?id=63656)

## Description

This example collects information from the session in the beforeFactory
EventHandler using JavaScript. This information is loaded into a Map.
The Map is then parsed in a Scripted Data Source and the results are
displayed in the report.

**`Before``   ``Factory`**
`// Create a hash table which will contain lists of other lists`
`var topMap = new Packages.java.util.Hashtable();`

`// Request Attributes`
`var request = reportContext.getHttpServletRequest();`
`var requestAttrMap = new Packages.java.util.Hashtable();`
`for (var attrNames = request.getAttributeNames(); attrNames.hasMoreElements(); ) {`
`      var aName = attrNames.nextElement();`
`      requestAttrMap.put(aName, request.getAttribute(aName).toString());`
`}`
`topMap.put("requestAttributes", requestAttrMap);`

`// Request Parameters`
`var requestParamMap = new Packages.java.util.Hashtable();`
`for (var paramIter = request.getParameterMap().entrySet().iterator();`
`     paramIter.hasNext(); ) {`
`      var entry = paramIter.next();`
`      requestParamMap.put(entry.getKey(), (entry.getValue()[0]));`
`}`
`topMap.put("requestParameters",requestParamMap);`

`// Session Attributes`
`var sessionAttrMap = new Packages.java.util.Hashtable();`
`var session = request.getSession();`
`// Insert a variable on the session`
`session.setAttribute("ReportAttribute", "arbitrary value to pass to container");`
`var sessionAttrNames = session.getAttributeNames();`
`var i = 0;`
`while (sessionAttrNames.hasMoreElements()) {`
`      i ++;`
`      var aaa = sessionAttrNames.nextElement();`
`      sessionAttrMap.put(aaa, session.getAttribute(aaa));`
`}`
`topMap.put("sessionAttributes", sessionAttrMap);`

`// Get the system properties`
`topMap.put("systemProps", Packages.java.lang.System.getProperties());`

`// Store top map as a global`
`reportContext.setPersistentGlobalVariable("topMap", topMap);`

**`Open``   ``Script``   ``for``   ``the``   ``Scripted``   ``Data``
 ``Set`**
`aMap = reportContext.getPersistentGlobalVariable("topMap");`
`topIter = aMap.entrySet().iterator();`
`if (topIter == null)`
`{`
`     topIterator = new Packages.java.util.Iterator();`
`     Packages.java.util.logging.Logger.getLogger("").info("OPEN NULL " );`
`}`
`innerIter = null;`

**`Fetch``   ``Script``   ``for``   ``the``   ``Scripted``   ``Data``
 ``Set`**
`while (!innerIter.hasNext())`
`{ // find an innerIter that has a new value`
`      if (innerIter == null || !innerIter.hasNext())`
`      {    // no value in the inner iterator, get the next Hashtable out of the toHashtable`
`             if (topIter.hasNext())`
`             {`
`                   outerObject = topIter.next();`
`                   innerIter = outerObject.getValue().entrySet().iterator();`
`             }`
`             else`
`             { // no more top hash tables. close things up`
`                   return false;`
`             }`
`      }`
`}`

`// we must have another innerIter`
`innerObject = innerIter.next();`

`row["propName"] = innerObject.getKey();`
`row["propValue"] = innerObject.getValue().toString();`
`row["propType"] = outerObject.getKey();`
`return true;`

## Comments

Please enter comments below by selecting the edit icon to the right. You
will need a Bugzilla account to add comments.

-----

[Category:BIRT](Category:BIRT "wikilink") [Category:BIRT
Example](Category:BIRT_Example "wikilink") [Category:BIRT Example
Report](Category:BIRT_Example_Report "wikilink")