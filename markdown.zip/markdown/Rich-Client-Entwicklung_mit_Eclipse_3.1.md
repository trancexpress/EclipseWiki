Book: "Rich-Client-Entwicklung mit Eclipse 3.2"

Authors: Berthold Daum

Publisher: dpunkt.verlag ([Publishers Website](http://www.dpunkt.de/))

Date of publication: November 1st, 2006

Book website: [Book
Website](http://www.dpunkt.de/buecher/3-89864-427-8.html)