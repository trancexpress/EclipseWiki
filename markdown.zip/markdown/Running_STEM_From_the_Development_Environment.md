![Image:STEM TOP BAR.gif](STEM_TOP_BAR.gif "Image:STEM TOP BAR.gif")

**[Back](http://wiki.eclipse.org/Tutorials_for_Developers)**

## To Simply **Run Stem** you do not need to build the application

You can do this from the STEM Eclipse Development Environment.

1.  Go to the package: **org.eclipse.stem.ui**
2.  Open the file **stem.product**
3.  In the editor, Overview tab, click on **Launch an Eclipse
    Application**
4.  This will create a STEM run configuration in your environment. To
    see it go to the Menu Bar.

`  Click Run>Run Configurations...`
`  It will appear on the LHS under `**`Eclipse``   ``Applications`**
`  Give the Configuration a name (like stem.product)`
`  On the RHS click on the Plug-ins Tab`
`   > Click the Add Required Plug-ins button`
`   > Click Validate Plug-ins`
`   > Click Apply`
`   > Click Run`