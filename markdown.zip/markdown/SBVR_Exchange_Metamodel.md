\>\> **[SBVR Home](MDT-SBVR "wikilink")**

# Overview

This page describes the SBVR 1.0 CMOF metamodel that may be used to load
and save XMI files (with '.xmi' extension) compliant with the SBVR
Exchange Document format.

**See also:**

  - [SBVR Tools Metamodel](SBVR_Tools_Metamodel "wikilink")

## Model and Diagrams

The UML and Ecore models for this metamodel are checked into CVS in the
plugin: **org.eclipse.sbvr.xmi**.

  - Based on the [SBVR CMOF
    model](http://www.omg.org/spec/SBVR/20070901/SBVR-model.xml) as
    published with the OMG specification

Class diagrams created from the original SBVR 1.0 metamodel
specification:

  - [conceptual schema and fact model
    diagram](Media:SBVR_conceptual-schema.gif "wikilink") --
    Associations between **conceptual schema** and **fact model**
  - [concept representation
    diagram](Media:SBVR_concept-representation.gif "wikilink") -- Subset
    of associations between **concept**, **representation**, and
    **designation**
  - [set diagram](Media:SBVR_set.gif "wikilink") -- Subclasses of
    **set** and their associations
  - [terminological dictionary
    diagram](Media:SBVR_dictionary.gif "wikilink") -- Associations
    between **terminological dictionary**, **vocabulary**, and **body of
    shared meanings**

General observations about the SBVR CMOF model from the specification:

  - SBVR is defined in terms of SBVR language
      - the CMOF metamodel is generated from the SBVR language
      - the CMOF model in the specification was not created or edited
        using a UML modeling tool
  - There is **no** use of composite aggregation anywhere in the model
  - All associations own both property ends and none are navigable from
    the end classes.

# Issues

The following issues were discovered while implementing the SBVR CMOF
serialization metamodel.

### Issue 1: designation::signifier

Class diagram created from the original SBVR 1.0 metamodel
specification:

  - [concept representation
    diagram](Media:SBVR_concept-representation.gif "wikilink") -- Shows
    a subset of associations between **concept**, **representation**,
    and **designation**.

**representation::expression** has multiplicity \[1..1\] and is thus
required in all specializations. The SBVR 1.0 specification indicates
that **designation::signifier** {subsets expression}, but the {subsets}
reference is not included in the CMOF model. Without the subsets
reference, the designation subclass will require values for both
expression and signifier.

  - Change **designation::signifier** to add **{subsets expression}**

The specification also shows that **designation::signifier** has
multiplicity \[1..1\], but it is \[0..\*\] in the CMOF model. This
expanded multiplicity is also incompatible with use of {subsets}.

  - Change **designation::signifier** multiplicity to \[1..1\]

### Issue 2:

### Issue 3:

# Resolutions

Track the resolution of issues by OMG SBVR revision task force
committee.

[Category:Modeling](Category:Modeling "wikilink")
[Category:MDT](Category:MDT "wikilink")
[Category:SBVR](Category:SBVR "wikilink")