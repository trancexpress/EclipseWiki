←[Back to SQL Dev Main Page](SQL_Development_Tools "wikilink")

### The following features are committed for SQL Dev Tools Callisto:

#### JUnit Tests

<PMC>Add JUnit tests to SQL Dev</PMC>

#### SQL Editor Framework

  - **Toggle comment**
      - Requirement: Add context menu in SQL Editor to toggle sql
        statement comment
      - Development Estimate: 2 days
      - Possible Start Date: May 15
      - API Impacts: None
      - UI Impacts: None.

#### SQL Results View

  - **Add some methods to support WTP Outputview's current consumers**
      - Requirement: Currently, WTP Output view's current consumers need
        some extra APIs which are not contained in current SQL Results
        View's API, we need to support some of them to lessen the
        refactoring effort of Output view's consumers
      - Development Estimate: 6\~9 days
      - Possible Start Date: April 10
      - API Impacts:
        org.eclipse.datatools.sqltools.result.ResultsViewAPI

### The following features are *under consideration* for SQL Dev Tools Callisto:

#### SQL Editor Framework

  - **Add preferences pages**
      - Requirement: Allow user to config SQL Dev Tools including
          - sql execution preference page: whether to continue when
            error occurs during sql execution
          - SQL Editor preference page: show affordance in hover on how
            to make it sticky
          - SQL template preference page: create, edit or remove
            templates
      - Development Estimate: 2 weeks
      - Possible Start Date: April 17
      - API Impacts: None
      - UI Impacts: None.

<PMC>This seems to have UI impact.</PMC>

  - **Templates**
      - Requirement: make code template available in content assist add
        context menu in SQL Editor to "Save as template..."
      - Development Estimate: 1 week
      - Possible Start Date: May 8
      - API Impacts: None
      - UI Impacts: None.

<!-- end list -->

  - **Toolbar**
      - Requirement: show some of the most frequently used sql editor
        context menu to the toolbar, which is requested by Jeff in bug:
        81036
      - Development Estimate: 3 days
      - Possible Start Date: May 24
      - API Impacts: None
      - UI Impacts: None.

<PMC>This seems to have UI impact.</PMC>

#### SQL Results View

  - **Add "Save History..." context menu in for script history**
      - Requirement: Save the history into a external file which
        include: script, messages, parameters, results.
      - Development Estimate: 1 day
      - Possible Start Date: Post April 9
      - API Impacts: None