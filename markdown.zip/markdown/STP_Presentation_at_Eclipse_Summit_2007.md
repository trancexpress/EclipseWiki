This is the presentation delivered by Adrian Skehill at the Eclipse
Summit in Germany, 2007.

<http://wiki.eclipse.org/images/5/55/Eclipse_summit2007.pdf>