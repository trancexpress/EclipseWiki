<table border='1' cellpadding='3'>

<tr>

<td>

[Eclipse Home](http://www.eclipse.org/corona)

</td>

<td>

[Wiki Home](Corona "wikilink")

</td>

<td>

[Demo EclipseWorld](Demo "wikilink")

</td>

</tr>

</table>

-----

## Demo EclipseWorld: Script

The theme for the collaboration demo is based upon a *Project* context.
Two Eclipse Workbench clients collaborating on changes to a common
resouce.

1.  Start the first Eclipse Workbench (WB-1)
2.  Use the *ProjectContainerExplorer* to show the list of locally known
    *ProjectContaines*(s)
3.  Selects the *ProjectContainer* named **Demo**
    1.  The *ProjectContainerView* is launched and its
        *ProjectContainerView-Pages* are initialized
    2.  A ''ProjectEvent is published indicating that a
        *ProjectContainer* has been opened''
        1.  The *Collaboration Server* receives the *ProjectEvent* and
            creates the ECF chat room for the *ProjectContainer*
4.  Start the second Eclipse Workbench (WB-2)
5.  Use the *ProjectContainerExplorer* to show the list of locally known
    *ProjectContaines*(s)
6.  Selects the *ProjectContainer* named **Demo**
    1.  The *ProjectContainerView* is launched and its
        *ProjectContainerView-Pages* are initialized
    2.  A ''ProjectEvent is published indicating that a
        *ProjectContainer* has been opened''
        1.  WB-1 receives the *ProjectEvent*
7.  WB-1 updates local resource
    1.  A *ProjectEvent* is published notifying the Workgroup that a
        common resource has been modified
        1.  WB-2 receives the *ProjectEvent* indicating that common
            resource has been modified
8.  WB-2 posts a comment to the *ProjectContainer*'s chat room inquiring
    about the changed resource
9.  WB-1 and WB-2 collaborate on modifying the shared resource
    1.  use ECF chat room
    2.  use ECF shared editor
10. WB-1 finishes updates to common resource
    1.  Shared resource is commited to CVS
    2.  *ProjectEvent* is published notifying workgroup of synch event
11. WB-2 receives *ProjectEvent* re: synch event
    1.  WB-2 performs a CVS team synchronize