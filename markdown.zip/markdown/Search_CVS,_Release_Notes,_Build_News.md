So you want to implement Search CVS, generate your Release Notes from
that database, and provide a ticker listing builds released on your
homepage?

Well, here's how to do that.

## Setup Search CVS Tool

Read this: [Search CVS Setup](Search_CVS#Setup "wikilink"). You might
also like [the database
schema](http://build.eclipse.org/modeling/build/schema.php).

That'll get you a database with search CVS data, but no releases (an
empty table). To get Release data, you need to publish [RSS
feeds](Eclipse_Build_Available_RSS_Feeds_Getting_Started "wikilink") for
your project(s).

## Ensure Regular Updates

The second part is to ensure that updates are done regularly. I've got a
cron running that looks like this:

`00 04,20 * * * /shared/modeling/searchcvs/parsecvs.sh 2>&1 1> /shared/modeling/searchcvs/parsecvs_cron.log.txt`

Updating the entire database takes about two hours for the projects
listed in the
[setup.sh](http://dev.eclipse.org/viewcvs/index.cgi/org.eclipse.releng.basebuilder/plugins/org.eclipse.build.tools/scripts_cvs/searchcvs/setup.sh?revision=1.1.2.8&view=markup&pathrev=releng_test)
script.

## Restricted Access (Read-Write)

  - [promoteToEclipse.sh](http://dev.eclipse.org/viewcvs/indextools.cgi/emf-home/emf-build/scripts/promoteToEclipse.sh?view=markup)
    is used to, among other things, publish the [RSS
    feed](Eclipse_Build_Available_RSS_Schema "wikilink") (look for `if [
    "$RSS" -eq 1 ]; then`) and kick an update of the [Search
    CVS](Search_CVS "wikilink") database (look for `if
    [[$searchCVS_-eq_1|$searchCVS -eq 1]]; then`). [RSS
    feeds](Eclipse_Build_Available_RSS_Feeds_Getting_Started "wikilink")
    are used to generate release information for the Release Notes and
    Build News.

<!-- end list -->

  - A web interface to [kick an update to the
    database](http://build.eclipse.org/modeling/build/updateSearchCVS.php)
    (as used in the above script). This isn't restricted yet since too
    many updates don't cause any problems except to slow down those
    updates.

<!-- end list -->

  - A web interface to allow authorized users to [remove a
    release](http://build.eclipse.org/modeling/mdt/build/removeRelease.php)
    from the releases table. The removed release must ALSO be removed
    manually from the RSS feed or it will be added back after the next
    database refresh. In theory, this tool should never be needed.

## Public Web Access (Read-Only)

Accessing the database is done in several ways:

  - [Search CVS](http://www.eclipse.org/modeling/mdt/searchcvs.php)
  - [Release
    Notes](http://www.eclipse.org/modeling/mdt/news/relnotes.php)
  - [Build News](http://www.eclipse.org/modeling/mdt/) (see "Build News"
    sidebar box; also [Older build
    news](http://www.eclipse.org/modeling/mdt/news-whatsnew.php#build))

Additionally, the database has been extended to include data for these
applications:

  - [Download
    Stats](http://www.eclipse.org/modeling/emf/downloads/stats.php)
  - [Meet The Modeling Team](http://www.eclipse.org/modeling/team/)

## See Also

  - [Search CVS](Search_CVS "wikilink")
  - [Modeling database
    schema](http://build.eclipse.org/modeling/build/schema.php)

[Category:Releng](Category:Releng "wikilink")
[Category:RSS](Category:RSS "wikilink")
[Category:Modeling](Category:Modeling "wikilink")