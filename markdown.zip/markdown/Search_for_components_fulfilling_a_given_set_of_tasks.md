It is possible to describe a component in terms of the “tasks” it
carries out. Let’s suppose - just as an example - a developer is using
two components in his/her application, one for “dom-parsing” and the
other for “sax-parsing”, and he/she was not on earth in the last years
and I want to know if there exists a single component doing the two
things.

![Image:Search-union-tasks.png](Search-union-tasks.png
"Image:Search-union-tasks.png")

Selecting the two components and clicking the proper context menu item,
the application shows that Xerces-j
[1](http://xerces.apache.org/xerces-j/) actually accomplishes both the
task needed, and the developer might decide to use it to reduce the
number of dependencies needed by the application.

![Image:Tasks-union.png](Tasks-union.png "Image:Tasks-union.png")