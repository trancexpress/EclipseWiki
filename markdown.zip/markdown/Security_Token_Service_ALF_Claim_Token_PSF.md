The following is an Eclipse Team Project Set for committers (See [Using
This PSF](Using_This_PSF "wikilink"))

    <?xml version="1.0" encoding="UTF-8"?>
    <psf version="2.0">
            <provider id="org.eclipse.team.cvs.core.cvsnature">
                    <project reference="1.0,:extssh:dev.eclipse.org:/cvsroot/technology,org.eclipse.higgins/plugins/org.eclipse.higgins.sts.server.token.alf,org.eclipse.higgins.sts.server.token.alf"/>
            </provider>
    </psf>

The following is an Eclipse Team Project Set for anonymous access (See
[Using This PSF](Using_This_PSF "wikilink"))

    <?xml version="1.0" encoding="UTF-8"?>
    <psf version="2.0">
            <provider id="org.eclipse.team.cvs.core.cvsnature">
                    <project reference="1.0,:pserver:dev.eclipse.org:/cvsroot/technology,org.eclipse.higgins/plugins/org.eclipse.higgins.sts.server.token.alf,org.eclipse.higgins.sts.server.token.alf"/>
            </provider>
    </psf>

## See Also

  - [Higgins Home](http://www.eclipse.org/higgins)
  - [Components](Components "wikilink")