## General CVS Information

|                 |                     |       |
| --------------- | ------------------- | ----- |
| Connection Type | Committers          | :ext: |
| Anon access     | :pserver:           |       |
| Host            | dev.eclipse.org     |       |
| Repository Path | /cvsroot/technology |       |
|                 |                     |       |

## Security Token Service Projects

The STS consists of multiple projects, each is held in a different CVS
module. Since building and running the STS requires a large set of
dependent projects, we provide Project Set files that include all
projects necessary to build and run the STS.

|  |
|  |
|  |
|  |
|  |
|  |
|  |

## Build Instructions

  - Building within Eclipse:
      - The normal project build method will compile the source
      - How to produce a standalone jar:
          - In Eclipse, do this:
              - Window, Show View, Ant. An ant browser appears.
              - Right-Click, Add Buildfiles..., browse to the buildfile
                (build.xml) you want to add and select it.
              - Expand the build file to expose the jar target.
              - Double-click the jar target to build the jar.
      - How to produce javadoc:
          - Follow the instructions above to add the ant buildfile to
            the ant browser
          - Double-click the javadoc target.
      - How to produce an Eclipse plugin:
          - Follow the instructions above to add the ant buildfile to
            the ant browser
          - Right-Click the plugin target, Run As, 2 Ant Build..., go to
            JRE tab.
          - Make sure that you either choose "Run in the same JRE as the
            workspace" option or provide
            "-DECLIPSE_HOME=<path to eclipse installation>" VM
            argument.
          - Click Run.
  - Command-line build
      - How to produce an Eclipse plugin:
          - From the project directory, run "ant plugin
            -DECLIPSE_HOME=<path to eclipse installation>"
          - Note that this requires an Eclipse installation
      - How to produce a standalone jar file:
          - From the project directory, run "ant jar"<sup>1</sup>.
      - How to produce javadoc:
          - From the project directory, run "ant javadoc"<sup>1</sup>.

<!-- end list -->

  - **Builds notes:**
      - <sup>1</sup> In order to process plugin specific files you will
        need to add "-DECLIPSE_HOME=<path to eclipse installation>"
        option to the command line.

## See Also

  - [Higgins Home](http://www.eclipse.org/higgins)
  - [Components](Components "wikilink")