As specified in [issue
\#4427](http://issues.hudson-ci.org/browse/HUDSON-4427), Hudson should
report which items fail to load. This may be annoying especially if you
run a Hudson instance with a lot of jobs after updating some plugins
which are not backwards compatible.

If Hudson loads the jobs in parallel it is not able to show the names of
the offending jobs right now. A workaround is to disable parallel job
loading by specifying -Dhudson.model.Hudson.parallelLoad=false on the
command line when starting Hudson (See
[Hudson.java](http://fisheye.hudson-ci.org/browse/hudson/trunk/hudson/main/core/src/main/java/hudson/model/Hudson.java?r=21549#l3373)
or [the page about system
properties](http://wiki.hudson-ci.org/display/HUDSON/Features+controlled+by+system+properties)
for the specifics).

This will force Hudson to use the code in
[line 2008](http://fisheye.hudson-ci.org/browse/hudson/trunk/hudson/main/core/src/main/java/hudson/model/Hudson.java?r=21549#l2008)
instead.