![Eclipse_survey2017.png](Eclipse_survey2017.png
"Eclipse_survey2017.png")

Take the survey here: [Eclipse
Survey 2017](https://www.surveymonkey.com/r/DevoxxFR)