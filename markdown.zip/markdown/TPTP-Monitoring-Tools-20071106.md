## Attendees

  - Present:
      - Alex Nan
      - Yasuhisa Gotoh
      - Richard Yun Song Huang
      - Rohit Shetty
  - Absent:
      - Hariharan Narayanan - on vacation

## 4.4.1

  - Rohit checked in the fix for
    [202983](https://bugs.eclipse.org/bugs/show_bug.cgi?id=202983)
  - Alex fixed
    [205837](https://bugs.eclipse.org/bugs/show_bug.cgi?id=205837)
  - added readme entry
    [207044](https://bugs.eclipse.org/bugs/show_bug.cgi?id=207044) for
    the problem investigated in
    [202715](https://bugs.eclipse.org/bugs/show_bug.cgi?id=202715)
  - Alex hasn't finished
    [206665](https://bugs.eclipse.org/bugs/show_bug.cgi?id=206665) yet
  - assigned
    [206260](https://bugs.eclipse.org/bugs/show_bug.cgi?id=206260) to
    Rohit

## 4.5

  - 4.5 i3 TP1 finished
  - still an outstanding test suite to run Monitor.UI.Common.Services
  - some of the BTM test results were not checked into CVS yet
  - iteration numbers have shifted out by 2 to align with the Eclipse
    Ganymede milestone numbers
      - Alex has updated i2 and i3 targetted defects to i4 and i5
  - work in progress on
    [207240](https://bugs.eclipse.org/bugs/show_bug.cgi?id=207240)
  - work in progress on
    [208586](https://bugs.eclipse.org/bugs/show_bug.cgi?id=208586)
  - in TP2 we will run only a smoke test since no defects were fixed in
    TP1
  - in the remaining spare time to try finishing the test case
    automation work
      - [207251](https://bugs.eclipse.org/bugs/show_bug.cgi?id=207251)
      - [207253](https://bugs.eclipse.org/bugs/show_bug.cgi?id=207253)
      - [207251](https://bugs.eclipse.org/bugs/show_bug.cgi?id=207251)
      - [207255](https://bugs.eclipse.org/bugs/show_bug.cgi?id=207255)
  - new defects have been opened by Marius to track the work for the
    features
    [200138](https://bugs.eclipse.org/bugs/show_bug.cgi?id=200138),
    [200139](https://bugs.eclipse.org/bugs/show_bug.cgi?id=200139)
  - new defects have been opened, reported by a consuming product:
      - [207763](https://bugs.eclipse.org/bugs/show_bug.cgi?id=207763)
      - [207806](https://bugs.eclipse.org/bugs/show_bug.cgi?id=207806)
      - could be potential 4.4.1 candidates
      - consuming product will likely request a patch on TPTP4.2.2
  - after TP2 the focus should be on reducing the backlog of defects and
    feature work

## Action items

  - Richard to check in the remaining BTM test results
  - Rohit to fix
    [206260](https://bugs.eclipse.org/bugs/show_bug.cgi?id=206260) as
    soon as possible
  - Alex to finish
    [206665](https://bugs.eclipse.org/bugs/show_bug.cgi?id=206665) as
    soon as possible
  - Alex in collaboration with Joel and Samson to finish
    [208586](https://bugs.eclipse.org/bugs/show_bug.cgi?id=208586)
  - Alex to define the smoke test content (at the time these notes are
    written this is already done)
  - Alex (with Marius) to finish work on
    [207240](https://bugs.eclipse.org/bugs/show_bug.cgi?id=207240)
  - finish TP2 by Friday November 9, 2007 (worse case by Tuesday
    November 13, 2007)