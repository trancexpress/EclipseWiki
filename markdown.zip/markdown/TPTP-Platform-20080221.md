<h1>

Attendees:

</h1>

  - DuWayne Morris
  - Paul Slauenwhite
  - Alex
  - Bing
  - Kiryl
  - Stanislav
  - Alexander
  - Eugene
  - Joel
  - Jonathan
  - Mikhail
  - Ritwik
  - Alan
  - Joanna

<h1>

Minutes:

</h1>

  - IPv6 Discussion:

<!-- end list -->

  - DuWayne shared his experience in testing the TPTP Test subproject:

<!-- end list -->

  - Environment is fully IPv6; address that comes back is IPv4
  - Vista has IPv6 by default
  - Windows has both protocol stacks operating simultaneously
  - IPv6 supports IPv4 but there are still differences in behaviour
    because both protocols are up and running
  - used Firefox, SOCKS 5 proxy
  - used IPv6 hardcoded IP address
  - did not test on Linux but believes it is the case that both protocol
    stacks are installed. Volunteered to test on RedHat over the next
    couple of days.
  - if you are using IPv4 to get higher traffic you may want to keep
    using that rather than wrapping it in IPv6 protocol (IPv6 can handle
    IPv4 traffic it is just not as efficient at doing so)
  - tested on Java 5 (IPv6 supported in Java 5)
  - nothing configured in Java in order to do the recording. There was
    an environment variable that was set that says I prefer IPv6 (by
    default Java prefers IPv4)
  - recommends watching for parsing of literal strings to determine
    address of URL for example
  - In his tests, the AC was using IPv4 (record what the appl wants us
    to record so have SOCKS 5 up and running - if appl connected with
    IPv6 address it will be honoured)

<li>

Stanislav has reviewed the AC code and has noted changes needed for
IPv6. Would like IBM to investigate channel support

</li>

<li>

Mikhail believes IPv6 change will affect all models (look through all
the code where we are dealing with connections)

</li>

<li>

Intel to look into what is needed in JVMTI to support IPv6 and provide a
sizing

</li>

<li>

All IPv6 changes are to be sized and added to bugzilla

</li>

<li>

launch configuration in the workbench - what is needed for IPv6 support?
Needs to be investigated

</li>

</ul>

<li>

4.4.1:

</li>

  - Testing needs to be completed by eod Friday Feb 22

<li>

4.5:

</li>

  - Changes can be checked into Head now
  - any outstanding tests need to be completed

</ul>