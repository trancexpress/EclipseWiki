<h1>

Attendees:

</h1>

  - Stanislav
  - Alexander
  - Eugene
  - Jonathan
  - Joanna
  - Paul
  - Alan

<h1>

Minutes:

</h1>

  - Discussion re enhancement 165409. Jonathan appended a document to
    the enhancement recommending a number of development stages. This
    meeting is to review and discuss the proposal. Jonathan's
    recommendation is that we make the smaller changes first (for
    example, IPv4 to IPv6 translation - socket API) and then in the
    later stages handle the larger changes to the Agent Controller such
    as adding XML and Hyades commands.

  - The following is a summary of the discussion:

  -   - Stage 1:

    <!-- end list -->

      - discuss the needed changes - today's mtg; further discussion can
        be done in the bugzilla
      - discuss potential build changes. Jonathan thought that Visual
        Studio 2003 may be needed if we are using Visual C++ v6
        libraries. Intel believes that build should not be an issue
        because the Intel build uses Platform SDK from Microsoft that is
        targeted to 2003 and it contains IPv6 support (Kiryl to confirm)

  - Stage 2:

<!-- end list -->

  - deploy build changes (if needed) and then smoke test the AC (again
    if build changes were needed)
  - Rewrite native/Java socket code so that both IPv4 and IPv6 are
    supported (e.g. using sockaddr_storage rather than sockaddr_in).
    Should result in working AC that uses the new socket code.
  - determine the particular network configurations that we need to
    support; do we need additional routers etc.
  - investigate larger changes as well as UI changes (e.g. changes to
    code logic, rather than merely changes to code form. For instance,
    adding additional XML commands to support changed IP address
    formats, updating existing XML commands, adding additional Hyades
    commands to the Hyades protocol to support IP addresses of more than
    4 byte, etc.). These larger changes would be made in Stage 4.

<li>

Stage 3:

</li>

  - testing and deployment: test the socket code with IPv4 to make sure
    it still works

<li>

Stage 4:

</li>

  - complete the larger code changes identified in Stage 2
  - At the end of this stage IPv6 code changes should be complete.

<li>

Stage 5:

</li>

  - complete testing of IPv4 and IPv6 on Windows and Linux

<li>

Refer to Jonathan's document in the bugzilla for a more detailed
description of the development stages.

</li>

</ul>

<li>

Reviewed the division of work between IBM and Intel:

</li>

  - Jonathan to complete 221258 and then begin work on this enhancement
  - Stanislav to complete 201412 and 196713 and then begin working on
    this enhancement (Stanislav to check with Jonathan on enhancement
    status before beginning IPv6 work)
  - Eugene to complete 80440 and critical i6 defects before beginning
    work on this enhancement.

</ul>