## Attendees

  - Present:
      - Paul Slauenwhite
      - DuWayne Morris
      - Tony Wang
      - Jerome Bozier

## 4.5

### Release Information

  - 4.5 will ship with the Ganymede Simultaneous Release (target release
    date: June 30, 2008).

<!-- end list -->

  - [Detailed
    Schedule.](http://www.eclipse.org/tptp/home/project_info/releaseinfo/4.5/schedule.html)

<!-- end list -->

  - [Defect
    queries.](http://www.eclipse.org/tptp/reports/bugs/report_45.php?src=All&queryType=bugs&component=All)

<!-- end list -->

  - [Download.](http://www.eclipse.org/tptp/home/downloads/?ver=4.5)

<!-- end list -->

  - [Test
    reports.](http://www.eclipse.org/tptp/reports/test/testpass_45.php?source=All)

### Where are we at?

  - This week is I7 TP2 (target: May 2).

### Testing

  - We need to complete I7 TP1 by EOD today using the [candidate
    driver](http://www.eclipse.org/tptp/home/downloads/?buildId=TPTP-4.5.0-200804240100).
  - For I7 TP2, Tony will continue running the smoke test suites for the
    resolved blocking defects.
      -   - Paul, Jerome, and Duwayne will continue resolving the
            defects blocking the I7 TPs.

#### 4.5 I7 TP1

  - TP1 testing assignments:
      - Manual:
          - Tony:
              - /org.eclipse.hyades.test.java.tests/manual/regressionTests/Test.Execution.JUnitPluginRunner.testsuite
              - /org.eclipse.hyades.test.ui.navigator.tests/manual/Test.UI.TestNavigator_bugzilla_225157.testsuite
              - /org.eclipse.hyades.test.ui.datapool.tests/manual/datapool/Test.UI.EncryptedDatapool_editing.testsuite
          - Paul:
              - /org.eclipse.tptp.test.doc.user/manual/Doc/Test.Doc.smoke.testsuite
          - Duwayne:
              - /org.eclipse.hyades.test.URLTest.tests/manual/basic_tests/Test.UI.URLTest.Windows.testsuite
              - /org.eclipse.hyades.test.URLTest.tests/manual/basic_tests/Test.UI.URLTest.Linux.testsuite
              - /org.eclipse.hyades.test.URLTest.tests/manual/basic_tests/Test.Execution.URLRunner.Remote.testsuite
      - JUnit:
          - Tony:
              - /org.eclipse.tptp.test.testservices.tests/junit/Test.DatapoolPasswordServicesTest.testsuite
      - AGR:
          - Tony:
              - /org.eclipse.hyades.test.java.tests/autoui/Test.Execution.IBM16_JUnitRunner.testsuite
              - /org.eclipse.hyades.test.java.tests/autoui/Test.Execution.Sun16_JUnitRunner.testsuite
              - /org.eclipse.hyades.test.java.tests/autoui/Test.Execution.IBM142_JUnitRunner.testsuite
              - /org.eclipse.hyades.test.java.tests/autoui/Test.Execution.IBM15_JUnitRunner.testsuite
              - /org.eclipse.hyades.test.java.tests/autoui/Test.Execution.Sun142_JUnitRunner.testsuite
              - /org.eclipse.hyades.test.java.tests/autoui/Test.Execution.Sun15_JUnitRunner.testsuite
              - /org.eclipse.hyades.test.java.tests/autoui/Test.Execution.JUnitRunner.Bug186196.testsuite
              - /org.eclipse.hyades.test.ui.datapool.tests/gui/Test.UI.EncryptedDatapoolEditor.testsuite

### News Group

  - The following news group posts require a reply:
      - Duwayne:
          - Re: Using wait command in AGR script (March 11, 2008 2:07
            PM)
          - Re: HTTP Recording stops immediately after start-up
            (FireFox) or never records data (IE) (March 25, 2008 1:15
            PM)
          - tptp execuation task issue (April 2, 2008 3:12 PM)
          - Multi-Language tests with AGR (April 7, 2008 3:11 PM)
          - Testing an application with Custom component (April 8, 2008
            11:03 AM)
          - Re: NoClassDefFoundError: org.eclipse.hyades.test.common...?
            (April 10, 2008 5:33 PM)

### Test Automation Initiative

  - Paul and the Release Engineering Team are working on consolidating
    our testing process and automation infrastructure:
      - For more information, see the [WIKI
        page](http://wiki.eclipse.org/4.5_Test_Automation_Initiative).
      - To see the BVT results for a specific build, open the [Build
        Reports](http://www.eclipse.org/tptp/home/downloads/?ver=4.5.0)
        page for a specific build and select [BVT
        Results](http://download.eclipse.org/tptp/4.5.0/dev/TPTP-4.5.0-200802210400/BVT).
      - Outstanding defect against the Platform Project include:
          - [Execution of any testsuite fails using the IAC -
            InactiveProcessException](https://bugs.eclipse.org/bugs/show_bug.cgi?id=222382)
      - Outstanding defect against the Test Project include:
          - Paul:
              - [JUnit Plug-in runner incorrectly modifies deployed
                plugin.xml
                files.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=229931)
              - [AGR Tests require absolute path to Equinox
                JAR](https://bugs.eclipse.org/bugs/show_bug.cgi?id=222759)
              - [Clear remote workspace launch does not work for remote
                test
                execution](https://bugs.eclipse.org/bugs/show_bug.cgi?id=222760)
              - [AGR Tests cannot be run with start
                ACServer](https://bugs.eclipse.org/bugs/show_bug.cgi?id=222761)
              - [Remove XMLUnit dependency and convert reporting tests
                to TPTP
                tests](https://bugs.eclipse.org/bugs/show_bug.cgi?id=211476)
              - [Content missing in Tabular
                Report](https://bugs.eclipse.org/bugs/show_bug.cgi?id=215078)
              - [Connection property does not deploy all
                dependencies](https://bugs.eclipse.org/bugs/show_bug.cgi?id=220390)
              - [Connection property does not allow JUnit Plug-in Tests
                to be
                executed](https://bugs.eclipse.org/bugs/show_bug.cgi?id=220391)
          - Duwayne:
              - [ASF marshalling return value between service and client
                adapter does not have support for failures /
                exceptions](https://bugs.eclipse.org/bugs/show_bug.cgi?id=194503)
              - [Confusing exceptions when running automated
                services.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=217487)
              - [ASF Test Execution Service races with AutoBuildJob --
                can lead to unexpected test
                results](https://bugs.eclipse.org/bugs/show_bug.cgi?id=200194)
              - [ANT test results property requires trailing slash to
                specify
                location](https://bugs.eclipse.org/bugs/show_bug.cgi?id=210289)
              - [ANT importExistingProjects throws
                Exception](https://bugs.eclipse.org/bugs/show_bug.cgi?id=210292)

### Enhancements

  - [Queries.](http://www.eclipse.org/tptp/reports/bugs/report_45.php?src=All&queryType=enh&component=Test)
  - [Schedule.](http://wiki.eclipse.org/TPTP_45_Weekly_Schedule)

<!-- end list -->

  - Jerome:
      - [Move, Copy, Delete, Rename and Import/Export test
        assets](https://bugs.eclipse.org/bugs/show_bug.cgi?id=166025):
        Complete.

<!-- end list -->

  - Alexander Nyßen:
      - [Providing the ability to record user's interactions with GEF
        objects in a GEF
        editor](https://bugs.eclipse.org/bugs/show_bug.cgi?id=133099):
        Alexander (TPTP user and contributor) has contributed a patch
        and documentation for basic GEF/Draw2D support in the AGR.
        AG/PMC approved and Contribution Questionnaire (CQ) approved.
        Deferred to I8 for integration and testing.

### Defects

  - [Queries.](http://www.eclipse.org/tptp/reports/bugs/report_45.php?src=All&queryType=bugs&component=Test)

<!-- end list -->

  - [Schedule](http://wiki.eclipse.org/TPTP_45_Weekly_Schedule).

<!-- end list -->

  - Defects blocking the I7 TPs:
      - Paul:
          - [Failures in
            /org.eclipse.hyades.test.ui.datapool.tests/junit/datapool/Test.UI.EncryptedDatapoolEditor_running.testsuite.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228227):
            Attempting to complete in I7.
          - [datapool creation does not work properly if first row of
            CSV file contains variable
            name](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228989):
            Attempting to complete in I7.
              - [Cannot import valid CSV file into
                datapool.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228923):
                Attempting to complete in I7.
          - [Context sensitive help requires refactoring and new
            content.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=200586):
            Requires the below defects. Attempting to complete in I7.
              - [Technical review of Test Project documentation
                before 4.5
                release.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=213622):
                Attempting to complete in I7.
              - [Fix spelling/broken links/accessibility errors in JUnit
                Plugin/Manual Test/BIRT Reports
                plug-ins.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=220875):
                Attempting to complete in I7.
              - [Documentation smoke test
                failures.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228253):
                Attempting to complete in I7.
      - Duwayne:
          - [Parallel agent startup errors,
            InactiveProcessException](https://bugs.eclipse.org/bugs/show_bug.cgi?id=229134):
            Attempting to complete in I7.
          - [Random intermitten errors while launching a test against
            remote
            agents](https://bugs.eclipse.org/bugs/show_bug.cgi?id=229189):
            Attempting to complete in I7.
          - [Regression, URL Test Does Not Get
            Generated](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228747):
            Attempting to complete in I7.
          - [SSL Recording not working,
            regression](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228914):
            Attempting to complete in I7.
          - [Exception when canceling a recording (before "recording
            "actually
            starts)](https://bugs.eclipse.org/bugs/show_bug.cgi?id=59905):
            Attempting to complete in I7.
          - [Cannot remove a test invocation to a removed HTTP
            request.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=201896):
            Patch is attached for one symptom (single test invocation),
            but solution for symptom with multiple test invocations is
            outstanding. Duwayne will attempt to complete in I7 but he
            needs more time to determine the root cause.
      - Jerome:
          - [Test Navigator link to editor doesn't work when multiple
            editors open on file mapping to same proxy
            node.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=229546):
            Attempting to complete in I7.
          - [Refactoring error on attempt to Delete multiple Results
            from TN
            view.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=229430):
            Attempting to complete in I7.
          - [Deletion of Result from Test Navigator view
            fails.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=229435):
            Attempting to complete in I7.
          - [persisted proxy fail to
            load](https://bugs.eclipse.org/bugs/show_bug.cgi?id=229248):
            Attempting to complete in I7.
          - [Unable to create proxy for
            testsuite](https://bugs.eclipse.org/bugs/show_bug.cgi?id=227769):
            Attempting to complete in I7.
          - [Impossible to copy/paste files from windows explorer to
            test
            navigator](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228991):
            Regression from [Providing the ability to record user's
            interactions with GEF objects in a GEF
            editor](https://bugs.eclipse.org/bugs/show_bug.cgi?id=133099).
            Attempting to complete in I7.
      - Tony:
          - [Accessibility-Need shortcuts for all Test Navigator
            pulldowns](https://bugs.eclipse.org/bugs/show_bug.cgi?id=195203):
            Problems with shortcuts for on Test Navigator context menus.
            Deferring to I8.

<!-- end list -->

  - Platform Project impacting the Test Project:
      - [Execution of any testsuite fails using the IAC -
        InactiveProcessException](https://bugs.eclipse.org/bugs/show_bug.cgi?id=222382):
        Bing cannot reproduce. Working with originator to determine if a
        configuration issue.
      - [Problem with AC on
        Linux](https://bugs.eclipse.org/bugs/show_bug.cgi?id=229055):
        Jonathan is investigating.

<!-- end list -->

  - Defects required in I8:
      - Paul:
          - [Review all plug-in
            dependencies.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=218292)
          - [Need new icon for testlog
            files](https://bugs.eclipse.org/bugs/show_bug.cgi?id=200201)
          - [Creating resources with \# in name is not prevented but
            causes problems loading the
            model](https://bugs.eclipse.org/bugs/show_bug.cgi?id=101308)
          - [Test editor is too wide for users to
            read](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228930)
          - [(Usability) HTTP tests do not automatically generate JUnit
            Java code like JUnit
            tests.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=123650)
          - [Clean-up the TPTP committer lists and project
            matrix.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=214388)
          - [URL test type does not support encrypted
            datapools.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=216080)
          - [Junit plug-in test type does not support encrypted
            datapools.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=216078)
          - [TPTP EMF models needs to
            update](https://bugs.eclipse.org/bugs/show_bug.cgi?id=221097)
          - [Provide ISV documentation for
            enhancement 166025.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228241)
      - Jerome:
          - [Open test editors are not refreshed when removing
            referenced test
            assets.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228262)
          - [Changing the file name of a test asset in the Test
            Navigator updates the logical
            name.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228260)

## Round-table

### Paul

  - Last Week:
      - 4.5 I7 TP1.
      - Resolved defects:
          - [Exception in the deployment editor when a referenced
            artifact is
            deleted.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228259)
          - [NPE inTestsuiteLocationWizardPage constructor if no wizard
            is
            given](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228470)
          - [\[ASF](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228804)
            FileNotFoundException when interrogating test execution
            results.\]
          - [Can not run junit test using String and Double encrypted
            datapool
            data](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228172)
          - [Test Tools about.properties files contain incorrect
            descriptions.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=225523)
          - [NullPointerException constructing navigator proxies:
            DefaultTestSuiteProxyNode.addInvocationReferences](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228029)
          - [BIDI3.4:Spaces are truncated in code update
            preview](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228177)
          - [HTML Test Report Generation fails - MalformedURLException:
            unknown protocol:
            d](https://bugs.eclipse.org/bugs/show_bug.cgi?id=227191)
          - [ClassNotFoundException when running ASF automation services
            without
            OSGi/ICU.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=228873)
          - [Running a test linked to a datapool cause Severe
            Error](https://bugs.eclipse.org/bugs/show_bug.cgi?id=227770)
          - [The invocation for some deleted testcases can't be removed
            in behaviour
            tab](https://bugs.eclipse.org/bugs/show_bug.cgi?id=225963)

<!-- end list -->

  - This Week:
      - See
        [Defects](http://wiki.eclipse.org/TPTP-Test-Tools-20080428#Defects)
        section.

### Duwayne

  - Last Week:
      - 4.5 I7 TP1.
      - Working on [Cannot remove a test invocation to a removed HTTP
        request.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=201896):
        Model code defect.
  - Assisting consuming products resolving issues found during
    integrating with TPTP M5.

<!-- end list -->

  - This Week:
      - Out of Office: 1 day
      - See
        [Defects](http://wiki.eclipse.org/TPTP-Test-Tools-20080428#Defects)
        section.

### Jerome

  - Last Week:
      - Vacation: 4 days
      - Resolved defects:
          - [Filename vs. logical name in
            UI](https://bugs.eclipse.org/bugs/show_bug.cgi?id=160485)
          - [Test assets' editors (locations, datapools etc) allow save
            with empty internal
            names](https://bugs.eclipse.org/bugs/show_bug.cgi?id=162407)
          - [Adding a location or artifact with a duplicate name of a
            removed resource in a deployment does not
            work](https://bugs.eclipse.org/bugs/show_bug.cgi?id=220555)
          - [Move, Copy, Delete, Rename and Import/Export test
            assets.](https://bugs.eclipse.org/bugs/show_bug.cgi?id=166025)

<!-- end list -->

  - This Week:
      - Out of Office: 2 days
      - See
        [Defects](http://wiki.eclipse.org/TPTP-Test-Tools-20080428#Defects)
        section.

### Tony

  - Last Week:
      - 4.5 I7 TP1:

<!-- end list -->

  - This Week:
      - Complete 4.5 I7 TP1.
      - 4.5 I7 TP2:
      - Complete defect [Accessibility-Need shortcuts for all Test
        Navigator
        pulldowns](https://bugs.eclipse.org/bugs/show_bug.cgi?id=195203).

## Action items

  - None.

## Notes

  - None.

## Reminders

### Lead Committers

  - Continually review copyright reports and ensure files will missing
    copyright or incorrect copyright year are corrected.
  - Add the Original Estimate (PH) when triaging a new defect.
  - Update the Hours Worked (PH) when completing a defect.
  - Test their
    [components](http://www.eclipse.org/tptp/home/project_info/structure/TPTP_Project_Info.html)
    or review/track testing contributed by other committers/resources.
  - Monitor the TPTP news group and answer posts specific to their Test
    Project components.
  - Verify that all API changes (modifications, additions, and removals)
    do not breech the [TPTP API
    Contract](http://www.eclipse.org/tptp/home/documents/process/development/api_contract.html).
  - Use the [MyFoundation
    Portal](https://dev.eclipse.org/portal/myfoundation/portal/portal.php)
    for committer elections.