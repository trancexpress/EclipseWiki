## Date

  - November 13, 2007

## Attendees

  - Present:
      - Paul Slauenwhite
      - Harm Sluiman
      - Duwayne Morris
      - Kent Siefkes

## Background

  - AG review of enhancement
    [208110](https://bugs.eclipse.org/bugs/show_bug.cgi?id=208110)
    (Generic Recorder Wizard enhancement to filter the list of
    recorders).

<!-- end list -->

  - [Description
    Document](http://www.eclipse.org/tptp/groups/Architecture/documents/features/hf_208110.htm)

## Minutes

  - Requirements:
      - The Generic Recording Framework (GRF) provides an extension
        point (`org.eclipse.hyades.test.core.Recorder`) to contribute a
        recorder.
      - Contributed recorders appear in the Generic Recorder Wizard
        (`File >> New >> Other... >> Test >> Test from Recording`).
      - Since some consuming products may not want to display all of the
        contributed recorders, a new mechanism is required to filter the
        recorders that appear in the Generic Recorder Wizard when it is
        started.
      - This mechanism would improve the usability in consuming products
        is by reducing user confusion by filtering similarly named
        recorders. For example, users may pick the wrong recorder and be
        missing functionality, such as handling digital certificates.

<!-- end list -->

  - Proposed Design:
      - An extension point would filter a list of recorders from
        appearing in the Generic Recorder Wizard (`File >> New >>
        Other... >> Test >> Test from Recording`) based on their unique
        identifier(s).
      - This extension point would include the following properties:
          - Unique identifier
          - Name
          - Sequence of zero or more unique identifier(s) of recorder(s)
            to be filtered
      - If a version of TPTP does not package a recorder identified in
        this extension point, it is ignored.
      - An annotated schema would provide user documentation for this
        extension point.
      - The extension point would be implemented and packaged by the
        consuming products.
      - The extension point would not be implemented and packaged by
        TPTP.

<!-- end list -->

  - Concerns:
      - In a mixed environment (for example, more than one consuming
        product contributing an implementation of this extension point),
        filters need to be managed so the user experience is the same
        for all applications sharing the same Eclipse shell. For
        example, one consuming product's filters should not alter the
        recorders contributed by another application.
      - The user cannot enable/disable a recorder.
      - Consuming products cannot enable/disable a recorder from
        different entry points. Different perspectives or capabilities
        may want to enable a different set of recorders. For example,
        starting the Generic Recorder Wizard from the file menu (`File
        >> New >> Other... >> Test >> Test from Recording`) or from a
        custom perspective.

<!-- end list -->

  - Alternative Design:

<!-- end list -->

1.  Change the name and description of the TPTP URL recorder to reduce
    user confusion when displayed with similar contributed recorders.
2.  Isolate the implementation of the
    `org.eclipse.hyades.test.core.Recorder` extension point for the TPTP
    URL recorder to a separate and optional plug-in and feature.
    Consuming products can disable or remove this feature.

<!-- end list -->

  - Optional Enhancements (not required for this enhancements):

<!-- end list -->

1.  Provide an API for starting the Generic Recorder Wizard with a list
    of unique identifier(s) for the recorders that would not appear in
    the wizard. Consuming products would call this API from their own
    entry point (for example, custom perspective). Starting the Generic
    Recorder Wizard from the file menu (File \>\> New \>\> Other... \>\>
    Test \>\> Test from Recording) would display all of the recorders.
    This API would be used when opening the Generic Recorder Wizard from
    the Recorder Control view in the Test Perceptive.
2.  Provide a preference panel for users to control what recorder appear
    in the Generic Recorder Wizard (similar to Eclipse Activities which
    are too coarse grained for this application only supporting views,
    editors, perspectives, preference pages, property pages, menus,
    toolbars, and new project wizards).
3.  Provide an extension point or API to create a new Test Perspective
    specific to a tester scenarios (for example, one or more test
    types).

## Action items

  - Paul: Update the [Description
    Document](http://www.eclipse.org/tptp/groups/Architecture/documents/features/hf_208110.htm)
    with the alternate design.