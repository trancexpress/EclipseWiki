[TPTP Main Page](http://www.eclipse.org/tptp/) \> [TPTP
wiki](TPTP "wikilink") \>

## Summaries of F2F Meetings

  - [TPTP March 09 face to face](TPTP_March_09_face_to_face "wikilink")
  - [TPTP Mar 08 face to face](TPTP-PMC-F2F-200803 "wikilink")
  - [TPTP Sep 07 face to face](TPTP_Sep_07_face_to_face "wikilink")
  - [TPTP Jan 07 face to face](TPTP_Jan_07_face_to_face "wikilink")

## Contact

[Mailing Lists and News
group](http://www.eclipse.org/tptp/home/project_info/general/mailnews.php)