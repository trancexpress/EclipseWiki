{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}

Vocabulary to describe a Template Context. Contains information
necessary to dynamically instantiate regular contexts. Part of the
[Persona Data Model 2.0](Persona_Data_Model_2.0 "wikilink").

## Files

  - Most recently
    [published](http://www.eclipse.org/higgins/ontologies/2010/6/template)
  - SVN source:
    [template.owl](https://dev.eclipse.org/svnroot/technology/org.eclipse.higgins/trunk/H2/org.eclipse.higgins.ontology/template.owl)

## UML Overview

![Template-2.0.122.png](Template-2.0.122.png "Template-2.0.122.png")

## Overview

TemplateContexts are used to instantiate both regular contexts and
connector contexts mentioned here: [Persona Data Model
2.0](Persona_Data_Model_2.0 "wikilink"). The AppTemplate subclass of
TemplateContext (itself a subclass of ctxt:Context) is used to describe
the former, and the ConnectionTemplate subclass of TemplateContext, the
latter. TemplateContexts have an optional policy attribute whose value
is an an instance of DataPolicy.

### AppTemplate

An AppTemplate is a template for an app. An app is a PDS add-on. Apps
run within a PDS-provided runtime environment. Apps have read (and
potentially write) access to a specific set of attributes within the
PDS. An AppTemplate is a TemplateContext subclass with a
ContextPrototype instance that describes a context to be used to support
an app.

  - subClassOf TemplateContext
  - 1..1 app App

#### App

Abstract class. A prototype of a context instance that holds
app-specific data (e.g. Person entity) if any. Subclasses reference
active content (aka code).

  - subclass of ContextPrototype
  - 1..1 description--human friendly text that describes this
    app/view/context
  - 0..1 viewRoot (inherited) - value is a structure created using the
    [View-builder vocabulary](View-builder_vocabulary "wikilink") that
    describes how to dynamically construct a UI to view and/or edit the
    attributes of this context.
  - 0..1 settingsViewRoot (inherited) - value is a structure created
    using the [View-builder
    vocabulary](View-builder_vocabulary "wikilink") that describes how
    to dynamically construct a UI to view and/or edit administrative
    settings related to the JavaScript app (if present)

The instantiated context of an AppTemplate TemplateContext is a place
where the JavaScript of the app can persist new attributes if needed.
Apps use an API that may update the values of attributes in other
contexts.

### ConnectionTemplate

A TemplateContext containing two ContextPrototypes instances that
describe connector context(s) in a relationship. In some cases only a
single *Participant* context is instantiated, in others a
*Participant/Definer* pair is instantiated.

The **Definer** ContextPrototype instance has the following attributes:

  - 0..1 viewRoot - value is a structure created using the [View-builder
    vocabulary](View-builder_vocabulary "wikilink") that describes how
    to dynamically construct a UI to view and/or edit the attributes of
    this context.
  - 0..1 settingsViewRoot - value is a structure created using the
    [View-builder vocabulary](View-builder_vocabulary "wikilink") that
    describes how to dynamically construct a UI to view and/or edit
    administrative settings related to the JavaScript app (if present)

The **Participant** ContextPrototype instance has the following
attributes:

  - 0..1 templateRole - value is a default Role to assign to the new
    p:Person instance in the newly instantiated context

in the relationship for which the participant is authoritative and may
optionally decide to provide

  - 0..1 viewRoot - value is a structure created using the [View-builder
    vocabulary](View-builder_vocabulary "wikilink") that describes how
    to dynamically construct a UI to view and/or edit the attributes of
    this context.
  - 0..1 settingsViewRoot - value is a structure created using the
    [View-builder vocabulary](View-builder_vocabulary "wikilink") that
    describes how to dynamically construct a UI to view and/or edit
    administrative settings related to the JavaScript app (if present)

#### Example

Below is an example of a ConnectionTemplate. See
([nytimes.com.n3](https://dev.eclipse.org/svnroot/technology/org.eclipse.higgins/trunk/H2/org.eclipse.higgins.ontology/templates/nytimes.com.n3)
for details):

Here is the ConnectionTemplate (Note: the image value is truncated):

` <`<http://www.eclipse.org/higgins/ontologies/examples/nytimes.com>`>`
`     a       template:ConnectionTemplate , owl:Ontology ;`
`     template:participant`
`             :WebsiteFacade_1 ;`
`     template:proxyClass `<proxy:WebLogin>` ;`
`     `<proxy:connectionType>` `<proxy:News>` ;`
`     `<proxy:domain>` "nytimes.com"^^xsd:string ;`
`     `<proxy:externalResource>
`             "`<http://nytimes.com>`"^^xsd:anyURI ;`
`     `<proxy:image>` "329849238457234523453454"^^xsd:base64Binary ;`
`     `<proxy:imageType>` "JPG"^^xsd:string ;`
`     owl:imports <`<http://www.eclipse.org/higgins/ontologies/2011/2/view-builder>`> ,`
`     <`<http://www.eclipse.org/higgins/ontologies/2010/6/fp>`> ,`
`     <`<http://www.eclipse.org/higgins/ontologies/2010/6/template>`> ;`
`     skos:prefLabel "NYTimes ConnectionTemplate"^^xsd:string .`

Here is the definer WebsiteFacade:Participant (Note: the actual code of
the JavaScript has been omitted). See [App-data
vocabulary](App-data_vocabulary "wikilink") for a complete example of a
WebsiteFacade object:

` :WebsiteFacade_1`
`     rdf:type app-data:WebsiteFacade ;`
`     app-data:script :Login_1 ;`
`     template:contextClass`
`             <`<http://www.eclipse.org/higgins/ontologies/2011/6/context#ConnectionContext>`> .`

Here is its Login CDEScript:

` :Login_1`
`     a       app-data:Login ;`
`     app-data:data "`<JSON script goes here>`"^^xsd:string ;`
`     app-data:version "1.0"^^xsd:string ;`
`     skos:prefLabel "Script to auto-login to the New York Times website."^^xsd:string .`

## Classes

### App

Abstract class. A prototype of a context instance that holds
app-specific data (e.g. Person entity) if any. Subclasses reference
active content (aka code).

  - subClassOf ContextPrototype
  - 1..1 appURI
  - 1..1 description

### AppTemplate

An AppTemplate is a template for an app. An app is a PDS add-on. Apps
run within a PDS-provided runtime environment. Apps have read (and
potentially write) access to a specific set of attributes within the
PDS. An AppTemplate is a TemplateContext subclass with a
ContextPrototype instance that describes a context to be used to support
an app.

  - 1..1 app

### ConnectionTemplate

A TemplateContext containing two ContextPrototypes instances that
describe the participant context or the participant and definer
connector contexts in a relationship. The *<proxy:externalResource>* is
the URI of the external site (e.g. <http://groupon.com>). The
*<proxy:connectionType>* (and the *<proxy:externalResource>*) are used
to instantiate <proxy:Proxy> instances.

  - subClassOf: TemplateContext
  - 0..1 definer
  - 1..1 participant
  - 1..1 <proxy:connectionType> - e.g. "business"
  - 1..1 <proxy:externalResource> - e.g. <http://nytimes.com>
  - 1..1 <proxy:domain> - e.g. nytimes.com

### ContextPrototype

Abstract class. A prototype of an Context instance including,
potentially, active code to be executed. The attributes of the prototype
are copied into a Context instance.

  - 0..1 viewRoot
  - 0..1 contextSettingsClass

### Definer

A prototype of a context that is one side of a connector context pair.
The Definer side is a context managed by the same party that created the
TemplateContext--the party that defines the overall parameters of the
connector relationship. In a person-to-business connector. Definer would
typically be the business as it is the business that defines the
relationship including the set of attributes that will go back and
forth.

  - subClassOf: Connector

### HBXApp

An App that consists of an *app-data:Overlay* that is loaded by the HBX
and executed in the foreground--i.e. as an overlay to the current page.

  - subClassOf App
  - 1..1 overlay

### Participant

A prototype of a context that is one side of a connector context pair.
The Participant side is a context managed by the other party--not the
party that created the TemplateContext that defines the overall
parameters of the connector relationship. In a person-to-business
connector. Participant would be the person (the PDS owner/user)

  - subClassOf: Connector
  - 0..1 overlayCode

### PortalApp

A kind of App that loads HTML/JS from *appURI* and displays it within
the portal. The appURI may be within the PDS operator's domain or
external to it.

  - subClassOf App
  - 1..1 appURI

### TemplateContext

A TemplateContext is an abstract class for a context whose attributes
act analogous to a "class" for regular context "instances".

  - subclassOf ctxt:Context (see [Context
    vocabulary](Context_vocabulary "wikilink"))
  - 0..1 <proxy:image>
  - 0..1 <proxy:imageType>
  - 0..1 <proxy:imageURL>
  - 0..1 <proxy:description>
  - 1..1 <proxy:displayName>
  - 1..1 proxyClass

## Attributes

### app

AppContext ContextPrototype

  - domain: AppTemplate
  - value: App

### appURI

App UI page

  - domain: App
  - value: xsd:anyURI

### contextClass

Type (as in rdf:type) of ctxt:Context to instantiate (e.g.
ctxt:ConnectionContext, ctxt:InboxContext, etc.). If not present then
ctxt:Context is used.

  - domain: ContextPrototype
  - value: owl:Class

### contextSettingsClass

The subclass of ctxt:Settings to instantiate when creating a new context
instance from this context prototype. If not present then ctxt:Settings
is used.

  - domain: ContextPrototype
  - value: owl:Class

### definer

Definer context within a pair of Participant/Definer connector contexts.

  - domain: ConnectionTemplate
  - value: Definer

### overlay

JavaScript code that provides web augmentation/overlay to the user's
current webpage in the browser.

  - domain: Participant or HBXApp
  - value: app-data:Overlay

### participant

Participant context within a pair of Participant/Definer connector
contexts.

  - domain: ConnectionTemplate
  - value: Participant

### proxyClass

Subclass of <proxy:Proxy> to instantiate in the root context.

  - domain: TemplateContext
  - value: owl:Class

### role

Default role played by new Person entity instances in contexts
instantiated from this Participant prototype

  - domain: Participant
  - value: persona:Role

### settingsViewRoot

Root of a tree of ViewNodes that describe the UI for the settings
control panel for this context.

  - domain: ContextPrototype
  - value: view-builder:ViewNode

### role

Default role played by new Person entity instances in contexts
instantiated from this Participant prototype

  - domain: Participant
  - value: persona:Role

### viewRoot

Root of a tree of ViewNodes that describe the UI for this context.

  - domain: ContextPrototype
  - value: view-builder:ViewNode

## Links

  - [App-data vocabulary](App-data_vocabulary "wikilink")
  - [Persona Data Model 2.0](Persona_Data_Model_2.0 "wikilink")

[Category:Higgins 2
Vocabularies](Category:Higgins_2_Vocabularies "wikilink")