## Participants

  - S. Jerman, J. Worrell, R. Craddock, E. Dillon, J. Strawn

## Minutes

  - 0.3 Release
      - We got the greenlight from EMO.
      - Content will be 0.3RC1 plus fix for Associations not working on
        large models (\[Bug
        238535|<https://bugs.eclipse.org/bugs/show_bug.cgi?id=238535>\]).
      - There are some known issues with Annotations that have already
        been fixed in the HEAD (Validation, Tigerstripe subclass
        annotations). See tigerstripe-dev mailing list for details about
        scenarios.
  - IPackageArtifact
      - Richard's got it almost working with exception of refactoring.
      - Ready to commit code. Took a tag (v200806301157) on the HEAD in
        case things go "wrong" with the IPackageArtifact stuff.
  - Ganymede Support
      - Explorer seems to be working now, except for refactoring. Eric
        to commit changes in a separate branch and tentatively merge
        into HEAD next week.
      - GMF look-n-feel slightly different. In particular the Package
        label appear with \<\<...\>\> when empty. Maybe more.
      - Had to turn off start of Auditor for some reason. Need to look
        into that.
  - Annotations
      - Graphical representation getting ready. Yuri to confirm but
        should be all in CVS and ready to play with soon.

[Category:Tigerstripe_Community_Meeting](Category:Tigerstripe_Community_Meeting "wikilink")