## New Annotations Integration

  - New contributions is ready to be committed.
  - Integration with Tigerstripe to be done by J. Worrell
      - Need to implement URI provider based on selection
      - Need to implement router to decide where annotations are
        persisted'
      - Access Annotations from Generator

<!-- end list -->

  -