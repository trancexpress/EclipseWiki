{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}
![Higgins_logo_76Wx100H.jpg](Higgins_logo_76Wx100H.jpg
"Higgins_logo_76Wx100H.jpg")

## Overview

The [Token Service](Token_Service "wikilink") relies on Token Provider
(plug-ins) for packaging and signing of specific kinds of security
tokens.

[Category:Higgins Components](Category:Higgins_Components "wikilink")