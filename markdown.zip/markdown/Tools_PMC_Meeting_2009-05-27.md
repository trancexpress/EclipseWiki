Time: 2:00 PM Eastern

Conference number: North America 1 866-842-3549, Ottawa 613-787-5018,
Passcode: 6046633

  - If passcode is not recognized. After the third failure, you will be
    transferred to an operator who will ask for the conference ID
    (6046633), sponsoring company (IBM) and meeting organizer (Anthony
    Hunter).
  - Pressing \*0 will bring you directly to an operator.

### Attendees

  - Anthony Hunter
  - David Williams
  - John Duimovich
  - Doug Schaefer

### Minutes

  - Galileo update
      - Everyone on track.
  - Bjorn
      - Plans to stay on the Tools PMC.
  - Bjorn - Update on COBOL project status
      - Wait for Bjorn, leaning towards termination review.
  - Anthony - Update on VE project lead status
      - Post on ve-dev to confirm Yves in the lead, Email tools PMC that
        Yves is in and Joe is out.

<!-- end list -->

  - What guidance to give sub-projects on "Provider Name"

<!-- end list -->

  -   - Two alternatives?
          - "Eclipse Tools"
          - By subproject (no abbreviations, etc.)

` Eclipse AspectJ Development Tools`
` Eclipse AspectJ`
` Eclipse Buckminster Component Assembly`
` Eclipse C/C++ Development Tooling`
` Eclipse COBOL IDE`
` Eclipse Graphical Editor Framework`
` Eclipse Hibachi`
` Eclipse Mylyn`
` Eclipse Orbit Project (?Or, Eclipse Orbit ?)`
` Eclipse Parallel Tools Platform`
` Eclipse PHP Development Tools`
` Eclipse Visual Editor`

  - probably too late to go back and fix.
      - Recommendation not to fix right now since we are RC2.
  - GEF used "Eclipse Modeling Project"
  - Recommendation to use what is in the table above for the next
    release.

<!-- end list -->

  - Other projects moving to Tools?
      - Doug - Linux Tools / Mobile Linux maybe?
      - ATF incubating in webtools
      - talked about advantages of being in tools.
      - Seemed ok about ATF moving to tools.

<!-- end list -->

  - What projects belong in tools?
      - Future:
          - What is the tools project about, what is the scope?
          - Why do we have fewer rules?
          - Should we review our charter?
          - Maybe we should take another run at moving JDT and PDE into
            tools.

<!-- end list -->

  - Discussed possibility of having "project wide" meetings (PMC +
    Project Leads) ... perhaps alternate months.
      - Anthony to set up and invite PLs to June meeting.
          - Can debrief Galileo release
          - See if interest in every-other month meetings

### Calendar

<googlecalendar width="100%" title="Tools PMC Meeting Calendar">st544hsrpoucufc092hlgg74fg%40group.calendar.google.com</googlecalendar>

[Category:Tools_Meetings__Archives](Category:Tools_Meetings_Archives "wikilink")