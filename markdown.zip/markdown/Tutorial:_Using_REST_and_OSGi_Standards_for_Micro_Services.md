<css> .mw-code {

` background-color: #fafafa;`
` padding: 20px;`
` border-color: #ddd;`
` border-width: 3px;`
` border-style: solid;`
` border-radius: 5px;`
` margin-left: 10px;`
` margin-right: 10px;`
` overflow-x: auto;`

}

.mw-headline {

` font-family: Helvetica Neue,Helvetica,Arial,sans-serif;`
` color: rgb(51, 51, 51);`

}

p {

` font-family: Helvetica Neue,Helvetica,Arial,sans-serif;`
` text-align: justify;`

}

h1 {

` border-bottom-color: rgb(238, 238, 238);`
` font-weight: bold;`
` padding-bottom: 17px;`
` font-size: 30px;`
` line-height: 36px;`

}

h2 {

` border-bottom-color: rgb(238, 238, 238);`
` padding-bottom: 12px;`
` font-weight: bold;`
` font-size: 24px;`
` line-height: 36px;`

}

h3 {

` border-bottom-width: 1px;`
` border-bottom-style: solid;`
` border-bottom-color: rgb(238, 238, 238);`
` padding-bottom: 8px;`
` font-size: 18px;`
` line-height: 27px;`

}

h4 {

` font-size: 14px;`

}

h5 {

` font-size: 12px;`

}

h6 {

` font-size: 11px;`
` color: #EBEBEB;`
` text-transform: uppercase;`

}

a {

` color: rgb(0, 105, 214);`
` font-family: Helvetica Neue,Helvetica,Arial,sans-serif;`

}

a:visited {

` color: rgb(0, 105, 214);`

} </css>

## Introduction

It's currently popular to create REST-based networked services. This is
understandable, as the ubiquity http/https, the simplicity of the REST
approach, and the availability of open, cross-language object
serialization formats like JSON and XML, along with the availability of
quality distribution frameworks all make it easier than ever to define,
implement, and deploy a service and it's associated API.

One thing that is relatively new, however, is that there are now open
standards that deal with two levels of concerns

1.  Transport/Distribution-Level Concerns: What protocol and
    serialization format are to be used? How to support cross-language
    type systems? How to be as bandwidth efficient and performant as
    possible? How to handle network failure? etc.
2.  Service-Level Concerns: How to discover the service? How to version
    the service? How to handle service dynamics? How to secure the
    service? How to describe and document the service so that others may
    easily understand and use it? How to combine services and have
    service-level dependencies in a dynamic environment? etc.

## Transport and Distribution Concerns

From the service implementer's perspective, the selection of a framework
or implementation makes de-facto design choices about transport or
distribution concerns. For example, some REST frameworks use XML, some
JSON, some support both. However, once such a framework is chosen the
service implemented and deployed, it can become very difficult,
time-consuming, or even technically impossible to change to use other
frameworks or distribution systems.

For REST-based services, however, standards are beginning to emerge that
allow REST services to be defined and implemented without making a
specific choice of distribution system or framework. One example in Java
is [JAX Remote
Services](https://en.wikipedia.org/wiki/Java_API_for_RESTful_Web_Services)
or JAX-RS. JAX-RS defines/standardizes Java annotations for classes and
methods that are to be exposed for remote access. JAX-RS implementations
then use these annotations to 'export' the service (make it available
for remote access) and handle the mapping between http/https requests,
and the appropriate method invocation. For example, here's a small
'hello-world' service that uses JAX-RS annotations:

``` java
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.Path;

// The Java class will be hosted at the URI path "/helloworld"
@Path("/helloworld")
public class HelloWorldResource implements HelloWorldService {

    // The Java method will process HTTP GET requests
    @GET
    // The Java method will produce content identified by the MIME Media
    // type "text/plain"
    @Produces("text/plain")
    public String getMessage() {
        // Return some textual content
        return "Hello World";
    }
}
```

One very useful aspect of the JAX-RS annotations is that multiple
implementations may exist, and it is relatively easy to switch from one
implementation to another.

## Service-Level Concerns

Although frequently of secondary concern to service implementers,
service-level concerns are typically of primary importance to service
**consumers**. For example, before I can use any REST-based service, I
have to know about (discover) the service and needed meta-data: the
service location (i.e. it's URL), what methods exist and arguments are
required, and what can be expected in response. Additionally, what
version of the service is being accessed, what credentials/security are
required, what are the run-time qualities of the remote service?

### OSGi Remote Services

In recent releases the OSGi Alliance has defined a specification called
[Remote Services](http://www.osgi.org/Specifications/HomePage) (chapter
100 in the enterprise spec). Along with the Remote Service Admin
specification (chapter 122 in enterprise spec), Remote Services defines
ways to express answers to service-level concerns in an
implementation-independent way, similar to what JAX-RS does for
transport-level concerns. For example, the Remote Service spec allows
meta-data for service type, service version, service endpoint/URL
identification, security, and quality of service properties to be
communicated between service implementer and service consumer without
referring to any Remote Services implementation. Further, Remote
Services/RSA defines a way to dynamically discover and un-discover
remote services, allowing for easy consumer support for networked and
frequently unreliable services.

Several implementations of OSGi Remote Services exist, including open
source [ECF](https://wiki.eclipse.org/ECF#OSGi_Remote_Services),
[CXF](http://cxf.apache.org/), [Amdatu](http://www.amdatu.org/) and
commercial implementations.

OSGi RSA has the concept of a distribution system responsible for
exporting a local service and making it available for remote access.
According to the specification, many distributions systems may be used
even for a single service. ECF's implementation is unique because it has
an open API for creating/adding new distribution providers. Currently,
ECF committers have implemented the following distribution providers

  - [ECF 'generic'](https://www.eclipse.org/ecf/downloads.php)
  - [r-OSGi](https://www.eclipse.org/ecf/downloads.php)
  - [Java Messaging Service (JMS)](https://github.com/ECF/JMS)
  - [MQTT](https://github.com/ECF/Mqtt-Provider)
  - [Hazelcast](https://github.com/ECF/HazelcastProvider)
  - [JavaGroups](https://github.com/ECF/JGroups)
  - [Jax-RS/Jersey and
    Jax-RS/CXF](https://github.com/ECF/JaxRSProviders)

## Jax-RS with OSGi Remote Services

Since ECF's RSA implementation implements the OSGi RS and RSA
specifications, and Jersey implements the Jax-RS specification, it's
possible create and export a remote service that deals with both the
transport and service-level concerns in a way completely standardized,
and not dependent upon either the OSGi RS/RSA implementation (e.g. ECF),
nor on the distribution system provider implementation (Jersey).

For example, here is some example OSGi code for exporting a remote
service using the [Jax-RS/Jersey](https://github.com/ECF/JaxRSProviders)
provider:

``` java
BundleContext bundleContext;
Dictionary<String, String> props = new Hashtable<String,String>();
// osgi rs property to signal to distribution system
// that this is a remote service
props.put("service.exported.interfaces","*");
// specify the distribution provider with osgi rs property
props.put("service.exported.configs", "ecf.jaxrs.jersey.server");
// as per spec, <provider>.<prop> represents a property intended for use by this provider
props.put("ecf.jaxrs.jersey.server.alias", "/jersey");
// register (and export) HelloImpl as remote service described by Hello interface
bundleContext.registerService(HelloWorldService.class, new HelloWorldResource(), props);
```

HelloWorldResource implements a HelloWorldService interface which is
defined

``` java
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.Path;

// The Java class will be hosted at the URI path "/helloworld"
@Path("/helloworld")
public interface HelloWorldService {

    // The Java method will process HTTP GET requests
    @GET
    // The Java method will produce content identified by the MIME Media
    // type "text/plain"
    @Produces("text/plain")
    public String getMessage();
}
```

Note that the HelloWorldService has exactly the same Jax-RS annotations
as the HelloWorldResource implementation class.

With the Jax-RS/Jersey distribution provider, the above registerService
call will dynamically export the remote service (via Jersey) so that
remote clients (Java/OSGi-based or not) can access getMessage by sending
a GET to an URL like this:

curl <http://localhost:8080/jersey/helloworld/1>

Would respond with "Hello World"

The use of Jax-RS annotations to implement an ECF distribution provider,
and the use of OSGi Remote Services has several important advantages for
the service implementer and the service consumer:

1.  An ability to flexibly handle both transport-level and service-level
    concerns in a way appropriate to the application
2.  A clean separation between service contract (HelloWorldService
    interface), and service implementation (HelloWorldResource)
3.  A clean separation between application concerns from transport
    **or** service-level concerns
4.  Alternative implementations of Jax-RS and/or OSGi RS/RSA may be
    substituted at any time without application changes

## Using the Remote Service

Since the HelloWorldService is exported via Jax-RS/Jersey provider, it
may be accessed by any client (e.g. javascript, java, curl, etc) that
can access via http calls. If, however, it is an OSGi client (or a
non-OSGi Java Client) ECF Remote Service can automatically construct a
proxy for the remote service, and make the proxy available as an OSGi
Service on the client. For a description and example of doing this, see
[Exposing a Jax REST Service as an OSGi
Service](Tutorial:_Exposing_a_Jax_REST_service_as_an_OSGi_Remote_Service "wikilink").

## A More Complete Example

A more complex example exists in the [Jax-RS/Jersey
Provider](https://github.com/ECF/JaxRSProviders) repo. The remote
service host/server is in the
[com.mycorp.examples.student.remoteservice.host](https://github.com/ECF/JaxRSProviders/tree/master/examples/com.mycorp.examples.student.remoteservice.host)
bundle. The remote service consumer/client is in
[com.mycorp.examples.student.client](https://github.com/ECF/JaxRSProviders/tree/master/examples/com.mycorp.examples.student.client)
bundle. Notice that neither of these bundles has references to ECF,
Jersey, or even OSGi classes, but rather only to Jax-RS standard
annotation types (javax.\*) and model classes defined in the
[com.mycorp.examples.student](https://github.com/ECF/JaxRSProviders/tree/master/examples/com.mycorp.examples.student)
bundle.

## Background and Related Articles

[Tutorial: Exposing a Jax REST service as an OSGi Remote
Service](Tutorial:_Exposing_a_Jax_REST_service_as_an_OSGi_Remote_Service "wikilink")

[Getting Started with ECF's OSGi Remote Services
Implementation](Getting_Started_with_ECF's_OSGi_Remote_Services_Implementation "wikilink")

[OSGi Remote Services and ECF](OSGi_Remote_Services_and_ECF "wikilink")

[Asynchronous Proxies for Remote
Services](Asynchronous_Proxies_for_Remote_Services "wikilink")

[Static File-based Discovery of Remote Service
Endpoints](File-based_Discovery "wikilink")

[Download ECF Remote Services/RSA
Implementation](EIG:Download "wikilink")

[How to Add Remote Services/RSA to Your Target
Platform](EIG:Add_to_Target_Platform "wikilink")