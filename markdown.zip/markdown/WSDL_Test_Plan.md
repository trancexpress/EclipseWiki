__NOTOC__

<table width="100%">

<tr>

<td width="80%" align="top">


<b><big>WSDL Component Test Plan</big></b>
<b><big>WTP 1.5 Final</big></b>

<td>

<http://www.eclipse.org//webtools/images/wtplogosmall.jpg>

</td>

</tr>

</table>

<table width="100%">

<tr>

<td valign="top" bgcolor="#0080c0">

<big><b><font face="Arial,Helvetica" color="#ffffff">  Task Oriented
Tests</font></b></big>

</td>

</tr>

</table>

<h3>

Test Case 1 : Start From Scratch - Standalone

</h3>

1.  Use the New WSDL Wizard to create a new wsdl (alternative) Use New
    File to create a blank 'wsdl' file ... everything should still
    work



<li>

Select a 'target' WSDL that you can attempt to reproduce. Here's some
suggestions but feel free to come up with your own

<table border='1'>

<tr bgcolor="#CCCCCC">

<td>

Description

</td>

<td>

Where

</td>

</tr>

<tr>

<td>

PhoneBanking

</td>

<td>

XML Examples Project

</td>

</tr>

<tr>

<td>

Google Search API

</td>

<td>

[link](http://api.google.com/GoogleSearch.wsdl)

</td>

</tr>

<tr>

<td>

Fax

</td>

<td>

[link](http://www.sms.mio.it/webservices/sendmessages.asmx?WSDL)

</td>

</tr>

</table>

</ul>

</li>



<li>

Using the target WSDL as a guide, utilize the design view to reproduce
it. Attempt to use a top down flow since this best simulates how a user
would go about building from scratch (e.g. start with the main elements
and types and work your way down to the leaf objects. Be sure to open
bugs if...

  - you run into quirky problems that make editing feel unnatural
  - you need to go off to the outline or source view to work around
    problems
  - you hit performance problems that affect your productivity
  - etc.

</li>



<li>

When you think your WSDL is complete, use the validator to ensure it's
valid.

  - Since the editor was used to author the document there should be
    very few validation problems (if any). If there are some look at
    these carefully and consider why the editor produced these.
  - some of the validation problems are unavoidable but in general the
    editor should be fairly good at protecting the users against 'bad'
    WSDLs
  - if there are problems it's likely that the user will need to use the
    source view to fix them
  - ensure that all problems can be fixed in the source view and that
    red squggles work
  - as you fix things in the source view ensure that red squiggle
    indicators go away
  - ensure that when you flip back to the design view that any source
    changes are reflected in the view

</li>



<li>

As a final test open use the 'jst' tools to generate and deploy a
skeleton web services for the WSDL

</li>

</ol>

-----

<h3>

<b>Test Case 2 : Start From Scratch - One Piece of a Larger Project</b>

</h3>

1.  Repeat Test Case 1 but recreate a WSDL that's uses a muti-file
    pattern . Here's some examples...
    <table border='1'>
    <tr bgcolor="#CCCCCC">
    <td>
    Name
    </td>
    <td>
    Where
    </td>
    </tr>
    <tr>
    <td>
    SpaceWarGame-b
    </td>
    <td>
    XML Examples Project
    </td>
    </tr>
    <tr>
    <td>
    PhoneBanking-b
    </td>
    <td>
    XML Examples Project
    </td>
    </tr>
    </table>

</ul>

</li>

<li>

Be sure to utilize the 'Browse...' function when editing type and
element references.

</li>

<li>

Inspect the WSDL after using 'Browse...' to ensure that the <include> or
<import> and the 'xmlns:xxx' gets updated correctly.

</li>

<li>

Inspect the source view after using 'Browse...' to ensure the type or
element reference is not red squiggled (and muck with it to make sure
the squiggle does show when expected)

</li>

</ol>


\----

<h3>

<b>Test Case 3 : Visualize and Browse a Large/Complex WSDL</b>

</h3>

1.  Select a WSDL that we want to view.
2.  Use the design view to naviagate the WSDL and open referenced XML
    Schemas. Ensure all of the following work...
      - click on the 'arrow' beside an element or complex type in the
        portType ... ensure a schema editor is opened and the 'clicked'
        object is shown
      - after following a chain of referenes, ensure the 'back arrow'
        button allows you to reverse back up the chain
      - expand the binding objects to ensure they layout correctly in
        their 'ruler-ish' form

3.  Use the source view to naviage thru the WSDLs and XSDs. Ensure all
    of the following work...
      - hold down crtl to see the hyperlinks as you mouse over them,
        ensure hyperlins appear for all 'references'
      - ctrl-lick or F3 on hypelinks to ensure 'open on' works
      - after following a chain of referenes, ensure the 'back arrow'
        button allows you to reverse back up the chain



<li>

Navigate thru the WSDLs and XSDs using both the design and source view
(flipping between 'em) and ensure both modes of navigation work together
nicely.

</li>



<li>

Use the outline view in conjuction and ensure it interacts as expected
with the source and design view

</li>



<li>

From the source, design and outline views. Use the
'references-\>project' or 'references-\>workspace' for several
components (portTypes, bindings, types, elements etc.) to understand how
components are reused.

</li>

</li>

</ol>

__NOTOC__

<table width="100%">

<tr>

<td valign="top" bgcolor="#0080c0">

<big><b><font face="Arial,Helvetica" color="#ffffff">  Function Oriented
Tests</font></b></big>

</td>

</tr>

</table>

<h3>

<b>New WSDL Wizard</b>

</h3>

1.  Try the various options available on the New WSDL file options page
      - option to create WSDL Skeleton
      - SOAP...document literal, rpc literal, rpc encoded
      - HTTP...HTTP GET, HTTP POST

<h3>

<b>design View</b>

</h3>

1.  Top Level View
      - Actions to add/remove/rename components
      - Open Schema/WSDL Imports
      - Imported WSDL components should appear but not be editable
      - Inline Schemas located in the 'top level' view should allow
        drill down
      - Connecting lines should appear to show WSDL component
        relationships
2.  In Drilled Down View of Schema Components...
      - Test that menus show proper content for different objects
      - Test Drag and Drop
      - Ensure deleting the 'top level' component pops you back to the
        top view
      - Test selection of 'simple type' icon within an element
        declaration
      - Content that originates via derivation should be demarked with
        dotted box

<h3>

<b>Outline View</b>

</h3>

1.  Selection from Outline view should select the corresponding object
    in the design view
2.  Context menu for a particular component should be the same in both
    the design and Outline views

<h3>

<b>Source View</b>

</h3>

1.  Test editing features
      - Add WSDL Components
      - Delete from source
      - Copy and paste
      - Test for invalid content
2.  Test 'standard' xml content assist support (see xml source editor)
    for adding WSDL and schema elements

<h3>

<b>Properties View</b>

</h3>

1.  Properties view should be available for all selected schema
    components
2.  Test that view can't be 'broken'... should always have 'good'
    content
3.  Imported WSDL components should not be editable through the
    properties
4.  Renaming components should 'auto refactor' within source file
    (references to renamed component should be updated)
5.  Update documentation for various components

<h3>

<b>Set Existing Component Dialog</b>

</h3>

1.  Set Existing Component Dialog launched via the context menu or
    properties
      - Port
      - Binding
      - Input
      - Output
      - Fault
      - Part
2.  Adjust the search scope. The available components displayed should
    be updated
3.  The text filter located at the top of the dialog is used to filter
    the available types

<h3>

<b>Generate Binding Content</b>

</h3>

1.  Click on a Binding and select "Generate Binding Content..." from the
    context menu. Select the "Overwrite existing binding information
    option". Ensure the proper binding information is generated
2.  Test out the different Binding options (SOAP, HTTP, etc...)

<h3>

<b>Smart Renaming</b>

</h3>

1.  Test smart renaming on the following Components
      - Operation
      - Fault
      - Message
      - Part
2.  Renaming one of the above elements should also rename it's
    'children' if the 'child' has a generated name. For example,
    "MyOperationName" (Operation) --\> Input --\>
    "MyOperationNameRequest" (Message) --\> "MyOperationNameRequest"
    (Part) A rename on Operation to "NewOp" will cause the following
    result: "newOpName" (Operation) --\> Input --\> "newOpNameRequest"
    (Message) --\> "newOpNameRequest" (Part)
3.  The same pattern follows when renaming a Fault, Message, and Part
4.  Initiate renaming via the context menu or the properties view

<h3>

<b>Imports</b>

</h3>

1.  WSDL imports
      - Test adding them via outline/properties view and via source view
      - Verify imported objects show up in design view (may need to
        close and reopen editor
      - Verify new components are available in the 'set type' dialog
      - Verify import shows up in outline view
2.  XSD imports
      - Test adding them via the 'set type' dialog will add xsd import
        to the wsdl
      - Verify new components are available in the 'set type' dialog
      - Verify xsd:import and wsdl:import cannot be interchanged and
        using one instead of the other will result in validaiton error
3.  Unused imports
      - Check preferences under Web Services-\>WSDL Files
      - Test that unused WSDL and XSD imports are removed

<h3>

<b>General</b>

</h3>

1.  Test the various menu actions available for different components
2.  Reload dependancies action from the WSDL Editor menu bar
3.  Test 'Edit Namespaces...' action
4.  Menu actions for 'categories' should only provide actions appicable
    to that particular category (e.g. element category should have 'Add
    Element')
5.  Undo/Redo
6.  View selection synchronization
7.  Editing synchronization : source -\> model (perform source changes
    below and ensure model is intact)

<!-- end list -->

  - cut and paste sections to/from source view
  - make various random changes in the souce view and then undo
  - delete and restore component declarations from source and ensure
    references are updated
  - change a file locally and refresh

<li>

Editing synchronization : model -\> source (perform designical changes
below and ensure source is intact)

</li>

  - make random changes to the WSDL model via the graphical views
  - make various changes in the souce view and then undo

<li>

F3 support

  - F3 on component references should cause selection to 'jump' to
    referenced component
  - F3 on imports should open the imported schema or WSDL

</li>

</ol>

<table width="100%">

<tr>

<td valign="top" bgcolor="#0080c0">

<big><b><font face="Arial,Helvetica" color="#ffffff">  Performance
Tests</font></b></big>

</td>

</tr>

</table>

<div id="example">

an id attribute

</div>

<h3>

Performance Test 1 : Validation

</h3>

1.  Perform a 'full' validation of a large project (see list of project
    in Usage Test 2)
2.  Open an applicable artifact in the editor and type in the source
    page to ensure 'as you type' validation is responive
3.  Test validation on projects that contain references to external URLs
4.  Validate in disconnected mode (no internet access)
5.  Run JUnit validation performance tests



<h3>

Performance Test 2 : Opening the Editor

</h3>

1.  Test how many editors can be opened at once
      - Import a large project into the workspace with many applicable
        artifacts
      - Open an editor for each artifact until you run out of memory
        (hint : use multi-select and open)
2.  Test how how quickly an editor opens
      - Use a very large artifact
      - Use an artifact that pulls in lots of other artifacts

<h3>

Performance Test 3 : Editing Responsiveness

</h3>

1.  Add and Remove various objects
      - from the design view
      - from the outline
      - from the source view
2.  Typing in the source view
      - rename an element (type quickly on the keyboard)
3.  Open on
      - from the design view
      - from the source view

<h3>

Performance Test 4 : Search and Refactoring

</h3>

  - Using a mediumm or large sized schema project
      - select a component and test 'refereces-\>workspace'
      - select a component and refactor-\>rename (with preview and
        without)
      - record timings for both 'cold' and 'warm' starts