# WTP Weekly What's Cooking?

## WTP 2.0

### March 9, 2007 - March 16, 2007

  - [2.0 Bugs fixed this
    week](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=bug_severity&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=2.0+M6&target_milestone=1.0+M6&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&resolution=FIXED&bug_severity=blocker&bug_severity=critical&bug_severity=major&bug_severity=normal&bug_severity=minor&bug_severity=trivial&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=2007-03-09&chfieldto=2007-03-16&chfield=resolution&chfieldvalue=FIXED&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

<!-- end list -->

  - [2.0 Enhancements added this
    week](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=bug_severity&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=2.0+M6&target_milestone=1.0+M6&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&resolution=FIXED&bug_severity=enhancement&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=2007-03-09&chfieldto=2007-03-16&chfield=resolution&chfieldvalue=FIXED&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

<!-- end list -->

  - [Build
    Notes](http://download.eclipse.org/webtools/downloads/drops/R2.0/I-I200703161509-200703161509/buildNotes.php)

<!-- end list -->

  - [Adopter Breakage
    Report](http://download.eclipse.org/webtools/downloads/drops/R2.0/I-I200703161509-200703161509/apiresults/api-ref-compatibility.html)

<!-- end list -->

  - Plugin Version Changes

<!-- end list -->

  -
    org.eclipse.wst.wsdl - 1.0.103 to 1.0.203

### Remaining for 2.0 M6

  - [2.0 Remaining Targeted M6
    Defects](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=bug_severity&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=2.0+M6&target_milestone=1.0+M6&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=%2C)

<!-- end list -->

  - [All Remaining 2.0 Targeted
    Enhancements](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=target_milestone&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=1.0&target_milestone=2.0+M1&target_milestone=2.0&target_milestone=2.0+M2&target_milestone=2.0+M3&target_milestone=2.0+M4&target_milestone=2.0+M5&target_milestone=2.0+M6&target_milestone=1.0+M6&target_milestone=2.0+RC1&target_milestone=2.0+RC2&target_milestone=2.0+RC3&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&bug_severity=enhancement&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

### Migrating to M6

  - See the [M6 Migration Guide](New_Help_for_Old_Friends_II "wikilink")
    for help porting to M6

### Focus Areas

  - [WTP Java EE5 Support and Meeting Minutes](JEE_5_Support "wikilink")

<!-- end list -->

  - [Axis2 Integration in WTP](Axis2_Integration_in_WTP "wikilink")

## WTP 1.5.4

### March 9, 2007 - March 16, 2007

  - [1.5.4 Bugs fixed this
    week](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=bug_severity&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=1.5.4+M154&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&resolution=FIXED&bug_severity=blocker&bug_severity=critical&bug_severity=major&bug_severity=normal&bug_severity=minor&bug_severity=trivial&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=2007-03-09&chfieldto=2007-03-16&chfield=resolution&chfieldvalue=FIXED&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

<!-- end list -->

  - Plugin Version Changes

### Remaining for 1.5.4

  - \[<https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=bug_severity&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=1.5.4+M154&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=>,
    1.5.4 Remaining Targeted Bugs\]

## References

[Back to What's Cooking Archive](WTP_Weekly_What%27s_Cooking "wikilink")

[Back to Web Tools Project Wiki Home](Web_Tools_Project "wikilink")