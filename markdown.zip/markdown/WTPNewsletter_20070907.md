# WTP Weekly What's Cooking?

## Headline News\!

  - WTP 2.0.1 RC1 declared today. PMC approval is required for all
    remaining 2.0.1 fixes.
  - The first 3.0 M2 I build declared today. A problem in platform
    (201906) requires you to use the M1 platform driver this week.

## WTP 2.0.1

### August 31, 2007 - September 07, 2007

  - [2.0.1 Bugs fixed this
    week](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=bug_severity&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=1.0.1&target_milestone=2.0.1+M201&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&resolution=FIXED&bug_severity=blocker&bug_severity=critical&bug_severity=major&bug_severity=normal&bug_severity=minor&bug_severity=trivial&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=2007-08-31&chfieldto=2007-09-07&chfield=resolution&chfieldvalue=FIXED&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

<!-- end list -->

  - [2.0.1 Remaining Targeted
    Defects](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=bug_severity&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=1.0.1&target_milestone=2.0.1+M201&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=%2C)

<!-- end list -->

  - [All Remaining 2.0.1 Targeted
    Enhancements](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=target_milestone&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=1.0.1&target_milestone=2.0.1+M201&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=UNCONFIRMED&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&bug_severity=enhancement&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

<!-- end list -->

  - Plug-in Version Information

<!-- end list -->

  -
    [Versioning
    Report](http://download.eclipse.org/webtools/downloads/drops/R2.0/M-2.0.1-20070830174756/versioningReport_2.0.1.html)

## WTP 3.0

### August 31, 2007 - September 07, 2007

  - [3.0 Bugs fixed this
    week](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=bug_severity&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=3.0+M1&target_milestone=2.0+M1&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&resolution=FIXED&bug_severity=blocker&bug_severity=critical&bug_severity=major&bug_severity=normal&bug_severity=minor&bug_severity=trivial&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=2007-08-31&chfieldto=2007-09-07&chfield=resolution&chfieldvalue=FIXED&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

<!-- end list -->

  - [3.0 Enhancements added this
    week](https://bugs.eclipse.org/bugs/report.cgi?x_axis_field=bug_severity&y_axis_field=component&z_axis_field=&query_format=report-table&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&target_milestone=3.0+M1&target_milestone=2.0+M1&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&resolution=FIXED&bug_severity=enhancement&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=2007-08-31&chfieldto=2007-09-07&chfield=resolution&chfieldvalue=FIXED&format=table&action=wrap&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

<!-- end list -->

  - [Build
    Notes](http://download.eclipse.org/webtools/downloads/drops/R3.0/I-I20070907104717-20070907104717/buildNotes.php)

<!-- end list -->

  - \*[Adopter Breakage
    Report](http://download.eclipse.org/webtools/downloads/drops/R3.0/I-I20070907104717-20070907104717/apiresults/api-ref-compatibility.html)

<!-- end list -->

  - Plugin Version Information

<!-- end list -->

  -
    [Version
    Info](http://download.eclipse.org/webtools/downloads/drops/R3.0/I-I20070907104717-20070907104717/versioningReport_I20070907104717.html)

## References

### Previous Adopter Breakage Report Information

:\*<i><b>Details</b></i>

::\*org.eclipse.jst.jsf.context.resolver.structureddocument.internal.impl.MetadataContextResolver
was renamed to
org.eclipse.jst.jsf.common.metadata.query.TaglibDomainMetaDataQueryHelper.

::\*In org.eclipse.wst.server.ui.internal.Messages, the fields
host,name,vendor, and version were removed.

::\*In the internal package, org.eclipse.wst.server.core.internal,
deprecated classes ModuleEvent, ModuleFactoryEvent, and IModuleListener
were removed.

::\*In the internal class
org.eclipse.wst.server.core.internal.ServerPlugin,
getModuleArtifact(...) was removed.

::\*In the internal class,
org.eclipse.jst.j2ee.internal.common.operations.JavaModelUtil, the
method findType(..) changed arguments. This class is basically a copy of
a JEM class to avoid adding a JEM dependency, and to keep up with
changes in JEM, this class was updated.

::\*In org.eclipse.wst.wsdl.binding.soap.SOAPHeader and
org.eclipse.wst.wsdl.binding.soap.SOAPHeaderFault, the methods
getPart(...), setPart(...), getMessage(...), setMessage(...) were
replaced by new methods. Details:

  -

      -
        The WSDL model SOAPHeader and SOAPAddress classes should have
        been inheriting the WSDL4J interfaces but weren't. Unfortunately
        the javax.wsdl interface already defines getMessage() and
        getPart () using a different signature. So this is a case where
        in order to 'fix' our model to make it comply with the WSDL4J we
        needed to break the 'provisional API' (these classes specified
        api=false in the component.xml file). Current clients will
        simply need to change references from getPart or getMessage to
        getEPart and getEMessage to access the EMF equivalent classes.


[Back to What's Cooking Archive](WTP_Weekly_What%27s_Cooking "wikilink")

[Back to Web Tools Project Wiki Home](Web_Tools_Project "wikilink")