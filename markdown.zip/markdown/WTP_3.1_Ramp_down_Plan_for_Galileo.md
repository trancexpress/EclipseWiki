## WTP Ramp down for Galileo

For reference, see the [Galileo Simultaneous
Release](Galileo_Simultaneous_Release "wikilink"), in particular the
[Milestones and Release
Candidates](Galileo_Simultaneous_Release#Milestones_and_Release_Candidates "wikilink").

### Early Milestones

Just to remind everyone, there is a bit of "ramp down" or control for
every milestone. Typically the last week of a Milestone is for testing,
and fixing only regressions and P1 or blocking defects. For milestones,
the project lead (or delegate) is enough to review and approve a bug for
inclusion in that milestone.

### M5: The EclipseCon Milestone

We plan to ensure good enough quality that M5 can be used by the
committers for demos and tutorials, etc.

### M6: Feature Complete, API Freeze, UI Freeze

For M6, we plan to be functionally and API complete and the remaining
Milestone and Release Candidates are for (only) fixing bugs, or fixing
release required items (such as version numbers, licensing, etc.).

From M6 to M7, we expect each component lead (or delegate) to review and
verify their teams' bugs (i.e. no PMC review ... though we will be
watching :) ).

We expect committers to concentrate on performance and other "internal"
improvements, after M6, leading up to M7. In addition, it's a good time
to improve documentation (for end-users and adopters).

If there are exceptions to these conditions, then they will require PMC
review. In that event, the Project Lead must open a bugzilla, detailing
the feature to be added after M6 and mark for PMC review. And that must
be done before M6 is declared. Exceptions (with bug numbers) will also
be listed at the end of this document, to help facilitate communication.

:\*Place NLS or API or Feature in the heading of the bug depending on
which type it is

:\*Notify PMC memebers [PMC Defect
Review](http://wiki.eclipse.org/index.php/WTP_PMC_Defect_Review), 1 vote
is needed

:\*Once approved, code can be released

:\*Update this page to append the bug at the bottom of the page

### M7: PMC Review starts after M7

After the M7, the process of building and testing Release Candidates
begins (sometimes called "the end game"). At first, after M7 but before
RC1, in addition to the normal component team review, at least 1 PMC
member must also review and vote +1 after reviewing the bug for
appropriateness (weighing benefits and risks).

### Release Candidates

We expect Release Candidates to truly be candidates for release (i.e.
well performing, high quality, product ready code). After the first RC
is produced, other RCs will be produced, as needed, every week.

After M7 is produced, the time for general functional improvements is
long past. The following describes the types of bugs that would be
appropriate:

<!-- end list -->

  - A regression
  - A P1 or P2 bug, one that is 'blocking' or 'critical', and some cases
    of 'major' severities.
  - Documentation and PII files are exceptions to the normal PMC
    required review, since there is little chance of that breaking
    anything, though it is still expected to be complete by M6, and
    remaining work to be only documentation fixes (that is, no
    refactoring of plugins, build changes, etc, without PMC review and
    approval).
  - In addition to a bug meeting the above priority/severity conditions,
    there should be a simple, safe, well understood fix that is well
    isolated from effecting other components, that doesn't affect API or
    adopters, that has been well reviewed and well tested.
  - As each Release Candidate passes, the criteria for weighing the
    benefit-to-risk ratio criteria gets higher and higher, and as such
    requires a larger number of PMC members to review.

</ol>

#### RC1

After RC1, same rules as after M7: besides the normal component team
review, at least 1 PMC members must also review and vote +1 after
reviewing the bug for appropriateness and risk.

#### RC2

After RC2, besides the normal component team review, at least 2 PMC
members must also review and vote +1 after reviewing the bug for
appropriateness and risk.

#### RC3

After RC3, besides the normal component team review, at least 3 PMC
members must also review and vote +1 after reviewing the bug for
appropriateness and risk.

#### RC4

After RC4 is produced, we'll prepare and test the zip's, update site,
web pages, etc.

### Release

Celebrate\!

## Post-M6 Exceptions by sub-project

### Releng

  - Repackage capabilities plugins

<!-- end list -->

  - Provide 4 "product packages" (JavaScript, XML, Web Development, Java
    EE Development)

### Dali

  - Support for Entities in JARs
    [197069](https://bugs.eclipse.org/bugs/show_bug.cgi?id=197069)
  - Added provisional API as part of a bug fix
    [269256](https://bugs.eclipse.org/bugs/show_bug.cgi?id=269256)
  - Fix API leakage
    [269581](https://bugs.eclipse.org/bugs/show_bug.cgi?id=269581)

### Server Tools

  - Support for multiple Server profilers
    [270503](https://bugs.eclipse.org/bugs/show_bug.cgi?id=270503)

[Category:Eclipse Web Tools Platform
Project](Category:Eclipse_Web_Tools_Platform_Project "wikilink")