# WTP 3.2 Release Outline

~~The committers of WTP would like to have an off-cycle release, roughly
end-of-year.~~

No longer true. Plans changed. See our [Standard Format
Plans](http://www.eclipse.org/projects/project-plan.php?projectid=webtools).