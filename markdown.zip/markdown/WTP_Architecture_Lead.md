### The WTP Architecture Lead is responsible for maintaining and improving the architecture of WTP

The Architecture Lead is the officially appointed representative to the
EMO Architecture Council (though, with the new Architecture Council,
there can be other members of WTP on the council in addition).

The lead will:

  - Make recommendations to the PMC, project leads, and committers
    related to architecture.
  - Form groups to accomplish specific tasks from time to time.
  - Update the [Subsystems and
    Features](http://www.eclipse.org/webtools/development/arch_and_design/subsystems/SubsystemsAndFeatures.html)
    document.
  - Solve particular architecture problems.
  - Set architecture goals for a release.
  - Maintain a wiki page dedicated to architecture
    [WTP_Architecture_Working_Group](WTP_Architecture_Working_Group "wikilink")
  - Maintain and evolve the
    [WTP_API_Policy](WTP_API_Policy "wikilink")

[WTP_Roles](Category:WTP_Roles "wikilink")