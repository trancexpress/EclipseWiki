## Web Tools Compatibility Test Information

  - WTP 1.5 \<-\> WTP 2.0 Background Information

:\*<u>WTP 1.5 -\> WTP 2.0</u>

::\*Each team should create a test scenario to load projects or
artifacts from WTP 1.5 and attempt to load, display, edit, and run them
on a WTP 2.0 workspace. The links should be published here.

::\*Possible coordinated compatibility JUnit which will run as part of
the builds where each team can add 1.5 metadata or projects and methods
to exercise their function on WTP 2.0. Java EE team has a current JUnit
to be used as an example.

::\*Workspace migration testing will mainly consist of a few workspaces
with multiple types of content, settings, and a lot of views and
perspectives open.

::\*Questions remain about what exactly we need to test and we will have
to gather feedback from each component team. Be wary of anything written
out to settings or extension point changes.

:\*<u>WTP 2.0 -\> WTP 1.5</u>

::\*We should support shared projects in a team environment where one
user is on WTP 1.5 and one is on WTP 2.0, so we will need some backwards
compatibility testing.

  - Compatibility Test Table

<table>
<caption>December 18, 2006</caption>
<thead>
<tr class="header">
<th><p>Component</p></th>
<th><p>Platform(s)</p></th>
<th><p>Compatibility Test Coverage</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td><p>Java EE</p></td>
<td><p>Windows or Linux</p></td>
<td><ul>
<li>Create a Dynamic Web Project with WTP 1.5.x.</li>
<li>Create an EJB Project with WTP 1.5.x.</li>
<li>Create an Enterprise Application Project with WTP 1.5.x.</li>
<li>Reopen workspace with WTP 2.0.</li>
<li>Verify that everything appears correctly in the Project Explorer in the J2EE Perspective (deployment descriptor node appears and expands to reveal proper contents, java containers are present and appear correct)</li>
</ul>
<ul>
<li>Create a Dynamic Web Project (2.2-2.4) with WTP 2.0.</li>
<li>Create an EJB Project (1.1-2.1) with WTP 2.0.</li>
<li>Create an Enterprise Application Project (1.2-1.4) with WTP 2.0.</li>
<li>Reopen workspace with WTP 1.5.x.</li>
<li>Verify that everything appears correctly in the Project Explorer in the J2EE Perspective (deployment descriptor node appears and expands to reveal proper contents, java containers are present and appear correct)</li>
</ul></td>
</tr>
<tr class="odd">
<td><p>JSF</p></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td><p>JPA</p></td>
<td></td>
<td><p>At this time it is not planned for Dali 1.0 to be backward compatible to the 0.5 tech preview release.</p></td>
</tr>
<tr class="odd">
<td><p>Server</p></td>
<td><p>Windows or Linux</p></td>
<td><ul>
<li>Create server and one or more projects in WTP 1.5.x. Include a runnable JSP, servlet, or html file.</li>
<li>Use Run on Server and make sure the web browser appears.</li>
<li>Reopen workspace with WTP 2.0.</li>
<li>Make sure the server still appears in the servers view, the project is added to the server.</li>
<li>Use Run on Server and make sure it still works.</li>
</ul></td>
</tr>
<tr class="even">
<td><p>Web Services</p></td>
<td><p>Windows XP</p></td>
<td><ul>
<li>Create top-down, bottom-up Web service and Web service client with WTP 1.5.2.</li>
<li>Open up WTP 1.5.2 workspace with WTP 2.0 driver.
<ul>
<li>Ensure that Web services and Web service client still works.</li>
<li>Go through creating top-down/bottom-up Web service and Web service client again on existing projects and ensure that they work.</li>
<li>Save WTP 2.0 workspace.</li>
</ul></li>
<li>Re-open WTP 2.0 workspace in WTP 1.5.2.
<ul>
<li>Ensure that Web services and Web service client still works.</li>
<li>Go through creating top-down/bottom-up Web service and Web service client again on existing projects and ensure that they work.</li>
</ul></li>
</ul></td>
</tr>
<tr class="odd">
<td><p>XML and JSP</p></td>
<td><p>Windows or Linux</p></td>
<td><ul>
<li>Create Dynamic Web Project that contains a CSS, HTML, JSP, and JSPF file with WTP 1.5.x.</li>
<li>Set some properties for the files and project using the JSP Fragment and Web Content Settings Properties pages.
<ul>
<li>Ensure the properties are followed.</li>
</ul></li>
<li>Set some preferences in the Structured Text Editors, CSS/DTD/HTML/JavaScript/JSP/XML Files, and Task Tags preference pages. (Include creating some templates)
<ul>
<li>Ensure the preferences are followed.</li>
</ul></li>
<li>Create some snippets in the Snippets view.
<ul>
<li>Ensure the snippets show up in the Snippets view.</li>
</ul></li>
<li>Open up WTP 1.5.x workspace with WTP 2.0 driver.</li>
<li>Verify changes made in the 1.5.x workspace still work in 2.0.</li>
<li>Change some preferences &amp; properties</li>
<li>Open workspace back up in WTP 1.5.x and make sure everything still works.</li>
</ul></td>
</tr>
</tbody>
</table>

[Category:Eclipse Web Tools Platform
Project](Category:Eclipse_Web_Tools_Platform_Project "wikilink")
[WTP_Testing_Related](Category:WTP_Testing_Related "wikilink")