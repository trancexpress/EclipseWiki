The Education Lead is responsible for enabling and educating WTP
end-users by providing them quality resources for self-learning, and
increase WTP awareness and usage by obtaining, creating, and
coordinating, materials for tutorials, articles, webinars, and other
digital mediums.

The lead will:

  - Organizing exisiting materials and soliciting tutorials and articles
    from community.
  - Help design educational curricula to teach WTP in collaboration with
    the ECESIS project.
  - Recruit educators and contributors to create and share educational
    materials that demonstrate the use and extensions of WTP.
  - Promote and coordinate WTP tutorials activities in conferences,
    summits and user groups.
  - Coordinate and assist contributers to keep educational materials
    updated with new releases of WTP.
  - Maintain a wiki page dedicated to WTP Education
  - Provide feedback to make WTP more accessible and help improve
    usability
  - Promote the use of labs/examples from these materials for
    smoke-testing, provide quality feedback.

[WTP_Roles](Category:WTP_Roles "wikilink")