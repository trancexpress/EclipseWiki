## Web Tools 2.0.1 Shutdown Functional Tests -- September 13, 2007



\===Instructions===

  -
    <i><b> Teams: Please add a link or some brief descriptions of your
    test plans for WTP 2.0.1 shutdown. We want to ensure all teams
    update this information and execute their test plans before we
    declare WTP 2.0.1. This does not have to be anything extravagant,
    but we need to know some testing will be done.</b></i>

### Test Matrix

| Component    | Platform(s)   | Functional Coverage                                                                                                                                                                                                                                                                                                                                                                                              | Results                                                     |
| ------------ | ------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------- |
|              |               |                                                                                                                                                                                                                                                                                                                                                                                                                  |                                                             |
| Java EE      | Win XP        | Adhoc & smoke tests, Verifying all 201 fixes.                                                                                                                                                                                                                                                                                                                                                                    | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif") |
| JSF          | Win XP        | Smoke Tests, verifying bug fixes, ad-hoc testing                                                                                                                                                                                                                                                                                                                                                                 | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif") |
| JPA          | Win XP        | Smoke tests, Ad-hoc tests, verifying fixes                                                                                                                                                                                                                                                                                                                                                                       | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif") |
| Server       | Win XP        | Adhoc & smoke tests, testing within a WTP adopter product                                                                                                                                                                                                                                                                                                                                                        | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif") |
| Web Services | Win XP, Linux | Adhoc & smoke tests, some FVT testing within a WTP adopter product. Verifying fixes.                                                                                                                                                                                                                                                                                                                             | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif") |
| WSDL         | Win XP        | Adhoc, smoke tests, and verifying 2.0.1 fixes                                                                                                                                                                                                                                                                                                                                                                    | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif") |
| XML/JSP/XSD  | Win32 & Linux | [verify SSE bugs fixed in WTP 2.0.1](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&classification=WebTools&product=Web+Tools&component=jst.jsp&component=wst.css&component=wst.dtd&component=wst.html&component=wst.javascript&component=wst.sse&component=wst.xml&target_milestone=2.0.1+M201&resolution=FIXED) [SSE Smoke Test Scenario](SSE_Smoke_Test_Scenario "wikilink") & adhoc testing | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif") |

September 13, 2007


;[Back to the WTP Functional Test Main
Page](WTP_Functional_Test "wikilink")

  - [Back to the WTP Main Page](Web_Tools_Project "wikilink")