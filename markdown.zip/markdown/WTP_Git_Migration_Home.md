This document will serve as the home page for content related to the
migration of WTP projects to [Git](http://git-scm.com/), a free & open
source, distributed version control system.

## Check list

  - [WTP Git Migration
    Checklist](WTP_Git_Migration_Checklist "wikilink")

## Mailing list

  - [Eclipse Git Mailing
    List](https://dev.eclipse.org/mailman/listinfo/git) - Git related
    discussions, specifcally migration help for projects at Eclipse.org

## WTP Git WorkFlows

  - [WTP Git Workflows](WTP_Git_Workflows "wikilink") - Git/Egit for
    common workflows in WTP

## Learning Materials

### Books

  - [Git Community Book](http://book.git-scm.com/) - The open Git
    resource pulled together by the whole community
  - [Pro Git](http://progit.org/book/) - Another free book for Git

### Wiki Pages

  - [EGit User Guide](http://wiki.eclipse.org/EGit/User_Guide)
  - [Git for Eclipse
    Users](http://wiki.eclipse.org/EGit/Git_For_Eclipse_Users)
  - [Migrating to Git](http://wiki.eclipse.org/Git/Migrating_to_Git)
  - [Handling Git
    Contributions](http://wiki.eclipse.org/Development_Resources/Handling_Git_Contributions)
    - Committer/Contributor IP process with Git
  - [Git
    workflows](http://wiki.eclipse.org/Platform-releng/Git_Workflows) -
    Git equivalents for common CVS workflows used by the Eclipse Project

### Blogs

  - [Git for Eclipse
    Users](http://alblue.bandlem.com/2010/02/git-for-eclipse-users.html)
  - [Continuous Integration with PDE Build and
    Git](http://eclipsesource.com/blogs/2011/09/08/announcing-a-full-featured-pde-build-example-from-a-git-repository/)

### Videos

  - [Linus Torvalds on Git](http://www.youtube.com/watch?v=4XpnKHJAok8)
  - [Introduction to Git with Scott Chacon of
    GitHub](http://youtu.be/ZDR433b0HJY)

## Other

  - [Git Mirror for Eclipse CVS](http://dev.eclipse.org/git/) - All CVS
    repositories at Eclipse.org are mirrored on a read-only Git server.
    This is useful for playing with Git before migrating your project.
  - [WTP Committers Readiness For
    Git](WTP_Committers_Readiness_For_Git "wikilink")
  - [Countdown to CVS becoming
    Read-Only](http://eclipse.org/projects/scmcountdown.php)
  - [Git settings used by the Eclipse
    Project](http://dev.eclipse.org/mhonarc/lists/eclipse-dev/msg09224.html)
  - [Gerrit](https://git.eclipse.org/r/), a web-based tool for receiving
    and reviewing Git submissions, now available at Eclipse
  - [Git Magic](http://www-cs-students.stanford.edu/~blynn/gitmagic/)
  - A [Git Reference](http://gitref.org/), courtesy of the GitHub Team

[Eclipse_Web_Tools_Platform_Project](Category:Eclipse_Web_Tools_Platform_Project "wikilink")