Processes below have not been adopted by Eclipse or WTP and are
currently under development. They are here for the purpose of
collaboration and openness.

### Process to serve as a member of a standards or expert group on behalf of an Eclipse project

1.  Committer notifies their PMC with a request to serve or nomination
    of another to serve as a member of a standards or specification
    group.
    1.  This request should be sent to the PMC mailing list and should
        include the details of which group they intend to join, and why
        this makes sense from an Eclipse perspective.
2.  The PMC should evaluate the appropriateness of the request and grant
    approval or disapproval using standard PMC voting procedures.
    1.  The PMC should evaluate whether the standards or specification
        group is appropriate for Eclipse involvement (this determination
        will ultimately be made by the foundation, but the PMC can
        direct this request to the EMO).
    2.  The PMC should evaluate whether the standard or specification
        group focus is the right fit for the project, subproject, or
        component.
    3.  Disapproval should come with an explanation on why the request
        was denied. Appeals can be made to the EMO.
3.  Upon PMC approval, a formal nomination should be made within the
    applicable Eclipse project, subproject, or component.
    1.  The individual should be nominated or can request nomination.
        This nomination should be made on the developer mailing list (or
        other applicable tool).
    2.  This vote should follow the committer voting process for a given
        Eclipse project. +1 (yes), -1 (no, or veto), and 0 (abstain) /
        project voting time limits
4.  Upon a successful vote from applicable committers, the PMC should
    confirm the results of the vote and seek a final approval from the
    EMO.
    1.  The PMC Lead should send all relevant information associated
        with the request and the PMC's approval of the request to the
        EMO.
5.  The EMO reviews the request and approves or disapproves it, after
    which they inform the PMC and nominee of the decision. Disapprovals
    should come with an explanation on why the request was denied.
    1.  The EMO should evaluate whether or not Eclipse is able to
        participate in the given standards or specification organization
        and whether the specific group meets the standards set forth in
        the "[Eclipse Foundation Policy on Interacting with Standards
        and Specification
        Organizations](http://www.eclipse.org/org/documents/Eclipse_SpecOrgs_final.pdf)"
        document.
    2.  The EMO should confirm that the appropriate procedures were
        followed.
6.  After all Eclipse approvals have been granted, the nominee can
    pursue the nomination process of the given group with the assistance
    of the (Eclipse Representative?) to the standards or specification
    organization.