## Web Tools 2.0 Smoke Test Results

<table>
<caption>This Week's Results</caption>
<thead>
<tr class="header">
<th><p>Component</p></th>
<th><p>Result</p></th>
<th><p>Initials/Comments</p></th>
</tr>
</thead>
<tbody>
<tr class="odd">
<td></td>
<td></td>
<td></td>
</tr>
<tr class="even">
<td><p>Java EE</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>ccc</p></td>
</tr>
<tr class="odd">
<td><p>JSF</p></td>
<td><figure>
<img src="Questionmark.gif" title="Image:Questionmark.gif" alt="" /><figcaption>Image:Questionmark.gif</figcaption>
</figure></td>
<td></td>
</tr>
<tr class="even">
<td><p>JPA</p></td>
<td><figure>
<img src="Questionmark.gif" title="Image:Questionmark.gif" alt="" /><figcaption>Image:Questionmark.gif</figcaption>
</figure></td>
<td></td>
</tr>
<tr class="odd">
<td><p>Server</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>AV</p></td>
</tr>
<tr class="even">
<td><p>Web Services, WSDL</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Checkmark.gif" width="12" alt="Checkmark.gif" /> Web Services (mh) <img src="Checkmark.gif" title="fig:Checkmark.gif" width="12" alt="Checkmark.gif" /> WSDL (rm)</p>
<p>(<a href="https://bugs.eclipse.org/bugs/show_bug.cgi?id=176767">176767</a> fails our smoke test, but this is a base bug)</p></td>
</tr>
<tr class="odd">
<td><p>XML, JSP, XSD</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Checkmark.gif" width="12" alt="Checkmark.gif" /> XSD (kc) <img src="Checkmark.gif" title="fig:Checkmark.gif" width="12" alt="Checkmark.gif" /> XML+JSP (aw)</p>
<p>(<a href="https://bugs.eclipse.org/bugs/show_bug.cgi?id=176767">176767</a> fails our smoke test, but this is a base bug)</p></td>
</tr>
</tbody>
</table>

`Smoke Test Passed = `![`Image:Checkmark.gif`](Checkmark.gif
"Image:Checkmark.gif")
`Smoke Test Failed = `![`Image:Fail.gif`](Fail.gif "Image:Fail.gif")
`Smoke Test Pending = `![`Image:Questionmark.gif`](Questionmark.gif
"Image:Questionmark.gif")

##### [Back to the WTP Smoke Test Results Main Page](WTP_Smoke_Test_Results "wikilink")