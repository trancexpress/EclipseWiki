## Web Tools 2.0.1 Smoke Test Results

| Component          | Result                                                               | Initials/Comments                                                                                                           |
| ------------------ | -------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
|                    |                                                                      |                                                                                                                             |
| Java EE            | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif")          | ccc                                                                                                                         |
| JSF                | ![Image:Questionmark.gif](Questionmark.gif "Image:Questionmark.gif") |                                                                                                                             |
| Dali               | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif")          | njh                                                                                                                         |
| Server             | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif")          | AV                                                                                                                          |
| Web Services, WSDL | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif")          | ![Checkmark.gif](Checkmark.gif "Checkmark.gif") Web Services (kc) ![Checkmark.gif](Checkmark.gif "Checkmark.gif") WSDL (jg) |
| XML, JSP, XSD      | ![Image:Checkmark.gif](Checkmark.gif "Image:Checkmark.gif")          | ![Checkmark.gif](Checkmark.gif "Checkmark.gif") XSD (jg) ![Checkmark.gif](Checkmark.gif "Checkmark.gif") XML+JSP (team)     |

This Week's Results

`Smoke Test Passed = `![`Image:Checkmark.gif`](Checkmark.gif
"Image:Checkmark.gif")
`Smoke Test Failed = `![`Image:Fail.gif`](Fail.gif "Image:Fail.gif")
`Smoke Test Pending = `![`Image:Questionmark.gif`](Questionmark.gif
"Image:Questionmark.gif")

##### [Back to the WTP Smoke Test Results Main Page](WTP_Smoke_Test_Results "wikilink")