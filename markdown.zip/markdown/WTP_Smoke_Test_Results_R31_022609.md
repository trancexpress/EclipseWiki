## Smoke Test Promotion votes

<table>
<caption>This Week's Results</caption>
<tbody>
<tr class="odd">
<td><p>Project</p></td>
<td><p>Vote</p></td>
<td><p>Initials Comments</p></td>
</tr>
<tr class="even">
<td><p>Java EE</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>km <a href="https://bugs.eclipse.org/bugs/show_bug.cgi?id=266341">266341</a></p></td>
</tr>
<tr class="odd">
<td><p>JSF</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>da</p></td>
</tr>
<tr class="even">
<td><p>Dali</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>njh</p></td>
</tr>
<tr class="odd">
<td><p>Server</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>AV</p></td>
</tr>
<tr class="even">
<td><p>Web Services, WSDL</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />Web Services (kc)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />WSDL (mo)</p></td>
</tr>
<tr class="odd">
<td><p>Source Editing</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XML + JSP (ns)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XSD (mo)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />JSDT (cmj)</p></td>
</tr>
<tr class="even">
<td><p>Release Engineering</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><a href="https://bugs.eclipse.org/bugs/show_bug.cgi?id=266175">266175</a></p></td>
</tr>
</tbody>
</table>

`Smoke Test ok to promote vote = `![`Image:Checkmark.gif`](Checkmark.gif
"Image:Checkmark.gif")
`Smoke Test do not promote vote = `![`Image:Fail.gif`](Fail.gif
"Image:Fail.gif")
`Smoke Test Pending = `![`Image:Questionmark.gif`](Questionmark.gif
"Image:Questionmark.gif")

##### [Back to the WTP Smoke Test Results Main Page](WTP_Smoke_Test_Results "wikilink")