## Smoke Test Promotion votes

<table>
<caption>This Week's Results</caption>
<tbody>
<tr class="odd">
<td><p>Project</p></td>
<td><p>Vote</p></td>
<td><p>Initials Comments</p></td>
</tr>
<tr class="even">
<td><p>Java EE</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>KR, VP, ccc retested w/ 20100527211052</p></td>
</tr>
<tr class="odd">
<td><p>JSF</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>da</p></td>
</tr>
<tr class="even">
<td><p>Dali</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>njh</p></td>
</tr>
<tr class="odd">
<td><p>Server</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>EY</p></td>
</tr>
<tr class="even">
<td><p>Web Services, WSDL</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />Web Services (wm)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />WSDL (wm)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />JAXWS (sc)</p></td>
</tr>
<tr class="odd">
<td><p>JSDT</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>cmj</p></td>
</tr>
<tr class="even">
<td><p>Source Editing</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XML + JSP (ns) Note: two likely intermittent failures appeared in the latest build. They have before and continue to succeed when run locally.</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XSD (wm)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XSL (nd) No changes since M7.</p></td>
</tr>
<tr class="odd">
<td><p>Release Engineering</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td></td>
</tr>
</tbody>
</table>

`Smoke Test ok to promote vote = `![`Image:Checkmark.gif`](Checkmark.gif
"Image:Checkmark.gif")
`Smoke Test do not promote vote = `![`Image:Fail.gif`](Fail.gif
"Image:Fail.gif")
`Smoke Test Pending = `![`Image:Questionmark.gif`](Questionmark.gif
"Image:Questionmark.gif")

##### [Back to the WTP Smoke Test Results Main Page](WTP_Smoke_Test_Results "wikilink")