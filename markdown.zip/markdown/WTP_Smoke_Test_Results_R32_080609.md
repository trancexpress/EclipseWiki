## Smoke Test Promotion votes

<table>
<caption>This Week's Results</caption>
<tbody>
<tr class="odd">
<td><p>Project</p></td>
<td><p>Vote</p></td>
<td><p>Initials Comments</p></td>
</tr>
<tr class="even">
<td><p>Java EE</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>DG - Win XP</p></td>
</tr>
<tr class="odd">
<td><p>JSF</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>da</p></td>
</tr>
<tr class="even">
<td><p>Dali</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>njh</p></td>
</tr>
<tr class="odd">
<td><p>Server</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>AV</p></td>
</tr>
<tr class="even">
<td><p>Web Services, WSDL</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />Web Services (rl)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />WSDL (rl)</p></td>
</tr>
<tr class="odd">
<td><p>Source Editing</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XML + JSP (amk)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XSD (rl)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />JSDT (nsd)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XSL (dac)</p></td>
</tr>
<tr class="even">
<td><p>Release Engineering</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>(DW)</p></td>
</tr>
</tbody>
</table>

`Smoke Test ok to promote vote = `![`Image:Checkmark.gif`](Checkmark.gif
"Image:Checkmark.gif")
`Smoke Test do not promote vote = `![`Image:Fail.gif`](Fail.gif
"Image:Fail.gif")
`Smoke Test Pending = `![`Image:Questionmark.gif`](Questionmark.gif
"Image:Questionmark.gif")

##### [Back to the WTP Smoke Test Results Main Page](WTP_Smoke_Test_Results "wikilink")