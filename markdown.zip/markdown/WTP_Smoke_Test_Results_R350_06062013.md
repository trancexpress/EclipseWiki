## Smoke Test Promotion votes

Instructions:

Use a red X (fail) icon (![Image:Fail.gif](Fail.gif "Image:Fail.gif"))
to signify that the build should not be promoted, that a respin is
required. In that case, please provide bug number and be sure those that
need to fix something are aware of it, and can arrange for a respin.
Once the issue has been fixed, and confirmed, change the red X to a
green check mark with the build Id where is was verified, so those doing
the promotion know its ready to go.

If a smoke test does not pass but the build can still be promoted, use a
green check mark (ok) icon (![Image:Checkmark.gif](Checkmark.gif
"Image:Checkmark.gif")) but then document in the comments bug numbers,
how the smoke test fails, workarounds, or cautions about the build.

If a build can be promoted and no issues were found, simple use the
green check mark and include the initials or names of who performed the
test.

Remember the significant column for promoting a build is the left-most
project column. If some component within a project has not (or can not)
be tested, the Project Lead should either make sure someone does the
test, or make a judgment call on if the build (from their project's
point of view) can be promoted or not. If the smoke test could not be
performed, a note should be made in the comments section that it wasn't
performed, why, and why that should prevent promotion.

Keep in mind the threshold for promoting a build gets higher as we near
a milestone or near a release.

<table>
<caption>This Week's Results</caption>
<tbody>
<tr class="odd">
<td><p>Project</p></td>
<td><p>Vote</p></td>
<td><p>Initials Comments</p></td>
</tr>
<tr class="even">
<td><p>Java EE</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>AS</p></td>
</tr>
<tr class="odd">
<td><p>JSF</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>IMT</p></td>
</tr>
<tr class="even">
<td><p>Dali</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>NL</p></td>
</tr>
<tr class="odd">
<td><p>Server</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>SH</p></td>
</tr>
<tr class="even">
<td><p>Web Services, WSDL</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />Web Services (ad) <img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />WSDL (ad)</p>
<p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />JAXWS (sc)</p></td>
</tr>
<tr class="odd">
<td><p>JSDT</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p>JP</p></td>
</tr>
<tr class="even">
<td><p>Source Editing</p></td>
<td><figure>
<img src="Checkmark.gif" title="Image:Checkmark.gif" alt="" /><figcaption>Image:Checkmark.gif</figcaption>
</figure></td>
<td><p><img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XML + JSP (ns) <img src="Checkmark.gif" title="fig:Image:Checkmark.gif" alt="Image:Checkmark.gif" />XSD (ad)</p></td>
</tr>
<tr class="odd">
<td><p>Release Engineering</p></td>
<td><figure>
<img src="Questionmark.gif" title="Image:Questionmark.gif" alt="" /><figcaption>Image:Questionmark.gif</figcaption>
</figure></td>
<td></td>
</tr>
</tbody>
</table>



`Smoke Test ok to promote vote = `![`Image:Checkmark.gif`](Checkmark.gif
"Image:Checkmark.gif")
`Smoke Test do not promote vote = `![`Image:Fail.gif`](Fail.gif
"Image:Fail.gif")
`Smoke Test Pending = `![`Image:Questionmark.gif`](Questionmark.gif
"Image:Questionmark.gif")



##### [Back to the WTP Smoke Test Results Main Page](WTP_Smoke_Test_Results "wikilink")