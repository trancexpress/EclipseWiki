 

3rd party artifact report:
[1](http://www.eclipse.org/projects/tools/downloads.php?id=webtools)



<table>
<tbody>
<tr class="odd">
<td><p>Third party artifact</p></td>
<td><p>Location</p></td>
<td><p>Found related CQ</p></td>
<td><p>Project owner</p></td>
<td><p>Proposed Action</p></td>
<td><p>Status</p></td>
</tr>
<tr class="even">
<td><p>antlr.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/09-06-eclipseworld/t4-wtp-src.zip/TicketWeb/WebContent/WEB-INF/lib</span></p></td>
<td><p>CQ 2662</p></td>
<td><p><br />
</p></td>
<td><p>Removed - fixed link</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="odd">
<td><p>commons-beanutils.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/09-06-eclipseworld/t4-wtp-src.zip/TicketWeb/WebContent/WEB-INF/lib</span></p></td>
<td><p><font face="Arial, sans-serif"><span style="font-size: 12px; line-height: 16px;"> </span></font> <font face="Arial, sans-serif"></font> <font face="Arial, sans-serif"></font> <font face="Arial, sans-serif"></font> <font face="Arial, sans-serif"></font></p></td>
<td><p><br />
</p></td>
<td><p>Removed - Fixed link</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="even">
<td><p>commons-digester.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/09-06-eclipseworld/t4-wtp-src.zip/TicketWeb/WebContent/WEB-INF/lib</span></p></td>
<td></td>
<td><p><br />
</p></td>
<td><p>Removed - Fixed link</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="odd">
<td><p>commons-fileupload.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/09-06-eclipseworld/t4-wtp-src.zip/TicketWeb/WebContent/WEB-INF/lib</span></p></td>
<td></td>
<td><p><br />
</p></td>
<td><p>Removed - Fixed link</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="even">
<td><p>commons-logging.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/09-06-eclipseworld/t4-wtp-src.zip/TicketWeb/WebContent/WEB-INF/lib</span></p></td>
<td></td>
<td><p><br />
</p></td>
<td><p>Removed - Fixed link</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="odd">
<td><p>commons-validator.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/09-06-eclipseworld/t4-wtp-src.zip/TicketWeb/WebContent/WEB-INF/lib</span></p></td>
<td></td>
<td><p><br />
</p></td>
<td><p>Removed - Fixed link</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="even">
<td><p>derby.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/03-20-eclipsecon/WTPTutorialExamples.zip/examples/quicktour/iteration3/part3/Project1/WebContent/WEB-INF/lib</span></p></td>
<td></td>
<td><p>Chuck B</p></td>
<td><p>Remove the jar from presentation</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="odd">
<td><p>jakarta-oro.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/09-06-eclipseworld/t4-wtp-src.zip/TicketWeb/WebContent/WEB-INF/lib</span></p></td>
<td></td>
<td><p><br />
</p></td>
<td><p>Removed - Fixed link</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="even">
<td><p>jstl.jar</p></td>
<td><p>/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/09-06-eclipseworld/t4-wtp-src.zip/TicketWeb/WebContent/WEB-INF/lib<br />
</p></td>
<td></td>
<td><p><br />
</p></td>
<td><p>Removed - Fixed link</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="odd">
<td><p>org.antlr.runtime_v31_3.1.0.*.jar</p></td>
<td><p>Many...  </p>
<p>/home/data/httpd/download.eclipse.org/webtools/downloads/drops/R0.7.0/S-0.7.0M1-20100112112859/xquery_sdk/updateSite/plugins</p></td>
<td><p>CQ 2662</p></td>
<td></td>
<td><p>Related CQ should cover this</p></td>
<td><p>Still need to open CQ to cover older builds</p></td>
</tr>
<tr class="even">
<td><p>standard.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/downloads/presentations/2006/09-06-eclipseworld/t4-wtp-src.zip/TicketWeb/WebContent/WEB-INF/lib</span></p></td>
<td></td>
<td><p><br />
</p></td>
<td><p>Removed - Fixed link</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="odd">
<td><p>struts.jar</p></td>
<td><p>Many...</p>
<p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/patches/drops/R1.5.5/P-P20091030023754-20091030023754/wtp-patches-tests-P-P20091030023754-20091030023754.zip/eclipse/plugins/org.eclipse.jst.jsp.ui.tests_1.0.1.v200806021550/testfiles/116523</span></p></td>
<td><p>CQ 6558</p></td>
<td><p>Nick</p></td>
<td><p>CQ opened</p></td>
<td><p>New CQ opened</p></td>
</tr>
<tr class="even">
<td><p>uddi4j.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/jpa/jsr220orm/dependency/wtp-wst-sdk-I20050809.zip/eclipse/plugins/org.uddi4j_2.0.3/lib</span></p></td>
<td></td>
<td><p>Neil</p></td>
<td><p>File has been deleted.</p></td>
<td><p>Complete</p></td>
</tr>
<tr class="odd">
<td><p>jsflibrary-api-1.1.3.*.jar</p></td>
<td><p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">Many...</span></p>
<p><span style="font-family: Arial, sans-serif; font-size: 12px; line-height: 16px; text-align: left;">/home/data/httpd/download.eclipse.org/webtools/patches/drops/R3.1.2/P-3.1.2-20100423061036/wtp-patches312-tests-P-3.1.2-20100423061036.zip/plugins/org.eclipse.jst.jsf.core.tests_1.1.206.v201004221334/testfiles/facet</span></p></td>
<td><p>CQ 1982 (was CQ 3696)</p></td>
<td><p>Raghu</p></td>
<td><p>CQ 1982 is more appropriate. Waiting to hear from EMO. The existing CQ 3696 is for a "workswith" dependency. Workswith dependencies should not be directly distributed from eclipse.org. May need new CQ (Test and Build). Note that a "test and build" dependency is a specialization of "workswith" and cannot be distributed from eclipse.org.</p></td>
<td><p>Test/stub jar being removed from Juno builds - tracked by Bug 381931</p></td>
</tr>
</tbody>
</table>