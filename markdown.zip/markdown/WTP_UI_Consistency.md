The WTP UI consistency effort focuses on the consistency of the WTP user
interfaces (all pieces including, but not limited to, editors, menu
contributions, views, preference pages, properties pages and wizards)
with the Eclipse platform and the various operating systems (the UI
should be consistent with the OS).

This effort also handles UI usability improvements, such as those that
can be seen in the XSD and WSDL editors and Web services wizard.

## Team

[Lawrence Mandel](http://www.eclipse.org/webtools/people/mandel.html)

Janet Mockler

May Zhu

## Component Work

### WSDL Editor: improve look and feel

Development contacts: [Craig
Salter](http://www.eclipse.org/webtools/people/salter.html), [Richard
Mah](http://www.eclipse.org/webtools/people/mah.html)

Status: In progress

[Open
Bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=%5BUI_Consistency%5D&classification=WebTools&product=Web+Tools&component=wst.wsdl&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=)
| [Resolved
Bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=%5BUI_Consistency%5D&classification=WebTools&product=Web+Tools&component=wst.wsdl&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=RESOLVED&bug_status=VERIFIED&bug_status=CLOSED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

The improvement of the look and feel of the WSDL editor has already
begun. Significant changes can be seen in WTP 1.5. Further work is still
required.

TODO: break down the current design into top 10 work items for 2.0 and
create bugs.

### XSD Editor: improve the look and feel

Development contacts: [Craig
Salter](http://www.eclipse.org/webtools/people/salter.html), [Keith
Chong](http://www.eclipse.org/webtools/people/chong.html)

Status: In progress

[Open
Bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=%5BUI_Consistency%5D&classification=WebTools&product=Web+Tools&component=wst.xsd&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=)
| [Resolved
Bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=%5BUI_Consistency%5D&classification=WebTools&product=Web+Tools&component=wst.xsd&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=RESOLVED&bug_status=VERIFIED&bug_status=CLOSED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

The improvement of the look and feel of the XSD editor has already
begun. Significant changes can be seen in WTP 1.5. Further work is still
required.

TODO: break down the current design into top 10 work items for 2.0 and
create bugs.

### JSF Graphical Editor

Development contacts: Jean Choi and [Craig
Salter](http://www.eclipse.org/webtools/people/salter.html)

Status: Under investigation

This item focuses on the JSF graphical editor that will be contributed
in WTP 2.0. The importance of this item is to ensure this new editor
fits with the existing Eclipse and WTP editors.

### Validation Frameworks Preferences Page

Development contact: [Chuck
Bridgham](http://www.eclipse.org/webtools/people/bridgham.html)

Status: Under investigation

This item focuses on the validation framework preference page. Specific
difficulties that have encountered include enabling and disabling
different types (manual, build) validation and representation of
advanced validator properties. The design of this page is also currently
not consistent with that of the Eclipse preference pages due to these
advanced property requirements.

Current working suggestions: - Properties page per project - Should be
able to define preference validation files per artifact. - Across
resource types and the main validation page

### Facet wizard UI work

Development contact: [Konstantin
Komissarchik](http://www.eclipse.org/webtools/people/komissarchik.html)

Status: Under investigation

The facet wizard is currently awkward to use in that it's use may
require an end user to navigate backwards in the wizard. The facet
wizard also contains inconsistent UI use for constraints and should be
easier for new users to understand.

### WebServices wizard

Development contact: [Chris
Brealey](http://www.eclipse.org/webtools/people/brealey.html)

Status: In progress

[Open
Bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=%5BUI_Consistency%5D&classification=WebTools&product=Web+Tools&component=wst.ws&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=)
| [Resolved
Bugs](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=%5BUI_Consistency%5D&classification=WebTools&product=Web+Tools&component=wst.ws&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=RESOLVED&bug_status=VERIFIED&bug_status=CLOSED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=)

Much of this work has already been completed in WTP 1.5. Outstanding
work includes further enhancements to reduce the complexity of this
wizard in order to assist new users in creating Web services.

[Category:Eclipse Web Tools Platform
Project](Category:Eclipse_Web_Tools_Platform_Project "wikilink")