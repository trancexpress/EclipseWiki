# Eclipse Web Tools Platform Project 2.0 Plan

*Last revised 01:58, 3 April 2007 (EDT). Previous draft archived at [Web
Tools Platform 2.0 Plan](Web_Tools_Platform_2.0_Plan "wikilink")*

*Please send comments about this plan to the* wtp-pmc@eclipse.org *or*
wtp-dev@eclipse.org *mailing list.*

This document lays out the feature and API set for the next release of
The Eclipse Web Tools Platform Project, to be released as part of the
Eclipse Europa Release in June 2007, and called "WTP 2.0", for short.

The first part of the plan deals with the important matters of release
deliverables, release milestones, target operating environments, and
release-to-release compatibility. These are all things that need to be
clear for any release, even if no features were to change.

The remainder of the plan consists of plan items for the subprojects
under the Eclipse Web Tools top-level project. Each plan item covers a
feature or API that is to be added to Web Tools, or some aspect of Web
Tools that is to be improved. **Each plan item will have its own entry
in the Eclipse bugzilla database, with a title and a concise summary
(usually a single paragraph) that explains the work item at a suitably
high enough level so that everyone can readily understand what the work
item is without having to understand the nitty-gritty detail.**

The current status of each plan item is noted:

  - **Committed** plan item - A committed plan item is one that we have
    decided to address for the release.
  - **Proposed** plan item - A proposed plan item is one that we are
    considering addressing for the release. Although we are actively
    investigating it, we are not yet in a position to commit to it, or
    to say that we won't be able to address it. After due consideration,
    a proposal will either be committed or deferred.
  - **Deferred** plan item - A reasonable proposal that will not make it
    in to this release for some reason is marked as deferred with a
    brief note as to why it was deferred. Deferred plan items may
    resurface as committed plan items at a later point.
  - **Help Wanted** plan item - Typically something that started off as
    a Medium or Low priority, but marked "help wanted" as an
    acknowledgement that there are no core resources to implement the
    item, but if a company or person from the community wants to
    contribute it, then the core teams would be more willing than usual
    to consider any high quality patches or contributions made via
    bugzillas.

## Release deliverables

The release deliverables have the same form as previous releases,
namely:

  - Source code release for Eclipse WTP Project, available as versions
    tagged "R2_0_0" in the Eclipse WTP Project CVS repository
  - Eclipse WTP runtime binary and SDK download with all Eclipse
    pre-reqs (downloadable).
  - Eclipse WTP runtime binary and SDK download (downloadable).

In addition, the Eclipse WTP runtime binary and SDK will be available as
part of the "Europa" update site as well as our own Web Tools Platform
update site.

## Release milestones and release candidates

Release milestones will occur at roughly 6 week intervals in
synchronization with the Eclipse Platform milestone releases (starting
with M1) and will be compatible with Eclipse 3.3 builds. See [Europa
Simultaneous Release](Europa_Simultaneous_Release "wikilink") for the
complete Europa schedule. The following are the *approximate* dates for
WTP milestones. The *approximate* 1.5.x maintenance release dates are
given too. The exact dates will be updated as the times grow nearer.

  - M1:Friday, Sep 1, 2006
    Theme: run on Eclipse 3.3 stream

  - 1.5.1:September 29, 2006
    M2:Friday Oct 6, 2006
    Theme: run on Eclipse 3.3 stream

  - 1.5.2:October 31, 2006
    M3:Friday Nov 17, 2006
    Theme: Cleanup warnings, JUnits, Analyze Adopter Usage Reports

  - M4:Friday Jan 4, 2006
    Theme Propose/implement APIs/Features

  - 1.5.3:Friday February 16, 2007
    M5:Friday Feb 23, 2007 (EclipseCon is 3/5)
    Theme: provide good base for EclipseCon demos\! :)

    Most Function and API complete (e.g. 80%)

  - M6:Friday Apr 6, 2007
    Theme: Function complete. API Freeze

  - RC0:Friday May 18, 2007
    Theme: from M6 to RC1 will be polish, bug fixes, documentation

  - other RCs:TBD
    (June 22, latest final build)

  - Release:June 29, 2007

## Target Operating Environments

The Eclipse WTP Project is mainly tested and validated on Windows
platforms, it should run on all platforms validated by the Eclipse
Platform project:

[Eclipse Target Operating
Environments](http://www.eclipse.org/eclipse/development/eclipse_project_plan_3_3.html#TargetOperatingEnvironments)

#### Java version

The 2.0 release of the Eclipse WTP Project is written and compiled
against an appropriate version of Java as specified by the Execution
Environment of each plugin. In general, Java 5 of the Java Platform
(Java SE 5.0) will be needed to use WTP as a whole, but, the Execution
Environment will be specified for each plugin, starting at J2SE 1.4,
which is the current requirement, and then only moved up to Java SE 5
when some change made that requires it. WTP adopters should expect that
full functionality will require running on a Java SE 5. Servers
integrated into Eclipse WTP deliverables will be tested and validated on
the same platforms listed above. Tests for other platforms will be
relying on the community support.

#### Dependencies on other Eclipse Projects

  - Eclipse Platform (Platform, JDT, PDE) 3.3
  - Eclipse Modeling Framework (EMF, XSD InfoSet, SDO) 2.3
  - Graphical Editing Framework (GEF) 3.3
  - Data Tools Platform (DTP) 1.5

#### Internationalization

The Eclipse WTP Project is designed as the basis for internationalized
products. The user interface elements provided by the Eclipse SDK
components, including dialogs and error messages, are externalized. The
English strings are provided as the default resource bundles. Other
language support, if any, will rely on the community support.

## Compatibility with Other WTP Releases

Workspace Compatibility:

  - WTP 2.0 should be able to open workspaces created or used with WTP
    1.5. That is, there may be some views or preferences that are not
    preserved, but there should be no outright failures to open and use
    the workspace.

Project Compatibility:

  - WTP 2.0 should be usable in a team environment where some team
    members use WTP 1.5 and team members share projects through a source
    code control system such as CVS or Subversions. Specifically, A WTP
    1.5 user should be able to create a project, check it in to the
    repository. A WTP 2.0 user should be able to check it out, work on
    it, and check it back in. A WTP 1.5 should then be able to check it
    back out and continue to work it on. For examples of how we test
    this, see [WTP Compatibility
    Tests](WTP_Compatibility_Tests "wikilink")
  - By default, WTP 1.5 should work on projects created by WTP 2.0 users
    and shared via a repository. Artifacts created by WTP 2.0 that are
    consistent with 1.5 features should not break WTP 1.5, and where
    possible WTP 1.5 should either ignore or tolerate any new artifacts
    in WTP 2.0 and subsequent releases. Attempts to use (or convert to)
    new 2.0 functionality that cannot be made backwards compatible with
    1.5 must be clearly identified in documentation.

API Compatibility:

  - WTP 2.0 will preserve (public, declared) API compatibility with the
    1.5 release, both in terms of syntax and behavior
  - A plug-in that is developed on WTP 1.5 and that uses no non-API
    methods should run correctly without recompilation on WTP 2.0
  - A plug-in that is developed on WTP 1.5 and that uses no non-API
    methods should recompile without error on WTP 2.0
  - WTP 2.0 should provide migration notes and adequate notification and
    lead time to adopters for any API or non-API code that is removed or
    changed in WTP 2.0
  - WTP 2.0 should continue to provide adopters with the ability to
    register their code usage reports and to be consulted in any
    proposed changes to non-API code. WTP will take into account adopter
    feedback on proposed changes to non-API code, but reserves the right
    to change non-API notwithstanding that feedback.
  - All of the above statements are subject to the [documented WTP
    Development
    processes](http://www.eclipse.org/webtools/devProcess/devProcess.html)
    which clarify the procedures and review processes for making changes
    to API and non-API which is clearly used by adopters, according to
    registered code scans.

Prerequisite Version Compatibility:

  - Eclipse WTP 2.0 deliverables will be compatible with the Europa
    Version of Eclipse and WTP pre-reqs. No special attention will give
    for being compatible with previous Eclipse versions. But, our
    pre-req version ranges will be accurate. That is, in some places, we
    have found it necessary to use non-API from the base platform, and
    therefore will (correctly) defined narrow prerequisite version
    ranges for those cases.

## Eclipse WTP Subprojects

The Eclipse WTP consists of four subprojects. Each subproject is covered
in its own section:

[Web Standard Tools (WST)](http://eclipse.org/webtools/wst/main.html)

[J2EE Standard Tools (JST)](http://eclipse.org/webtools/jst/main.html)

[JavaServer Faces Tools (JSF
Tools](http://www.eclipse.org/webtools/jsf/index.html), graduated as a
new component in JST

[JPA (Dali/JPA](http://www.eclipse.org/dali)\], graduated as a new
subproject

[AJAX Tools Framework](http://www.eclipse.org/atf/)\], incubating and
hence will not be part of the WTP 2.0 release

## Major themes

### Improve Quality

Focused effort will be made to reduce bug backlog, improving test
coverage, performance and performance testing, ISV documentation and
examples, usability and UI consistency.

### Adopter readiness

  - Extensibility

<!-- end list -->

  -
    Provide extension points for adopters to add-in implementation
    functionality, such as for JEE5 features, publishing support, add to
    project creation pages, etc.

<!-- end list -->

  - improve API coverage

<!-- end list -->

  -
    Convert provisional APIs in a careful, well reviewed way, to
    minimize adopter breakage

### Improved Provisioning of Third Party Content

**Committed Items**

  - Participate in Orbit project to move our commonly needed third-party
    content to a common Eclipse repository.

<!-- end list -->

  -
    We have moved Axis, WSDL and releated bundles, moved Xerces, and
    adopted use of many Orbit bundles, such as javax.servlet, ant,
    junit, etc.

<!-- end list -->

  - Provide improved server-adapter support so server providers can more
    independently provide their adapters to WTP users.

**Proposed Items**

  -
**Deferred Items**

  - Help create remote Update Manager sites hosted by providers of third
    party content required by WTP to streamline the process of adopting
    new versions

<!-- end list -->

  -
    users should be able to acquire revisions of third party content in
    a more timely fashion
    begin by creating a common site at Apache for components such as
    Axis2, Woden, Tomcat, Geronimo

<!-- end list -->

  - assist, if needed, to create new site at ObjectWeb for Jonas

### Help Content

**Committed Items**

  - content updates
  - index improvements
  - [179863](https://bugs.eclipse.org/bugs/show_bug.cgi?id=179863)
    footprint reduction
  - [96465](https://bugs.eclipse.org/bugs/show_bug.cgi?id=96465)
    performance improvements

**Proposed Items**

  -
**Deferred Items**

  - work with DITA-OT project at SourceForge to improve integration of
    build process with PDE
  - \[[153134](https://bugs.eclipse.org/bugs/show_bug.cgi?id=153134)
    [161783](https://bugs.eclipse.org/bugs/show_bug.cgi?id=161783) \] -
    Increase server coverage
  - [143586](https://bugs.eclipse.org/bugs/show_bug.cgi?id=143586) -
    Welcome Page Contribution

### Architectural harmonization

#### Eclipse Platform

**Committed Items**

  - Move Internet Proxy settings and preferences to base platform

**Proposed Items**

  -
**Deferred Items**

  - Use Platform provided Undoable Operations framework (instead of the
    one from EMF) in our editors

#### DTP

**Committed Items**

  - Removed all Relational Database access tools (RDB) from WTP and
    instead use the corresponding components from DTP.

<!-- end list -->

  -
    JST has only a small dependency on DTP which was made optional. JPA
    (Dali), has stronger dependency on DTP, so, DTP is listed as one of
    the pre-reqs for WTP as a whole. But, if JPA is not installed then
    DTP will not be required.

**Proposed Items**

  -
**Deferred Items**

  -
#### STP

**Committed Items**

  -
**Proposed Items**

  -
**Deferred Items**

  - Investigate areas of overlap with STP, especially in the areas of
    Web services, and ensure that existing WTP components can be
    extended as required by STP.

#### TPTP

**Committed Items**

  - Improve integration with TPTP in the area of profiling servers,
    providing a generic extension point to allow TPTP additional support
    for profiling servers.

**Proposed Items**

  -
**Deferred Items**

  -
#### PHP Tools Project

**Committed Items**

  - HTTP Server support provided in wst.server (in principle, doesn't
    need to be provided by PHP Tools).

**Proposed Items**

  -
**Deferred Items**

  - Investigate if other generic components currently in the PHP project
    should be moved in WTP.
  - Need to investigate and support their use of our SSE Incremental DOM
    parser and A.) not break them :) or B.) provide API.

#### JEM

**Committed Items**

  - Move the JEM component of VE to be a component of JST (This is for
    maintenance, no enhancements planned).

**Proposed Items**

  -
**Deferred Items**

  -
## Web Standard Tools subproject

### Common WST Component

**Committed Items**

  - [175171](https://bugs.eclipse.org/bugs/show_bug.cgi?id=175171) -
    Move the Internet proxy page down to Eclipse platform
    ([154100](https://bugs.eclipse.org/bugs/show_bug.cgi?id=154100)) and
    remove the page from WTP.

**Proposed Items**

  -
**Deferred Items**

### XML Editing

**Committed Items**

  - QuickFix (for Spelling problems at minimum)
  - Improved formatting, e.g. whitespace handling

**Deferred Items**

  - Large document performance enhancements
  - Configurable Code folding
  - Migrate to Platform Undo (IOperationHistory)
  - Run in Eclipse RCP
  - Support for EFS
  - WYSIWYG (for DITA, DocBook, etc.)

### Web Services Support

**Committed Items**

  - [117034](https://bugs.eclipse.org/bugs/show_bug.cgi?id=117034) -
    SOAP Header support in the Web Services Explorer.
  - [173552](https://bugs.eclipse.org/bugs/show_bug.cgi?id=173552) -
    Update from Axis 1.3 to 1.4.
  - [176493](https://bugs.eclipse.org/bugs/show_bug.cgi?id=176493) -
    Make the transport / message stack pluggable in the Web Services
    Explorer.

**Proposed Items**

  -
**Deferred Items**

  -
## Java EE Standard Tools

### Common JST

**Committed Items**

  - Publish/export support for classpath entries: Allows the resolved
    contributions from Java classpath entries (classpath containers,
    libraries and variables) to be added to the published (or exported)
    structure of Java EE module projects.

**Proposed Items**

  -
**Deferred Items**

  -
### Java EE 5

**Committed Items**

  - Provide extensibility for providers of JEE5 implementations
  - Support for basic JEE5 module and project types
      - Web 2.5
      - Ejb 3.0
      - Ear 5.0
  - Publish JEE5 Projects to compliant runtimes
  - Support for JEE5 namespaces in XML-based deployment descriptors
      - Limited model support

**Proposed Items**

  - investigate: import a JEE5 project (help wanted)
  - investigate: export JEE5 project (help wanted)

**Deferred Items**

  - Java EE 5 models - the models must be upgraded to handle Java EE 5
    without ANY API breakage. Existing clients MUST continue to work
    without recompilation. If existing clients are recompiled with the
    new model, then compilation errors MUST NOT occur (note: we assume
    that existing clients will not break in any way if they only use the
    published API - code that relies on internal interfaces MAY break)
  - JSR 175 - support Java EE 5 specifications for annotation based
    programming, e.g. for EJB 3.0, JPA, Web services
      - JSR 181 - Web Services
      - JSR 220 - EJB 3.0, JPA
  - validate a JEE5 project (help wanted)

### JSF

**Committed Items**

  - Web Page Editor
      - Multi-page Editor
      - Visual JSF-JSP Page Designer
          - Support for JSF RI components
          - Extensibility framework to simplify adding support for other
            component libraries
      - Preview Page
      - Enhanced Source Editor gives content assists and provides both
        syntax and semantic validations
      - JSF Validation
  - Faces Configuration Model, Editor and Wizards
      - Multi-page Editor
      - Graphical diagram editor for navigational rules
      - EMF model of the application configuration resource file
  - JSF Library Registry
      - Manage a named collection of JARs including tag libraries, JSF
        reference implementations and utility jars
  - Extensible Frameworks
      - Design-time Meta-data Framework
      - Design-time Tag Processor
      - Design-time Application Manager
      - JSF Application Configuration Manager
  - Support for JavaServer Faces 1.1 and 1.2 versions

**Proposed Items**

  -
**Deferred Items**

  - [157233](https://bugs.eclipse.org/bugs/show_bug.cgi?id=157233) Faces
    Confid Editor UI support for JSF 1.2 elements
  - [183302](https://bugs.eclipse.org/bugs/show_bug.cgi?id=183302) Web
    Page Editor doesn't support XML format JSPX file

### JSP

**Committed Items**

  - Improved JSP 2.0 support
    [124288](https://bugs.eclipse.org/bugs/show_bug.cgi?id=124288)
      - Use of tag/tagx files (packaged according to JSP-8.4.3 only)
      - Editing and debugging of tag/tagx files
      - Included prelude and coda segments specified from web.xml

**Deferred Items**

  - File encoding specified from web.xml
    [104785](https://bugs.eclipse.org/bugs/show_bug.cgi?id=104785)
  - Support JSP 2.1

### Web Services

**Committed Items**

  - [176489](https://bugs.eclipse.org/bugs/show_bug.cgi?id=176489) -
    Have Web services popups exploit IAdapterManager so that adopters
    can define an adaptor to handle a custom type and still reuse the
    Web services popup.
  - [176580](https://bugs.eclipse.org/bugs/show_bug.cgi?id=176580) -
    Generate a Web service client proxy accepting URL as a constructor.
  - [165664](https://bugs.eclipse.org/bugs/show_bug.cgi?id=165664) -
    Integrate Apache Axis2 into WTP. This includes the following child
    RFEs:
      - [168762](https://bugs.eclipse.org/bugs/show_bug.cgi?id=168762) -
        Create Axis2 bottom-up and top-down Java Web service.
      - [172186](https://bugs.eclipse.org/bugs/show_bug.cgi?id=172186) -
        Create Axis2 Web service client.
      - [168765](https://bugs.eclipse.org/bugs/show_bug.cgi?id=168765) -
        User-specified Axis2 runtime location.
      - [168766](https://bugs.eclipse.org/bugs/show_bug.cgi?id=168766) -
        Adding Axis2 facet.
      - [168937](https://bugs.eclipse.org/bugs/show_bug.cgi?id=168937) -
        Axis2 preference page.

**Proposed Items**

  -
**Deferred Items**

  -
### Server Runtime

**Committed Items**

  - HTTP Server support
  - Preview server
  - BEA server adapters moved to external update site

**Proposed Items**

  -
**Deferred Items**

  - JSR 88 Support, Advanced Server Support for one/multiple open source
    J2EE server

<!-- end list -->

  - Server runtime facet enhancements (link TBD)

## Dali JPA Tools

**Committed Items**

  - WTP (Facet) integration
  - DTP Integration
  - XML Mapping Descriptor editing support (JPA1.0 orm.xml)
  - Annotated Java and ORM XML context based defaulting
  - Enhanced validation
  - Table/Column annotation value code completion
  - DDL Generation extension
  - Entity Generation extension

**Proposed Items**

**Deferred Items**

  - Project Explorer contribution
  - ORM XML element/attribute value completion
  - Entity Generation enhancements
  - Multiple persistence unit support
  - Persistence.xml Editor

For more information see the [1.0 Milestone
Plan](Dali_1.0_planning "wikilink").

[Category:Eclipse Web Tools Platform
Project](Category:Eclipse_Web_Tools_Platform_Project "wikilink")