{{\#eclipseproject:technology.higgins|eclipse_custom_style.css}}

## Data Model

This section shows an example of a root context and an instance of a
WebsiteFacade:Participant context.

### Root context

` :RootContext`
`     skos:prefLabel "Root context"^^xsd:string .`

` :WebLogin_1`
`     rdf:type `<proxy:WebLogin>` ;`
`     `<proxy:connectionType>
`             "business"^^xsd:string ;`
`     `<proxy:externalResource>
`             "`<http://nytimes.com>`"^^xsd:anyURI ;`
`     `<proxy:image>` "2348fa0a9a8865556098"^^xsd:base64Binary ;`
`     `<proxy:imageType>` "PNG"^^xsd:string ;`
`     `<proxy:password>` "password1"^^xsd:string ;`
`     `<proxy:resource>` nytimes-participant:Person_1 ;`
`     `<proxy:userid>` "alice@gmail.com"^^xsd:string .`

` :me   rdf:type persona:Person ;`
`     h:correlation :WebLogin_1 .`

### Participant context

` <`<http://www.eclipse.org/higgins/ontologies/examples/nytimes-participant>`>`
`     rdf:type ctxt:Context , owl:Ontology ;`
`     ctxt:template <`<http://www.eclipse.org/higgins/ontologies/examples/nytimes-template-context>`> ;`
`     `<proxy:image>` "3241923401323412"^^xsd:base64Binary ;`
`     `<proxy:imageType>` "PNG"^^xsd:string ;`
`     owl:imports <`<http://www.eclipse.org/higgins/ontologies/examples/nytimes-template-context>`> ,`
`                 <`<http://www.eclipse.org/higgins/ontologies/2010/6/persona>`> ;`
`     owl:versionInfo "2.0.100"^^xsd:string .`

` :Name_1`
`     rdf:type v:Name ;`
`     v:family-name "Jones"^^xsd:string ;`
`     v:given-name "Alice"^^xsd:string .`

` :Participant_1`
`     rdf:type template:Participant .`

` :Person_1`
`     rdf:type persona:Person ;`
`     v:n     :Name_1 ;`
`     foaf:mbox <`[`mailto:alice@gmail.com`](mailto:alice@gmail.com)`> .`

### NYTimes ConnectionTemplate context

` <`<http://www.eclipse.org/higgins/ontologies/examples/nytimes-template-context>`>`
`     rdf:type template:ConnectionTemplate , owl:Ontology ;`
`     template:definer :Definer_1 ;`
`     template:participant`
`             :Participant_1 ;`
`     template:policy :DataPolicy_1 ;`
`     `<proxy:connectionType>
`             "business"^^xsd:string ;`
`     `<proxy:image>` "329849238457234523453454"^^xsd:base64Binary ;`
`     `<proxy:imageType>` "JPG"^^xsd:string ;`
`     owl:imports <`<http://www.eclipse.org/higgins/ontologies/2010/6/fp>`> ,`
`          <`<http://www.eclipse.org/higgins/ontologies/2010/6/template>`> ;`
`     skos:prefLabel "NYTimes ConnectionTemplate"^^xsd:string .`

` :DataPolicy_1`
`     rdf:type template:DataPolicy ;`
`     template:desires fpa:fashionAndStyle , fpa:worldLocalities ;`
`     template:provides <`<http://nytimes.com/schema/accountNumber>`> ;`
`     template:requires fp:email , fp:givenName , fp:familyName .`

` :Definer_1`
`     rdf:type template:Definer .`

` :JavaScript_1`
`     rdf:type app-data:JavaScript .`

` :Participant_1`
`     rdf:type template:WebsiteFacade ;`
`     template:homePage "`<http://nytimes.com>`"^^xsd:anyURI ;`
`     template:loginPath "/login"^^xsd:anyURI ;`
`     template:profilePath`
`             "/profile-page"^^xsd:anyURI ;`
`     template:role <`<http://www.eclipse.org/higgins/ontologies/2010/6/persona#Ecommerce>`> ;`
`     template:scrapeFill :JavaScript_1 .`

### Visually

All the contexts together visually:
![Nytimes-contexts.png](Nytimes-contexts.png "Nytimes-contexts.png")

All the person nodes together visually:
![Nytimes-persons.png](Nytimes-persons.png "Nytimes-persons.png")