Workspace 3.6 Development Plan draft. Some items listed below can end up
in [the official 3.6 component
plan](http://www.eclipse.org/eclipse/platform-team/team3.6/plan.php).

If you are not a member of the Platform Workspace Team and you want to
add your work to the plan, please follow the steps below.

1.  Raise a bug in the bugzilla describing the issue you want to solve
    (if not already raised).
2.  Update appropriate section with your bug. If no section matches your
    issue, add new section.
3.  Place your contact details (name, bugzilla id, email) next to the
    bug.
4.  Right after any visible traffic on the bug occurs, a Platform
    Workspace team member will update the plan.

'''Remember '''

1.  '''Adding an item to the plan is a strong commitment\! '''
2.  **The Platform Workspace team reserves the right to decide what is
    published on the dev plan page.**



## Content Type

  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")\[0.05\]
    \[Content Type\] ContentTypeMatcher does too much work  \<- plan
  - \[Content Type\] Support files without extensions
  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")\[0.05\]
    \[Content Type\] ContentTypeCatalog causes deadlock (regression from
    269158)  \<- plan
  - \[Content Type\] simpler implementation of
    XMLRootElementContentDescriber

## Builder Framework

  - More efficient and parallel builds
  - Build before launch takes 10s for a runtime workbench  **(Dani P2)**

## Flexible Resources

  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")\[0.75\]
    Merge e4 resources changes back into 3.x stream  \<- plan
  - \[1\] Support physical nesting of projects  \<- plan

## Other Resources

  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")\[Linked
    Resources\] If .project file edit fails, linked resource shows up
    anyway under certain conditions  \<- plan
  - IResource\#move(..) and \#delete(..) fail on locked files on the Mac
     **(Dani P2)**
  - Job\#isBlocking doesn't work for all cases (, reason is : Update and
    Replace operations should terminate blocking build job) **(Dani
    P3)**

## History and History View Improvements

  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")\[History\]
    Allow to never prune history  **(Dani P2)**
  - \[History\] Ability to pin a specific version in local history
  - \[History View\] CVS Resource History shows revisions from all
    branches
  - \[History\] History Store "max states" policy enforcement
  - \[History\] "Maximum entries per file" for the history is not
    respected
  - \[History\] History Store "oldest entry" policy enforcement could be
    smarter
  - \[History\] Local History should tell that too large file versions
    were skipped
  - \[History\] Set Maximum Size for a given workspace's local history

## Java Compare Improvements

  - [Bugs from JDT tagged with "compare" assigned to someone from
    \*pl.ibm.com (or
    CC'ed)](http://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=compare&classification=Eclipse&product=JDT&component=Text&component=UI&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=NEW&bug_status=ASSIGNED&bug_status=REOPENED&emailassigned_to1=1&emailcc1=1&emailtype1=substring&email1=pl.ibm.com&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=everconfirmed&type0-0-0=noop&value0-0-0=)
      - ![Image:Ok_green.gif](Ok_green.gif
        "Image:Ok_green.gif")\[compare\] auto-indent not working as
        expected
      - \[compare\] Support mark occurrences in Java compare editor
      - \[compare\] Java compare editor should enable Refactor and
        Source menu items
      - \[compare\] Open Declaration does not work in Java compare
        editor if target is not in visible segment
      - \[compare\] Refactor initiated in a CU editor cannot be
        continued in the Compare Editor
      - \[Compare\] CompilationUnitEditorAdapter creation flow should be
        more like a flow of a standalone editor
      - and more (check the query above)

## Compare Editor

  - \[Edit\] Enhanced text compare
  - Use views to present Structure Compare viewers
  - Outline view for the Compare Editor (showing changes with an option
    to switch to a structure viewer)
  - \[Sync View\] Migrate Compare with Each Other to the Synchronize
    view
  - \[Structure Viewers\] Reconcile structure upon document changes
  - \[Patch\] Generate diff from "Compare With"
  - Use MultiEditor as base class of CompareEditor, compose Compare
    Editor of editors not source viewers (even if they are retrieved
    from editors)
  - Consider removing resource listener for those viewers that are
    backed by a TextFileDocumentProvider
  - Deprecate ResourceCompareInput
  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")NPE on
    "Override and update"
  - Do not schedule diffs computation in the UI thread (don't use
    IProgressService), use IJobRunnable instead
  - Regressions introduced by SaveablesCompareEditorInput
  - Compare editor on local file: 'Open' action should set selection
    **(Dani P2)**

## Create and Apply Patch

  - Apply patch in Sync view
      - ![Image:Ok_green.gif](Ok_green.gif
        "Image:Ok_green.gif")\[Patch\]\[Sync View\] Use Synchronize View
        for Apply Patch
      - \[Apply Patch\] Compare current workspace against a patch  \<-
        use case **(Dani P2)**

<!-- end list -->

  - Improve applying patches with non-matching hunks:
      - \[Viewers\] Hunk compare editor should help the user when
        context lines don't match
          - \[Patch\] Indicate the offset used to match
          - \[Apply Patch\] Show initial insertion point for a hunk
          - \[Patch\] Indicate the offset used to match
          - \[Apply Patch\] Show which context lines has been applied
            with a fuzz factor
      - \[Patch\] Use PopupDialog to display patch/hunk content in the
        Apply Patch wizard

<!-- end list -->

  - Actions prior applying a patch:
      - \[Patch\] Apply patch forces me to save all files
      - \[Patch\] Select current project when creating a patch in
        workspace
      - \[Apply Patch\] Add option to filter out closed project when
        applying a patch
      - or add option to open a closed project (opening a project is a
        long-running op, will block applying patch for a while)

<!-- end list -->

  - Fuzz factor:
      - \[Apply Patch\] Wizard should warn about fuzz factor \>=
        available context lines count
      - \[Apply Patch\] Usability of the Fuzz Factor widget  -\> spinner
      - Apply Patch with Fuzz factor 100000 is long running

<!-- end list -->

  - Hunks navigation/selection:
      - Poor keybard nav in patch compare - remove need for double click

      - \[Apply Patch\] Preview should be possible by single clicking in
        Apply Patch Wizard
      - \[Patch\] Apply Patch -\> Verify Patch page could do with a
        Select/De-Select all button
      - Use CheckboxTreeViewer in Apply Patch wizard, use checkboxes to
        exclude/include hunk
      - \[Apply Patch\] Use faded font to identify excluded resources
        could be fixed by the bug above
      - \[Apply Patch\] Finish button should be disabled when all
        segments excluded

<!-- end list -->

  - Actions after applying a patch:
      - \[Patch\] Option to open affected files after applying patch
      - \[Change Sets\] Create change set on apply patch  **(Dani P3)**

<!-- end list -->

  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")\[0.05\]
    Apply patch from URL

## Merge Viewers Switching

  - \[Viewers\]\[Preferences\] Customize and persist the way
    \*MergeViewers are picked and used in compare
  - Selection issue when switching between Structure Merge Viewers
  - \[Viewers\] Disable merge viewer drop down menu when empty
  - Duplicated code in CompareUIPlugin

## Net

  - \[Net\] Add a facility to set a custom proxy provider
  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")\[Net\]
    Provide a way for clients to authenticate with NTLM scheme

## CVS Support Improvements

  - \[Sync View\] Regressions in model sync when compare to old style
    sync
      - \[Sync View\] Cannot change resource model layout during share
      - see other blockers
      - ![Image:Ok_green.gif](Ok_green.gif
        "Image:Ok_green.gif")\[0.05\] CVS Commit Files dialog should
        support Logical Model  \<- plan
      - \[0.05\] CVS Repository view support for Logical Model  \<- plan
      - \[SyncView\] Help should describe various models and what do
        they mean
  - \[0.05\] Enhanced global pattern capability  \<- plan
  - \[Change Sets\] Support drag'n'drop with items into outgoing change
    sets
  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")\[0.05\]
    Branch creation problem in CVS  \<- plan
  - CVS tag deletion
  - \[Merge\] CVS substituted keywords treated as conflicts
  - Support binary patches  **(Dani P2)**
  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")Create
    Patch should sort diffs by file path  **(Dani P2)**

## Team Framework Improvements

  - Share project with linked resources and EFS resources
  - \[0.05\] Import PSF from URL
  - Offer Team actions in compare editor  **(Dani P1)**
  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")\[Sync
    View\] "Link with Editor" for Synchronize view  **(Dani P1)**
  - ![Image:Ok_green.gif](Ok_green.gif "Image:Ok_green.gif")Enable
    'Apply Patch' on working sets  **(Dani P1)**
  - \[Change Sets\] Change sets should be persisted when they are
    changed  **(Dani P2)**

## Other

  - [Bugs with at least 2 votes,
    descending](http://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=Eclipse&product=Platform&component=Compare&component=CVS&component=Team&component=Resources&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=NEW&bug_status=ASSIGNED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=votes&type0-0-0=greaterthan&value0-0-0=1)
  - Compare results more like first-class workspace citizens
  - Provide more flexible way to compare files  and all blockers
  - \[compare\] 'Compare With' menu entries not intuitive
  - \[Sync View\] Add 'expand all' toolbar icon to the synchronize view
  - \[Change Sets\] compare with branch or version: wrong commit sets
    displayed
  - \[Viewers\] Provide a way to select type of changes
  - \[Theme\] Adopt the new menu/command framework