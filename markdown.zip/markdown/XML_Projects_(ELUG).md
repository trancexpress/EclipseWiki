![Image:Elug draft icon.png](Elug_draft_icon.png
"Image:Elug draft icon.png") '''For the latest EclipseLink
documentation, please see
<http://www.eclipse.org/eclipselink/documentation/> '''

-----

# Creating and Configuring XML Projects

The following sections contain general information about XML projects,
as well as detailed information on how to create and configure these
projects:

  - [Introduction to XML
    Projects](Introduction_to_XML_Projects_\(ELUG\) "wikilink")

<!-- end list -->

  - [Creating an XML
    Project](Creating_an_XML_Project_\(ELUG\) "wikilink")

<!-- end list -->

  - [Configuring an XML
    Project](Configuring_an_XML_Project_\(ELUG\) "wikilink")

**[Related
Topics](Special:Whatlinkshere/XML_Projects_\(ELUG\) "wikilink")**

-----

*[Copyright
Statement](EclipseLink_User's_Guide_Copyright_Statement "wikilink")*

[Category: EclipseLink User's
Guide](Category:_EclipseLink_User's_Guide "wikilink")