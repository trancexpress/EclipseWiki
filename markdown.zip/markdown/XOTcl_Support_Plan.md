## XOTcl Support Plan

(February 14th, 2007)

XOTcl support for [DLTK TCL IDE](DLTK_TCL "wikilink") will require some
features to be implemented in the DLTK Core Framework. Plan items
follow.

### DLTK Core Items

  - **Type hierarchies.** DLTK should provide implementation of Type
    hierarchy and Quick type hierarchy views.

<!-- end list -->

  - **Search Engine improvements.** DLTK Search engine should provide
    search support for: implementers, superclasses, constructors and
    read/write access of variables.

### DLTK TCL Items

  - **XOTcl-related UI.** TCL IDE should provide following UI features:
    wizards (New Class, New Method, etc).

<!-- end list -->

  - **Search Engine improvements.** TCL IDE should provide search for
    XOTcl classes, methods, and fields.

<!-- end list -->

  - **Debugging.** TCL debugger should provide support for XOTcl objects
    in TCL debugger.

<!-- end list -->

  - **Interactive Console.** Interactive TCL console should provide code
    assistance for XOTcl objects.

<!-- end list -->

  - **Content assistance.** TCL IDE should provide full content
    assistance support for XOTcl classes and objects.

<!-- end list -->

  - **Type hierarchies.** TCL IDE should extend core type hierarchies
    model to support XOTcl type hierarchies.

<!-- end list -->

  - **Documentation.** TCL IDE should provide documentation for XOTcl
    classes, methods, and fields.

<!-- end list -->

  - **XOTcl class browsing.** DLTK TCL should provide XOTcl browsing
    perspective with set of views displaying XOTcl OO elements.

## Milestones

This proposed items to be incorporated into [DLTK 0.95 Project
Plan](DLTK_0.95_Project_Plan "wikilink"). Each milestone is 6 weeks
long, *Milestone X* will be changed with actual Milestone number of
top-level plan.

### Milestone X+0

  - TCL Core improvements to support XOTcl.
      - XOTcl model builder
      - XOTcl indexing/search
      - XOTcl basic code selection (local module method, fields
        selection).
      - XOTcl build-in commands completion.
      - XOTcl UI Wizards (new class wizard, new method wizard, etc)
  - Initial Tcl debugging
      - Initial Tcl debugger implementation (interpreter-side, DBGp
        protocol implementation).
      - TCL IDE-side support for debugger (integration).

### Milestone X+1

  - XOTcl full featured code selection engine and type inferencing.
  - XOTcl advanced navigation.
      - Open type, proc, etc dialogs.
      - Goto super implementation.
  - XOTcl documentation support.
  - Full featured TCL debugger with console support.
      - Interactive TCL console: support for XOTcl objects.
      - Full DBGp protocol implementation, DBGp protocol extension to
        support console with content assistance in debug session.

### Milestone X+2

  - XOTcl code completion engine.
      - XOTcl method completion.
      - XOTcl variable completion.
  - XOTcl browsing perspective and views.
  - XOTcl type hierarchies. (Type hierarchy view, quick type hierarchy
    view).
  - XOTcl debugger and console support finalization.

[Category:DLTK](Category:DLTK "wikilink")