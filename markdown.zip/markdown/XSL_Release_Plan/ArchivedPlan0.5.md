## 0.5M9

**Goals:** Project Specific Validation, Bug Cleanup, and Stabilization

**Testing Week: August 4, 2008**

**0.5M9 Build Declared: August 11, 2008**

The current [iteration
plan](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&product=Web+Tools&component=incubator&target_milestone=0.5+M9&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=).
Any bug you target as being in 0.5M9 will show up in the plan list.

## 0.5M8

**Goals:** XPath Content Assistance improvement, Project Specific
Validation Preferences

**Testing Week: June 16, 2008**

**0.5M8 Build Declared: June 23, 2008**

The current [iteration
plan](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&product=Web+Tools&component=incubator&target_milestone=0.5+M8&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=).
Any bug you target as being in 0.5M8 will show up in the plan list.

## 0.5M7

**Goals:** Validation and Bug Fixes.

**Testing Week: April 28, 2008**

**0.5M7 Build Declared: May 7, 2008**

The current [iteration
plan](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&product=Web+Tools&component=incubator&target_milestone=0.5+M7&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=).
Any bug you target as being in 0.5M7 will show up in the plan list.

## 0.5M6

**Goals:** XInclude, Docbook, and XSL Content Assistance.

**Testing Week: March 31, 2008**

**0.5M6 Build Declared: April 7, 2008**

The current [iteration
plan](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&product=Web+Tools&component=incubator&target_milestone=0.5+M6&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=).
Any bug you target as being in 0.5M6 will show up in the plan list.

## 0.5M5

**Testing Week: February 10, 2008**

**0.5M5 Build Declared: February 17, 2008**

Please Review the [current
backlog](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=%5Bxslt%5D&classification=WebTools&product=Web+Tools&component=incubator&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&bug_status=NEW&bug_status=ASSIGNED&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=)
and add a target milestone of 0.5M5 to any items you plan to work on
during the next month.

The current [iteration
plan](https://bugs.eclipse.org/bugs/buglist.cgi?query_format=advanced&short_desc_type=allwordssubstr&short_desc=&classification=WebTools&product=Web+Tools&component=incubator&target_milestone=0.5+M5&long_desc_type=allwordssubstr&long_desc=&bug_file_loc_type=allwordssubstr&bug_file_loc=&status_whiteboard_type=allwordssubstr&status_whiteboard=&keywords_type=allwords&keywords=&emailtype1=substring&email1=&emailtype2=substring&email2=&bugidtype=include&bug_id=&votes=&chfieldfrom=&chfieldto=Now&chfieldvalue=&cmdtype=doit&order=Reuse+same+sort+as+last+time&field0-0-0=noop&type0-0-0=noop&value0-0-0=).
Any bug you target as being in 0.5M5 will show up in the plan list.

Please only select items that you feel you can complete. If there is a
feature listed in the requirements page, that doesn't have a bug please
create one for it as well. Anything that is planned to be worked on
should have a bug entered to track it's progress.

[XSL_Tools](Category:XSL_Tools "wikilink")